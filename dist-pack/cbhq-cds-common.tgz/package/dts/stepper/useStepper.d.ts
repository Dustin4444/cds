export type BaseStepperValue = {
  id: string;
  subSteps?: BaseStepperValue[];
};
export type StepperOptions<StepType extends BaseStepperValue = BaseStepperValue> = {
  /** The array of steps data. */
  steps: StepType[];
  /** The default active step ID. If not provided, the first step will be used. Pass null to indicate no active step initially. */
  defaultActiveStepId?: string | null;
  /** If true, steps containing sub-steps will never be made active.
   * This is useful if you want the parent step to treated only as a visual grouping of steps rather than a step itself.
   * @default false
   */
  skipParentSteps?: boolean;
};
export type StepperState = {
  /** React state for the currently active step ID. Can be null if no step is active. */
  activeStepId: string | null;
};
export type StepperApi = {
  /** Update the currently active step to the step with `stepId`. */
  goToStep: (stepId: string) => void;
  /** Update the currently active step to the next enabled step in the steps array. Does nothing if the last step is already active. */
  goNextStep: () => void;
  /** Update the currently active step to the previous enabled step in the steps array. Does nothing if the first step is already active. */
  goPreviousStep: () => void;
  /** Reset the active step to the original default active step. */
  reset: () => void;
};
/**
 * A hook for managing StepperHorizontal or StepperVertical state.
 * Both components can be used on their own, but this hook provides a convenient way to sync state changes to the component props.
 *
 * @param options - The options for the stepper.
 * @param options.steps - The array of steps data.
 * @param options.defaultActiveStepId - The default active step ID.
 * @param options.skipParentSteps - If true, steps containing sub-steps will never be made active.
 * @returns A tuple where the first element is the stepper state and the second element is an API for manipulating the stepper state.
 */
export declare const useStepper: <StepType extends BaseStepperValue = BaseStepperValue>({
  steps,
  defaultActiveStepId,
  skipParentSteps,
}: StepperOptions<StepType>) => [StepperState, StepperApi];
//# sourceMappingURL=useStepper.d.ts.map
