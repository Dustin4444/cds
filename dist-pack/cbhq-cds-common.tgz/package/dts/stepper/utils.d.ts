import type { BaseStepperValue } from './useStepper';
/**
 * Checks if a step or any of its descendants contains the target step ID
 */
export declare function containsStep({
  step,
  targetStepId,
}: {
  step: BaseStepperValue;
  targetStepId: string;
}): boolean;
/**
 * Flattens a tree of steps into a linear array in the order they appear when rendered
 */
export declare function flattenSteps<T extends BaseStepperValue>(steps: T[]): T[];
/**
 * Checks if a step should be considered "visited" based on step progression.
 * A step is visited if it comes before the active step in the flattened order.
 */
export declare function isStepVisited({
  step,
  activeStepId,
  flatStepIds,
}: {
  step: BaseStepperValue;
  activeStepId: string;
  flatStepIds: string[];
}): boolean;
//# sourceMappingURL=utils.d.ts.map
