/**
 * These are the core CDS Theme variable types used across mobile and web.
 */
/**
 * This utility type makes the final intellisense into human-readable literal values.
 */
type Prettify<T> = {
  [K in keyof T]: T[K];
} & {};
export type ColorScheme = 'dark' | 'light';
export type ColorSchemePreference = ColorScheme | 'system';
/**
 * This is the default set of Theme variables available to all CDS components.
 * Only the interface keys are used to define the available Theme variables.
 * The interface values are not used.
 * @danger You probably don't want to use this namespace directly, unless you are
 * referring explicitly to ONLY the default CDS variables. Otherwise, you probably
 * want to use the ThemeVars namespace instead, which inherits from this namespace.
 * @docs http://cds.coinbase.com/getting-started/theming/#themevars-namespace
 */
export declare namespace ThemeVarsDefault {
  interface SpectrumHue {
    blue: void;
    green: void;
    orange: void;
    yellow: void;
    gray: void;
    indigo: void;
    pink: void;
    purple: void;
    red: void;
    teal: void;
    chartreuse: void;
  }
  interface SpectrumHueStep {
    0: void;
    5: void;
    10: void;
    15: void;
    20: void;
    30: void;
    40: void;
    50: void;
    60: void;
    70: void;
    80: void;
    90: void;
    100: void;
  }
  interface Color {
    currentColor: void;
    fg: void;
    fgMuted: void;
    fgInverse: void;
    fgPrimary: void;
    fgWarning: void;
    fgPositive: void;
    fgNegative: void;
    bg: void;
    bgAlternate: void;
    bgInverse: void;
    bgOverlay: void;
    bgElevation1: void;
    bgElevation2: void;
    bgPrimary: void;
    bgPrimaryWash: void;
    bgSecondary: void;
    bgTertiary: void;
    bgSecondaryWash: void;
    bgNegative: void;
    bgNegativeWash: void;
    bgPositive: void;
    bgPositiveWash: void;
    bgWarning: void;
    bgWarningWash: void;
    bgLine: void;
    bgLineHeavy: void;
    bgLineInverse: void;
    bgLinePrimary: void;
    bgLinePrimarySubtle: void;
    accentSubtleRed: void;
    accentBoldRed: void;
    accentSubtleGreen: void;
    accentBoldGreen: void;
    accentSubtleBlue: void;
    accentBoldBlue: void;
    accentSubtlePurple: void;
    accentBoldPurple: void;
    accentSubtleYellow: void;
    accentBoldYellow: void;
    accentSubtleGray: void;
    accentBoldGray: void;
    transparent: void;
  }
  interface IllustrationColor {
    primary: void;
    black: void;
    white: void;
    gray: void;
    gray2: void;
    gray3: void;
    positive: void;
    negative: void;
    accent1: void;
    accent2: void;
    accent3: void;
    accent4: void;
    invert: void;
    invert2: void;
  }
  interface Space {
    0: void;
    0.25: void;
    0.5: void;
    0.75: void;
    1: void;
    1.5: void;
    2: void;
    3: void;
    4: void;
    5: void;
    6: void;
    7: void;
    8: void;
    9: void;
    10: void;
  }
  interface IconSize {
    xs: void;
    s: void;
    m: void;
    l: void;
  }
  interface AvatarSize {
    s: void;
    m: void;
    l: void;
    xl: void;
    xxl: void;
    xxxl: void;
  }
  interface BorderWidth {
    0: void;
    100: void;
    200: void;
    300: void;
    400: void;
    500: void;
  }
  interface BorderRadius {
    0: void;
    100: void;
    200: void;
    300: void;
    400: void;
    500: void;
    600: void;
    700: void;
    800: void;
    900: void;
    1000: void;
  }
  interface Font {
    display1: void;
    display2: void;
    display3: void;
    title1: void;
    title2: void;
    title3: void;
    title4: void;
    headline: void;
    body: void;
    label1: void;
    label2: void;
    caption: void;
    legal: void;
  }
  interface FontFamily extends Font {}
  interface FontSize extends Font {}
  interface FontWeight extends Font {}
  interface LineHeight extends Font {}
  interface TextTransform extends Font {}
  interface Shadow {
    elevation1: void;
    elevation2: void;
  }
  interface ControlSize {
    checkboxSize: void;
    radioSize: void;
    switchWidth: void;
    switchHeight: void;
    switchThumbSize: void;
    tileSize: void;
  }
  interface Elevation {
    0: void;
    1: void;
    2: void;
  }
}
declare module '@cbhq/cds-common/core/theme' {
  /**
   * Override interfaces in this namespace to add new variables to the ThemeVars
   * namespace, making their types available to all CDS components. Only the
   * interface keys are used to define the available Theme variables. The
   * interface values are not used.
   * @danger Only use this namespace for overriding. Once overridden, you should
   * prefer to read from the ThemeVars namespace instead, which inherits from this
   * namespace.
   * @docs http://cds.coinbase.com/getting-started/theming/#extending-the-theme
   */
  namespace ThemeVarsExtended {
    interface SpectrumHue {}
    interface SpectrumHueStep {}
    interface Color {}
    interface IllustrationColor {}
    interface Space {}
    interface IconSize {}
    interface AvatarSize {}
    interface BorderWidth {}
    interface BorderRadius {}
    interface Font {}
    interface FontFamily {}
    interface FontSize {}
    interface FontWeight {}
    interface LineHeight {}
    interface TextTransform {}
    interface Shadow {}
    interface ControlSize {}
    interface Elevation {}
  }
}
/**
 * This is the complete set of Theme variables available to all CDS components.
 * Combines all variables from the ThemeVarsDefault and ThemeVarsExtended
 * namespaces. You can use this namespace to read all available Theme variables.
 * You can use the ThemeVarsExtended namespace to extend this namespace with new
 * variables.
 * @docs http://cds.coinbase.com/getting-started/theming/#themevars-namespace
 */
export declare namespace ThemeVars {
  type SpectrumHue = Prettify<
    keyof ThemeVarsDefault.SpectrumHue | keyof ThemeVarsExtended.SpectrumHue
  >;
  type SpectrumHueStep = Prettify<
    keyof ThemeVarsDefault.SpectrumHueStep | keyof ThemeVarsExtended.SpectrumHueStep
  >;
  type SpectrumColor = `${SpectrumHue}${SpectrumHueStep}`;
  type Color = Prettify<keyof ThemeVarsDefault.Color | keyof ThemeVarsExtended.Color>;
  type IllustrationColor = Prettify<
    keyof ThemeVarsDefault.IllustrationColor | keyof ThemeVarsExtended.IllustrationColor
  >;
  type Space = Prettify<keyof ThemeVarsDefault.Space | keyof ThemeVarsExtended.Space>;
  type IconSize = Prettify<keyof ThemeVarsDefault.IconSize | keyof ThemeVarsExtended.IconSize>;
  type AvatarSize = Prettify<
    keyof ThemeVarsDefault.AvatarSize | keyof ThemeVarsExtended.AvatarSize
  >;
  type BorderWidth = Prettify<
    keyof ThemeVarsDefault.BorderWidth | keyof ThemeVarsExtended.BorderWidth
  >;
  type BorderRadius = Prettify<
    keyof ThemeVarsDefault.BorderRadius | keyof ThemeVarsExtended.BorderRadius
  >;
  type Font = Prettify<keyof ThemeVarsDefault.Font | keyof ThemeVarsExtended.Font>;
  type FontFamily = Prettify<
    keyof ThemeVarsDefault.FontFamily | keyof ThemeVarsExtended.FontFamily
  >;
  type FontSize = Prettify<keyof ThemeVarsDefault.FontSize | keyof ThemeVarsExtended.FontSize>;
  type FontWeight = Prettify<
    keyof ThemeVarsDefault.FontWeight | keyof ThemeVarsExtended.FontWeight
  >;
  type LineHeight = Prettify<
    keyof ThemeVarsDefault.LineHeight | keyof ThemeVarsExtended.LineHeight
  >;
  type TextTransform = Prettify<
    keyof ThemeVarsDefault.TextTransform | keyof ThemeVarsExtended.TextTransform
  >;
  type Shadow = Prettify<keyof ThemeVarsDefault.Shadow | keyof ThemeVarsExtended.Shadow>;
  type ControlSize = Prettify<
    keyof ThemeVarsDefault.ControlSize | keyof ThemeVarsExtended.ControlSize
  >;
  type Elevation = Prettify<keyof ThemeVarsDefault.Elevation | keyof ThemeVarsExtended.Elevation>;
}
export {};
//# sourceMappingURL=theme.d.ts.map
