import type { ThemeVars } from '../core/theme';
import type { TagColorScheme, TagEmphasis, TagIntent } from '../types/TagBaseProps';
export declare const tagEmphasisMap: Record<TagEmphasis, TagIntent>;
export declare const tagHorizontalSpacing: Record<TagIntent, ThemeVars.Space>;
export declare const tagFontMap: Record<TagIntent, ThemeVars.FontFamily>;
export declare const tagBorderRadiusMap: Record<TagIntent, ThemeVars.BorderRadius>;
type TagEmphasisColorMap = Record<
  TagEmphasis,
  Record<
    TagColorScheme,
    {
      background: ThemeVars.SpectrumColor;
      foreground: ThemeVars.SpectrumColor;
    }
  >
>;
export declare const tagEmphasisColorMap: TagEmphasisColorMap;
type TagColorMap = Record<
  TagIntent,
  Record<
    TagColorScheme,
    {
      background: ThemeVars.SpectrumColor;
      foreground: ThemeVars.SpectrumColor;
    }
  >
>;
/**
 * @deprecated Use tagEmphasisColorMap instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const tagColorMap: TagColorMap;
export {};
//# sourceMappingURL=tags.d.ts.map
