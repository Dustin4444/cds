export declare const defaultDuration = 5000;
export declare const withActionDuration = 2000;
export declare const perCharsDuration = 300;
export declare const charsThreshold = 50;
//# sourceMappingURL=toast.d.ts.map
