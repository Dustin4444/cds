export declare const cardSizes: {
  readonly small: {
    readonly width: 136;
    readonly height: 144;
  };
  readonly medium: {
    readonly width: 312;
    readonly height: 192;
  };
  readonly large: {
    readonly width: undefined;
    readonly height: undefined;
  };
};
export declare const defaultMediaDimension = '96x96';
export declare const defaultPictogramMediaDimension = '64x64';
export declare const defaultMediaSize: import('../utils/convertDimensionToSize').SizeObject;
export declare const defaultSpacingBottom = 2;
export declare const upsellCardMinHeight = 158;
export declare const upsellCardDefaultWidth = 327;
export declare const containedAssetCardLargeWidth = 359;
export declare const containedAssetCardSmallDimension = 156;
export declare const containedAssetCardLargeDimension = 327;
export declare const floatingAssetCardLargeWidth = 359;
export declare const floatingAssetCardSmallDimension = 156;
export declare const defaultNudgeCardWidth = 327;
export declare const contentCardMinWidth = 280;
export declare const contentCardMaxWidth = 800;
//# sourceMappingURL=card.d.ts.map
