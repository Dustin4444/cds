export declare const appSwitcherWidth = 359;
export declare const denseAppSwitcherWidth = 324;
export declare const appSwitcherMaxSize = 600;
//# sourceMappingURL=appSwitcher.d.ts.map
