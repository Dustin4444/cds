export declare const colorSchemeMap: {
  readonly blue: 'blue60';
  readonly teal: 'teal60';
  readonly purple: 'purple60';
  readonly pink: 'pink60';
  readonly green: 'green60';
  readonly gray: 'gray60';
  readonly orange: 'orange60';
  readonly yellow: 'yellow60';
  readonly indigo: 'indigo60';
  readonly red: 'red60';
  readonly chartreuse: 'chartreuse60';
};
//# sourceMappingURL=avatar.d.ts.map
