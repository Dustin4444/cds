export declare const FOCUSABLE_ELEMENTS =
  'a[href], button:not([disabled]), textarea, input, select, [contenteditable]:not([contenteditable="false"])';
//# sourceMappingURL=overlays.d.ts.map
