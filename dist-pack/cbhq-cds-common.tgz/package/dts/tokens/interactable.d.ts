export declare const opacityHovered = 0.88;
export declare const opacityPressed = 0.82;
export declare const accessibleOpacityDisabled = 0.5;
export declare const opacityDisabled = 0.75;
//# sourceMappingURL=interactable.d.ts.map
