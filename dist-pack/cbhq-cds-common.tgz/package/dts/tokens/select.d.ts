import type { CellSpacingConfig, InputVariant } from '../types';
export declare const labelTextColor: InputVariant;
/** Spacing config for Select Option (web) */
export declare const selectCellSpacingConfig: CellSpacingConfig;
/** Spacing config for Select Option (mobile) */
export declare const selectCellMobileSpacingConfig: CellSpacingConfig;
//# sourceMappingURL=select.d.ts.map
