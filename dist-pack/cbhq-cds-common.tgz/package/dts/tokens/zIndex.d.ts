export declare const zIndex: {
  readonly interactable: 1;
  readonly navigation: 2;
  readonly portal: 100001;
  readonly popoverMenu: 2;
  readonly modal: 3;
  readonly dropdown: 4;
  readonly tooltip: 5;
  readonly toast: 6;
  readonly alert: 7;
  readonly tray: 4;
  readonly max: 2147483647;
};
//# sourceMappingURL=zIndex.d.ts.map
