export declare const gutter = 3;
export declare const tapTarget = 40;
//# sourceMappingURL=sizing.d.ts.map
