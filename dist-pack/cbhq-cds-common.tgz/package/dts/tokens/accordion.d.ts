export declare const accordionSpacing: {
  readonly paddingTop: 2;
  readonly paddingX: 3;
  readonly paddingBottom: 3;
};
export declare const accordionMinWidth = 300;
//# sourceMappingURL=accordion.d.ts.map
