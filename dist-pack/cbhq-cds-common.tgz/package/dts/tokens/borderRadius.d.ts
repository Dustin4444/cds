import type { Shape } from '../types/Shape';
export declare const shapeBorderRadius: Record<Shape, number>;
//# sourceMappingURL=borderRadius.d.ts.map
