export declare const pictogramSize = 48;
export declare const pictogramWrapperSize = 62;
export declare const pictogramScaleMultiplier = 0.8;
//# sourceMappingURL=tile.d.ts.map
