export declare const pageHeaderHeight = 72;
export declare const pageFooterHeight = 80;
//# sourceMappingURL=page.d.ts.map
