export declare const sidebarMenuMinWidth = 240;
export declare const sidebarMenuMaxWidth = 327;
//# sourceMappingURL=menu.d.ts.map
