import type { DotSize } from '../types';
import type { AvatarSize } from '../types/AvatarSize';
export declare const avatarIconSizeMap: Record<AvatarSize, DotSize>;
export declare const avatarDotSizeMap: Record<AvatarSize, DotSize>;
/**
 * The fixed height of the DotCount component.
 * Width grows based on content length.
 **/
export declare const dotCountSize = 24;
/**
 * @deprecated Use local sizing logic instead. This export is temporarily supported for
 * compatibility. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const dotSizeTokens: {
    readonly s: 28;
    readonly m: 36;
    readonly l: 48;
};
/**
 * @deprecated Use local sizing logic instead. This export is temporarily supported for
 * compatibility. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const getDotSize: (count?: number) => 48 | 28 | 36;
//# sourceMappingURL=dot.d.ts.map