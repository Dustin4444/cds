export declare const sidebarGutter = 1;
export declare const sidebarHorizontalSpacing = 2;
//# sourceMappingURL=sidebar.d.ts.map
