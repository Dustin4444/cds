export declare const navigationBarMinHeight = 80;
//# sourceMappingURL=navigation.d.ts.map
