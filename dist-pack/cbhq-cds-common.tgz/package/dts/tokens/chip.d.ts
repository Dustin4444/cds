export declare const chipMaxWidth = 200;
//# sourceMappingURL=chip.d.ts.map
