import type { ThemeVars } from '../core/theme';
import type { BannerVariant } from '../types/BannerBaseProps';
export type BannerVariantStyle = {
  background: ThemeVars.Color | undefined;
  iconColor: ThemeVars.Color;
  textColor: ThemeVars.Color;
  primaryActionColor: ThemeVars.Color;
  secondaryActionColor: ThemeVars.Color;
  iconButtonColor: ThemeVars.Color;
  borderColor: ThemeVars.Color;
};
export type BannerVariantConfig = Record<BannerVariant, BannerVariantStyle>;
export declare const variants: BannerVariantConfig;
export declare const bannerMinWidth = 320;
//# sourceMappingURL=banner.d.ts.map
