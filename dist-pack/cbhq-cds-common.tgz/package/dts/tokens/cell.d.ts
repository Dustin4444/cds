import type { IconName, ThemeVars } from '..';
export declare const mediaSize = 32;
export declare const imageSize = 48;
export declare const pictogramScaleMultiplier = 1;
/**
 * @deprecated This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 * */
export declare const listHeight = 80;
/**
 * @deprecated This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 * */
export declare const compactListHeight = 40;
/** Spacing configs for Cells to be parsed in [web/mobile]/hooks/useCellSpacing */
/** Default spacing config */
export declare const defaultSpacingConfig: {
    readonly innerSpacing: {
        readonly paddingX: 2;
        readonly paddingY: 1;
        readonly marginX: -2;
    };
    readonly outerSpacing: {
        readonly paddingX: 3;
        readonly paddingY: 1;
        readonly marginX: 0;
    };
};
/**
 * @deprecated Used by deprecated Select component. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const selectOptionHeight = 56;
export declare const cellPriorities: readonly ["start", "middle", "end"];
export declare const cellHelperTextVariants: Record<'information' | 'warning' | 'error', {
    iconName: IconName;
    color: ThemeVars.Color;
}>;
//# sourceMappingURL=cell.d.ts.map