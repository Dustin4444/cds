export declare const interactableHeight: {
  regular: number;
  compact: number;
};
//# sourceMappingURL=interactableHeight.d.ts.map
