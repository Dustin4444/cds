export declare const tooltipMaxWidth = 260;
export declare const tooltipPaddingX = 2;
export declare const tooltipPaddingY = 1;
//# sourceMappingURL=tooltip.d.ts.map
