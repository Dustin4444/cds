import type { SparklineInteractiveHeaderSignVariant } from '../types';
export declare const chartHeight = 320;
export declare const chartCompactHeight = 120;
export declare const maskOpacity = 0.8;
export declare const lineOpacity = 0.4;
export declare const lineDashArray: number[];
export declare const fadeDuration: 200;
export declare const periodLabelMap: Record<string, string>;
export declare const subheadIconSignMap: Record<SparklineInteractiveHeaderSignVariant, string>;
export declare const borderWidth = 2;
//# sourceMappingURL=sparkline.d.ts.map
