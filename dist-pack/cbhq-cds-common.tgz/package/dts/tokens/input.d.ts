/** Focused/Unfocused Styling */
export declare const inputBorderWidth = 1;
export declare const focusedInputBorderWidth = 2;
export declare const inputStackGap = 0.5;
export declare const helperTextHeight = 20;
//# sourceMappingURL=input.d.ts.map
