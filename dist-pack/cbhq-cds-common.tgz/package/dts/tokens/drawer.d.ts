/** Max percentage of View height the drawer can take up */
export declare const verticalDrawerPercentageOfView = 0.75;
/** Max percentage of View width the drawer can take up */
export declare const horizontalDrawerPercentageOfView = 0.85;
/** The maximum percentage of the View height that the Drawer can take up before being considered large */
export declare const drawerHeightThreshold = 0.4;
/** HandleBar offset from Tray/Bottom Drawer */
export declare const handleBarOffset = 60;
export declare const handleBarHeight = 4;
/** Based on trial and error this seems to normalize the relationship between pan gesture distance and drawer translation */
export declare const normalizeDrawerPanDistanceMultiplier = 1.1;
//# sourceMappingURL=drawer.d.ts.map
