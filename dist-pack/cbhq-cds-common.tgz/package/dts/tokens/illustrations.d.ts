export declare const illustrationDimensions: {
  readonly heroSquare: readonly ['240x240', '200x200'];
  readonly spotRectangle: readonly ['240x120'];
  readonly spotSquare: readonly ['96x96'];
  readonly spotIcon: readonly ['32x32', '24x24'];
  readonly pictogram: readonly ['48x48', '64x64'];
};
export declare const illustrationDimensionDefaults: {
  readonly all: '48x48';
  readonly heroSquare: '240x240';
  readonly pictogram: '48x48';
  readonly spotSquare: '96x96';
  readonly spotIcon: '32x32';
  readonly spotRectangle: '240x120';
};
/** [width, height] tuples for allowed dimensions */
export declare const illustrationSizes: {
  readonly '24x24': readonly [24, 24];
  readonly '32x32': readonly [32, 32];
  readonly '48x48': readonly [48, 48];
  readonly '64x64': readonly [64, 64];
  readonly '96x96': readonly [96, 96];
  readonly '120x120': readonly [120, 120];
  readonly '200x200': readonly [200, 200];
  readonly '240x120': readonly [240, 120];
  readonly '240x240': readonly [240, 240];
};
//# sourceMappingURL=illustrations.d.ts.map
