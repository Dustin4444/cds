export declare const variants: {
    readonly primary: {
        readonly color: "fgInverse";
        readonly background: "bgPrimary";
        readonly borderColor: "bgPrimary";
    };
    readonly secondary: {
        readonly color: "fg";
        readonly background: "bgSecondary";
        readonly borderColor: "bgSecondary";
    };
    readonly tertiary: {
        readonly color: "fg";
        readonly background: "bgTertiary";
        readonly borderColor: "bgTertiary";
    };
    readonly foregroundMuted: {
        readonly color: "fgMuted";
        readonly background: "bgSecondary";
        readonly borderColor: "bgLine";
    };
    readonly positive: {
        readonly color: "fgInverse";
        readonly background: "bgPositive";
        readonly borderColor: "bgPositive";
    };
    readonly negative: {
        readonly color: "fgInverse";
        readonly background: "bgNegative";
        readonly borderColor: "bgNegative";
    };
    readonly inverse: {
        readonly color: "fgInverse";
        readonly background: "bgInverse";
        readonly borderColor: "bgInverse";
    };
};
export declare const transparentVariants: {
    readonly primary: {
        readonly color: "fgPrimary";
        readonly background: "bg";
        readonly borderColor: "transparent";
    };
    readonly secondary: {
        readonly color: "fg";
        readonly background: "bg";
        readonly borderColor: "transparent";
    };
    readonly tertiary: {
        readonly color: "fg";
        readonly background: "bg";
        readonly borderColor: "transparent";
    };
    readonly foregroundMuted: {
        readonly color: "fgMuted";
        readonly background: "bg";
        readonly borderColor: "transparent";
    };
    readonly positive: {
        readonly color: "fgPositive";
        readonly background: "bg";
        readonly borderColor: "transparent";
    };
    readonly negative: {
        readonly color: "fgNegative";
        readonly background: "bg";
        readonly borderColor: "transparent";
    };
    readonly inverse: {
        readonly color: "fg";
        readonly background: "bg";
        readonly borderColor: "transparent";
    };
};
//# sourceMappingURL=button.d.ts.map