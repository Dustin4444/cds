export declare const defaultMaxWidth = 450;
//# sourceMappingURL=multiContentModule.d.ts.map
