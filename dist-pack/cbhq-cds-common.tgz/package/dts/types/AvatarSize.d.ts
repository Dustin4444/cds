export type AvatarSize = 's' | 'm' | 'l' | 'xl' | 'xxl' | 'xxxl';
//# sourceMappingURL=AvatarSize.d.ts.map
