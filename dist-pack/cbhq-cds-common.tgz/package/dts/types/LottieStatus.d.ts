export type LottieStatus = 'loading' | 'success' | 'cardSuccess' | 'failure' | 'pending';
//# sourceMappingURL=LottieStatus.d.ts.map
