import type { IconName } from '@cbhq/cds-icons';
export type { IconName };
//# sourceMappingURL=IconName.d.ts.map
