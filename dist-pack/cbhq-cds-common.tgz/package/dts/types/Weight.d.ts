export type Weight = 'thin' | 'normal' | 'semiheavy' | 'heavy';
//# sourceMappingURL=Weight.d.ts.map
