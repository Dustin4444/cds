export type Visibility = 'hidden' | 'visible';
export type VisibilityProps = {
  visibility: 'hidden' | 'visible';
};
//# sourceMappingURL=Visibility.d.ts.map
