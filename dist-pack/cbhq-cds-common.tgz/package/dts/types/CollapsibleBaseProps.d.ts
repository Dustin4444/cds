export type CollapsibleDirection = 'vertical' | 'horizontal';
//# sourceMappingURL=CollapsibleBaseProps.d.ts.map
