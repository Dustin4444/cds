export type SparklineInteractiveHeaderVariant = 'foregroundMuted' | 'positive' | 'negative';
export type SparklineInteractiveHeaderSignVariant =
  | 'positive'
  | 'negative'
  | 'upwardTrend'
  | 'downwardTrend'
  | '';
//# sourceMappingURL=SparklineInteractiveHeaderBaseProps.d.ts.map
