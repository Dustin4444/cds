import type { EventHandlerCustomConfig } from '../system/EventHandlerProvider';
export type ComponentEventHandlerProps = {
  eventConfig?: EventHandlerCustomConfig;
  analyticsId?: string;
};
//# sourceMappingURL=ComponentEventHandlerProps.d.ts.map
