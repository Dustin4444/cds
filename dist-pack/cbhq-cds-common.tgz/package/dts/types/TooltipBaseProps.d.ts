export type BaseTooltipPlacement = 'top' | 'bottom' | 'right' | 'left';
//# sourceMappingURL=TooltipBaseProps.d.ts.map
