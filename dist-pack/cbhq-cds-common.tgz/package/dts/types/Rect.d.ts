export type Rect = {
  x: number;
  y: number;
  width: number;
  height: number;
};
export declare const defaultRect: Rect;
//# sourceMappingURL=Rect.d.ts.map
