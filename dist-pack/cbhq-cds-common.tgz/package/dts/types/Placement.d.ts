export type Placement = 'above' | 'below' | 'beside' | 'start' | 'end';
export type PinPlacement = 'top-start' | 'top-end' | 'bottom-start' | 'bottom-end';
//# sourceMappingURL=Placement.d.ts.map
