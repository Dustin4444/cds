export type Display =
  | 'block'
  | 'inline-block'
  | 'flex'
  | 'inline-flex'
  | 'none'
  | 'contents'
  | 'grid';
//# sourceMappingURL=Display.d.ts.map
