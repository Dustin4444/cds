import type { ButtonVariant } from './ButtonBaseProps';
export type IconButtonVariant = ButtonVariant;
//# sourceMappingURL=IconButtonBaseProps.d.ts.map
