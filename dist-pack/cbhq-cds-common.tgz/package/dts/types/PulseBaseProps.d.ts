export type PulseVariant = 'moderate' | 'subtle' | 'heavy';
//# sourceMappingURL=PulseBaseProps.d.ts.map
