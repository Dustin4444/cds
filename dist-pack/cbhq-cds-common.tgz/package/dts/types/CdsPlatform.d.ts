export type CdsPlatform = 'mobile' | 'web';
//# sourceMappingURL=CdsPlatform.d.ts.map
