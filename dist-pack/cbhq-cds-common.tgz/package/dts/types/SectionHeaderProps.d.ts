import type { IconName } from '@cbhq/cds-icons';
import type { SharedAccessibilityProps } from './SharedAccessibilityProps';
import type { SharedProps } from './SharedProps';
import type { PaddingProps } from './SpacingProps';
export type SectionHeaderProps = {
  /** Text or ReactNode to be displayed in Title */
  title: React.ReactNode;
  start?: React.ReactNode;
  icon?: Exclude<React.ReactNode, 'string'> | IconName;
  /** Whether the icon is active */
  iconActive?: boolean;
  /** ReactNode or UiIconName to present balances wherever it is necessary */
  balance?: React.ReactNode;
  /** ReactNode to display up to 2 lines of copy that frames the section's purpose and relevance */
  description?: React.ReactNode;
  end?: React.ReactNode;
} & SharedProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabel'> &
  PaddingProps;
//# sourceMappingURL=SectionHeaderProps.d.ts.map
