export type IconSize = 'xs' | 's' | 'm' | 'l';
export type IconSourcePixelSize = 12 | 16 | 24;
//# sourceMappingURL=IconSize.d.ts.map
