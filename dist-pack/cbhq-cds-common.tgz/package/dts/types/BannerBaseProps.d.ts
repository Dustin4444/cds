export type BannerVariant = 'warning' | 'promotional' | 'informational' | 'error';
export type BannerStyleVariant = 'inline' | 'global' | 'contextual';
//# sourceMappingURL=BannerBaseProps.d.ts.map
