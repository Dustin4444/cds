import type { ThemeVars } from '../core/theme';
export type PaletteValue = ThemeVars.SpectrumColor | [ThemeVars.SpectrumColor, number];
export type PaletteValueTuple = [ThemeVars.SpectrumColor, number];
export type UsePaletteFn = () => Record<ThemeVars.Color, string>;
//# sourceMappingURL=Palette.d.ts.map
