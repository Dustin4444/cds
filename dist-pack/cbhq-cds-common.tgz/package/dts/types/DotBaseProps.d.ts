import type { IconSize } from './IconSize';
export type DotVariant = 'positive' | 'negative' | 'primary' | 'foregroundMuted' | 'warning';
export type DotOverlap = 'circular';
export type DotSize = IconSize;
//# sourceMappingURL=DotBaseProps.d.ts.map
