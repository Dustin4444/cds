import type { ThemeVars } from '@cbhq/cds-common/core/theme';
type GetMediaChipSpacingPropsParams = {
  start?: boolean;
  end?: boolean;
  children?: boolean;
  compact?: boolean;
};
export declare const getMediaChipSpacingProps: ({
  compact,
  start,
  end,
  children,
}: GetMediaChipSpacingPropsParams) => {
  paddingX?: ThemeVars.Space;
  paddingY?: ThemeVars.Space;
  padding?: ThemeVars.Space;
  paddingStart?: ThemeVars.Space;
  paddingEnd?: ThemeVars.Space;
  paddingTop?: ThemeVars.Space;
  paddingBottom?: ThemeVars.Space;
  gap?: ThemeVars.Space;
};
export {};
//# sourceMappingURL=getMediaChipSpacingProps.d.ts.map
