export type TabValue<TabId extends string = string> = {
    /** The tab id. */
    id: TabId;
    /** The tab label. */
    label?: React.ReactNode;
    /** Disable interactions on the tab. */
    disabled?: boolean;
};
export type TabsOptions<TabId extends string = string> = {
    /** The array of tabs data. */
    tabs: TabValue<TabId>[];
    /** React state for the currently active tab. Setting it to `null` results in no active tab. */
    activeTab: TabValue<TabId> | null;
    /** Callback that is fired when the active tab changes. Use this callback to update the `activeTab` state. */
    onChange: (activeTab: TabValue<TabId> | null) => void;
    /** Disable interactions on all the tabs. */
    disabled?: boolean;
};
export type TabsApi<TabId extends string = string> = Omit<TabsOptions<TabId>, 'onChange'> & {
    /** Update the currently active tab to the tab with `tabId`. */
    updateActiveTab: (tabId: TabId | null) => void;
    /** Update the currently active tab to the next enabled tab in the tabs array. Does nothing if the last tab is already active. */
    goNextTab: () => void;
    /** Update the currently active tab to the previous enabled tab in the tabs array. Does nothing if the first tab is already active. */
    goPreviousTab: () => void;
};
/** A controlled hook for managing tabs state, such as the currently active tab. */
export declare const useTabs: <TabId extends string>({ tabs, activeTab, disabled, onChange, }: TabsOptions<TabId>) => TabsApi<TabId>;
//# sourceMappingURL=useTabs.d.ts.map