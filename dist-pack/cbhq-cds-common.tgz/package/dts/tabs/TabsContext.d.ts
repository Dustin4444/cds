import { type TabsApi } from './useTabs';
export type TabsContextValue<TabId extends string = string> = TabsApi<TabId>;
export declare const TabsContext: import("react").Context<TabsContextValue<string> | undefined>;
export declare const useTabsContext: <TabId extends string>() => TabsContextValue<TabId>;
//# sourceMappingURL=TabsContext.d.ts.map