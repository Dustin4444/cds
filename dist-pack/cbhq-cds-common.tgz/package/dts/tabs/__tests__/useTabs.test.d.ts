export {};
//# sourceMappingURL=useTabs.test.d.ts.map
