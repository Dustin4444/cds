export {};
//# sourceMappingURL=TabsContext.test.d.ts.map
