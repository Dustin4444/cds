/**
 * Options for configuring the useMultiSelect hook
 */
export type MultiSelectOptions<SelectValue extends string = string> = {
  /** Initial array of selected values */
  initialValue: SelectValue[] | null;
};
/**
 * API returned by the useMultiSelect hook for managing multi-select state
 */
export type MultiSelectApi<SelectValue extends string = string> = {
  /** Current array of selected values */
  value: SelectValue[];
  /** Handler for toggling selection of one or more values.
   * When a single value is passed, it will be added to the selection if it is not already selected.
   * If the value is already selected, it will be removed from the selection.
   * When an array of values is passed, all values will be added to the selection.
   * When null is passed, all values will be removed from the selection.
   */
  onChange: (value: string | string[] | null) => void;
  /** Add one or more values to the selection */
  addSelection: (value: string | string[]) => void;
  /** Remove one or more values from the selection */
  removeSelection: (value: string | string[]) => void;
  /** Clear all selected values */
  resetSelection: () => void;
};
/**
 * Hook for managing multi-select state with convenient API methods
 * @param options - Configuration options including initial value
 * @returns API object for managing multi-select state
 */
export declare const useMultiSelect: <SelectValue extends string = string>({
  initialValue,
}: MultiSelectOptions<SelectValue>) => MultiSelectApi<SelectValue>;
//# sourceMappingURL=useMultiSelect.d.ts.map
