export {};
//# sourceMappingURL=useMultiSelect.test.d.ts.map
