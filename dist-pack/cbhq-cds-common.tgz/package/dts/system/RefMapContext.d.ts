import type React from 'react';
import { type RefMapApi } from '../hooks/useRefMap';
export type RefMapContextValue<RefValue> = RefMapApi<RefValue>;
export type RefMapProviderProps<RefValue> = {
  api: RefMapContextValue<RefValue>;
  children?: React.ReactNode;
};
export declare const RefMapContext: React.Context<RefMapContextValue<any>>;
export declare const useRefMapContext: <T>() => RefMapContextValue<T>;
//# sourceMappingURL=RefMapContext.d.ts.map
