export {};
//# sourceMappingURL=EventHandlerProvider.test.d.ts.map
