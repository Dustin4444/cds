import React from 'react';
type RecursiveMapType<T> = T | Record<string, T>;
export type EventDataEntryTypes = string | number | boolean | null | undefined;
export type EventDataEntry = EventDataEntryTypes | EventDataEntryTypes[];
export type EventHandlerAction = string;
export type EventCustomData = Record<string, RecursiveMapType<EventDataEntry>>;
export type EventHandlerComponent = 'Button';
export type EventCallbackProps = {
  componentName?: string;
  analyticsId?: string;
  data?: EventCustomData;
};
export type EventHandlerCallback = (eventData: EventCallbackProps) => void;
export type EventHandlerEntry = Record<string, EventHandlerCallback>;
export type EventHandlerConfig = {
  actionMapping?: Record<string, string>;
  handlers?: Record<EventHandlerComponent, EventHandlerEntry>;
};
export type EventHandlerCustomConfig = {
  actions: EventHandlerAction[];
  componentName: string;
  data?: EventCustomData;
};
export declare const DEFAULT_EVENT_HANDLER_CONTEXT: EventHandlerConfig;
export declare const EventHandlerContext: React.Context<EventHandlerConfig>;
export type EventHandlerProviderProps = {
  config?: EventHandlerConfig;
};
export declare const EventHandlerProvider: React.FC<
  React.PropsWithChildren<EventHandlerProviderProps>
>;
export {};
//# sourceMappingURL=EventHandlerProvider.d.ts.map
