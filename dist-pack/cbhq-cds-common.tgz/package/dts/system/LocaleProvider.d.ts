import React from 'react';
export type LocaleContextValue = {
  /** A valid JavaScript Intl locale. */
  locale: string;
};
export declare const LocaleContext: React.Context<LocaleContextValue>;
export type LocaleProviderProps = LocaleContextValue & {
  children?: React.ReactNode;
};
export declare const LocaleProvider: ({
  locale,
  children,
}: LocaleProviderProps) => import('react/jsx-runtime').JSX.Element;
export declare const useLocale: () => LocaleContextValue;
//# sourceMappingURL=LocaleProvider.d.ts.map
