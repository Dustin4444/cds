export declare function debounce<Params extends unknown[]>(
  func: (...args: Params) => unknown,
  timeout: number,
): (...args: Params) => void;
//# sourceMappingURL=debounce.d.ts.map
