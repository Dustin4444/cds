export declare const getRectWidthVariant: (
  variant: number | undefined,
  increment: number,
) => number | undefined;
//# sourceMappingURL=getRectWidthVariant.d.ts.map
