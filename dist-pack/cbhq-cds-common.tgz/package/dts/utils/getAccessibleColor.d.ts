import { type A11yColorUsage } from '../types/Color';
type GetAccessibleColorParams = {
  background: string;
  foreground?: 'auto';
  /**
   * Where the foreground color is being applied.
   * @default 'normalText'
   */
  usage?: A11yColorUsage;
  /** Use higher contrast ratio. */
  enhanced?: boolean;
};
/**
 * People with low vision often have difficulty reading text that does not contrast with its background.
 * This can be exacerbated if the person has a color vision deficiency that lowers the contrast even further.
 * Providing a minimum luminance contrast ratio between the text and its background can make the text more
 * readable even if the person does not see the full range of colors. It also works for the rare individuals who see no color.
 *
 * If foreground='auto:
 * 2. Return white or black based on contrast ratio with background.
 *
 * If foreground does not exist or doesn't meet contrast criteria:
 * 1. Check background color contrast ratios with white and black
 * 2. Return the color with higher contrast.
 */
export declare const getAccessibleColor: ({
  background,
  foreground,
  usage,
  enhanced,
}: GetAccessibleColorParams) => 'rgb(255,255,255)' | 'rgb(0,0,0)' | '#ffffff' | '#000000';
export {};
//# sourceMappingURL=getAccessibleColor.d.ts.map
