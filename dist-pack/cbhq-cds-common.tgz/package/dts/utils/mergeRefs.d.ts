import type React from 'react';
type OptionalRef<T> = React.Ref<T> | undefined;
/**
 * Merge multiple refs into a single ref callback.
 *
 * - Supports callback refs and object refs.
 * - Ignores `null`/`undefined` refs.
 * - Intentionally does not support legacy string refs.
 */
export declare const mergeRefs: <T = unknown>(...refs: OptionalRef<T>[]) => React.RefCallback<T>;
/**
 * Like `mergeRefs`, but also includes an existing ref already present on a React element.
 *
 * This is React 18/19 compatible:
 * - React 19 stores refs on `element.props.ref`
 * - React 18 and earlier store refs on `element.ref`
 */
export declare const mergeReactElementRef: <T = unknown>(element: React.ReactElement, ...refs: OptionalRef<T>[]) => React.RefCallback<T>;
/**
 * @deprecated This is an unnecessary hook (it doesn't call hooks). Prefer `mergeRefs` function instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const useMergeRefs: <T = unknown>(...refs: OptionalRef<T>[]) => React.RefCallback<T>;
export {};
//# sourceMappingURL=mergeRefs.d.ts.map