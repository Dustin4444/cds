import type { IllustrationVariant } from '../types';
/** Returns the default aspect ratio tuple for an illustration variant */
export declare function getDefaultAspectRatioForIllustration(
  variant: IllustrationVariant,
):
  | readonly [32, 32]
  | readonly [48, 48]
  | readonly [96, 96]
  | readonly [240, 120]
  | readonly [240, 240];
//# sourceMappingURL=getDefaultAspectRatioForIllustration.d.ts.map
