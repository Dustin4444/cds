import type { IllustrationDimension } from '../types';
/** Returns the aspect ratio tuple for a given dimension */
export declare function convertDimensionToAspectRatio(
  dimension: IllustrationDimension,
):
  | readonly [24, 24]
  | readonly [32, 32]
  | readonly [48, 48]
  | readonly [64, 64]
  | readonly [96, 96]
  | readonly [200, 200]
  | readonly [240, 120]
  | readonly [240, 240];
//# sourceMappingURL=convertDimensionToAspectRatio.d.ts.map
