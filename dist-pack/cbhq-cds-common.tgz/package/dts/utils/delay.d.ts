/** Delay
 * @example await delay(200);
 */
export declare const delay: (milliseconds: number) => Promise<unknown>;
//# sourceMappingURL=delay.d.ts.map
