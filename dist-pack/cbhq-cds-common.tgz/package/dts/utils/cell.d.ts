import type { CellPriority } from '../types';
export declare const hasCellPriority: (
  priorityToMatch: CellPriority,
  priority?: CellPriority | CellPriority[],
) => boolean;
//# sourceMappingURL=cell.d.ts.map
