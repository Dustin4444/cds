export {};
//# sourceMappingURL=getRectWidthVariant.test.d.ts.map
