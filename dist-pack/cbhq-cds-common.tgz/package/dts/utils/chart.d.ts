export declare const minMax: <T>(data: T[], dataToNumFn: (data: T) => number) => (T | undefined)[];
//# sourceMappingURL=chart.d.ts.map
