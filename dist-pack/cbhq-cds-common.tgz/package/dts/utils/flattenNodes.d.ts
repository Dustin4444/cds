type FlattenedNode = React.ReactElement | string | number;
export default function flattenNodes(children: React.ReactNode, depth?: number, keys?: (string | number)[]): FlattenedNode[];
export {};
//# sourceMappingURL=flattenNodes.d.ts.map