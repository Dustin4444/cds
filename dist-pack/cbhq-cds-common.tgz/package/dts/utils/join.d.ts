import React from 'react';
/**
 * Util for adding a separator element between react components excluding the last item
 */
export declare const join: (
  arr: unknown[],
  node: React.ReactNode,
) => import('react/jsx-runtime').JSX.Element[];
//# sourceMappingURL=join.d.ts.map
