/**
 * Formats a count number into a string representation.
 * @param count - The count number to be formatted.
 * @returns The formatted count as a string.
 *
 * @example
 * // returns '999'
 * formatCount(999)
 *
 * @example
 * // returns '1.5K'
 * formatCount(1500)
 *
 * @example
 * // returns '1.5M
 * formatCount(1500000)
 * @example
 * // returns '1.5B'
 * formatCount(1500000000)
 *
 * @example
 * // returns '1.5T'
 * formatCount(1500000000000)
 */
export declare const formatCount: (count: number) => string;
//# sourceMappingURL=formatCount.d.ts.map
