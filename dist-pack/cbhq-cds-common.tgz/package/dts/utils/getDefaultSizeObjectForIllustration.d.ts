import type { IllustrationVariant } from '../types';
/** Returns the default size object for an illustration variant */
export declare function getDefaultSizeObjectForIllustration(
  variant?: IllustrationVariant,
): import('./convertDimensionToSize').SizeObject;
//# sourceMappingURL=getDefaultSizeObjectForIllustration.d.ts.map
