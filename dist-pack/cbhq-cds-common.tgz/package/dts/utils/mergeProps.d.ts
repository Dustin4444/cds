export type UnknownProps = Record<string, unknown>;
export declare function mergeProps<T>(prev: UnknownProps, next: UnknownProps): T;
//# sourceMappingURL=mergeProps.d.ts.map
