export declare function getRadius(containerSize: number, strokeWidth?: number): number;
export declare function getCircumference(radius: number): number;
export declare function getCenter(containerSize: number): number;
//# sourceMappingURL=circle.d.ts.map
