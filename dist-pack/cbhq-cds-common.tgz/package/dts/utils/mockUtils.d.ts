export declare const NoopFn: () => void;
//# sourceMappingURL=mockUtils.d.ts.map
