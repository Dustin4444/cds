export declare const MAX_OVERFLOW_COUNT = 99;
export declare const parseDotCountMaxOverflow: (count: number, max?: number) => string | number;
//# sourceMappingURL=parseDotCountMaxOverflow.d.ts.map
