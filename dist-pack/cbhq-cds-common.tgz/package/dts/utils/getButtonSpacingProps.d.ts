import type { ThemeVars } from '../core/theme';
import type { NegativeSpace } from '../types';
export type GetButtonSpacingParams = {
    compact?: boolean;
    /** If present decrease horizontal padding */
    flush?: 'start' | 'end' | boolean;
};
type ButtonSpacingValue = {
    paddingX?: ThemeVars.Space;
    paddingY?: ThemeVars.Space;
    marginEnd?: NegativeSpace;
    marginStart?: NegativeSpace;
};
/**
 * @deprecated This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const getButtonSpacingProps: ({ compact, flush, }: GetButtonSpacingParams) => ButtonSpacingValue;
export {};
//# sourceMappingURL=getButtonSpacingProps.d.ts.map