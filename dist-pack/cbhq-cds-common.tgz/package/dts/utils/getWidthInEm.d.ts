/**
 * Returns the width of an element in em units by dividing its computed width by font-size.
 * Useful for animating width across font-size changes without hardcoding pixels.
 */
export declare const getWidthInEm: (element: HTMLElement) => string;
//# sourceMappingURL=getWidthInEm.d.ts.map
