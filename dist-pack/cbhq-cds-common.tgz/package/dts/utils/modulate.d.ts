type ModulateRange = {
  inputRange: [number, number];
  outputRange: [number, number];
  clamp: boolean;
};
/** create incremental transformations based on user interaction */
export declare const modulate: (
  value: number,
  { inputRange, outputRange, clamp }: ModulateRange,
) => number;
export {};
//# sourceMappingURL=modulate.d.ts.map
