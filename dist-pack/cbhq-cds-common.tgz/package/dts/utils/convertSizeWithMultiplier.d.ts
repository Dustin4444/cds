/** Take a width, height object return the same object with a multiplier applied. */
export declare function convertSizeWithMultiplier(
  size: {
    width: number;
    height: number;
  },
  multiplier: number,
): {
  width: number;
  height: number;
};
//# sourceMappingURL=convertSizeWithMultiplier.d.ts.map
