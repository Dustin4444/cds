/**
 * Motion specs
 * @link https://coda.io/d/Motion-Foundations_d5KlLHcBPlL/CDS-Dots_suq2C#_luRZr
 */
export declare const dotOpacityEnterConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const dotScaleEnterConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const dotOpacityExitConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const dotScaleExitConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
//# sourceMappingURL=dot.d.ts.map
