import type { MotionTransition } from '../types';
export declare const colorSurgeEnterConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const colorSurgeExitConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const shakeTranslateX: number[];
export declare const shakeTransitionConfig: MotionTransition;
export declare const pulseTransitionConfig: MotionTransition;
export declare const pulseVariantOpacity: {
  moderate: number;
  subtle: number;
  heavy: number;
};
//# sourceMappingURL=hint.d.ts.map
