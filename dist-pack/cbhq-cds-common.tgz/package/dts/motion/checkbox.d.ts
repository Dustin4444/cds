/**
 * Motion specs
 * @link https://coda.io/d/Motion-Foundations_d5KlLHcBPlL/CDS-Check-Box_suHNC#_luS1p
 */
export declare const checkboxOpacityEnterConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const checkboxScaleEnterConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const checkboxOpacityExitConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
export declare const checkboxScaleExitConfig:
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: import('..').MotionDuration;
      oneOffDuration?: number;
    };
//# sourceMappingURL=checkbox.d.ts.map
