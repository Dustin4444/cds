import type { MotionCurve, MotionProperty, MotionValue } from '../types';
type MotionValues = [MotionValue, MotionValue] | MotionValue;
export declare const generateAnimToken: (
  property: MotionProperty,
  values: MotionValues,
  easing: MotionCurve,
) =>
  | {
      property: MotionProperty;
      fromValue: MotionValue;
      toValue: MotionValue;
      easing:
        | 'global'
        | 'enterExpressive'
        | 'enterFunctional'
        | 'exitExpressive'
        | 'exitFunctional'
        | 'linear';
    }
  | {
      property: MotionProperty;
      toValue: MotionValue;
      easing:
        | 'global'
        | 'enterExpressive'
        | 'enterFunctional'
        | 'exitExpressive'
        | 'exitFunctional'
        | 'linear';
      fromValue?: undefined;
    };
export {};
//# sourceMappingURL=utils.d.ts.map
