import type { MotionBaseSpec, MotionDuration, MotionEffect } from '../types';
export type EasingArray = [number, number, number, number];
export declare const curves: {
  readonly global: EasingArray;
  readonly enterExpressive: EasingArray;
  readonly enterFunctional: EasingArray;
  readonly exitExpressive: EasingArray;
  readonly exitFunctional: EasingArray;
  readonly linear: EasingArray;
};
export declare const durations: {
  readonly quick: 33;
  /** Buttons, Toggles, Text, Icons, Selection Controls */
  readonly fast1: 100;
  readonly fast2: 133;
  readonly fast3: 150;
  /** Short distance movements, System Messaging, Navigation Drawer, Modals */
  readonly moderate1: 200;
  readonly moderate2: 250;
  readonly moderate3: 300;
  /** Large distance movements, Page Transitions, Full screen dialogue */
  readonly slow1: 350;
  readonly slow2: 400;
  readonly slow3: 500;
  readonly slow4: 1000;
};
export declare const animations: {
  readonly fadeIn:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly fadeIn10:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly fadeIn20:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly fadeIn30:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly fadeOut:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly fadeOut10:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly fadeOut20:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly fadeOut30:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideUp:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideUp8:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideUp16:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideUp24:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideUp40:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideDown:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideDown8:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideDown16:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideDown24:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideDown40:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideRight:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideRight8:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideRight16:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideRight24:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideRight40:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideLeft:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideLeft8:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideLeft16:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideLeft24:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly slideLeft40:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly scaleUpXXS:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly scaleUpXS:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly scaleUpS:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly scaleDownXXS:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly scaleDownXS:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
  readonly scaleDownS:
    | {
        property: import('..').MotionProperty;
        fromValue: import('..').MotionValue;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
      }
    | {
        property: import('..').MotionProperty;
        toValue: import('..').MotionValue;
        easing:
          | 'global'
          | 'enterExpressive'
          | 'enterFunctional'
          | 'exitExpressive'
          | 'exitFunctional'
          | 'linear';
        fromValue?: undefined;
      };
};
export declare const createMotionConfig: (
  effect: MotionEffect,
  duration: MotionDuration,
  overrides?: Partial<MotionBaseSpec>,
) =>
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: MotionDuration;
      oneOffDuration?: number;
    }
  | {
      property: string;
      toValue: import('..').MotionValue;
      fromValue?: import('..').MotionValue;
      delay?: number;
      useNativeDriver?: boolean;
      easing: import('..').MotionCurve;
      duration: MotionDuration;
      oneOffDuration?: number;
    };
//# sourceMappingURL=tokens.d.ts.map
