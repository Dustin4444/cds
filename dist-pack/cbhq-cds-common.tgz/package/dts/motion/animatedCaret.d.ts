import type { MotionBaseSpec } from '../types';
export declare const animateRotateConfig: Omit<MotionBaseSpec, 'toValue'>;
//# sourceMappingURL=animatedCaret.d.ts.map
