import type { MotionTransition } from '../types';
/**
 * Motion specs
 * @link https://coda.io/d/Motion-Foundations_d5KlLHcBPlL/CDS-Switch_su7H7#_lu8Pe
 */
export declare const switchTransitionConfig: MotionTransition;
//# sourceMappingURL=switch.d.ts.map
