export * from './useCarouselAutoplay';
//# sourceMappingURL=index.d.ts.map
