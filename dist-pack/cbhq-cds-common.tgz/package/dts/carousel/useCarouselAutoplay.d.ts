export type CarouselAutoplayOptions = {
  /**
   * Whether autoplay is enabled.
   */
  enabled: boolean;
  /**
   * The interval in milliseconds between auto-advances.
   */
  interval: number;
  /**
   * Callback fired when autoplay starts.
   */
  onStart?: () => void;
  /**
   * Callback fired when autoplay stops.
   */
  onStop?: () => void;
};
export type CarouselAutoplayState = {
  /**
   * Whether autoplay is actively running (enabled AND not stopped AND not paused).
   */
  isPlaying: boolean;
  /**
   * Whether autoplay has been stopped by the user.
   */
  isStopped: boolean;
  /**
   * Whether autoplay is temporarily paused due to user interaction (hover/touch).
   */
  isPaused: boolean;
};
export type CarouselAutoplayApi = {
  /**
   * Start autoplay. Resumes from paused progress if available.
   */
  start: () => void;
  /**
   * Stop autoplay. Preserves current progress for resuming later.
   */
  stop: () => void;
  /**
   * Toggle autoplay on/off.
   */
  toggle: () => void;
  /**
   * Reset the autoplay timer (e.g., after manual navigation).
   */
  reset: () => void;
  /**
   * Temporarily pause autoplay (e.g., on hover/touch). Does not change isStopped state.
   * Progress is preserved and will resume from where it left off.
   */
  pause: () => void;
  /**
   * Resume autoplay after interaction pause. Only resumes if not user-stopped.
   */
  resume: () => void;
  /**
   * Get the current remaining time. Useful for calculating progress in platform-native animations.
   */
  getRemainingTime: () => number;
  /**
   * Add a listener to be called when the autoplay timer completes.
   * Returns an unsubscribe function.
   */
  addCompletionListener: (callback: () => void) => () => void;
};
/**
 * Combined state and API returned by useCarouselAutoplay.
 */
export type CarouselAutoplay = CarouselAutoplayState & CarouselAutoplayApi;
/**
 * A hook for managing carousel autoplay state and timing.
 * Provides controls for starting, stopping, and resetting autoplay.
 */
export declare const useCarouselAutoplay: ({
  enabled,
  interval,
  onStart,
  onStop,
}: CarouselAutoplayOptions) => CarouselAutoplay;
//# sourceMappingURL=useCarouselAutoplay.d.ts.map
