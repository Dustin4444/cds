export {};
//# sourceMappingURL=useCarouselAutoplay.test.d.ts.map
