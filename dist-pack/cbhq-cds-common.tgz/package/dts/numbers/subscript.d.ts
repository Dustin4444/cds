import type { NumberPart } from './IntlNumberFormat';
export declare const toSubscriptNumber: (n: number) => string;
/**
 * Builds parts for the fractional digits with subscript applied to leading zeros.
 */
export declare function buildFractionPartsWithSubscript(fractionDigits: string): NumberPart[];
//# sourceMappingURL=subscript.d.ts.map
