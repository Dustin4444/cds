export {};
//# sourceMappingURL=formatToParts.test.d.ts.map
