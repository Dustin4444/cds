export {};
//# sourceMappingURL=subscript.test.d.ts.map
