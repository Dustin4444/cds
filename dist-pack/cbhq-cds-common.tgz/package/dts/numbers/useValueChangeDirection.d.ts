export type SingleDirection = 'up' | 'down';
/**
 * Track the direction of value changes for RollingNumber animations.
 * Returns 'up' when value increases, 'down' when value decreases, and undefined on initial render or no change.
 */
export declare function useValueChangeDirection(value: number): SingleDirection | undefined;
//# sourceMappingURL=useValueChangeDirection.d.ts.map
