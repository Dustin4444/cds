import type { ChartFormatDate, ChartGetMarker } from '../types';
export type GetFormattedDateParams<Period extends string> = {
  getMarker: ChartGetMarker;
  formatDate: ChartFormatDate<Period>;
  selectedPeriod: Period;
};
export declare function useDateLookup<Period extends string>({
  getMarker,
  formatDate,
  selectedPeriod,
}: GetFormattedDateParams<Period>): (xPos: number) => string;
//# sourceMappingURL=useDateLookup.d.ts.map
