/**
 * Downsampling timeseries data using the "Largest-Triangle-Three-Buckets algorithm" (LTTB) as described in Sveinn Steinarsson's 2013 Master's thesis Downsampling Time Series for Visual Representation.
 *
 * The algorithm is based on the technique of forming triangles between adjacent data points and using the area of the triangles to determine the perceptual importance of the individual points.
 * This helps to retain the visual characteristics of the original path whilst greatly reducing the number of points representing it.
 *
 * The threshold parameter for the algorithm is set at half the current width of the svg in pixels - so at most there is one point in the input domain represented for every two pixels in the output range.
 *
 * Using this method helps to avoid any alising issues that occur when a high number of points are drawn in a low number of pixels.
 * @param data
 * @param threshold
 * @returns number[]
 * @example https://bl.ocks.org/FraserChapman/649f1aba28f6bc941d5c
 */
export declare const largestTriangleThreeBucket: (data: number[], threshold: number) => number[];
//# sourceMappingURL=largestTriangleThreeBucket.d.ts.map
