import type { Weight } from '../types/Weight';
export declare const getProgressSize: (weight: Weight) => 2 | 4 | 8 | 12;
//# sourceMappingURL=getProgressSize.d.ts.map
