import type { ChartDataPoint, ChartTimeseries } from '../types/Chart';
export type UseTimeseriesPathsParams = {
  data: ChartTimeseries[];
  width: number;
  height: number;
};
export declare function useTimeseriesPaths({ data, width, height }: UseTimeseriesPathsParams): {
  lineFn: import('d3-shape').Line<ChartDataPoint>;
  areaFn: import('d3-shape').Area<ChartDataPoint>;
};
//# sourceMappingURL=useTimeseriesPaths.d.ts.map
