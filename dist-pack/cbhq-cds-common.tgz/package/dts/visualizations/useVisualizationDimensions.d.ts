type VisualizationDimensions<DimensionType> = {
    userDefinedWidth: DimensionType;
    userDefinedHeight: DimensionType;
    calculatedWidth: number;
    calculatedHeight: number;
};
export declare const useVisualizationDimensions: <DimensionType = string | number | undefined | null>({ userDefinedWidth, userDefinedHeight, calculatedWidth, calculatedHeight, }: VisualizationDimensions<DimensionType>) => {
    width: number;
    height: number;
    circleSize: number;
    shouldObserve: boolean;
};
export {};
//# sourceMappingURL=useVisualizationDimensions.d.ts.map