export type UseCounterParams = {
  startNum: number;
  endNum: number;
  durationInMillis: number;
};
export declare const useCounter: ({
  startNum,
  endNum,
  durationInMillis,
}: UseCounterParams) => number;
//# sourceMappingURL=useCounter.d.ts.map
