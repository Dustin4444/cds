import type { Weight } from '../types/Weight';
/** @deprecated Use getProgressSize instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const useProgressSize: (weight: Weight) => 2 | 4 | 8 | 12;
//# sourceMappingURL=useProgressSize.d.ts.map
