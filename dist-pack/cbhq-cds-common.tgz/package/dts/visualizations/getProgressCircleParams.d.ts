type ProgressCircleParams = {
  size: number;
  strokeWidth: number;
  stroke: string;
};
export declare const getProgressCircleParams: ({
  size,
  strokeWidth,
  stroke,
}: ProgressCircleParams) => {
  stroke: string;
  cx: number;
  cy: number;
  r: number;
  strokeWidth: number;
  fill: string;
};
export {};
//# sourceMappingURL=getProgressCircleParams.d.ts.map
