import { type ScaleLinear } from 'd3-scale';
export type UseSparklinePathParams = {
  data: number[] | string[];
  height: number;
  width: number;
  yAxisScalingFactor?: number;
};
export type SparklineGeneratorParams = {
  xFunction: ScaleLinear<number, number>;
  yFunction: ScaleLinear<number, number>;
  data: [number];
};
type UseSparklinePathGeneratorParams = {
  generator: (params: SparklineGeneratorParams) => string;
} & UseSparklinePathParams;
export declare const useSparklinePathGenerator: ({
  data,
  height,
  width,
  yAxisScalingFactor,
  generator,
}: UseSparklinePathGeneratorParams) => string;
export {};
//# sourceMappingURL=useSparklinePathGenerator.d.ts.map
