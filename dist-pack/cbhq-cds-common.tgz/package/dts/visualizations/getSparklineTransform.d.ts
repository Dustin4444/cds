export declare function getSparklineTransform(
  width: number,
  height: number,
  yAxisScalingFactor?: number,
): {
  transform?: string;
};
//# sourceMappingURL=getSparklineTransform.d.ts.map
