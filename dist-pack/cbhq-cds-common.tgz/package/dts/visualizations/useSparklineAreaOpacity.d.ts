export declare function useSparklineAreaOpacity(colorScheme: 'dark' | 'light'): 0.2 | 0.4;
//# sourceMappingURL=useSparklineAreaOpacity.d.ts.map