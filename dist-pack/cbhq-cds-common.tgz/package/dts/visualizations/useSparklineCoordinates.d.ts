import * as d3Scale from 'd3-scale';
import type { ChartData } from '../types';
export type UseSparklineCoordinatesParams = {
  data: ChartData;
  width: number;
  height: number;
  yAxisScalingFactor?: number;
};
export declare const useSparklineCoordinates: ({
  data,
  width,
  height,
  yAxisScalingFactor,
}: UseSparklineCoordinatesParams) => {
  xFunction: d3Scale.ScaleTime<number, number, never>;
  yFunction: d3Scale.ScaleLinear<number, number, never>;
  path: string;
  area: string;
  getMarker: (xPos: number) =>
    | {
        value: number;
        date: Date;
        x: number;
        y: number;
      }
    | undefined;
};
//# sourceMappingURL=useSparklineCoordinates.d.ts.map
