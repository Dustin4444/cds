import type { UseSparklinePathParams } from './useSparklinePathGenerator';
export declare const useSparklinePath: (props: UseSparklinePathParams) => string;
//# sourceMappingURL=useSparklinePath.d.ts.map
