export declare const getSparklineRange: ({
  height,
  width,
  yAxisScalingFactor,
}: {
  height: number;
  width: number;
  yAxisScalingFactor?: number;
}) => {
  xRange: number[];
  yRange: number[];
};
//# sourceMappingURL=getSparklineRange.d.ts.map
