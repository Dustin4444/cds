export {};
//# sourceMappingURL=useSparklineArea.test.d.ts.map
