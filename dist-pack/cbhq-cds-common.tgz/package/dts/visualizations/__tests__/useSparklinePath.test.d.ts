export {};
//# sourceMappingURL=useSparklinePath.test.d.ts.map
