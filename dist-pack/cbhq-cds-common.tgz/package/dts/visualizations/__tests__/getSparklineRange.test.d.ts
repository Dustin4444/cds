export {};
//# sourceMappingURL=getSparklineRange.test.d.ts.map
