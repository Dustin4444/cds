export {};
//# sourceMappingURL=largestTriangleThreeBucket.test.d.ts.map
