export {};
//# sourceMappingURL=useSparklineCoordinates.test.d.ts.map
