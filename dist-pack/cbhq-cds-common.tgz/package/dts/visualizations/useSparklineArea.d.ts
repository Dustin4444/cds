import type { UseSparklinePathParams } from './useSparklinePathGenerator';
export declare const useSparklineArea: ({ height, ...props }: UseSparklinePathParams) => string;
//# sourceMappingURL=useSparklineArea.d.ts.map
