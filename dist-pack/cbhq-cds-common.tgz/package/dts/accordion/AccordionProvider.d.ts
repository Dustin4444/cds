import React from 'react';
export type AccordionContextValue = {
  activeKey: string | null;
  setActiveKey: (activeKey: string | null) => void;
};
export declare const AccordionContext: React.Context<AccordionContextValue>;
export declare const useAccordionContext: () => AccordionContextValue;
export type AccordionProviderProps = {
  activeKey?: AccordionContextValue['activeKey'];
  children?: React.ReactNode;
  /**
   * Default active accordion item key.
   * If not specified or does not exist in the accordion items,
   * all items will be closed on mount
   */
  defaultActiveKey?: string;
  /**
   * Callback function fired when any of accordion items is pressed
   */
  onChange?: AccordionContextValue['setActiveKey'];
  setActiveKey?: AccordionContextValue['setActiveKey'];
};
export declare const AccordionProvider: ({
  activeKey,
  children,
  defaultActiveKey,
  setActiveKey,
  onChange,
}: AccordionProviderProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=AccordionProvider.d.ts.map
