export {};
//# sourceMappingURL=AccordionProvider.test.d.ts.map
