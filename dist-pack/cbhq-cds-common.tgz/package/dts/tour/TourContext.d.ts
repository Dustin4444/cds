import { type Context } from 'react';
import type { TourApi } from './useTour';
export type TourContextValue<TourStepId extends string = string, TTarget = unknown> = TourApi<TourStepId, TTarget>;
export declare const TourContext: Context<TourContextValue<string, unknown> | undefined>;
export declare const useTourContext: <TourStepId extends string = string, TTarget = unknown>() => TourContextValue<TourStepId, TTarget>;
//# sourceMappingURL=TourContext.d.ts.map