export {};
//# sourceMappingURL=useTour.test.d.ts.map
