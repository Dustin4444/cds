import type React from 'react';
/**
 * Placement for the tour step arrow. Matches the placement values used by positioning libraries
 * (e.g. @floating-ui) so web/mobile can pass through their placement directly.
 */
export type TourStepArrowPlacement = 'top' | 'top-start' | 'top-end' | 'right' | 'right-start' | 'right-end' | 'bottom' | 'bottom-start' | 'bottom-end' | 'left' | 'left-start' | 'left-end';
/**
 * Arrow coordinates and offsets for the tour step arrow. Matches the shape provided by arrow
 * middleware (e.g. @floating-ui) so web/mobile can pass through their arrow data directly.
 */
export type TourStepArrowData = {
    x?: number;
    y?: number;
    centerOffset?: number;
    alignmentOffset?: number;
};
export type TourStepArrowComponentProps = {
    /** Arrow coordinates and offsets for positioning the arrow element. */
    arrow?: TourStepArrowData;
    /** Placement of the arrow relative to the floating element. */
    placement: TourStepArrowPlacement;
    style?: Record<string, string | number>;
};
/**
 * The TourStepArrowComponent must forwardRef onto the underlying element for the positioning
 * library to correctly position the element.
 */
export type TourStepArrowComponent = React.ForwardRefExoticComponent<TourStepArrowComponentProps & {
    ref?: React.Ref<any>;
}>;
export type TourStepComponent = React.FC<Omit<TourStepValue, 'Component'>>;
/**
 * Web only.
 */
export type TourScrollOptions = {
    behavior?: ScrollBehavior;
    marginX?: number;
    marginY?: number;
};
export type TourStepValue<TourStepId extends string = string> = {
    /**
     * The tour step id.
     */
    id: TourStepId;
    /**
     * The Component to render for this tour step.
     */
    Component: TourStepComponent;
    /**
     * The TourStepArrowComponent to render for this tour step.
     */
    ArrowComponent?: TourStepArrowComponent;
    /**
     * Disabling the tour step causes it to be skipped when calling `goNextTourStep()` or `goPreviousTourStep()`.
     */
    disabled?: boolean;
    /**
     * Hides the overlay when the tour is active.
     */
    hideOverlay?: boolean;
    /**
     * Callback function fired as this step becomes active. This step's `onActive` will fire simultaneously with the previously active step's `onInactive`.
     */
    onActive?: () => void | Promise<void>;
    /**
     * Callback function fired right before this step becomes active. This step's `onBeforeActive` will fire simultaneously with the previously active step's `onBeforeInactive`.
     */
    onBeforeActive?: () => void | Promise<void>;
    /**
     * Callback function fired as this step becomes inactive. This step's `onInactive` will fire simultaneously with the new active step's `onActive`.
     */
    onInactive?: () => void | Promise<void>;
    /**
     * Callback function fired right before this step becomes inactive. This step's `onBeforeInactive` will fire simultaneously with the new active step's `onBeforeActive`.
     */
    onBeforeInactive?: () => void | Promise<void>;
    /**
     * Padding to add around the edges of the TourMask's content mask.
     */
    tourMaskPadding?: string | number;
    /**
     * Corner radius for the TourMask's content mask. Uses SVG rect element's `rx` and `ry` attributes https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/rx.
     */
    tourMaskBorderRadius?: string | number;
    /**
     * Add styles to the TourStepArrowComponent for this tour step.
     */
    arrowStyle?: Record<string, string | number>;
    /**
     * Web only. Disables automatically scrolling to this TourStep when it becomes active.
     */
    disableAutoScroll?: boolean;
    /**
     * Web only. Controls the scrolling behavior and margins when calling element.scrollTo() to scroll to an active TourStep target.
     */
    scrollOptions?: TourScrollOptions;
};
export type TourOptions<TourStepId extends string = string> = {
    steps: TourStepValue<TourStepId>[];
    activeTourStep: TourStepValue<TourStepId> | null;
    onChange: (tourStep: TourStepValue<TourStepId> | null) => void;
};
/**
 * API returned by useTour and provided via TourContext.
 * @template TourStepId - Step id string literal type.
 * @template TTarget - Type of the active step's target element (e.g. HTMLElement for web, View for react-native). Defaults to unknown.
 */
export type TourApi<TourStepId extends string = string, TTarget = unknown> = Omit<TourOptions<TourStepId>, 'onChange'> & {
    /** The target element of the currently active tour step. */
    activeTourStepTarget: TTarget | null;
    /** Set the target element of the currently active tour step. */
    setActiveTourStepTarget: (target: TTarget | null) => void;
    setActiveTourStep: (tourStepId: TourStepId | null) => void;
    startTour: (tourStepId?: TourStepId) => void;
    stopTour: () => void;
    goNextTourStep: () => void;
    goPreviousTourStep: () => void;
};
/** A controlled hook for managing tour state, such as the currently active tour step. */
export declare const useTour: <TourStepId extends string = string, TTarget = unknown>({ steps, activeTourStep, onChange, }: TourOptions<TourStepId>) => TourApi<TourStepId, TTarget>;
//# sourceMappingURL=useTour.d.ts.map