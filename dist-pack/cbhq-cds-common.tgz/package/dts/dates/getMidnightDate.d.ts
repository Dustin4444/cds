/**
 * Clones a Date with the time set to midnight (00:00:00.000)
 */
export declare const getMidnightDate: (date: Date) => Date;
//# sourceMappingURL=getMidnightDate.d.ts.map
