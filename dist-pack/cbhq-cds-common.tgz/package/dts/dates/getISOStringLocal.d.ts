/**
 * Converts a Date to an ISO 8601 string (YYYY-MM-DD) in the local timezone (not UTC)
 */
export declare const getISOStringLocal: (date: Date) => string;
//# sourceMappingURL=getISOStringLocal.d.ts.map
