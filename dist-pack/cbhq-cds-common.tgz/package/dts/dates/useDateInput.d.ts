import { type DateInputValidationError } from './DateInputValidationError';
import {
  type DateInputValidationApi,
  type DateInputValidationOptions,
} from './useDateInputValidation';
export type DateInputOptions = {
  /** Control the date value of the DateInput. */
  date: Date | null;
  /** Callback function fired when the date changes, e.g. when a valid date is selected or unselected. */
  onChangeDate: (date: Date | null) => void;
  /** Control the error value of the DateInput. */
  error: DateInputValidationError | null;
  /** Callback function fired when validation finds an error, e.g. required input fields and impossible or disabled dates. Will always be called after `onChangeDate`. */
  onErrorDate: (error: DateInputValidationError | null) => void;
} & DateInputValidationOptions;
export type DateInputApi = {
  /** The DateInput's date string value. */
  inputValue: string;
  /** Callback that handles a DateInput's changing date string value. Updates the `inputValue` state and calls `onChangeDate` and `onErrorDate` as necessary. */
  onChangeDateInput: (newDateString: string) => void;
  /** The DateInput's placeholder value. */
  placeholder: string;
} & DateInputValidationApi;
/** Accepts DateInputOptions and returns a DateInputApi, which can be used to control a custom DateInput component. */
export declare const useDateInput: ({
  date,
  onChangeDate,
  error,
  onErrorDate,
  intlDateFormat,
  required,
  disabledDates,
  minDate,
  maxDate,
  requiredError,
  invalidDateError,
  disabledDateError,
}: DateInputOptions) => DateInputApi;
//# sourceMappingURL=useDateInput.d.ts.map
