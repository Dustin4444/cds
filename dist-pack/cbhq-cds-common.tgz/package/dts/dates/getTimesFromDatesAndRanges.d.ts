/**
 * Takes an array of Dates and Date tuples for date ranges, and generates a flattened array of corresponding Date.getTime() numbers, with the time set to midnight. A number will be generated for every individual date within a date range.
 */
export declare const getTimesFromDatesAndRanges: (
  datesAndRanges: (Date | [Date, Date])[],
) => number[];
//# sourceMappingURL=getTimesFromDatesAndRanges.d.ts.map
