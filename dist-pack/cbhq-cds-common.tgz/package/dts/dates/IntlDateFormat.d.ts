/**
 * IntlDateFormat is a utility class that uses the Intl.DateTimeFormat API to determine the date format for a given locale.
 * It can be used to parse and format date strings based on the locale's date format.
 * @param locale A valid JavaScript Intl locale used to determine the date format.
 * @param separator Character used to separate values in the date format, e.g. the forward slash in "MM/DD/YYYY".
 * @example
 * const intlDateFormat = new IntlDateFormat({ locale: 'en-US', separator: '/' });
 * const date = intlDateFormat.date('12/31/2020');
 * const dateString = intlDateFormat.format(new Date());
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat
 */
export declare class IntlDateFormat {
  /** A valid JavaScript Intl locale used to determine the date format. */
  locale: string;
  /** Character used to separate values in the date format, e.g. the forward slash in "MM/DD/YYYY". */
  separator: string;
  /** The indices of the separator characters in the date format. */
  separatorIndices: number[];
  /** Matches any character except digits and the separator character. */
  invalidDateFormatRegex: RegExp;
  /** Matches two or more consecutive separator characters. */
  duplicateSeparatorRegex: RegExp;
  /** Intl.DateTimeFormat class for the locale. */
  dateTimeFormat: Intl.DateTimeFormat;
  /** Array of Intl.DateTimeFormatParts - including day, month, year, and separators. */
  dateTimeFormatParts: Intl.DateTimeFormatPart[];
  /** The date format, based on the locale and including separator characters, e.g. "MM/DD/YYYY". */
  dateStringFormat: string;
  static datePartTypeMap: {
    [key in Intl.DateTimeFormatPartTypes]?: string;
  };
  constructor(props: { locale: string; separator: string });
  /**
   * Converts a valid date string to a Date object based on the locale's date format.
   */
  date(dateString: string): Date | null;
  /**
   * Converts a Date object to a date string based on the locale's date format.
   */
  format(date: Date): string;
}
//# sourceMappingURL=IntlDateFormat.d.ts.map
