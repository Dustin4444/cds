export {};
//# sourceMappingURL=useDateInput.test.d.ts.map
