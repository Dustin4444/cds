/**
 * Generates an array of Dates for a calendar month. Not localized with Intl. Assumes a Gregorian calendar with "en-US" DateTimeFormat. Treats Sunday as the first day of the week.
 */
export declare const generateCalendarMonth: (seedDate: Date) => Date[];
//# sourceMappingURL=generateCalendarMonth.d.ts.map
