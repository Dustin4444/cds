export type DateInputValidationErrorType = 'required' | 'invalid' | 'disabled';
export declare class DateInputValidationError extends Error {
  type: DateInputValidationErrorType | 'custom';
  constructor(type: DateInputValidationError['type'], message: string);
}
//# sourceMappingURL=DateInputValidationError.d.ts.map
