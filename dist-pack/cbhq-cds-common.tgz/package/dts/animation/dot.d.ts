import type { MotionBaseSpec } from '../types';
export declare const dotHidden = 0;
export declare const dotVisible = 1;
export declare const animateDotWidthConfig: Omit<MotionBaseSpec, 'toValue' | 'fromValue'>;
export declare const animateDotOpacityConfig: Omit<MotionBaseSpec, 'toValue' | 'fromValue'>;
//# sourceMappingURL=dot.d.ts.map
