import type { MotionTransition } from '../types';
export declare const animateProgressBaseSpec: MotionTransition;
//# sourceMappingURL=progress.d.ts.map
