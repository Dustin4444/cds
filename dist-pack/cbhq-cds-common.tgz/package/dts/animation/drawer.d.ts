/** Upper limit for how much the drawer can be extended in length by panning */
export declare const MAX_OVER_DRAG = 40;
/** Maximum drag distance (in pixels) required to dismiss. */
export declare const DISMISSAL_DRAG_THRESHOLD = 150;
/** Velocity threshold (px/ms) for quick swipes to dismiss, regardless of distance dragged. */
export declare const DISMISSAL_VELOCITY_THRESHOLD = 0.8;
/** Minimum panning distance required to capture pan gesture */
export declare const MIN_PAN_DISTANCE = 2;
export declare const drawerAnimationDefaultDuration = 'moderate3';
export declare const animateDrawerInConfig: {
  toValue: number;
  easing: string;
  duration: string;
};
export declare const animateDrawerOutConfig: {
  toValue: number;
  easing: string;
  duration: string;
};
//# sourceMappingURL=drawer.d.ts.map
