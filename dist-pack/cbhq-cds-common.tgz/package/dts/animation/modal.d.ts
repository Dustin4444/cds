import type { MotionBaseSpec } from '../types';
export declare const modalHiddenOpacity = 0;
export declare const modalHiddenScale = 0.98;
export declare const modalVisibleOpacity = 1;
export declare const modalVisibleScale = 1;
export declare const animateInOpacityConfig: MotionBaseSpec;
export declare const animateOutOpacityConfig: MotionBaseSpec;
export declare const animateInScaleConfig: MotionBaseSpec;
export declare const animateOutScaleConfig: MotionBaseSpec;
//# sourceMappingURL=modal.d.ts.map
