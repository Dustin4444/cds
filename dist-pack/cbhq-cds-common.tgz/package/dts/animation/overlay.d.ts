import type { MotionBaseSpec } from '../types';
export declare const overlayHiddenOpacity = 0;
export declare const overlayVisibleOpacity = 1;
export declare const animateInOpacityConfig: MotionBaseSpec;
export declare const animateOutOpacityConfig: MotionBaseSpec;
//# sourceMappingURL=overlay.d.ts.map
