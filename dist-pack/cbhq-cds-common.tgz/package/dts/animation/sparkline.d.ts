declare function easeOutQuint(x: number): number;
export declare const animatedPathConfig: {
  easing: typeof easeOutQuint;
  duration: number;
};
export {};
//# sourceMappingURL=sparkline.d.ts.map
