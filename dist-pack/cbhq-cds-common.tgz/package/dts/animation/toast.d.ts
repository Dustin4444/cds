import type { MotionBaseSpec } from '../types';
export declare const toastHiddenOpacity = 0;
export declare const toastHiddenBottom = 25;
export declare const toastVisibleOpacity = 1;
export declare const toastVisibleBottom = 0;
export declare const animateInOpacityConfig: MotionBaseSpec;
export declare const animateOutOpacityConfig: MotionBaseSpec;
export declare const animateInBottomConfig: MotionBaseSpec;
export declare const animateOutBottomConfig: MotionBaseSpec;
export declare const horizontalPanThreshold = 50;
export declare const bottomPanThreshold = 10;
//# sourceMappingURL=toast.d.ts.map
