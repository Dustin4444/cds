import type { MotionBaseSpec } from '../types';
export declare const animateCaretInConfig: MotionBaseSpec;
export declare const animateCaretOutConfig: MotionBaseSpec;
//# sourceMappingURL=select.d.ts.map
