import type { MotionBaseSpec } from '../types';
export declare const paddleHidden = 0;
export declare const paddleVisible = 1;
export declare const animateGradientScaleConfig: Omit<MotionBaseSpec, 'toValue' | 'fromValue'>;
export declare const animatePaddleOpacityConfig: Omit<MotionBaseSpec, 'toValue' | 'fromValue'>;
export declare const animatePaddleScaleConfig: Omit<MotionBaseSpec, 'toValue' | 'fromValue'>;
//# sourceMappingURL=paddle.d.ts.map
