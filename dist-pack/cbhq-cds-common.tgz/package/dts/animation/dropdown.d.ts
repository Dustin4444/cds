export declare const animateDropdownOpacityInConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    property: string;
    fromValue: number;
    toValue: number;
};
export declare const animateDropdownOpacityOutConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    property: string;
    fromValue: number;
    toValue: number;
};
export declare const animateDropdownTransformInConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    fromValue: number;
    toValue: number;
};
export declare const animateDropdownTransformOutConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    fromValue: number;
    toValue: number;
};
//# sourceMappingURL=dropdown.d.ts.map