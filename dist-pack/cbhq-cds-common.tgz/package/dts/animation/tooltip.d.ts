import type { BaseTooltipPlacement, MotionBaseSpec } from '../types';
export declare const tooltipHiddenOpacity = 0;
export declare const tooltipVisibleOpacity = 1;
export declare const tooltipHiddenY = 16;
export declare const tooltipVisibleY = 0;
export declare const animateInOpacityConfig: MotionBaseSpec;
export declare const animateOutOpacityConfig: MotionBaseSpec;
/**
 * Build tooltip translation config base on placement
 * @param placement Tooltip placement
 * @param transitionType animation type
 * @returns Motion config
 */
export declare const getTranslateConfigByPlacement: ({
  placement,
  isExiting,
}: {
  placement: BaseTooltipPlacement;
  isExiting?: boolean;
}) => MotionBaseSpec;
//# sourceMappingURL=tooltip.d.ts.map
