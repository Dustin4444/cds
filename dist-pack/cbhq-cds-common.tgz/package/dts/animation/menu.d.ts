export declare const animateMenuOpacityInConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    property: string;
    fromValue: number;
    toValue: number;
};
export declare const animateMenuOpacityOutConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    property: string;
    fromValue: number;
    toValue: number;
};
export declare const animateMenuTransformInConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    property: string;
    fromValue: number;
    toValue: number;
};
export declare const animateMenuTransformOutConfig: {
    easing: import("..").MotionCurve;
    duration?: import("..").MotionDuration | undefined;
    property: string;
    fromValue: number;
    toValue: number;
};
//# sourceMappingURL=menu.d.ts.map