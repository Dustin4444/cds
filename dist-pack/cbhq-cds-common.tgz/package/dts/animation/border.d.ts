import type { MotionBaseSpec } from '../types';
export declare const animateInputBorderInConfig: Omit<
  MotionBaseSpec,
  'property' | 'useNativeDriver'
>;
export declare const animateInputBorderOutConfig: Omit<
  MotionBaseSpec,
  'property' | 'useNativeDriver'
>;
//# sourceMappingURL=border.d.ts.map
