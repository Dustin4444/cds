import type { MotionBaseSpec } from '../types';
export declare const carouselVisibleOpacity = 1;
export declare const carouselDismissOpacity = 0;
export declare const carouselVisibleSize = 1;
export declare const carouselDismissSize = 0;
export declare const animateOpacityConfig: MotionBaseSpec;
export declare const animateSizeConfig: MotionBaseSpec;
//# sourceMappingURL=carousel.d.ts.map
