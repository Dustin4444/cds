import type { CollapsibleDirection, MotionBaseSpec } from '../types';
type CollapsibleMotionSpec = Record<CollapsibleDirection, MotionBaseSpec>;
export declare const collapsibleHiddenOpacity = 0;
export declare const collapsibleVisibleOpacity = 1;
export declare const collapsibleHiddenMaxSize = 0;
export declare const collapsibleVisibleMaxSize = 1000;
export declare const easing = 'global';
export declare const inDuration = 'slow1';
export declare const outDuration = 'moderate3';
export declare const animateInOpacityConfig: CollapsibleMotionSpec;
export declare const animateOutOpacityConfig: CollapsibleMotionSpec;
export declare const animateInMaxSizeConfig: CollapsibleMotionSpec;
export declare const animateOutMaxSizeConfig: CollapsibleMotionSpec;
export {};
//# sourceMappingURL=collapsible.d.ts.map
