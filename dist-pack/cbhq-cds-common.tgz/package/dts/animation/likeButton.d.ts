import type { MotionBaseSpec } from '../types';
export declare const activeScale = 1.2;
export declare const inactiveScale = 1;
export declare const scaleInConfig: MotionBaseSpec;
export declare const scaleOutConfig: MotionBaseSpec;
//# sourceMappingURL=likeButton.d.ts.map
