import type { MotionBaseSpec } from '../types';
type TabIndicatorMotionBaseSpec = Pick<MotionBaseSpec, 'easing' | 'duration' | 'property'>;
export declare const animateTabIndicatorBaseSpec: TabIndicatorMotionBaseSpec;
export {};
//# sourceMappingURL=tabs.d.ts.map
