export declare const accordionVisibleMaxHeight = 400;
export declare const accordionIconHiddenRotate = -180;
export declare const accordionIconVisibleRotate = 0;
//# sourceMappingURL=accordion.d.ts.map
