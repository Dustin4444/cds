import type { MotionBaseSpec } from '../types';
export declare const baseConfig: Pick<MotionBaseSpec, 'property' | 'easing' | 'duration'>;
//# sourceMappingURL=rotate.d.ts.map
