import type { MotionBaseSpec } from '../types';
export declare const modalHiddenOpacity = 0;
export declare const modalHiddenTranslateY = 80;
export declare const modalVisibleOpacity = 1;
export declare const modalVisibleTranslateY = 0;
export declare const animateInOpacityConfig: MotionBaseSpec;
export declare const animateOutOpacityConfig: MotionBaseSpec;
export declare const animateInTranslateYConfig: MotionBaseSpec;
export declare const animateOutTranslateYConfig: MotionBaseSpec;
export declare const animateInOverlayOpacityConfig: MotionBaseSpec;
export declare const animateOutOverlayOpacityConfig: MotionBaseSpec;
//# sourceMappingURL=fullscreenModal.d.ts.map
