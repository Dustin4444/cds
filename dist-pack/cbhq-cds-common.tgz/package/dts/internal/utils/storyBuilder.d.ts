import React from 'react';
type ArgType<T> = {
    name?: string;
    description?: string;
    defaultValue?: T;
    control?: 'text' | 'select' | 'boolean';
};
type ArgTypes<Props> = {
    [key in keyof Props]?: ArgType<Props[key]>;
};
type Parameters<Props, WrapperProps, Wrapper extends React.ComponentType<React.PropsWithChildren<WrapperProps>>> = {
    stories?: Story<Props, WrapperProps>[];
    wrapper?: Wrapper;
    wrapperProps?: WrapperProps;
    percy?: {
        /**  Boolean indicating whether or not to skip this story. */
        skip?: boolean;
        /** Story args to use when snapshotting. */
        args?: Props;
        /**  An array of additional snapshots to take of this story */
        additionalSnapshots?: {
            args?: Props;
        }[];
    };
    a11y?: {
        /**  Boolean indicating whether or not to skip the a11y test for this story. */
        skip?: boolean;
    };
    storyshots?: {
        /**  Boolean indicating whether or not to skip the a11y test for this story. */
        disable?: boolean;
    };
};
export type Story<Props, WrapperProps, ExampleFnReturnType = React.ReactElement<unknown>> = {
    (args: Props, context: StoryBuilderConfig<Props, WrapperProps>): ExampleFnReturnType;
    /**
     * Override the display name in the UI
     */
    storyName?: string;
    /**
     * Used to only include certain named exports as stories. Useful when you want to have non-story exports such as mock data or ignore a few stories.
     * @example
     * includeStories: ['SimpleStory', 'ComplexStory']
     * includeStories: /.*Story$/
     *
     * @see [Non-story exports](https://storybook.js.org/docs/formats/component-story-format/#non-story-exports)
     */
    includeStories?: string[] | RegExp;
    /**
     * Used to exclude certain named exports. Useful when you want to have non-story exports such as mock data or ignore a few stories.
     * @example
     * excludeStories: ['simpleData', 'complexData']
     * excludeStories: /.*Data$/
     *
     * @see [Non-story exports](https://storybook.js.org/docs/formats/component-story-format/#non-story-exports)
     */
    excludeStories?: string[] | RegExp;
    /**
     * Dynamic data that are provided (and possibly updated by) Storybook and its addons.
     * @see [Arg story inputs](https://storybook.js.org/docs/react/api/csf#args-story-inputs)
     */
    args?: Partial<Props>;
    /**
     * ArgTypes encode basic metadata for args, such as `name`, `description`, `defaultValue` for an arg. These get automatically filled in by Storybook Docs.
     * @see [Control annotations](https://github.com/storybookjs/storybook/blob/91e9dee33faa8eff0b342a366845de7100415367/addons/controls/README.md#control-annotations)
     */
    argTypes?: ArgTypes<Props>;
    /**
     * Custom metadata for a story.
     * @see [Parameters](https://storybook.js.org/docs/basics/writing-stories/#parameters)
     */
    parameters?: Parameters<Props, WrapperProps, React.ComponentType<React.PropsWithChildren<WrapperProps>>>;
    /**
     * Wrapper components or Storybook decorators that wrap a story.
     *
     * Decorators defined in Meta will be applied to every story variation.
     * @see [Decorators](https://storybook.js.org/docs/addons/introduction/#1-decorators)
     */
    decorators?: ((story: () => ExampleFnReturnType, context: StoryBuilderConfig<Props, WrapperProps>) => ExampleFnReturnType)[];
};
export type StoryBuilderConfig<Props, WrapperProps> = {
    args?: Props;
    argTypes?: ArgTypes<Props>;
    parameters?: Parameters<Props, WrapperProps, React.ComponentType<React.PropsWithChildren<WrapperProps>>>;
};
export declare const baseConfig: {
    args: {
        isDarkMode: boolean;
    };
    argTypes: {
        isDarkMode: {
            control: "boolean";
            description: string;
        };
    };
    parameters: {
        percy: {
            additionalSnapshots: {
                prefix: string;
                args: {
                    isDarkMode: boolean;
                };
            }[];
        };
    };
};
export declare function sanitizeProps<Props>(props: Props): Props;
export declare function storyBuilder<StoryBuilderArgs, WrapperProps>(builderConfig?: StoryBuilderConfig<StoryBuilderArgs, WrapperProps>): <Props, PropsWithoutChildren extends Omit<Props, "children">>(Component: React.ComponentType<React.PropsWithChildren<Props>>, sharedConfig?: StoryBuilderConfig<PropsWithoutChildren, WrapperProps>) => {
    build: <BuildWrapperProps>(args?: PropsWithoutChildren, customConfig?: StoryBuilderConfig<PropsWithoutChildren, BuildWrapperProps>) => Story<PropsWithoutChildren, WrapperProps, React.ReactElement<unknown, string | React.JSXElementConstructor<any>>>;
    buildSheet: <SheetWrapperProps>(args?: PropsWithoutChildren | PropsWithoutChildren[] | Readonly<PropsWithoutChildren> | readonly PropsWithoutChildren[], config?: StoryBuilderConfig<StoryBuilderConfig<PropsWithoutChildren, WrapperProps>["args"], SheetWrapperProps>) => Story<PropsWithoutChildren, WrapperProps, React.ReactElement<unknown, string | React.JSXElementConstructor<any>>>;
};
export {};
//# sourceMappingURL=storyBuilder.d.ts.map