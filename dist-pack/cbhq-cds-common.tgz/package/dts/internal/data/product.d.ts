export declare const product: {
  readonly navigationItems: readonly [
    {
      readonly title: 'Assets';
      readonly icon: 'chartPie';
    },
    {
      readonly title: 'Trade';
      readonly icon: 'trading';
    },
    {
      readonly title: 'Pay';
      readonly icon: 'pay';
    },
    {
      readonly title: 'For you';
      readonly icon: 'newsFeed';
    },
    {
      readonly title: 'Earn';
      readonly icon: 'giftBox';
    },
    {
      readonly title: 'Borrow';
      readonly icon: 'cash';
    },
    {
      readonly title: 'DeFi';
      readonly icon: 'defi';
    },
  ];
};
//# sourceMappingURL=product.d.ts.map
