export declare const feedImages: string[];
//# sourceMappingURL=feedImages.d.ts.map
