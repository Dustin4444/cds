export declare const prices: string[];
export declare const lowPrices: string[];
export declare const pricesWithScalingFactor: {
  yAxisScalingFactor: number;
  data: string[];
}[];
//# sourceMappingURL=prices.d.ts.map
