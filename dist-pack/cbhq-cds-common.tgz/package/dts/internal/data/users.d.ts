export declare const users: readonly [
  {
    readonly name: 'Donna';
    readonly role: 'Designer';
    readonly avatar: 'https://ca.slack-edge.com/E01HRQM32TX-U0295824QKD-ab8cab4b59a3-512';
  },
  {
    readonly name: 'Kat';
    readonly role: 'Engineer';
    readonly avatar: 'https://ca.slack-edge.com/E01HRQM32TX-UBVHL4UGJ-cce1f7d41786-512';
  },
];
//# sourceMappingURL=users.d.ts.map
