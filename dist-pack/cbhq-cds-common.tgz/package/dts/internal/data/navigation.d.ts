export declare const navigationOptions: {
  name: string;
  value: string;
  description: string;
  mediaName: string;
}[];
//# sourceMappingURL=navigation.d.ts.map
