export declare const avatarSizes: readonly ['s', 'm', 'l', 'xl', 'xxl', 'xxxl'];
export declare const avatars: readonly [
  'https://images.unsplash.com/profile-1611475141936-383e23c6cc6dimage?dpr=2&auto=format&fit=crop&w=32&h=32&q=60&crop=faces&bg=fff',
  'https://images.unsplash.com/profile-1628142977790-d9f66dcbc498image?dpr=2&auto=format&fit=crop&w=32&h=32&q=60&crop=faces&bg=fff',
];
//# sourceMappingURL=avatars.d.ts.map
