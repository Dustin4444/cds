export declare const iconSizes: readonly ['xs', 's', 'm', 'l'];
//# sourceMappingURL=iconData.d.ts.map
