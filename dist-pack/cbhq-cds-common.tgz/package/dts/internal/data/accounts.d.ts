export declare const accounts: (
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex: string;
        asset_id: string;
        slug: string;
        destination_tag_name?: undefined;
        destination_tag_regex?: undefined;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: string;
      updated_at: string;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      uk_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
      rewards_apy?: undefined;
      rewards?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex?: undefined;
        asset_id?: undefined;
        slug?: undefined;
        destination_tag_name?: undefined;
        destination_tag_regex?: undefined;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: string;
      updated_at: string;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      wire_deposit_information: {
        account_number: null;
        routing_number: string;
        bank_name: string;
        bank_address: string;
        bank_country: {
          code: string;
          name: string;
        };
        account_name: string;
        account_address: string;
        reference: string;
      };
      swift_deposit_information: null;
      uk_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
      rewards_apy?: undefined;
      rewards?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex?: undefined;
        asset_id?: undefined;
        slug?: undefined;
        destination_tag_name?: undefined;
        destination_tag_regex?: undefined;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: string;
      updated_at: string;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      uk_deposit_information: {
        sort_code: string;
        account_number: string;
        account_name: string;
        bank_name: string;
        reference: string;
      };
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
      rewards_apy?: undefined;
      rewards?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex?: undefined;
        asset_id?: undefined;
        slug?: undefined;
        destination_tag_name?: undefined;
        destination_tag_regex?: undefined;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: string;
      updated_at: string;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      sepa_deposit_information: {
        iban: string;
        swift: string;
        bank_name: string;
        bank_address: string;
        bank_country: {
          code: string;
          name: string;
        };
        account_name: string;
        account_address: string;
        reference: string;
      };
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      uk_deposit_information?: undefined;
      rewards_apy?: undefined;
      rewards?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex: string;
        asset_id: string;
        slug: string;
        destination_tag_name?: undefined;
        destination_tag_regex?: undefined;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: null;
      updated_at: null;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      uk_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
      rewards_apy?: undefined;
      rewards?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex: string;
        asset_id: string;
        slug: string;
        destination_tag_name?: undefined;
        destination_tag_regex?: undefined;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: null;
      updated_at: null;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      rewards_apy: string;
      rewards: {
        apy: string;
        formatted_apy: string;
        label: string;
      };
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      uk_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex: string;
        asset_id: string;
        destination_tag_name: string;
        destination_tag_regex: string;
        slug: string;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: null;
      updated_at: null;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      uk_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
      rewards_apy?: undefined;
      rewards?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex: string;
        asset_id: string;
        slug: string;
        destination_tag_name?: undefined;
        destination_tag_regex?: undefined;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: null;
      updated_at: null;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      rewards: {
        apy: string;
        formatted_apy: string;
        label: string;
      };
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      uk_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
      rewards_apy?: undefined;
    }
  | {
      id: string;
      name: string;
      primary: boolean;
      type: string;
      currency: {
        code: string;
        name: string;
        color: string;
        sort_index: number;
        exponent: number;
        type: string;
        address_regex: string;
        asset_id: string;
        destination_tag_name: string;
        destination_tag_regex: string;
        slug: string;
      };
      balance: {
        amount: string;
        currency: string;
      };
      created_at: null;
      updated_at: null;
      resource: string;
      resource_path: string;
      allow_deposits: boolean;
      allow_withdrawals: boolean;
      active: boolean;
      rewards: {
        apy: string;
        formatted_apy: string;
        label: string;
      };
      wire_deposit_information?: undefined;
      swift_deposit_information?: undefined;
      uk_deposit_information?: undefined;
      sepa_deposit_information?: undefined;
      rewards_apy?: undefined;
    }
)[];
//# sourceMappingURL=accounts.d.ts.map
