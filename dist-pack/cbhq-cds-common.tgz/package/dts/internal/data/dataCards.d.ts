export declare const dataCards: readonly [
  {
    readonly key: 'card1';
    readonly title: 'Crypto earned';
    readonly description: 'Earn $40 more by learning about new assets';
    readonly startLabel: '$80 earned';
    readonly progressVariant: 'circle';
    readonly progress: 0.8;
  },
  {
    readonly key: 'card2';
    readonly title: 'Cash borrowed';
    readonly description: 'Next payment due on Apr 15, 2021';
    readonly startLabel: '$12,500';
    readonly endLabel: '$35,000 left';
    readonly progressVariant: 'bar';
    readonly progress: 0.6;
  },
  {
    readonly key: 'card3';
    readonly title: 'Interest earned';
    readonly description: 'Earn up to 6.45% APY on your crypto';
    readonly startLabel: '$8.1234567';
    readonly endLabel: '2.00% APY';
  },
];
//# sourceMappingURL=dataCards.d.ts.map
