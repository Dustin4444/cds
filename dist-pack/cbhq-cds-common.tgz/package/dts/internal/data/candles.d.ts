export declare const candles: {
  start: string;
  low: string;
  high: string;
  open: string;
  close: string;
  volume: string;
}[];
//# sourceMappingURL=candles.d.ts.map
