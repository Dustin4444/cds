export declare const sampleTabs: {
  id: string;
  label: string;
  testID: string;
}[];
export declare const longTextTabs: (
  | {
      id: string;
      label: string;
      testID: string;
    }
  | {
      id: string;
      label: string;
      testID?: undefined;
    }
)[];
//# sourceMappingURL=tabs.d.ts.map
