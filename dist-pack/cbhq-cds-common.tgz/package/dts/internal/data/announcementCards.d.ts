import type { SpotSquareName } from '@cbhq/cds-illustrations';
export declare const announcementCards: {
  title: string;
  description: string;
  spotSquare: SpotSquareName;
  actionLabel: string;
  onActionPress: () => void;
  key: string;
}[];
//# sourceMappingURL=announcementCards.d.ts.map
