export declare const asset: {
  data: {
    marketHealth: {
      timestamp: string;
      marketCapStats: {
        percentChange: number;
      };
    };
    viewer: {
      assetByUuid: {
        asset: {
          uuid: string;
          name: string;
          latestPercentChanges: {
            year: number;
            day: number;
            week: number;
            hour: number;
            month: number;
            all: number;
          };
          id: string;
          symbol: string;
          contractAddress: null;
          experimental: boolean;
          slug: string;
          description: string;
          circulatingSupply: string;
          maxSupply: string;
          dominance: number;
          volume24h: string;
          volumePercentChange24h: number;
          tradableMarketCapRank: number;
          marketCap: string;
          signals: {
            holdTime: {
              value: number;
              updatedAt: string;
            };
            percentHolding: {
              rank: number;
              updatedAt: string;
              value: number;
            };
            tradingActivity: {
              updatedAt: string;
              value: number;
            };
            priceCorrelations: {
              assetCorrelations: {
                __typename: string;
                correlation: number;
                asset: {
                  uuid: string;
                  imageUrl: string;
                  name: string;
                  latestQuote: {
                    price: string;
                    quoteCurrency: string;
                  };
                  id: string;
                };
              }[];
            };
          };
          color: string;
          imageUrl: string;
          resources: {
            link: {
              url: string;
              text: string;
            };
            iconUrl: string;
            type: string;
          }[];
          newsArticles: {
            edges: {
              node: {
                uuid: string;
                attributionSource: string;
                title: string;
                publicationDate: string;
                linkUrl: string;
                images: {
                  url: string;
                }[];
                relatedAssets: {
                  uuid: string;
                  color: string;
                  name: string;
                  id: string;
                }[];
                id: string;
              };
            }[];
          };
          assetIssuerFeed: {
            edges: never[];
          };
          latestQuote: {
            price: string;
          };
          priceDataForHour: {
            quotes: {
              price: string;
              timestamp: string;
            }[];
          };
          priceDataForDay: {
            quotes: {
              price: string;
              timestamp: string;
            }[];
          };
          priceDataForWeek: {
            quotes: {
              price: string;
              timestamp: string;
            }[];
          };
          priceDataForMonth: {
            quotes: {
              price: string;
              timestamp: string;
            }[];
          };
          priceDataForYear: {
            quotes: {
              price: string;
              timestamp: string;
            }[];
          };
          priceDataForAll: {
            quotes: {
              price: string;
              timestamp: string;
            }[];
          };
        };
        id: string;
        reward: null;
        supportedContexts: {
          tradable: boolean;
          wallet: boolean;
          brokerage: boolean;
          convertible: boolean;
          staking: boolean;
          interest: boolean;
        };
        rewardPrincipalInsolvency: {
          event: null;
          id: string;
        };
        accounts: {
          primary: boolean;
          uuid: string;
          availableBalance: {
            value: string;
          };
          id: string;
        }[];
        earnCard: null;
      };
      id: string;
      portfolioPerformance: {
        latestValue: string;
      };
    };
  };
};
//# sourceMappingURL=asset.d.ts.map
