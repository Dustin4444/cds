import type { SpotSquareName } from '@cbhq/cds-illustrations';
export declare const featureEntryCards: (
  | {
      key: string;
      title: string;
      description: string;
      spotSquare: SpotSquareName;
      actionLabel: string;
      onActionPress: () => void;
    }
  | {
      key: string;
      title: string;
      description: string;
      spotSquare: SpotSquareName;
      actionLabel?: undefined;
      onActionPress?: undefined;
    }
)[];
//# sourceMappingURL=featureEntryCards.d.ts.map
