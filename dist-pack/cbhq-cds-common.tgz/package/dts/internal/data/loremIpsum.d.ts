export declare const loremIpsum =
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu justo nulla. Nam eu blandit dui, a dignissim mi. ';
//# sourceMappingURL=loremIpsum.d.ts.map
