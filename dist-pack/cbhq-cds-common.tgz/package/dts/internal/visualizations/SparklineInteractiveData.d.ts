import type { ChartDataPoint, ChartTimeseries } from '../../types/Chart';
export type SparklinePeriod = 'hour' | 'day' | 'week' | 'month' | 'year' | 'all';
export declare const sparklineInteractiveData: {
  hour: ChartDataPoint[];
  day: ChartDataPoint[];
  week: ChartDataPoint[];
  month: ChartDataPoint[];
  year: ChartDataPoint[];
  all: ChartDataPoint[];
};
export declare const strokeColor = '#F7931A';
export declare const sparklineInteractiveHoverData: Record<SparklinePeriod, ChartTimeseries[]>;
//# sourceMappingURL=SparklineInteractiveData.d.ts.map
