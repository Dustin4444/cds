import type { PaddingProps } from '../types';
export declare const getCardBodySpacingProps: ({
  padding,
  paddingX,
  paddingY,
  paddingTop,
  paddingEnd,
  paddingBottom,
  paddingStart,
  compact,
}: {
  compact?: boolean;
} & PaddingProps) => Pick<
  PaddingProps,
  'paddingTop' | 'paddingBottom' | 'paddingStart' | 'paddingEnd'
>;
//# sourceMappingURL=getCardBodySpacingProps.d.ts.map
