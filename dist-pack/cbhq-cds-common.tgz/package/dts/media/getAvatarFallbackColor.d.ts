import type { AvatarFallbackColor } from '../types';
export declare const rgbToAvatarFallbackColor: (color: string) => AvatarFallbackColor;
/**
 * Generates a fallback color for an Avatar based on a unique identifier
 */
export declare const getAvatarFallbackColor: (
  id: string,
) => import('@cbhq/cds-common/core/theme').ThemeVars.SpectrumHue;
//# sourceMappingURL=getAvatarFallbackColor.d.ts.map
