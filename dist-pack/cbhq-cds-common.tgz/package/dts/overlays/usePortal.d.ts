export declare const usePortal: () => import('./PortalContext').PortalProviderStates;
//# sourceMappingURL=usePortal.d.ts.map
