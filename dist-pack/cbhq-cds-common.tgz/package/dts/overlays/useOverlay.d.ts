import type { PortalNode } from './usePortalState';
export declare const useOverlay: (idPrefix?: string) => {
  open: (content: PortalNode['element']) => string;
  close: () => void;
};
//# sourceMappingURL=useOverlay.d.ts.map
