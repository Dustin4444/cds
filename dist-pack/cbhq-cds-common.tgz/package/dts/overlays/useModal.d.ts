/**
 * @deprecated Use the `visible` and `onRequestClose` props as outlined in the docs here https://cds.coinbase.com/components/modal#get-started. This will be removed in a future major release.
 * @deprecationExpectedRemoval v7
 */
export declare const useModal: () => {
    openModal: (content: import("./usePortalState").PortalNode["element"]) => string;
    closeModal: () => void;
};
//# sourceMappingURL=useModal.d.ts.map