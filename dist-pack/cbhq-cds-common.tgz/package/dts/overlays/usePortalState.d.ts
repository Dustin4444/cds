import type React from 'react';
/**
 * This type defines the basic interface of a Component rendered through the PortalProvider.
 */
export type PortalNode = {
  id: string;
  element: React.ReactElement<{
    visible: boolean;
    onDidClose: () => void;
    children?: React.ReactNode;
    ref?: React.Ref<{
      onRequestClose: () => void;
    }>;
  }>;
};
/**
 * This hook is used to manage the state of a set of nodes rendered through the PortalProvider.
 */
export declare const usePortalState: () => {
  nodes: PortalNode[];
  addNode: (id: string, element: PortalNode['element']) => void;
  removeNode: (id: string) => void;
};
//# sourceMappingURL=usePortalState.d.ts.map
