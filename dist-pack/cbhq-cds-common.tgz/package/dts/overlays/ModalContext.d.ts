export type ModalContextValue = {
  /**
   * Controls visibility of the Modal
   * @default false
   */
  visible: boolean;
  /**
   * Callback function fired when modal is closed.
   */
  onRequestClose: () => void;
  /**
   * Hide top and bottom dividers inside Modal body
   * @default false
   */
  hideDividers?: boolean;
  /**
   * Hide the close icon on the top right
   * @default false
   */
  hideCloseButton?: boolean;
  accessibilityLabelledBy?: string;
};
export declare const ModalContext: import('react').Context<ModalContextValue>;
export declare const useModalContext: () => ModalContextValue;
//# sourceMappingURL=ModalContext.d.ts.map
