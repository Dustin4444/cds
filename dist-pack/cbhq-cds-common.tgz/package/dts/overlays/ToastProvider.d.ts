import React from 'react';
import type { ThemeVars } from '../core/theme';
import type { OverlayLifecycleProps, SharedAccessibilityProps, SharedProps } from '../types';
export type ToastRefHandle = {
    hide: () => Promise<boolean>;
};
export type ToastDuration = {
    /**
     * Duration in milliseconds.
     * Duration is automatically calculated
     * @danger This will override default calculated value.
     */
    duration?: number;
};
export type ToastAction = SharedProps & {
    /**
     * Label for the action button
     */
    label: string;
    /**
     * Callback function fired when the button is pressed
     */
    onPress: () => void;
};
export type ToastBaseProps = SharedProps & SharedAccessibilityProps & Pick<OverlayLifecycleProps, 'onWillHide' | 'onDidHide'> & {
    /**
     * The message to be displayed in the toast
     */
    text: string;
    /**
     * Optional toast action i.e. a CTA button
     */
    action?: ToastAction;
    /**
     * The vertical offset from the bottom of the screen
     */
    bottomOffset?: string | number;
    /**
     * Controls color surge of the Toast background
     * @default primary
     */
    variant?: ThemeVars.Color;
};
export type ToastElement = React.ReactElement<ToastBaseProps & {
    ref?: React.Ref<ToastRefHandle>;
}>;
/**
 * The data structure managed by the ToastProvider.
 * It composes together the Toast element requested to be rendered and the duration for which it should be displayed.
 */
export type ToastNode = {
    duration: number;
    element: ToastElement;
};
export type ToastProviderProps = {
    /**
     * An optional, global override to individual Toasts' bottomOffset prop.
     * This value will be applied to all Toasts render via this Provider instance
     */
    toastBottomOffset?: ToastBaseProps['bottomOffset'];
};
export type ToastProviderStates = {
    activeToast?: ToastNode;
    addToast: (element: ToastNode['element'], duration: number) => void;
    removeToast: () => void;
    hideToast: () => void;
    clearToastQueue: () => void;
    pauseTimer: () => void;
    resumeTimer: () => void;
};
export declare const ToastContext: React.Context<ToastProviderStates>;
export declare const ToastProvider: React.FC<React.PropsWithChildren<ToastProviderProps>>;
//# sourceMappingURL=ToastProvider.d.ts.map