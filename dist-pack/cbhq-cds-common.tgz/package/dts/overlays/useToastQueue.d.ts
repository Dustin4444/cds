import type { ToastNode } from './ToastProvider';
export declare const useToastQueue: () => {
  activeToast: ToastNode | undefined;
  addToast: (element: ToastNode['element'], duration: number) => void;
  removeToast: () => void;
  hideToast: () => Promise<boolean | undefined>;
  clearToastQueue: () => Promise<void>;
  pauseTimer: () => number;
  resumeTimer: () => void;
};
//# sourceMappingURL=useToastQueue.d.ts.map
