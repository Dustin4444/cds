export type OverlayContentContextValue = {
  /** True if we are inside any overlay component like Overlay, Modal, Tray, or Drawer. */
  isOverlay?: boolean;
  /** True if we are inside a Modal component. */
  isModal?: boolean;
  /** True if we are inside a Drawer or Tray component. */
  isDrawer?: boolean;
  /** True if we are inside a Tour component. */
  isTour?: boolean;
};
export declare const OverlayContentContext: import('react').Context<OverlayContentContextValue>;
export declare const useOverlayContentContext: () => OverlayContentContextValue;
//# sourceMappingURL=OverlayContentContext.d.ts.map
