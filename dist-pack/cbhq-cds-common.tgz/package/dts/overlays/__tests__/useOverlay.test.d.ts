export {};
//# sourceMappingURL=useOverlay.test.d.ts.map
