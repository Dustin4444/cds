import type { PortalNode } from './usePortalState';
export type PortalProviderStates = {
  addNode: (id: string, element: PortalNode['element']) => void;
  removeNode: (id: string) => void;
  nodes: PortalNode[];
};
export declare const PortalContext: import('react').Context<PortalProviderStates>;
//# sourceMappingURL=PortalContext.d.ts.map
