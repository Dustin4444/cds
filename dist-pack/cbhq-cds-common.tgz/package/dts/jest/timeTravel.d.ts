export declare const FRAME_TIME = 10;
/**
 * Setup tests for time travel (start date)
 */
export declare function setup(startDate?: string): void;
/**
 * Travel a specific amount of time (in ms) inside a test
 */
export declare function timeTravel(time?: number): void;
/**
 * End test with time travel
 */
export declare function teardown(): void;
export declare const withTimeTravel: (func: (cb: typeof timeTravel) => void) => void;
//# sourceMappingURL=timeTravel.d.ts.map
