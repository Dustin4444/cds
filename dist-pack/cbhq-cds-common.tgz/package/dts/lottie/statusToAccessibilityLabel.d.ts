import type { LottieStatus } from '../types/LottieStatus';
export declare const lottieStatusToAccessibilityLabel: Record<LottieStatus, string>;
//# sourceMappingURL=statusToAccessibilityLabel.d.ts.map
