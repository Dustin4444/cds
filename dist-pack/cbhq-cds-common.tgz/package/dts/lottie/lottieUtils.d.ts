import type { LottieMarkersAsMap, LottieSource } from '../types';
type GetLottieMarkerOptions = {
  /** Convert frames to milliseconds (ms) */
  ms?: boolean;
};
export declare function getLottieFrameToMs(frame: number, fr: number): number;
export declare function getLottieDuration(source: LottieSource): number;
export declare function getLottieFrameRate(source: LottieSource): number;
export declare function getLottieMarkers<T extends LottieSource>(
  source: T,
  opts?: GetLottieMarkerOptions,
): LottieMarkersAsMap<T>;
export {};
//# sourceMappingURL=lottieUtils.d.ts.map
