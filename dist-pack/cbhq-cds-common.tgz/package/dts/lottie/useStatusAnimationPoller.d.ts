import type { LottiePlayer } from '../types/LottiePlayer';
import type { LottieSource } from '../types/LottieSource';
import type { LottieStatusAnimationType } from '../types/LottieStatusAnimationProps';
type TradeStatusLottie = LottieSource<
  | 'loadingStart'
  | 'loadingEnd'
  | 'successCardStart'
  | 'successCardEnd'
  | 'successStart'
  | 'successEnd'
  | 'failureStart'
  | 'failureEnd'
  | 'pendingStart'
  | 'pendingEnd'
  | 'pendingAltStart'
  | 'pendingAltLoopStart'
  | 'pendingAltLoopEnd'
  | 'pendingAltEnd'
  | 'successAltStart'
  | 'successAltEnd'
  | 'failureAltStart'
  | 'failureAltEnd'
>;
type UseStatusAnimationPollerParams = {
  status?: LottieStatusAnimationType;
  playMarkers?: LottiePlayer<TradeStatusLottie>['playMarkers'];
  onFinish?: () => void;
};
export declare const useStatusAnimationPoller: ({
  status,
  playMarkers,
  onFinish,
}: UseStatusAnimationPollerParams) => () => void;
export {};
//# sourceMappingURL=useStatusAnimationPoller.d.ts.map
