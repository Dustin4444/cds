import type { ColorScheme } from '../core/theme';
import type { A11yColorUsage, GradientArray } from '../types/Color';
type GetAccessibleForegroundGradientParams = {
  background: string;
  color: string;
  /** Active colorScheme (light or dark) */
  colorScheme: ColorScheme;
  /** Where the foreground color is being applied. */
  usage: A11yColorUsage;
};
export declare const getAccessibleForegroundGradient: ({
  background,
  color,
  colorScheme,
  usage,
}: GetAccessibleForegroundGradientParams) => GradientArray;
export {};
//# sourceMappingURL=getAccessibleForegroundGradient.d.ts.map
