import { type ColorCommonInstance, type RGBColor } from 'd3-color';
export type ColorValue =
  | string
  | {
      r: number;
      g: number;
      b: number;
      opacity?: number;
    }
  | ColorCommonInstance;
type BlendColorsParams = {
  underlayColor: ColorValue;
  overlayColor: ColorValue;
};
export declare const getRGBColor: (color: ColorValue) => RGBColor;
/**
 * The overlayColor value must have an alpha less than 1 in order to output a different color.
 * @param underlayColor ColorValue
 * @param overlayColor  ColorValue
 * @returns rbgString
 */
export declare const blendColors: ({ underlayColor, overlayColor }: BlendColorsParams) => RGBColor;
export {};
//# sourceMappingURL=blendColors.d.ts.map
