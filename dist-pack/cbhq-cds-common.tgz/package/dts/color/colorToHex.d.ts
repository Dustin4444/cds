/**
 * @param color - any valid color value, i.e. `rgba(255, 255, 255, 1)`
 * @returns hex - `#ffffff`
 * @website https://github.com/d3/d3-color#color
 */
export declare const colorToHex: (value: string) => string;
//# sourceMappingURL=colorToHex.d.ts.map
