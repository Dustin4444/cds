import type { ColorScheme } from '../core/theme';
/**
 * Configuration for the color scheme.
 *
 * For each color scheme, it has an underlay color and a high contrast luminance threshold.
 * The underlay color is the color that is used to blend with the overlay color.
 * The high contrast luminance threshold is the luminance value, above (in dark color scheme)
 * or below (in light color scheme) which the overlay color is considered in high contrast to the underlay color.
 */
export type ColorBlendConfigByColorScheme = {
  light: {
    underlayColor: string;
    highContrastLuminanceThreshold: number;
  };
  dark: {
    underlayColor: string;
    highContrastLuminanceThreshold: number;
  };
};
/**
 * The type of easing function to use for opacity adjustment.
 * - `linear`: A straight linear progression.
 * - `ease-out`: An "ease-out" curve, where the adjustment starts fast and slows down as the luminance delta gets larger. This is the default.
 * - `ease-in`: An "ease-in" curve, where the adjustment starts slow and speeds up as the luminance delta.
 */
export type BlendOpacityAdjustmentEasingFunction = 'linear' | 'ease-in' | 'ease-out';
/**
 * Configuration for fine-tuning the automatic blend opacity adjustment.
 */
export type BlendOpacityAdjustmentConfig = {
  /**
   * The minimum luminance difference between the overlay and underlay colors, below which no opacity adjustment occurs.
   * A value between 0 and 1.
   * @default 0.2
   */
  noAdjustmentLuminanceDelta: number;
  /**
   * This ratio controls the maximum strength of the opacity adjustment. It is a proportion of the "available
   * room for increase" (the difference between the starting blend opacity and 1.0).
   * @default 0.75
   */
  adjustmentStrengthRatio: number;
  /**
   * The easing function to use for the opacity adjustment.
   * @default 'ease-out'
   */
  adjustmentEasingFunction?: BlendOpacityAdjustmentEasingFunction;
};
/**
 * Configuration for the `getBlendedColor` function.
 */
export type ColorBlendConfig = {
  /**
   * The overlay color to create a variation of (CSS color string, hex, rgb, hsl, etc.).
   */
  overlayColor: string;
  /**
   * The opacity of the overlay color when blending (0-1).
   * A value of `1` means the color is fully opaque (no blending).
   * Lower values result in more blending with the background.
   */
  blendOpacity: number;
  /**
   * Optional configuration to fine-tune the automatic opacity adjustment logic.
   */
  blendOpacityAdjustmentConfig?: BlendOpacityAdjustmentConfig;
  /**
   * The current color scheme ('light' or 'dark').
   */
  colorScheme: ColorScheme;
  /**
   * Optional configuration for the color schemes, including underlay colors and luminance thresholds.
   */
  configByColorScheme?: ColorBlendConfigByColorScheme;
  /**
   * If true, disables automatic contrast optimization and always uses the current color scheme for blending.
   * @default false
   */
  skipContrastOptimization?: boolean;
};
/**
 * Creates subtle color variations by blending overlay color with underlay color based on the input color's luminance
 * and current theme. Automatically optimizes for contrast unless disabled.
 *
 * @param config - The configuration for the function.
 * @returns CSS color string with the blended result.
 *
 * @example
 * ```typescript
 * // Light theme
 * const lightVariation = getBlendedColor({
 *   overlayColor: '#0052ff',
 *   blendOpacity: 0.88,
 *   colorScheme: 'light'
 * });
 *
 * // Dark theme
 * const darkVariation = getBlendedColor({
 *   overlayColor: '#0052ff',
 *   blendOpacity: 0.82,
 *   colorScheme: 'dark'
 * });
 *
 * // Skip contrast optimization
 * const simpleVariation = getBlendedColor({
 *   overlayColor: '#0052ff',.
 *   blendOpacity: 0.75,
 *   colorScheme: 'light',
 *   skipContrastOptimization: true
 * });
 * ```
 */
export declare const getBlendedColor: ({
  overlayColor,
  blendOpacity,
  blendOpacityAdjustmentConfig,
  colorScheme,
  configByColorScheme,
  skipContrastOptimization,
}: ColorBlendConfig) => string;
//# sourceMappingURL=getBlendedColor.d.ts.map
