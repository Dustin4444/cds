export {};
//# sourceMappingURL=isLightOrDarkColor.test.d.ts.map
