export {};
//# sourceMappingURL=overrideAlpha.test.d.ts.map
