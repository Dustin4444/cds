/**
 * The Web Content Accessibility Guidelines (WCAG) include convenient quantitative recommendations for making text and graphics accessible based on the minimum acceptable contrast of foreground against background.
 * For example, black on yellow has a high contrast ratio (19.56) and therefore should be easier to read, whereas blue on blue is low contrast (2.31) and harder to read.
 */
export declare const getContrastRatio: (background: string, foreground: string) => number;
//# sourceMappingURL=getContrastRatio.d.ts.map
