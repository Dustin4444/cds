export declare const darkenColor: (value: string) => string | undefined;
//# sourceMappingURL=darkenColor.d.ts.map
