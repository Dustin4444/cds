/**
 * Relative luminance is the relative brightness of any point in an RGB colorspace, normalized to 0 for darkest black and 1 for lightest white.
 *
 * Edge cases:
 * - Returns undefined for invalid color values or non-parseable color strings
 * - HSL colors outside the RGB gamut will have their RGB components clamped to [0,255], which may not preserve the original color relationships
 * - Special color keywords like 'currentColor' or 'transparent' will return undefined
 * - CSS Variables or dynamic values cannot be calculated
 *
 * @see https://contrastchecker.online/color-relative-luminance-calculator
 */
export declare const getLuminance: (value: string) => number | undefined;
//# sourceMappingURL=getLuminance.d.ts.map
