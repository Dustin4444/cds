export declare const isLightOrDarkColor: (value: string) => "dark" | "light";
//# sourceMappingURL=isLightOrDarkColor.d.ts.map