/**
 * Modify the alpha value of an rgba string
 * @param color - valid color value, i.e. `#ffffff` or`rgba(255, 255, 255, 1)`
 * @param newOpacity - 0.5
 * @returns rgbaString - `rgba(255, 255, 255, 0.5)`
 */
export declare const overrideAlpha: (value: string, opacity: number) => string;
//# sourceMappingURL=overrideAlpha.d.ts.map
