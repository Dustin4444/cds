export declare const useValueChanges: (newValue: string) => {
  hasChanged: boolean;
  hasNotChanged: boolean;
  previousValue: unknown;
  newValue: string;
  addPreviousValue: (newValue: unknown) => void;
};
//# sourceMappingURL=useValueChanges.d.ts.map
