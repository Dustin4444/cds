export type RefMapOptions<RefValue> = {
  initialRefMap?: Record<string, RefValue>;
};
export type RefMapItem = {
  id: string;
};
export type RefMapApi<RefValue> = {
  refs: Record<string, RefValue>;
  getRef: (id: string) => RefValue | null;
  registerRef: (id: string, ref: RefValue) => void;
};
export declare const useRefMap: <RefValue>({
  initialRefMap,
}?: RefMapOptions<RefValue>) => RefMapApi<RefValue>;
//# sourceMappingURL=useRefMap.d.ts.map
