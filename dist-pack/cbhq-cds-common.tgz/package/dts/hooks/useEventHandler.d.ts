import type {
  EventHandlerAction,
  EventHandlerComponent,
  EventHandlerCustomConfig,
} from '../system/EventHandlerProvider';
export declare const useEventHandler: (
  component: EventHandlerComponent,
  action: EventHandlerAction,
  eventConfig?: EventHandlerCustomConfig,
  analyticsId?: string,
) => () => void;
//# sourceMappingURL=useEventHandler.d.ts.map
