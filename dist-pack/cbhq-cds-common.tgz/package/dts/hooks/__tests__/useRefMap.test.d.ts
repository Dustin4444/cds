export {};
//# sourceMappingURL=useRefMap.test.d.ts.map
