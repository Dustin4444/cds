export {};
//# sourceMappingURL=useFallbackShape.test.d.ts.map
