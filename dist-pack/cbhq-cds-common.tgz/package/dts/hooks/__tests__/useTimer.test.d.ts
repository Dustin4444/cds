export {};
//# sourceMappingURL=useTimer.test.d.ts.map
