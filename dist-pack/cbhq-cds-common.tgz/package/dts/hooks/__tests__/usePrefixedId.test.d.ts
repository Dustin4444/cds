export {};
//# sourceMappingURL=usePrefixedId.test.d.ts.map
