export declare function usePreviousValues<T>(initialValues?: T[]): {
  addPreviousValue: (newValue: T) => void;
  getPreviousValue: (allowDuplicates?: boolean) => T | undefined;
};
//# sourceMappingURL=usePreviousValues.d.ts.map
