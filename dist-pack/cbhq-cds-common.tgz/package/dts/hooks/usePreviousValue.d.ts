export declare const usePreviousValue: <T>(value: T) => T | undefined;
//# sourceMappingURL=usePreviousValue.d.ts.map
