import type { Shape } from '../types/Shape';
export type UseFallbackShapeOptions = {
    disableRandomRectWidth?: boolean;
    rectWidthVariant?: number;
};
export declare function useFallbackShape<T = string | number>(shape: Shape, baseWidth: T, options?: UseFallbackShapeOptions): {
    borderRadius: number;
    width: number | T;
};
//# sourceMappingURL=useFallbackShape.d.ts.map