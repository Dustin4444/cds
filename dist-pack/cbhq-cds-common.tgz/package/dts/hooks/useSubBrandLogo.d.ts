import type { ColorScheme } from '../core/theme';
type SubBrandLogoData = {
  viewBox: string;
  logoPath: string;
  typePath: string;
};
type SubBrandLogoDataByType = {
  analytics: SubBrandLogoData;
  ventures: SubBrandLogoData;
  assetHub: SubBrandLogoData;
  commerce: SubBrandLogoData;
  wallet: SubBrandLogoData;
  internationalExchange: SubBrandLogoData;
  privateClient: SubBrandLogoData;
  account: SubBrandLogoData;
  card: SubBrandLogoData;
  cloud: SubBrandLogoData;
  nft: SubBrandLogoData;
  pay: SubBrandLogoData;
  help: SubBrandLogoData;
  tracer: SubBrandLogoData;
  exchange: SubBrandLogoData;
  one: SubBrandLogoData;
  business: SubBrandLogoData;
  tokenManager: SubBrandLogoData;
};
type SubBrandLogoMarkData = SubBrandLogoDataByType & {
  base: SubBrandLogoData;
};
type SubBrandLogoWordmarkData = SubBrandLogoDataByType & {
  advanced: SubBrandLogoData;
  derivativesExchange: SubBrandLogoData;
  prime: SubBrandLogoData;
};
export type SubBrandLogoType = keyof SubBrandLogoDataByType;
export type SubBrandLogoMarkType = keyof SubBrandLogoMarkData;
export type SubBrandLogoWordmarkType = keyof SubBrandLogoWordmarkData;
export type SubBrandLogoWordmarkParams = {
  type: SubBrandLogoWordmarkType;
  foreground?: boolean;
  colorScheme: ColorScheme;
};
export type SubBrandLogoMarkParams = {
  type: SubBrandLogoMarkType;
  foreground?: boolean;
  colorScheme: ColorScheme;
};
export declare const useSubBrandLogoWordmark: ({
  foreground,
  type,
  colorScheme,
}: SubBrandLogoWordmarkParams) => {
  logoColor: string;
  typeColor: string;
  viewBox: string;
  logoPath: string;
  typePath: string;
};
export declare const useSubBrandLogoMark: ({
  foreground,
  type,
  colorScheme,
}: SubBrandLogoMarkParams) => {
  logoColor: string;
  typeColor: string;
  viewBox: string;
  logoPath: string;
  typePath: string;
};
export {};
//# sourceMappingURL=useSubBrandLogo.d.ts.map
