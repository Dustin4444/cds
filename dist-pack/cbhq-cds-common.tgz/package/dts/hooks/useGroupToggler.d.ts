export type GroupToggleState<T extends string> = {
  select: (value?: T) => void;
  unselect: (value?: T) => void;
  toggle: (value?: T) => void;
  isAllSelected: boolean | 'mixed';
};
/**
 *
 * @param values - An array of all possible options. Make sure the array doesn't change if it's the same values so that the handlers will also stay the same.
 * @param initialState - Initial checked option values.
 * @returns [
 *  selectedValues,
    {
      select,
      unselect,
      toggle,
      isAllSelected,
    }
  ]
 */
/**
 * @deprecated Do not use this. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const useGroupToggler: <T extends string>(
  values: T[],
  initialState?: T[],
) => [Set<T>, GroupToggleState<T>];
//# sourceMappingURL=useGroupToggler.d.ts.map
