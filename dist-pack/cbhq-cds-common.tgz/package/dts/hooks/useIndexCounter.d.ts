type StepTrackerParams = {
  length: number;
  startIndex?: number;
  onDecrement?: (newIndex: number) => void;
  onIncrement?: (newIndex: number) => void;
  onMinDecrement?: () => void;
  onMaxIncrement?: () => void;
};
export declare function useIndexCounter({
  length,
  startIndex,
  onDecrement,
  onIncrement,
  onMinDecrement,
  onMaxIncrement,
}: StepTrackerParams): {
  activeIndex: number;
  setActiveIndex: import('react').Dispatch<import('react').SetStateAction<number>>;
  isAtMin: boolean;
  isAtMax: boolean;
  handleDecrement: () => void;
  handleIncrement: () => void;
};
export {};
//# sourceMappingURL=useIndexCounter.d.ts.map
