/**
 * @deprecated Use React.useState instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare function useToggler(initial?: boolean): [
  boolean,
  {
    toggleOn: () => void;
    toggleOff: () => void;
    toggle: () => void;
  },
];
//# sourceMappingURL=useToggler.d.ts.map
