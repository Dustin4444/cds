import type { RecursiveKeyOf } from '../types/Helpers';
type UseSortParams<T> = Readonly<{
  /** An array of data we want to sort.  */
  data: readonly T[];
  /**
   * Key for the item we're sorting.
   * Use null/undefined to sort a simple array of strings or numbers
   * @example 'asset.name'
   */
  sortBy?: RecursiveKeyOf<T>;
  /**
   * The direction to sort items.
   * @default ascending
   */
  sortDirection?: React.TdHTMLAttributes<HTMLTableCellElement>['aria-sort'];
}>;
export declare const useSort: <T>({ data, sortBy, sortDirection }: UseSortParams<T>) => T[];
export {};
//# sourceMappingURL=useSort.d.ts.map
