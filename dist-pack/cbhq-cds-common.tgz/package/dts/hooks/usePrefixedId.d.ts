type IdentifierPrefix = string | string[] | null;
type PrefixedIdResult<T extends IdentifierPrefix> = T extends string
  ? string
  : T extends string[]
    ? string[]
    : string;
/**
 * Returns a prefixed id or array of prefixed ids from React.useId
 * that are SSR safe and unique across the application.
 * @param IdentifierPrefix - A string or array of strings to prefix the id with (optional).
 * @link https://react.dev/reference/react/useId#useid
 * @returns string | string[]
 */
export declare const usePrefixedId: <T extends IdentifierPrefix = null>(
  identifierPrefix?: T,
) => PrefixedIdResult<T>;
export {};
//# sourceMappingURL=usePrefixedId.d.ts.map
