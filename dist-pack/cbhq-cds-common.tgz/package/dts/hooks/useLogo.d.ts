import type { ColorScheme } from '../core/theme';
export declare const blue = "#0052FF";
export declare const black = "#0A0B0D";
export declare const white = "#FFFFFF";
export type LogoMarkParams = {
    size?: 16 | 24 | 32;
    foreground?: boolean;
    colorScheme: ColorScheme;
};
export type LogoWordmarkParams = {
    foreground?: boolean;
    colorScheme: ColorScheme;
};
export declare const useLogoWordmark: ({ foreground, colorScheme }: LogoWordmarkParams) => {
    color: string;
    viewBox: string;
    path: string;
};
export declare const useLogoMark: ({ size, foreground, colorScheme }: LogoMarkParams) => {
    color: string;
    path: string;
    viewBox: string;
    width: 32 | 16 | 24;
    height: 32 | 16 | 24;
};
//# sourceMappingURL=useLogo.d.ts.map