export declare const useTimer: () => {
  start: (callback: () => void, duration: number) => void;
  clear: () => void;
  pause: () => number;
  resume: () => void;
  getRemainingTime: () => number;
  reset: () => void;
};
//# sourceMappingURL=useTimer.d.ts.map
