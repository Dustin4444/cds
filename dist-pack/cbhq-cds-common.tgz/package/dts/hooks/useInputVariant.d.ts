import type { InputVariant } from '../types/InputBaseProps';
export declare const useInputVariant: (focused: boolean, variant: InputVariant) => InputVariant;
//# sourceMappingURL=useInputVariant.d.ts.map
