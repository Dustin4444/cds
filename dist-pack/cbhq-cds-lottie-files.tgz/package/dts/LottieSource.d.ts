/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
export type LottieMarker<T extends string> = {
  tm: number;
  cm: T;
  dr: number;
};
export type LottieSource<Marker extends string = string> = {
  meta: Record<string, unknown>;
  v: string;
  fr: number;
  ip: number;
  op: number;
  w: number;
  h: number;
  nm: string;
  ddd: number;
  assets: unknown[];
  layers: ({
    nm: string;
    cl?: string;
  } & Record<string, unknown>)[];
  markers: LottieMarker<Marker>[];
};
export type LottieMarkersAsMap<T extends LottieSource> = {
  [key in T['markers'][number]['cm']]: number;
};
//# sourceMappingURL=LottieSource.d.ts.map
