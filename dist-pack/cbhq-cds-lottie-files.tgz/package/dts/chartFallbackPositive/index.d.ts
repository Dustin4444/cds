/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type ChartFallbackPositiveLottie = LottieSource;
export declare const chartFallbackPositive: ChartFallbackPositiveLottie;
//# sourceMappingURL=index.d.ts.map
