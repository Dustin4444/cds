/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type WatchListStarLottie = LottieSource;
export declare const watchListStar: WatchListStarLottie;
//# sourceMappingURL=index.d.ts.map
