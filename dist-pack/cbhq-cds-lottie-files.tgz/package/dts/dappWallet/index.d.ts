/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type DappWalletLottie = LottieSource<
  | 'loadingStart'
  | 'loadingEnd'
  | 'loopStart'
  | 'loopEnd'
  | 'walletStart'
  | 'walletEnd'
  | 'walletLoopStart'
  | 'walletLoopEnd'
>;
export declare const dappWallet: DappWalletLottie;
//# sourceMappingURL=index.d.ts.map
