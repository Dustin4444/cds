/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type TradeStatusLottie = LottieSource<
  | 'loadingStart'
  | 'loadingEnd'
  | 'successCardStart'
  | 'successCardEnd'
  | 'successStart'
  | 'successEnd'
  | 'failureStart'
  | 'failureEnd'
  | 'pendingStart'
  | 'pendingEnd'
  | 'pendingAltStart'
  | 'pendingAltLoopStart'
  | 'pendingAltLoopEnd'
  | 'pendingAltEnd'
  | 'successAltStart'
  | 'successAltEnd'
  | 'failureAltStart'
  | 'failureAltEnd'
>;
export declare const tradeStatus: TradeStatusLottie;
//# sourceMappingURL=index.d.ts.map
