/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type ChartFallbackNegativeLottie = LottieSource;
export declare const chartFallbackNegative: ChartFallbackNegativeLottie;
//# sourceMappingURL=index.d.ts.map
