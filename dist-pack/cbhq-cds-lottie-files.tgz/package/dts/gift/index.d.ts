/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type GiftLottie = LottieSource;
export declare const gift: GiftLottie;
//# sourceMappingURL=index.d.ts.map
