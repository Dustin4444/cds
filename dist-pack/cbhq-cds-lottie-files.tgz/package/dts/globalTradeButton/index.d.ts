/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type GlobalTradeButtonLottie = LottieSource<
  'onPressInStart' | 'onPressInEnd' | 'onPressOutStart' | 'onPressOutEnd'
>;
export declare const globalTradeButton: GlobalTradeButtonLottie;
//# sourceMappingURL=index.d.ts.map
