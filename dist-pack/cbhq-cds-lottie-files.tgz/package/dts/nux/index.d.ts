/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type NuxLottie = LottieSource<'loopStart' | 'loopEnd'>;
export declare const nux: NuxLottie;
//# sourceMappingURL=index.d.ts.map
