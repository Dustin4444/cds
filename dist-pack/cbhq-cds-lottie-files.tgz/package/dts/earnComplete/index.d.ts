/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type EarnCompleteLottie = LottieSource<'1'>;
export declare const earnComplete: EarnCompleteLottie;
//# sourceMappingURL=index.d.ts.map
