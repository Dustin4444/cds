/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type ActivityIndicatorLottie = LottieSource;
export declare const activityIndicator: ActivityIndicatorLottie;
//# sourceMappingURL=index.d.ts.map
