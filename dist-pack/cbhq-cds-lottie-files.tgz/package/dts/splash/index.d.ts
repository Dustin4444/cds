/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type SplashLottie = LottieSource<
  | 'logoStart'
  | 'circleStart'
  | 'logoEnd'
  | 'circleOpacityStart'
  | 'circleEnd'
  | 'circleOpacityEnd'
  | 'end'
>;
export declare const splash: SplashLottie;
//# sourceMappingURL=index.d.ts.map
