/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type EarnTaskLottie = LottieSource<'1'>;
export declare const earnTask: EarnTaskLottie;
//# sourceMappingURL=index.d.ts.map
