/**
 * DO NOT MODIFY
 * Generated from scripts/codegen/main.ts
 */
import type { LottieSource } from '../LottieSource';
export type GiftingZoomLottie = LottieSource;
export declare const giftingZoom: GiftingZoomLottie;
//# sourceMappingURL=index.d.ts.map
