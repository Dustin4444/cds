import { type ComponentType } from 'react';
import type { ChartTextChildren, ChartTextProps } from '../text/ChartText';
import { type PointLabelPosition } from '../utils';
import { type Transition } from '../utils/transition';
export type PointBaseProps = {
    /**
     * X coordinate in data space (not pixel coordinates).
     */
    dataX: number;
    /**
     * Y coordinate in data space (not pixel coordinates).
     */
    dataY: number;
    /**
     * The fill color of the point.
     * @default theme.color.fgPrimary
     */
    fill?: string;
    /**
     * Optional Y-axis id to specify which axis to plot along.
     * @default first y-axis defined in chart props.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    yAxisId?: string;
    /**
     * Optional X-axis id to specify which axis to plot along.
     * @default first x-axis defined in chart props.
     * @note Only used for axis selection when layout is 'horizontal'. Vertical layout uses a single x-axis.
     */
    xAxisId?: string;
    /**
     * Radius of the point.
     * @default 5
     */
    radius?: number;
    /**
     * Opacity of the point.
     */
    opacity?: number;
    /**
     * Color of the outer stroke around the point.
     * @default theme.color.bg
     */
    stroke?: string;
    /**
     * Outer stroke width of the point.
     * Set to  0 to remove the stroke.
     * @default 2
     */
    strokeWidth?: number;
    /**
     * When set, overrides the chart's animation setting for this specific point.
     */
    animate?: boolean;
    /**
     * Custom component to render the label.
     * @default DefaultPointLabel
     */
    LabelComponent?: PointLabelComponent;
    /**
     * Position of the label relative to the point.
     * @default 'center'
     */
    labelPosition?: PointLabelPosition;
    /**
     * Distance in pixels to offset the label from the point.
     * @default 2 * radius
     */
    labelOffset?: number;
    /**
     * Font style for the label text.
     */
    labelFont?: ChartTextProps['font'];
};
/**
 * Props for point label components.
 */
export type PointLabelProps = {
    /**
     * X coordinate in SVG pixel space.
     */
    x: number;
    /**
     * Y coordinate in SVG pixel space.
     */
    y: number;
    /**
     * X coordinate in data space (usually same as index).
     */
    dataX: number;
    /**
     * Y coordinate in data space (same as value).
     */
    dataY: number;
    /**
     * Fill color for the point.
     */
    fill: string;
    /**
     * Position of the label relative to the point.
     * @default 'center'
     */
    position?: PointLabelPosition;
    /**
     * Distance in pixels to offset the label from the point.
     */
    offset?: number;
    /**
     * Content to display in the label.
     */
    children: ChartTextChildren;
};
export type PointLabelComponent = ComponentType<PointLabelProps>;
export type PointProps = PointBaseProps & {
    /**
     * Simple text label to display at the point position.
     * If provided, a label component will be automatically rendered.
     */
    label?: ChartTextChildren;
    /**
     * Transition configuration for enter and update animations.
     * @note Disable an animation by passing in null.
     */
    transitions?: {
        /**
         * Transition for the initial enter/reveal animation.
         * Set to `null` to disable.
         */
        enter?: Transition | null;
        /**
         * Transition for subsequent data update animations.
         * Set to `null` to disable.
         */
        update?: Transition | null;
    };
    /**
     * Transition for updates.
     * @deprecated Use `transitions.update` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v4
     */
    transition?: Transition;
};
export declare const Point: import("react").NamedExoticComponent<PointProps>;
//# sourceMappingURL=Point.d.ts.map