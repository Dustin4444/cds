import type { Rect } from '@cbhq/cds-common/types';
import { type AnimatedProp, type PathProps as SkiaPathProps } from '@shopify/react-native-skia';
import { type Transition } from './utils/transition';
/**
 * Duration in milliseconds for path enter transition.
 */
export declare const pathEnterTransitionDuration = 500;
export type PathBaseProps = {
    /**
     * Whether to animate this path. Overrides the animate prop on the Chart component.
     */
    animate?: boolean;
    /**
     * Initial path for enter animation.
     * When provided, the first animation will go from initialPath to d.
     * If not provided, defaults to d (no enter animation).
     */
    initialPath?: string;
    /**
     * Fill color for the path.
     * When provided, will render a fill with the given color.
     * If not provided, will not render a fill.
     */
    fill?: string;
    /**
     * Opacity for the path fill.
     */
    fillOpacity?: number;
    /**
     * Stroke color for the path.
     * When provided, will render a fill with the given color.
     * If not provided, will not render a fill.
     */
    stroke?: string;
    /**
     * Opacity for the path stroke.
     */
    strokeOpacity?: AnimatedProp<number>;
};
export type PathProps = PathBaseProps & Pick<SkiaPathProps, 'antiAlias' | 'blendMode' | 'children' | 'dither' | 'invertClip' | 'origin' | 'matrix' | 'strokeCap' | 'strokeJoin' | 'strokeMiter' | 'strokeWidth' | 'style' | 'transform'> & {
    /**
     * Transition configuration for enter and update animations.
     * @note Disable an animation by passing in null.
     *
     * @default transitions = {{
     *   enter: { type: 'timing', duration: 500 },
     *   update: { type: 'spring', stiffness: 900, damping: 120 }
     * }}
     *
     * @example
     * // Custom enter and update transitions
     * transitions={{ enter: { type: 'timing', duration: 300 }, update: { type: 'spring', damping: 20 } }}
     *
     * @example
     * // Disable enter animation
     * transitions={{ enter: null }}
     */
    transitions?: {
        /**
         * Transition for the initial enter/reveal animation.
         * Set to `null` to disable.
         */
        enter?: Transition | null;
        /**
         * Transition for subsequent data update animations.
         * Set to `null` to disable.
         */
        update?: Transition | null;
    };
    /**
     * Transition for updates.
     * @deprecated Use `transitions.update` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v4
     */
    transition?: Transition;
    /**
     * The SVG path data string.
     */
    d?: AnimatedProp<string | undefined>;
    /**
     * Offset added to the clip rect boundaries.
     */
    clipOffset?: number;
    /**
     * Custom clip path.
     * When set, overrides clipRect.
     * @note pass null to disable clipping.
     */
    clipPath?: string | null;
    /**
     * Custom clip path rect. If provided, this overrides the default chart rect for clipping.
     * @default drawingArea of chart + clipOffset
     * Will be overridden by clipPath if set.
     */
    clipRect?: Rect;
};
export declare const Path: import("react").NamedExoticComponent<PathProps>;
//# sourceMappingURL=Path.d.ts.map