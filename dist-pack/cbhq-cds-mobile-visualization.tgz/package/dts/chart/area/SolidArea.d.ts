import { type PathProps } from '../Path';
import type { AreaComponentProps } from './Area';
export type SolidAreaProps = Pick<PathProps, 'initialPath' | 'children' | 'stroke' | 'strokeOpacity' | 'strokeWidth' | 'strokeCap' | 'strokeJoin' | 'clipRect' | 'clipPath' | 'clipOffset'> & AreaComponentProps;
/**
 * A customizable solid area component.
 * When a gradient is provided, renders with gradient fill.
 * Otherwise, renders with solid fill.
 */
export declare const SolidArea: import("react").NamedExoticComponent<SolidAreaProps>;
//# sourceMappingURL=SolidArea.d.ts.map