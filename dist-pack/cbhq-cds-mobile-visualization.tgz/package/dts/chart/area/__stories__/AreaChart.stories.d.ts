declare const AreaChartStories: () => import("react/jsx-runtime").JSX.Element;
export default AreaChartStories;
//# sourceMappingURL=AreaChart.stories.d.ts.map