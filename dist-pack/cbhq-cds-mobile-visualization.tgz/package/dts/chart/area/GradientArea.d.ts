import { type PathProps } from '../Path';
import type { AreaComponentProps } from './Area';
export type GradientAreaProps = Pick<PathProps, 'initialPath' | 'children' | 'stroke' | 'strokeOpacity' | 'strokeWidth' | 'strokeCap' | 'strokeJoin' | 'clipRect' | 'clipPath' | 'clipOffset'> & AreaComponentProps & {
    /**
     * Opacity at peak of gradient.
     * @note only used when no gradient is provided
     * @default 0.3
     */
    peakOpacity?: number;
    /**
     * Opacity at the baseline.
     * @note only used when no gradient is provided
     * @default 0
     */
    baselineOpacity?: number;
};
/**
 * A customizable gradient area component.
 * When no gradient is provided, renders a default gradient based
 * on the fill color and peak/baseline opacities.
 */
export declare const GradientArea: import("react").NamedExoticComponent<GradientAreaProps>;
//# sourceMappingURL=GradientArea.d.ts.map