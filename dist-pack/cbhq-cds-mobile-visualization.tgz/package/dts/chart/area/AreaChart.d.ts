import type { View } from 'react-native';
import { type XAxisProps, type YAxisProps } from '../axis';
import { type CartesianChartBaseProps, type CartesianChartProps } from '../CartesianChart';
import { type LineProps } from '../line/Line';
import { type CartesianAxisConfigProps, type Series } from '../utils';
import { type AreaProps } from './Area';
export type AreaSeries = Series & Partial<Pick<AreaProps, 'AreaComponent' | 'curve' | 'fillOpacity' | 'type' | 'fill' | 'connectNulls' | 'transition' | 'transitions'>> & Partial<Pick<LineProps, 'LineComponent' | 'strokeWidth' | 'stroke' | 'opacity' | 'transition' | 'transitions'>> & {
    /**
     * The type of line to render for this series.
     * Overrides the chart-level lineType if provided.
     * @default 'solid'
     */
    lineType?: 'solid' | 'dotted';
};
export type AreaChartBaseProps = Omit<CartesianChartBaseProps, 'xAxis' | 'yAxis' | 'series'> & Pick<AreaProps, 'AreaComponent' | 'curve' | 'fillOpacity' | 'type' | 'connectNulls' | 'transition' | 'transitions'> & Pick<LineProps, 'LineComponent' | 'strokeWidth'> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series supports Area and Line component props for individual customization.
     */
    series?: Array<AreaSeries>;
    /**
     * Whether to stack the areas on top of each other.
     * When true, each series builds cumulative values on top of the previous series.
     *
     * **Note**: Only applies to series data containing singular numbers (e.g., `[10, 20, 30]`).
     * Series with [baseline, value] tuples (e.g., `[[0, 10], [0, -5]]`) will be skipped during stacking
     * and rendered as-is.
     */
    stacked?: boolean;
    /**
     * Whether to show the X axis.
     */
    showXAxis?: boolean;
    /**
     * Whether to show the Y axis.
     */
    showYAxis?: boolean;
    /**
     * Whether to show lines on top of the areas.
     * Useful for stacked contexts to show the outline of each area.
     */
    showLines?: boolean;
    /**
     * The type of line to render.
     * @default 'solid'
     */
    lineType?: 'solid' | 'dotted';
    /**
     * Configuration for x-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showXAxis` to true.
     */
    xAxis?: Partial<CartesianAxisConfigProps> & XAxisProps;
    /**
     * Configuration for y-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showYAxis` to true.
     */
    yAxis?: Partial<CartesianAxisConfigProps> & YAxisProps;
};
export type AreaChartProps = AreaChartBaseProps & Omit<CartesianChartProps, 'xAxis' | 'yAxis' | 'series'>;
export declare const AreaChart: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Omit<CartesianChartBaseProps, "series" | "xAxis" | "yAxis"> & Pick<AreaProps, "fillOpacity" | "transitions" | "transition" | "curve" | "type" | "AreaComponent" | "connectNulls"> & Pick<LineProps, "strokeWidth" | "LineComponent"> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series supports Area and Line component props for individual customization.
     */
    series?: Array<AreaSeries>;
    /**
     * Whether to stack the areas on top of each other.
     * When true, each series builds cumulative values on top of the previous series.
     *
     * **Note**: Only applies to series data containing singular numbers (e.g., `[10, 20, 30]`).
     * Series with [baseline, value] tuples (e.g., `[[0, 10], [0, -5]]`) will be skipped during stacking
     * and rendered as-is.
     */
    stacked?: boolean;
    /**
     * Whether to show the X axis.
     */
    showXAxis?: boolean;
    /**
     * Whether to show the Y axis.
     */
    showYAxis?: boolean;
    /**
     * Whether to show lines on top of the areas.
     * Useful for stacked contexts to show the outline of each area.
     */
    showLines?: boolean;
    /**
     * The type of line to render.
     * @default 'solid'
     */
    lineType?: "solid" | "dotted";
    /**
     * Configuration for x-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showXAxis` to true.
     */
    xAxis?: Partial<CartesianAxisConfigProps> & XAxisProps;
    /**
     * Configuration for y-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showYAxis` to true.
     */
    yAxis?: Partial<CartesianAxisConfigProps> & YAxisProps;
} & Omit<CartesianChartProps, "series" | "xAxis" | "yAxis"> & import("react").RefAttributes<View>>>;
//# sourceMappingURL=AreaChart.d.ts.map