/**
 * Simplified context bridge utilities for React Native.
 * Adapted from its-fine to enable context sharing across React renderers
 * https://github.com/pmndrs/its-fine/blob/598b81f02778c22ed21121c2b1a786bdefb14e23/src/index.tsx
 */
import * as React from 'react';
/**
 * A react-internal tree node provider that binds React children to the React tree for chart context bridging.
 */
export declare class ChartBridgeProvider extends React.Component<{
    children?: React.ReactNode;
}> {
    private _reactInternals;
    render(): import("react/jsx-runtime").JSX.Element;
}
export type ContextMap = Map<React.Context<any>, any> & {
    get<T>(context: React.Context<T>): T | undefined;
};
/**
 * Represents a chart context bridge provider component.
 */
export type ChartContextBridge = React.FC<React.PropsWithChildren<object>>;
/**
 * Returns a ChartContextBridge of live context providers to pierce Context across renderers.
 * Pass ChartContextBridge as a component to a secondary renderer (e.g., Skia Canvas) to enable context-sharing in charts.
 */
export declare function useChartContextBridge(): ChartContextBridge;
//# sourceMappingURL=ChartContextBridge.d.ts.map