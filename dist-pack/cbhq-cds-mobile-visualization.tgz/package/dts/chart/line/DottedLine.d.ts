import { type PathProps } from '../Path';
import type { LineComponentProps } from './Line';
export type DottedLineProps = Pick<PathProps, 'initialPath' | 'children' | 'strokeCap' | 'strokeJoin' | 'clipRect' | 'clipPath' | 'clipOffset'> & LineComponentProps & {
    fill?: string;
    /**
     * Stroke dash array for the dotted pattern.
     * @default [0, 4]
     */
    dashIntervals?: number[];
};
/**
 * A customizable dotted line component.
 * Supports gradient for gradient effects on the dots and smooth data transitions via AnimatedPath.
 */
export declare const DottedLine: import("react").NamedExoticComponent<DottedLineProps>;
//# sourceMappingURL=DottedLine.d.ts.map