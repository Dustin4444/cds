declare const ReferenceLineStories: () => import("react/jsx-runtime").JSX.Element;
export default ReferenceLineStories;
//# sourceMappingURL=ReferenceLine.stories.d.ts.map