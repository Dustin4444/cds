declare function ExampleNavigator(): import("react/jsx-runtime").JSX.Element;
export default ExampleNavigator;
//# sourceMappingURL=LineChart.stories.d.ts.map