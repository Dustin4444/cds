import { type PathProps } from '../Path';
import type { LineComponentProps } from './Line';
export type SolidLineProps = Pick<PathProps, 'initialPath' | 'children' | 'strokeCap' | 'strokeJoin' | 'clipRect' | 'clipPath' | 'clipOffset'> & LineComponentProps & {
    fill?: string;
};
/**
 * A customizable solid line component.
 * Supports gradient for gradient effects and smooth data transitions via AnimatedPath.
 */
export declare const SolidLine: import("react").NamedExoticComponent<SolidLineProps>;
//# sourceMappingURL=SolidLine.d.ts.map