import type { View } from 'react-native';
import { type XAxisProps } from '../axis/XAxis';
import { type YAxisProps } from '../axis/YAxis';
import { type CartesianChartBaseProps, type CartesianChartProps } from '../CartesianChart';
import { type CartesianAxisConfigProps, type Series } from '../utils';
import { type LineProps } from './Line';
export type LineSeries = Series & Partial<Pick<LineProps, 'curve' | 'showArea' | 'areaType' | 'areaBaseline' | 'type' | 'LineComponent' | 'AreaComponent' | 'stroke' | 'strokeWidth' | 'strokeOpacity' | 'opacity' | 'points' | 'connectNulls' | 'transition' | 'transitions'>>;
export type LineChartBaseProps = Omit<CartesianChartBaseProps, 'xAxis' | 'yAxis' | 'series'> & Pick<LineProps, 'showArea' | 'areaType' | 'type' | 'LineComponent' | 'AreaComponent' | 'curve' | 'points' | 'strokeWidth' | 'strokeOpacity' | 'connectNulls' | 'transition' | 'transitions' | 'opacity'> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series supports Line component props for individual customization.
     */
    series?: Array<LineSeries>;
    /**
     * Whether to show the X axis.
     */
    showXAxis?: boolean;
    /**
     * Whether to show the Y axis.
     */
    showYAxis?: boolean;
    /**
     * Configuration for x-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showXAxis` to true.
     */
    xAxis?: Partial<CartesianAxisConfigProps> & XAxisProps;
    /**
     * Configuration for y-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showYAxis` to true.
     */
    yAxis?: Partial<CartesianAxisConfigProps> & YAxisProps;
};
export type LineChartProps = LineChartBaseProps & Omit<CartesianChartProps, 'xAxis' | 'yAxis' | 'series' | 'scrubberAccessibilityLabelStep'> & {
    /**
     * Number of data points to move between screen-reader samples.
     * @default Computed from data length (targeting 10 samples)
     */
    scrubberAccessibilityLabelStep?: number;
};
export declare const LineChart: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Omit<CartesianChartBaseProps, "series" | "xAxis" | "yAxis"> & Pick<LineProps, "strokeWidth" | "strokeOpacity" | "transitions" | "transition" | "curve" | "type" | "showArea" | "areaType" | "LineComponent" | "AreaComponent" | "opacity" | "points" | "connectNulls"> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series supports Line component props for individual customization.
     */
    series?: Array<LineSeries>;
    /**
     * Whether to show the X axis.
     */
    showXAxis?: boolean;
    /**
     * Whether to show the Y axis.
     */
    showYAxis?: boolean;
    /**
     * Configuration for x-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showXAxis` to true.
     */
    xAxis?: Partial<CartesianAxisConfigProps> & XAxisProps;
    /**
     * Configuration for y-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showYAxis` to true.
     */
    yAxis?: Partial<CartesianAxisConfigProps> & YAxisProps;
} & Omit<CartesianChartProps, "series" | "xAxis" | "yAxis" | "scrubberAccessibilityLabelStep"> & {
    /**
     * Number of data points to move between screen-reader samples.
     * @default Computed from data length (targeting 10 samples)
     */
    scrubberAccessibilityLabelStep?: number;
} & import("react").RefAttributes<View>>>;
//# sourceMappingURL=LineChart.d.ts.map