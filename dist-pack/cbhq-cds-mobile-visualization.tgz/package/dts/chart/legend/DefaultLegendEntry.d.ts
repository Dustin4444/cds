import { type HStackProps } from '@cbhq/cds-mobile/layout';
import type { LegendEntryProps } from './Legend';
export type DefaultLegendEntryProps = LegendEntryProps & Omit<HStackProps, 'children' | 'color'>;
export declare const DefaultLegendEntry: import("react").NamedExoticComponent<DefaultLegendEntryProps>;
//# sourceMappingURL=DefaultLegendEntry.d.ts.map