declare const LegendStories: () => import("react/jsx-runtime").JSX.Element;
export default LegendStories;
//# sourceMappingURL=Legend.stories.d.ts.map