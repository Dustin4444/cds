import { type BoxProps } from '@cbhq/cds-mobile/layout';
import type { LegendShapeProps } from './Legend';
export type DefaultLegendShapeProps = LegendShapeProps & Omit<BoxProps, 'children' | 'color'>;
export declare const DefaultLegendShape: import("react").NamedExoticComponent<DefaultLegendShapeProps>;
//# sourceMappingURL=DefaultLegendShape.d.ts.map