import type { GradientDefinition } from '../utils';
export type GradientBaseProps = {
    /**
     * Gradient definition with stops, axis, and other configuration.
     */
    gradient: GradientDefinition;
    /**
     * X-axis ID to use for gradient processing.
     * When provided, the gradient will align with the specified x-axis range.
     */
    xAxisId?: string;
    /**
     * Y-axis ID to use for gradient processing.
     * When provided, the gradient will align with the specified y-axis range.
     * This ensures gradients work correctly when the axis has a custom range configuration.
     */
    yAxisId?: string;
};
export type GradientProps = GradientBaseProps;
/**
 * Renders a Skia LinearGradient element based on a GradientDefinition.
 * The gradient should be used as a child of a Path component.
 *
 * @example
 * <Path d={pathString} stroke="red">
 *   {gradient && <Gradient gradient={gradient} yAxisId={yAxisId} />}
 * </Path>
 */
export declare const Gradient: import("react").NamedExoticComponent<GradientBaseProps>;
//# sourceMappingURL=Gradient.d.ts.map