export * from './Gradient';
//# sourceMappingURL=index.d.ts.map