export default function All(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=PeriodSelector.stories.d.ts.map