declare function ExampleNavigator(): import("react/jsx-runtime").JSX.Element;
export default ExampleNavigator;
//# sourceMappingURL=ChartTransitions.stories.d.ts.map