declare const ChartStories: () => import("react/jsx-runtime").JSX.Element;
export default ChartStories;
//# sourceMappingURL=CartesianChart.stories.d.ts.map