declare function ExampleNavigator(): import("react/jsx-runtime").JSX.Element;
export default ExampleNavigator;
//# sourceMappingURL=ChartAccessibility.stories.d.ts.map