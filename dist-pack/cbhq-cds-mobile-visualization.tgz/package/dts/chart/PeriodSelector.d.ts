import React from 'react';
import { View, type ViewStyle } from 'react-native';
import { type SegmentedTabsProps, type TabsActiveIndicatorProps } from '@cbhq/cds-mobile/tabs';
import { type TextBaseProps } from '@cbhq/cds-mobile/typography';
export declare const PeriodSelectorActiveIndicator: ({ activeTabRect, background, position, borderRadius, }: TabsActiveIndicatorProps) => import("react/jsx-runtime").JSX.Element | undefined;
export type LiveTabLabelBaseProps = TextBaseProps & {
    /**
     * The label to display.
     * @default 'LIVE'
     */
    label?: string;
    /**
     * Whether to hide the dot.
     */
    hideDot?: boolean;
    /**
     * Style prop for customization
     */
    style?: any;
};
export type LiveTabLabelProps = LiveTabLabelBaseProps;
export declare const LiveTabLabel: React.MemoExoticComponent<React.ForwardRefExoticComponent<import("@cbhq/cds-mobile/styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: import("react-native").Animated.WithAnimatedValue<import("react-native").StyleProp<import("react-native").TextStyle>>;
    animated?: boolean;
    align?: "start" | "end" | "center" | "justify";
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    disabled?: boolean;
    mono?: boolean;
    underline?: boolean;
    tabularNumbers?: boolean;
    numberOfLines?: number;
    ellipsize?: import("react-native").TextProps["ellipsizeMode"];
    noWrap?: boolean;
    dangerouslySetColor?: import("react-native").TextStyle["color"];
    dangerouslySetBackground?: import("react-native").TextStyle["backgroundColor"];
    renderEmptyNode?: boolean;
    testID?: string;
} & {
    /**
     * The label to display.
     * @default 'LIVE'
     */
    label?: string;
    /**
     * Whether to hide the dot.
     */
    hideDot?: boolean;
    /**
     * Style prop for customization
     */
    style?: any;
} & React.RefAttributes<View>>>;
export type PeriodSelectorProps = SegmentedTabsProps;
/**
 * PeriodSelector is a specialized version of SegmentedTabs optimized for chart period selection.
 * It provides transparent background, primary wash active state, and full-width layout by default.
 */
export declare const PeriodSelector: React.MemoExoticComponent<React.ForwardRefExoticComponent<Partial<Pick<import("@cbhq/cds-mobile/tabs").TabsBaseProps<string>, "TabComponent" | "TabsActiveIndicatorComponent">> & Omit<import("@cbhq/cds-mobile/tabs").TabsBaseProps<string>, "styles" | "TabComponent" | "TabsActiveIndicatorComponent"> & Partial<Pick<import("@cbhq/cds-mobile/tabs").TabsProps<string>, "TabComponent" | "TabsActiveIndicatorComponent">> & Omit<import("@cbhq/cds-mobile/tabs").TabsProps<string>, "styles" | "TabComponent" | "TabsActiveIndicatorComponent"> & {
    styles?: {
        root?: import("react-native").StyleProp<ViewStyle>;
        tab?: import("react-native").StyleProp<ViewStyle>;
        activeIndicator?: import("react-native").StyleProp<ViewStyle>;
    };
} & React.RefAttributes<any>>>;
//# sourceMappingURL=PeriodSelector.d.ts.map