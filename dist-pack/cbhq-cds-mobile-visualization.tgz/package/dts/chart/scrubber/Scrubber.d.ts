import React from 'react';
import { type AnimatedProp, type SkParagraph } from '@shopify/react-native-skia';
import { type ReferenceLineBaseProps, type ReferenceLineLabelComponentProps } from '../line';
import type { ChartTextChildren, ChartTextProps } from '../text';
import { type ChartInset, type Series } from '../utils';
import type { Transition } from '../utils/transition';
import { type ScrubberBeaconGroupBaseProps, type ScrubberBeaconGroupProps, type ScrubberBeaconGroupRef } from './ScrubberBeaconGroup';
import { type ScrubberBeaconLabelGroupBaseProps, type ScrubberBeaconLabelGroupProps } from './ScrubberBeaconLabelGroup';
export type ScrubberBeaconRef = {
    /**
     * Triggers a single pulse animation.
     * Only works when the beacon is in idle state (not actively scrubbing).
     */
    pulse: () => void;
};
export type ScrubberBeaconBaseProps = {
    /**
     * Id of the series.
     */
    seriesId: Series['id'];
    /**
     * Color of the beacon.
     */
    color?: AnimatedProp<string>;
    /**
     * X coordinate in data space.
     * In vertical layout this is the scrubber index-axis value.
     * In horizontal layout this is the series value.
     */
    dataX: AnimatedProp<number>;
    /**
     * Y coordinate in data space.
     * In vertical layout this is the series value.
     * In horizontal layout this is the scrubber index-axis value.
     */
    dataY: AnimatedProp<number>;
    /**
     * Whether the beacon is in idle state (not actively scrubbing).
     */
    isIdle: AnimatedProp<boolean>;
    /**
     * Pulse the beacon while it is at rest.
     *
     * @note Only has an effect when `isIdle` is `true`. Pulse animations work
     * regardless of the chart's `animate` prop.
     */
    idlePulse?: boolean;
    /**
     * Whether position animations are enabled.
     * @default to ChartContext's animate value
     */
    animate?: boolean;
    /**
     * Opacity of the beacon.
     * @default 1
     */
    opacity?: AnimatedProp<number>;
    /**
     * Stroke color of the beacon circle.
     * @default theme.color.bg
     */
    stroke?: string;
};
export type ScrubberBeaconProps = ScrubberBeaconBaseProps & {
    /**
     * Transition configuration for beacon animations.
     */
    transitions?: {
        /**
         * Transition for the initial enter/reveal animation.
         * Set to `null` to disable.
         */
        enter?: Transition | null;
        /**
         * Transition for subsequent data update animations.
         * Set to `null` to disable.
         */
        update?: Transition | null;
        /**
         * Transition used for the pulse animation.
         * @default transition { type: 'timing', duration: 1600, easing: Easing.bezier(0.0, 0.0, 0.0, 1.0) }
         */
        pulse?: Transition;
        /**
         * Delay, in milliseconds between pulse transitions
         * when `idlePulse` is enabled.
         * @default 400
         */
        pulseRepeatDelay?: number;
    };
};
export type ScrubberBeaconComponent = React.FC<ScrubberBeaconProps & {
    ref?: React.Ref<ScrubberBeaconRef>;
}>;
export type ScrubberBeaconLabelProps = Pick<Series, 'color'> & Pick<ChartTextProps, 'x' | 'y' | 'dx' | 'horizontalAlignment' | 'onDimensionsChange' | 'opacity' | 'font'> & {
    /**
     * Label for the series.
     */
    label: ChartTextChildren;
    /**
     * Id of the series.
     */
    seriesId: Series['id'];
};
export type ScrubberBeaconLabelComponent = React.FC<ScrubberBeaconLabelProps>;
export type ScrubberLabelProps = ReferenceLineLabelComponentProps;
export type ScrubberLabelComponent = React.FC<ScrubberLabelProps>;
export type ScrubberBaseProps = Pick<ScrubberBeaconGroupBaseProps, 'idlePulse'> & Pick<ReferenceLineBaseProps, 'LineComponent' | 'LabelComponent' | 'labelElevated'> & Pick<ScrubberBeaconGroupProps, 'BeaconComponent'> & Pick<ScrubberBeaconLabelGroupProps, 'BeaconLabelComponent'> & {
    /**
     * Array of series IDs to highlight when scrubbing with scrubber beacons.
     * By default, all series will be highlighted.
     */
    seriesIds?: string[];
    /**
     * Hides the beacon labels while keeping the line label visible (if provided).
     * @default true in horizontal layout, false in vertical layout.
     * @note Beacon labels are always hidden in horizontal layout, and cannot be overridden.
     */
    hideBeaconLabels?: boolean;
    /**
     * Hides the scrubber line.
     * @note This hides Scrubber's ReferenceLine including the label.
     */
    hideLine?: boolean;
    /**
     * Hides the overlay rect which obscures data beyond the scrubber position.
     */
    hideOverlay?: boolean;
    /**
     * Offset of the overlay rect relative to the drawing area.
     * Useful for when scrubbing over lines, where the stroke width would cause part of the line to be visible.
     * @default 2
     */
    overlayOffset?: number;
    /**
     * Minimum gap between beacon labels to prevent overlap.
     * Measured in pixels.
     */
    beaconLabelMinGap?: ScrubberBeaconLabelGroupBaseProps['labelMinGap'];
    /**
     * Horizontal offset for beacon labels from their beacon position.
     * Measured in pixels.
     */
    beaconLabelHorizontalOffset?: ScrubberBeaconLabelGroupBaseProps['labelHorizontalOffset'];
    /**
     * Preferred side for beacon labels.
     * @note labels will switch to the opposite side if there's not enough space on the preferred side.
     * @default 'right'
     */
    beaconLabelPreferredSide?: ScrubberBeaconLabelGroupBaseProps['labelPreferredSide'];
    /**
     * Label text displayed above the scrubber line.
     * Can be a static string or a function that receives the current dataIndex.
     */
    label?: string | SkParagraph | ((dataIndex: number) => string | SkParagraph);
    /**
     * Font style for the scrubber line label.
     */
    labelFont?: ChartTextProps['font'];
    /**
     * Bounds inset for the scrubber line label to prevent cutoff at chart edges.
     * @default { top: 4, bottom: 20, left: 12, right: 12 } when labelElevated is true, otherwise none
     */
    labelBoundsInset?: number | ChartInset;
    /**
     * Font style for the beacon labels.
     */
    beaconLabelFont?: ChartTextProps['font'];
    /**
     * Stroke color for the scrubber line.
     */
    lineStroke?: ReferenceLineBaseProps['stroke'];
    /**
     * Stroke color of the scrubber beacon circle.
     * @default theme.color.bg
     */
    beaconStroke?: string;
};
export type ScrubberProps = ScrubberBaseProps & {
    /**
     * Transition configuration for the scrubber.
     * Controls enter, update, and pulse animations for beacons and beacon labels.
     */
    transitions?: ScrubberBeaconProps['transitions'];
    /**
     * Transition configuration for the scrubber beacon.
     * @deprecated Use `transitions` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v4
     */
    beaconTransitions?: ScrubberBeaconProps['transitions'];
};
export type ScrubberRef = ScrubberBeaconGroupRef;
/**
 * Unified component that manages all scrubber elements (beacons, line, labels).
 */
export declare const Scrubber: React.MemoExoticComponent<React.ForwardRefExoticComponent<Pick<ScrubberBeaconGroupBaseProps, "idlePulse"> & Pick<ReferenceLineBaseProps, "LineComponent" | "LabelComponent" | "labelElevated"> & Pick<ScrubberBeaconGroupProps, "BeaconComponent"> & Pick<ScrubberBeaconLabelGroupProps, "BeaconLabelComponent"> & {
    /**
     * Array of series IDs to highlight when scrubbing with scrubber beacons.
     * By default, all series will be highlighted.
     */
    seriesIds?: string[];
    /**
     * Hides the beacon labels while keeping the line label visible (if provided).
     * @default true in horizontal layout, false in vertical layout.
     * @note Beacon labels are always hidden in horizontal layout, and cannot be overridden.
     */
    hideBeaconLabels?: boolean;
    /**
     * Hides the scrubber line.
     * @note This hides Scrubber's ReferenceLine including the label.
     */
    hideLine?: boolean;
    /**
     * Hides the overlay rect which obscures data beyond the scrubber position.
     */
    hideOverlay?: boolean;
    /**
     * Offset of the overlay rect relative to the drawing area.
     * Useful for when scrubbing over lines, where the stroke width would cause part of the line to be visible.
     * @default 2
     */
    overlayOffset?: number;
    /**
     * Minimum gap between beacon labels to prevent overlap.
     * Measured in pixels.
     */
    beaconLabelMinGap?: ScrubberBeaconLabelGroupBaseProps["labelMinGap"];
    /**
     * Horizontal offset for beacon labels from their beacon position.
     * Measured in pixels.
     */
    beaconLabelHorizontalOffset?: ScrubberBeaconLabelGroupBaseProps["labelHorizontalOffset"];
    /**
     * Preferred side for beacon labels.
     * @note labels will switch to the opposite side if there's not enough space on the preferred side.
     * @default 'right'
     */
    beaconLabelPreferredSide?: ScrubberBeaconLabelGroupBaseProps["labelPreferredSide"];
    /**
     * Label text displayed above the scrubber line.
     * Can be a static string or a function that receives the current dataIndex.
     */
    label?: string | SkParagraph | ((dataIndex: number) => string | SkParagraph);
    /**
     * Font style for the scrubber line label.
     */
    labelFont?: ChartTextProps["font"];
    /**
     * Bounds inset for the scrubber line label to prevent cutoff at chart edges.
     * @default { top: 4, bottom: 20, left: 12, right: 12 } when labelElevated is true, otherwise none
     */
    labelBoundsInset?: number | ChartInset;
    /**
     * Font style for the beacon labels.
     */
    beaconLabelFont?: ChartTextProps["font"];
    /**
     * Stroke color for the scrubber line.
     */
    lineStroke?: ReferenceLineBaseProps["stroke"];
    /**
     * Stroke color of the scrubber beacon circle.
     * @default theme.color.bg
     */
    beaconStroke?: string;
} & {
    /**
     * Transition configuration for the scrubber.
     * Controls enter, update, and pulse animations for beacons and beacon labels.
     */
    transitions?: ScrubberBeaconProps["transitions"];
    /**
     * Transition configuration for the scrubber beacon.
     * @deprecated Use `transitions` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v4
     */
    beaconTransitions?: ScrubberBeaconProps["transitions"];
} & React.RefAttributes<ScrubberBeaconGroupRef>>>;
//# sourceMappingURL=Scrubber.d.ts.map