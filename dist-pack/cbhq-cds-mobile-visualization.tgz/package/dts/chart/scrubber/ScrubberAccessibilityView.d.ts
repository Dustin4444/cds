import React from 'react';
export type ScrubberAccessibilityViewProps = {
    accessibilityLabel?: (dataIndex: number) => string;
    accessibilityStep?: number;
};
export declare const ScrubberAccessibilityView: React.MemoExoticComponent<({ accessibilityLabel, accessibilityStep }: ScrubberAccessibilityViewProps) => import("react/jsx-runtime").JSX.Element | undefined>;
//# sourceMappingURL=ScrubberAccessibilityView.d.ts.map