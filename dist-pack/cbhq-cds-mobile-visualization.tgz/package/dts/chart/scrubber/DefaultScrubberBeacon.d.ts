import { type Transition } from '../utils/transition';
import type { ScrubberBeaconProps, ScrubberBeaconRef } from './Scrubber';
export type DefaultScrubberBeaconProps = ScrubberBeaconProps & {
    /**
     * Radius of the beacon circle.
     * @default 5
     */
    radius?: number;
    /**
     * Stroke width of the beacon circle.
     * @default 2
     */
    strokeWidth?: number;
};
export declare const DefaultScrubberBeacon: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<import("./Scrubber").ScrubberBeaconBaseProps & {
    transitions?: {
        enter?: Transition | null;
        update?: Transition | null;
        pulse?: Transition;
        pulseRepeatDelay?: number;
    };
} & {
    /**
     * Radius of the beacon circle.
     * @default 5
     */
    radius?: number;
    /**
     * Stroke width of the beacon circle.
     * @default 2
     */
    strokeWidth?: number;
} & import("react").RefAttributes<ScrubberBeaconRef>>>;
//# sourceMappingURL=DefaultScrubberBeacon.d.ts.map