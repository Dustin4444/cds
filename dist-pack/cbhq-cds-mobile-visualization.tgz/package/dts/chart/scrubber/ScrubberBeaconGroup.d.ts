import type { ScrubberBeaconComponent, ScrubberBeaconProps } from './Scrubber';
export type ScrubberBeaconGroupRef = {
    /**
     * Triggers a pulse animation on all beacons.
     */
    pulse: () => void;
};
export type ScrubberBeaconGroupBaseProps = {
    /**
     * Array of series IDs to render beacons for.
     */
    seriesIds: string[];
    /**
     * Pulse the beacons while at rest.
     */
    idlePulse?: boolean;
};
export type ScrubberBeaconGroupProps = ScrubberBeaconGroupBaseProps & {
    /**
     * Transition configuration for beacon animations.
     */
    transitions?: ScrubberBeaconProps['transitions'];
    /**
     * Custom component for the scrubber beacon.
     * @default DefaultScrubberBeacon
     */
    BeaconComponent?: ScrubberBeaconComponent;
    /**
     * Stroke color of the beacon circle.
     * @default theme.color.bg
     */
    stroke?: string;
};
export declare const ScrubberBeaconGroup: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<ScrubberBeaconGroupBaseProps & {
    /**
     * Transition configuration for beacon animations.
     */
    transitions?: ScrubberBeaconProps["transitions"];
    /**
     * Custom component for the scrubber beacon.
     * @default DefaultScrubberBeacon
     */
    BeaconComponent?: ScrubberBeaconComponent;
    /**
     * Stroke color of the beacon circle.
     * @default theme.color.bg
     */
    stroke?: string;
} & import("react").RefAttributes<ScrubberBeaconGroupRef>>>;
//# sourceMappingURL=ScrubberBeaconGroup.d.ts.map