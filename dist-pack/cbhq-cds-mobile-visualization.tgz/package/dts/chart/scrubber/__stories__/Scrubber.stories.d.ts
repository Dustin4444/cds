declare const ExampleNavigator: () => import("react/jsx-runtime").JSX.Element;
export default ExampleNavigator;
//# sourceMappingURL=Scrubber.stories.d.ts.map