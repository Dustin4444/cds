import React from 'react';
import { type ScrubberContextValue } from '../utils';
export type ScrubberProviderProps = Partial<Pick<ScrubberContextValue, 'enableScrubbing'>> & {
    children: React.ReactNode;
    /**
     * Allows continuous gestures on the chart to continue outside the bounds of the chart element.
     */
    allowOverflowGestures?: boolean;
    /**
     * Callback fired when the scrubber position changes.
     * Receives the dataIndex of the scrubber or undefined when not scrubbing.
     */
    onScrubberPositionChange?: (index: number | undefined) => void;
};
/**
 * A component which encapsulates the ScrubberContext.
 * It depends on a ChartContext in order to provide accurate touch tracking.
 */
export declare const ScrubberProvider: React.FC<ScrubberProviderProps>;
//# sourceMappingURL=ScrubberProvider.d.ts.map