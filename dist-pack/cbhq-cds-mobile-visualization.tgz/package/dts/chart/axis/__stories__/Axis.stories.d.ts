declare const AxisStories: () => import("react/jsx-runtime").JSX.Element;
export default AxisStories;
//# sourceMappingURL=Axis.stories.d.ts.map