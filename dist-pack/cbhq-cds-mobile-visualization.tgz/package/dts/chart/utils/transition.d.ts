import { type ExtrapolationType, type SharedValue, type WithSpringConfig, type WithTimingConfig } from 'react-native-reanimated';
import { type SkPath } from '@shopify/react-native-skia';
/**
 * Transition for animations.
 * Supports timing and spring animation types.
 * Used for paths, positions, opacity, and any other animated properties.
 *
 * @example
 * // Spring animation
 * { type: 'spring', damping: 10, stiffness: 100 }
 *
 * @example
 * // Timing animation
 * { type: 'timing', duration: 500, easing: Easing.inOut(Easing.ease) }
 */
export type Transition = (({
    type: 'timing';
} & WithTimingConfig) | ({
    type: 'spring';
} & WithSpringConfig)) & {
    /**
     * Delay in milliseconds (ms) before the animation starts.
     *
     * @example
     * // Wait 2 seconds before animating
     * { type: 'timing', duration: 500, delay: 2000 }
     */
    delay?: number;
};
/**
 * Default update transition used across all chart components.
 * `{ type: 'spring', stiffness: 900, damping: 120 }`
 */
export declare const defaultTransition: Transition;
/**
 * Instant transition that completes immediately with no animation.
 * Used when a transition is set to `null`.
 */
export declare const instantTransition: Transition;
/**
 * Duration in milliseconds for accessory elements to fade in.
 */
export declare const accessoryFadeTransitionDuration = 150;
/**
 * Delay in milliseconds before accessory elements fade in.
 */
export declare const accessoryFadeTransitionDelay = 350;
/**
 * Default enter transition for accessory elements (Point, Scrubber beacons).
 * `{ type: 'timing', duration: 150, delay: 350 }`
 */
export declare const defaultAccessoryEnterTransition: Transition;
/**
 * Resolves a transition value based on the animation state and a default.
 * @note Passing in null will disable an animation.
 * @note Passing in undefined will use the provided default.
 */
export declare const getTransition: (value: Transition | null | undefined, animate: boolean, defaultValue: Transition) => Transition | null;
/**
 * @worklet
 */
type Interpolator<T> = (value: number, input: number[], output: T[], options: ExtrapolationType, result: T) => T;
export declare const useInterpolator: <T>(factory: () => T, value: SharedValue<number>, interpolator: Interpolator<T>, input: number[], output: T[], options?: ExtrapolationType) => SharedValue<T>;
/**
 * Builds a react-native-reanimated animation based on the configuration.
 *
 * @param targetValue - The target value to animate to
 * @param config - The transition configuration
 * @returns The animation value to assign to a shared value
 *
 * @example
 * // Use directly for animation
 * progress.value = 0;
 * progress.value = buildTransition(1, { type: 'spring', damping: 10, stiffness: 100 });
 *
 * @example
 * // Coordinate animations
 * animatedX.value = buildTransition(100, { type: 'spring', damping: 10, stiffness: 100 });
 * animatedY.value = buildTransition(200, { type: 'spring', damping: 10, stiffness: 100 });
 *
 * @example
 * // Timing animation
 * progress.value = buildTransition(1, { type: 'timing', duration: 500 });
 */
export declare const buildTransition: (targetValue: number, transition: Transition | null) => number;
/**
 * Hook for path animation state and transitions.
 *
 * @param currentPath - Current target path to animate to
 * @param initialPath - Initial path for enter animation. When provided, the first animation will go from initialPath to currentPath.
 * @param transitions - Transition configuration for enter and update animations
 * @returns Animated SkPath as a shared value
 *
 * @example
 * // Simple path transition
 * const path = usePathTransition({
 *   currentPath: d ?? '',
 *   transitions: {
 *     update: { type: 'timing', duration: 3000 },
 *   },
 * });
 *
 * @example
 * // Enter animation with different initial config (like DefaultBar)
 * const path = usePathTransition({
 *   currentPath: targetPath,
 *   initialPath: baselinePath,
 *   transitions: {
 *     enter: { type: 'tween', duration: 500 },
 *     update: { type: 'spring', stiffness: 900, damping: 120 },
 *   },
 * });
 */
export declare const usePathTransition: ({ currentPath, initialPath, transitions, transition, }: {
    /**
     * Current target path to animate to.
     */
    currentPath: string;
    /**
     * Initial path for enter animation.
     * When provided, the first animation will go from initialPath to currentPath.
     * If not provided, defaults to currentPath (no enter animation).
     */
    initialPath?: string;
    /**
     * Transition configuration for enter and update animations.
     */
    transitions?: {
        /**
         * Transition for the initial enter animation (initialPath → currentPath).
         * Only used when `initialPath` is provided.
         * If not provided, falls back to `update`.
         */
        enter?: Transition | null;
        /**
         * Transition for subsequent data update animations.
         * @default defaultTransition
         */
        update?: Transition | null;
    };
    /**
     * Transition for updates.
     * @deprecated Use `transitions.update` instead.
     */
    transition?: Transition;
}) => SharedValue<SkPath>;
export {};
//# sourceMappingURL=transition.d.ts.map