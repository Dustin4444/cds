import type { TextHorizontalAlignment, TextVerticalAlignment } from '../text';
import type { CartesianChartLayout } from './context';
import { type ChartScaleFunction, type PointAnchor, type SerializableScale } from './scale';
/**
 * Position a label should be placed relative to the point
 *
 * @example
 * 'top' would have the label be located above the point itself,
 * and thus the vertical alignment of that text would be bottom.
 */
export type PointLabelPosition = 'top' | 'bottom' | 'left' | 'right' | 'center';
/**
 * Get a point from a data value and a scale.
 *
 * @param dataValue - The data value to convert to a pixel position.
 * @param scale - The scale function.
 * @param anchor (@default 'middle') - For band scales, where to anchor the point within the band.
 * @returns The pixel value (@default 0 if data value is not defined in scale).
 */
export declare const getPointOnScale: (dataValue: number, scale: ChartScaleFunction, anchor?: PointAnchor) => number;
/**
 * Get a point from a data value and a serializable scale (worklet-compatible).
 *
 * @param dataValue - The data value to convert to a pixel position.
 * @param scale - The serializable scale function.
 * @param anchor (@default 'middle') - For band scales, where to anchor the point within the band.
 * @returns The pixel value (@default 0 if data value is not defined in scale).
 */
export declare function getPointOnSerializableScale(dataValue: number, scale: SerializableScale, anchor?: PointAnchor): number;
/**
 * Projects a single data point to pixel coordinates using serializable scales.
 * This is the worklet-compatible version for use in react-native-reanimated.
 */
export declare function projectPointWithSerializableScale({ x, y, xScale, yScale, }: {
    x: number;
    y: number;
    xScale: SerializableScale;
    yScale: SerializableScale;
}): {
    x: number;
    y: number;
};
/**
 * Projects a data point to pixel coordinates using the chart scale.
 * Automatically handles log scale transformations for zero/negative values.
 *
 * @example
 * ```typescript
 * const chartScale = getChartScale({ chartRect, domain, range, xScale, yScale });
 * const pixelCoord = projectPoint({ x: 5, y: 10, chartScale });
 * ```
 * @example
 * ```typescript
 * const chartScale = getChartScale({ chartRect, domain, range, xScale, yScale });
 * const pixelCoord = projectPoint({ x: 2, y: 10, chartScale, xData: ['Jan', 'Feb', 'Mar'] });
 * ```
 */
export declare const projectPoint: ({ x, y, xScale, yScale, }: {
    x: number;
    y: number;
    xScale: ChartScaleFunction;
    yScale: ChartScaleFunction;
}) => {
    x: number;
    y: number;
};
/**
 * Projects multiple data points to pixel coordinates using chart scale functions.
 * Handles both numeric and band scales automatically.
 *
 * @example
 * ```typescript
 * const chartScale = getChartScale({ chartRect, domain, range, xScale, yScale });
 * const pixelPoints = projectPoints({ data, chartScale });
 * // For mixed scales
 * const pixelPoints = projectPoints({ data, chartScale, xData: ['Jan', 'Feb', 'Mar'] });
 * ```
 */
export declare const projectPoints: ({ data, xScale, yScale, xData, yData, layout, }: {
    data: (number | null | {
        x: number;
        y: number;
    })[];
    xData?: number[];
    yData?: number[];
    xScale: ChartScaleFunction;
    yScale: ChartScaleFunction;
    /**
     * Chart layout.
     * @default 'vertical'
     */
    layout?: CartesianChartLayout;
}) => Array<{
    x: number;
    y: number;
} | null>;
/**
 * Determines text alignment based on label position.
 * For example, a 'top' position needs the text aligned to the 'bottom' so it appears above the point.
 */
export declare const getAlignmentFromPosition: (position: PointLabelPosition) => {
    horizontalAlignment: TextHorizontalAlignment;
    verticalAlignment: TextVerticalAlignment;
};
/**
 * Calculates the final label coordinates by applying offset based on position.
 */
export declare const getLabelCoordinates: (x: number, y: number, position: PointLabelPosition, offset: number) => {
    x: number;
    y: number;
};
//# sourceMappingURL=point.d.ts.map