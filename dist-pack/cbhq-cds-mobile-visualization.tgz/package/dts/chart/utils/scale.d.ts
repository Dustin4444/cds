import type { ScaleBand, ScaleLinear, ScaleLogarithmic } from 'd3-scale';
import type { AxisBounds } from './chart';
export type ChartAxisScaleType = 'linear' | 'log' | 'band';
export type NumericScale = ScaleLinear<number, number, never> | ScaleLogarithmic<number, number, never>;
export type CategoricalScale = ScaleBand<number>;
export type ChartScaleFunction = NumericScale | CategoricalScale;
export declare const isCategoricalScale: (scale: ChartScaleFunction) => scale is CategoricalScale;
export declare const isNumericScale: (scale: ChartScaleFunction) => scale is NumericScale;
/**
 * Type guard to check if a scale is logarithmic.
 */
export declare const isLogScale: (scale: ChartScaleFunction) => scale is ScaleLogarithmic<number, number, never>;
/**
 * Type guard to check if a scale is a SerializableScale.
 * This can be used in worklets to differentiate between scale objects and scale functions.
 */
export declare const isSerializableScale: (scale: SerializableScale | ChartScaleFunction) => scale is SerializableScale;
/**
 * Create a numeric scale (linear or logarithmic)
 * @returns A numeric scale function
 */
export declare const getNumericScale: ({ scaleType, domain, range, }: {
    scaleType: "linear" | "log";
    domain: AxisBounds;
    range: AxisBounds;
}) => NumericScale;
/**
 * Create a categorical scale (band)
 * @returns A categorical scale function
 */
export declare const getCategoricalScale: ({ domain, range, padding, }: {
    domain: AxisBounds;
    range: AxisBounds;
    padding?: number;
}) => CategoricalScale;
/**
 * Anchor position for points on a scale. Currently used only for band scales.
 *
 * For band scales, this determines where within the band to position a point:
 * - `'stepStart'` - At the start of the step
 * - `'bandStart'` - At the start of the band
 * - `'middle'` - At the center of the band
 * - `'bandEnd'` - At the end of the band
 * - `'stepEnd'` - At the end of the step
 */
export type PointAnchor = 'stepStart' | 'bandStart' | 'middle' | 'bandEnd' | 'stepEnd';
/**
 * Convert a D3 scale to a serializable scale configuration that can be used in worklets
 */
export declare function convertToSerializableScale(d3Scale: ChartScaleFunction): SerializableScale | undefined;
/**
 * Convert multiple D3 scales to serializable scales
 */
export declare function convertScalesToSerializableScales(xScale?: ChartScaleFunction, yScales?: Map<string, ChartScaleFunction>): {
    xScale?: SerializableScale;
    yScales: Record<string, SerializableScale>;
};
/**
 * Serializable scale implementations based on D3 scale concepts.
 * These scales can be used directly on the UI thread in Reanimated worklets.
 */
export type SerializableLinearScale = {
    type: 'linear';
    domain: [number, number];
    range: [number, number];
};
export type SerializableLogScale = {
    type: 'log';
    domain: [number, number];
    range: [number, number];
    base?: number;
};
export type SerializableBandScale = {
    type: 'band';
    domain: [number, number];
    range: [number, number];
    bandwidth: number;
    step: number;
};
export type SerializableScale = SerializableLinearScale | SerializableLogScale | SerializableBandScale;
/**
 * Serializable linear scale function
 */
export declare function applyLinearScale(value: number, scale: SerializableLinearScale): number;
/**
 * Serializable log scale function
 */
export declare function applyLogScale(value: number, scale: SerializableLogScale): number;
/**
 * Serializable band scale function
 */
export declare function applyBandScale(value: number, scale: SerializableBandScale): number;
/**
 * Universal serializable scale function that handles any scale type
 */
export declare function applySerializableScale(value: number, scale: SerializableScale): number;
/**
 * Get bandwidth for band scales (returns 0 for other scale types)
 */
export declare function getScaleBandwidth(scale: SerializableBandScale): number;
/**
 * Invert a linear scale - convert from range value back to domain value
 */
export declare function invertLinearScale(rangeValue: number, scale: SerializableLinearScale): number;
/**
 * Invert a log scale - convert from range value back to domain value
 */
export declare function invertLogScale(rangeValue: number, scale: SerializableLogScale): number;
/**
 * Invert a band scale - convert from range value back to domain index
 */
export declare function invertBandScale(rangeValue: number, scale: SerializableBandScale): number;
/**
 * Universal serializable scale invert function that handles any scale type
 */
export declare function invertSerializableScale(rangeValue: number, scale: SerializableScale): number;
//# sourceMappingURL=scale.d.ts.map