declare function ExampleNavigator(): import("react/jsx-runtime").JSX.Element;
export default ExampleNavigator;
//# sourceMappingURL=BarChart.stories.d.ts.map