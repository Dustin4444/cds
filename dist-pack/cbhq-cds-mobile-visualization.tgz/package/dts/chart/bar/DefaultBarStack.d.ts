import type { BarStackComponentProps } from './BarStack';
export type DefaultBarStackProps = BarStackComponentProps;
/**
 * Default stack component that renders children in a group with animated clip path.
 */
export declare const DefaultBarStack: import("react").NamedExoticComponent<BarStackComponentProps>;
//# sourceMappingURL=DefaultBarStack.d.ts.map