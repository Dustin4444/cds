import type { BarComponentProps } from './Bar';
export type DefaultBarProps = BarComponentProps;
/**
 * Default bar component that renders a solid bar with animation support.
 */
export declare const DefaultBar: import("react").NamedExoticComponent<BarComponentProps>;
//# sourceMappingURL=DefaultBar.d.ts.map