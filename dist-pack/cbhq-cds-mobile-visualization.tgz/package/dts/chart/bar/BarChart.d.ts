import type { View } from 'react-native';
import { type XAxisProps, type YAxisProps } from '../axis';
import { type CartesianChartBaseProps, type CartesianChartProps } from '../CartesianChart';
import { type CartesianAxisConfigProps } from '../utils';
import { type BarPlotProps } from './BarPlot';
import type { BarSeries } from './BarStack';
export type BarChartBaseProps = Omit<CartesianChartBaseProps, 'xAxis' | 'yAxis' | 'series' | 'borderRadius' | 'borderTopLeftRadius' | 'borderTopRightRadius' | 'borderBottomLeftRadius' | 'borderBottomRightRadius'> & Pick<BarPlotProps, 'barPadding' | 'BarComponent' | 'fillOpacity' | 'stroke' | 'strokeWidth' | 'borderRadius' | 'BarStackComponent' | 'roundBaseline' | 'stackGap' | 'barMinSize' | 'stackMinSize' | 'transitions' | 'transition'> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series can optionally define its own BarComponent.
     */
    series?: Array<BarSeries>;
    /**
     * Whether to stack the areas on top of each other.
     * When true, each series builds cumulative values on top of the previous series.
     *
     * @note only applies to series data containing singular numbers (e.g., `[10, 20, 30]`).
     * Series with start & end value tuples (e.g., `[[0, 10], [5, 20]]`) will be skipped during stacking
     * and rendered as-is.
     */
    stacked?: boolean;
    /**
     * Whether to show the X axis.
     */
    showXAxis?: boolean;
    /**
     * Whether to show the Y axis.
     */
    showYAxis?: boolean;
    /**
     * Configuration for x-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showXAxis` to true.
     */
    xAxis?: Partial<CartesianAxisConfigProps> & XAxisProps;
    /**
     * Configuration for y-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showYAxis` to true.
     */
    yAxis?: Partial<CartesianAxisConfigProps> & YAxisProps;
};
export type BarChartProps = BarChartBaseProps & Omit<CartesianChartProps, 'xAxis' | 'yAxis' | 'series' | 'borderRadius' | 'borderTopLeftRadius' | 'borderTopRightRadius' | 'borderBottomLeftRadius' | 'borderBottomRightRadius'>;
export declare const BarChart: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Omit<CartesianChartBaseProps, "borderRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "series" | "xAxis" | "yAxis"> & Pick<BarPlotProps, "strokeWidth" | "fillOpacity" | "stroke" | "transitions" | "transition" | "borderRadius" | "BarComponent" | "roundBaseline" | "stackGap" | "barMinSize" | "stackMinSize" | "BarStackComponent" | "barPadding"> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series can optionally define its own BarComponent.
     */
    series?: Array<BarSeries>;
    /**
     * Whether to stack the areas on top of each other.
     * When true, each series builds cumulative values on top of the previous series.
     *
     * @note only applies to series data containing singular numbers (e.g., `[10, 20, 30]`).
     * Series with start & end value tuples (e.g., `[[0, 10], [5, 20]]`) will be skipped during stacking
     * and rendered as-is.
     */
    stacked?: boolean;
    /**
     * Whether to show the X axis.
     */
    showXAxis?: boolean;
    /**
     * Whether to show the Y axis.
     */
    showYAxis?: boolean;
    /**
     * Configuration for x-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showXAxis` to true.
     */
    xAxis?: Partial<CartesianAxisConfigProps> & XAxisProps;
    /**
     * Configuration for y-axis.
     * Accepts axis config and axis props.
     * To show the axis, set `showYAxis` to true.
     */
    yAxis?: Partial<CartesianAxisConfigProps> & YAxisProps;
} & Omit<CartesianChartProps, "borderRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "series" | "xAxis" | "yAxis"> & import("react").RefAttributes<View>>>;
//# sourceMappingURL=BarChart.d.ts.map