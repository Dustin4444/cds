import React from 'react';
import { type StyleProp, type View, type ViewStyle } from 'react-native';
import type { BoxBaseProps, BoxProps } from '@cbhq/cds-mobile/layout';
import { type SkTypefaceFontProvider } from '@shopify/react-native-skia';
import { type ScrubberAccessibilityViewProps } from './scrubber/ScrubberAccessibilityView';
import { type ScrubberProviderProps } from './scrubber/ScrubberProvider';
import { type CartesianAxisConfigProps, type CartesianChartLayout, type ChartInset, type LegendPosition, type Series } from './utils';
export type CartesianChartBaseProps = Omit<BoxBaseProps, 'fontFamily'> & Pick<ScrubberProviderProps, 'enableScrubbing' | 'onScrubberPositionChange'> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series contains its own data array.
     */
    series?: Array<Series>;
    /**
     * Chart layout - describes the direction bars/areas grow.
     * - 'vertical' (default): Bars grow vertically. X is category axis, Y is value axis.
     * - 'horizontal': Bars grow horizontally. Y is category axis, X is value axis.
     * @default 'vertical'
     */
    layout?: CartesianChartLayout;
    /**
     * Whether to animate the chart.
     * @default true
     */
    animate?: boolean;
    /**
     * Configuration for x-axis(es). Can be a single config or array of configs.
     *
     * @note Multiple x-axis configs are only supported when `layout="horizontal"`.
     */
    xAxis?: Partial<CartesianAxisConfigProps> | Partial<CartesianAxisConfigProps>[];
    /**
     * Configuration for y-axis(es). Can be a single config or array of configs.
     *
     * @note `layout="horizontal"` supports only one y-axis config.
     */
    yAxis?: Partial<Omit<CartesianAxisConfigProps, 'data'>> | Partial<Omit<CartesianAxisConfigProps, 'data'>>[];
    /**
     * Inset around the entire chart (outside the axes).
     */
    inset?: number | Partial<ChartInset>;
    /**
     * Whether to show the legend or a custom legend element.
     * - `true` renders the default Legend component
     * - A React element renders that element as the legend
     * - `false` or omitted hides the legend
     */
    legend?: boolean | React.ReactNode;
    /**
     * Position of the legend relative to the chart.
     * @default 'bottom'
     */
    legendPosition?: LegendPosition;
    /**
     * Accessibility label for the legend group.
     * @default 'Legend'
     */
    legendAccessibilityLabel?: string;
};
export type CartesianChartProps = CartesianChartBaseProps & Pick<ScrubberProviderProps, 'allowOverflowGestures'> & Omit<BoxProps, 'fontFamily'> & {
    /**
     * Default font families to use within ChartText.
     * If not provided, will be the default for the system.
     * @example
     * ['Helvetica', 'sans-serif']
     */
    fontFamilies?: string[];
    /**
     * Skia font provider to allow for custom fonts.
     * If not provided, the only available fonts will be those defined by the system.
     */
    fontProvider?: SkTypefaceFontProvider;
    /**
     * Function that returns the accessibility label for each scrubber point.
     * Receives `dataIndex` for each scrubber point label.
     */
    getScrubberAccessibilityLabel?: ScrubberAccessibilityViewProps['accessibilityLabel'];
    /**
     * Number of data points to move between screen-reader samples.
     */
    scrubberAccessibilityLabelStep?: number;
    /**
     * Custom styles for the root element.
     */
    style?: StyleProp<ViewStyle>;
    /**
     * Custom styles for the component.
     */
    styles?: {
        /**
         * Custom styles for the root element.
         */
        root?: StyleProp<ViewStyle>;
        /**
         * Custom styles for the chart canvas element.
         */
        chart?: StyleProp<ViewStyle>;
    };
};
export declare const CartesianChart: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<BoxBaseProps, "fontFamily"> & Pick<ScrubberProviderProps, "enableScrubbing" | "onScrubberPositionChange"> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series contains its own data array.
     */
    series?: Array<Series>;
    /**
     * Chart layout - describes the direction bars/areas grow.
     * - 'vertical' (default): Bars grow vertically. X is category axis, Y is value axis.
     * - 'horizontal': Bars grow horizontally. Y is category axis, X is value axis.
     * @default 'vertical'
     */
    layout?: CartesianChartLayout;
    /**
     * Whether to animate the chart.
     * @default true
     */
    animate?: boolean;
    /**
     * Configuration for x-axis(es). Can be a single config or array of configs.
     *
     * @note Multiple x-axis configs are only supported when `layout="horizontal"`.
     */
    xAxis?: Partial<CartesianAxisConfigProps> | Partial<CartesianAxisConfigProps>[];
    /**
     * Configuration for y-axis(es). Can be a single config or array of configs.
     *
     * @note `layout="horizontal"` supports only one y-axis config.
     */
    yAxis?: Partial<Omit<CartesianAxisConfigProps, "data">> | Partial<Omit<CartesianAxisConfigProps, "data">>[];
    /**
     * Inset around the entire chart (outside the axes).
     */
    inset?: number | Partial<ChartInset>;
    /**
     * Whether to show the legend or a custom legend element.
     * - `true` renders the default Legend component
     * - A React element renders that element as the legend
     * - `false` or omitted hides the legend
     */
    legend?: boolean | React.ReactNode;
    /**
     * Position of the legend relative to the chart.
     * @default 'bottom'
     */
    legendPosition?: LegendPosition;
    /**
     * Accessibility label for the legend group.
     * @default 'Legend'
     */
    legendAccessibilityLabel?: string;
} & Pick<ScrubberProviderProps, "allowOverflowGestures"> & Omit<BoxProps, "fontFamily"> & {
    /**
     * Default font families to use within ChartText.
     * If not provided, will be the default for the system.
     * @example
     * ['Helvetica', 'sans-serif']
     */
    fontFamilies?: string[];
    /**
     * Skia font provider to allow for custom fonts.
     * If not provided, the only available fonts will be those defined by the system.
     */
    fontProvider?: SkTypefaceFontProvider;
    /**
     * Function that returns the accessibility label for each scrubber point.
     * Receives `dataIndex` for each scrubber point label.
     */
    getScrubberAccessibilityLabel?: ScrubberAccessibilityViewProps["accessibilityLabel"];
    /**
     * Number of data points to move between screen-reader samples.
     */
    scrubberAccessibilityLabelStep?: number;
    /**
     * Custom styles for the root element.
     */
    style?: StyleProp<ViewStyle>;
    /**
     * Custom styles for the component.
     */
    styles?: {
        /**
         * Custom styles for the root element.
         */
        root?: StyleProp<ViewStyle>;
        /**
         * Custom styles for the chart canvas element.
         */
        chart?: StyleProp<ViewStyle>;
    };
} & React.RefAttributes<View>>>;
//# sourceMappingURL=CartesianChart.d.ts.map