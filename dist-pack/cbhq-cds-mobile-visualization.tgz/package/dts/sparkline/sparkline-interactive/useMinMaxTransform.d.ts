import { Animated } from 'react-native';
import type { LayoutRectangle } from 'react-native';
type MinMaxTransformParams = {
    minMaxLayout: LayoutRectangle;
    x: number;
    transform: Animated.ValueXY;
    opacity: Animated.Value;
};
export declare function useMinMaxTransform({ minMaxLayout, x, transform, opacity }: MinMaxTransformParams): void;
export {};
//# sourceMappingURL=useMinMaxTransform.d.ts.map