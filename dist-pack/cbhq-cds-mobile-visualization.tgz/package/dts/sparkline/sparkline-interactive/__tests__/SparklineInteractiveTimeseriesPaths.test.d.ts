export {};
//# sourceMappingURL=SparklineInteractiveTimeseriesPaths.test.d.ts.map