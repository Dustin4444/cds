export {};
//# sourceMappingURL=SparklineInteractivePanGestureHandler.test.d.ts.map