export {};
//# sourceMappingURL=useMinMaxTransform.test.d.ts.map