import React from 'react';
import type { ChartDataPoint, ChartFormatAmount, ChartXFunction } from '@cbhq/cds-common/types';
export type SparklineInteractiveMinMaxProps = {
    dataPoint: ChartDataPoint | undefined;
    formatMinMaxLabel: ChartFormatAmount;
    xFunction: ChartXFunction;
};
export declare const SparklineInteractiveMinMax: React.FunctionComponent<React.PropsWithChildren<SparklineInteractiveMinMaxProps>>;
//# sourceMappingURL=SparklineInteractiveMinMax.d.ts.map