import { Animated } from 'react-native';
type Params = {
    animationListener: Animated.ValueListenerCallback;
    onInterrupt: () => void;
    ignoreMinMax?: boolean;
};
export declare const useInterruptiblePathAnimation: ({ animationListener, onInterrupt, ignoreMinMax, }: Params) => () => void;
export {};
//# sourceMappingURL=useInterruptiblePathAnimation.d.ts.map