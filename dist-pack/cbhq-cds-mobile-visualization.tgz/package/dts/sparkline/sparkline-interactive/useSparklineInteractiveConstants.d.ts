type Props = {
    compact?: boolean;
};
export declare function useSparklineInteractiveConstants({ compact }: Props): {
    chartHorizontalGutter: number;
    chartWidth: number;
    chartHeight: number;
    chartDimensionStyles: {
        height: number;
        width: number;
    };
    chartMarkerSize: number;
    SparklineInteractiveMinMaxLabelHeight: number;
    SparklineInteractiveMinMaxVerticalGutter: number;
    chartVerticalLineWidth: number;
    xRange: number[];
    yRange: number[];
    startX: number;
    endX: number;
};
export {};
//# sourceMappingURL=useSparklineInteractiveConstants.d.ts.map