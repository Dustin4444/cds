import React from 'react';
import { type SparklineFillType } from '../Sparkline';
export type SparklineInteractiveAnimatedPathProps = {
    d: string;
    color: string;
    area?: string;
    selectedPeriod: string;
    fillType?: SparklineFillType;
    yAxisScalingFactor?: number;
    initialPath?: string;
    initialArea?: string;
};
export declare const SparklineInteractiveAnimatedPath: React.MemoExoticComponent<({ d, color, selectedPeriod, area, fillType, yAxisScalingFactor, initialPath, initialArea, }: SparklineInteractiveAnimatedPathProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SparklineInteractiveAnimatedPath.d.ts.map