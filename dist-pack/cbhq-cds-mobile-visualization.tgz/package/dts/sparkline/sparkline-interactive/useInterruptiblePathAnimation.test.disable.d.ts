export {};
//# sourceMappingURL=useInterruptiblePathAnimation.test.disable.d.ts.map