export declare function useSparklineInteractiveLineStyles(): {
    dotStyle: ({
        backgroundColor: string;
        position?: undefined;
        top?: undefined;
        left?: undefined;
        height?: undefined;
        width?: undefined;
        borderRadius?: undefined;
        opacity?: undefined;
    } | {
        position: string;
        top: number;
        left: number;
        height: number;
        width: number;
        borderRadius: number;
        opacity: number;
        backgroundColor?: undefined;
    })[];
    lineProps: {
        strokeWidth: number;
        stroke: string;
        x1: number;
        x2: number;
        y1: number;
        y2: number;
        strokeDasharray: number[];
    };
};
//# sourceMappingURL=useSparklineInteractiveLineStyles.d.ts.map