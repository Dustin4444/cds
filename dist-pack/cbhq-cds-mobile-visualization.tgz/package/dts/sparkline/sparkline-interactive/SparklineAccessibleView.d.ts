import React from 'react';
import type { SparklineInteractiveBaseProps } from './SparklineInteractive';
type SparklineAccessibleViewProps<Period extends string> = {
    selectedPeriod: Period;
} & Pick<SparklineInteractiveBaseProps<Period>, 'data'>;
/**
 * SparklineAccessibleView renders an accessible view for Sparkline Chart.
 *
 * It chunks the sparkline data into 10 (or fewer) pieces, rendering each as a View with
 * flex width proportional to the chunk size. The first data point in each chunk is used
 * to generate an accessibilityLabel with the date and value.
 *
 * @param data - The sparkline data mapped by time period
 * @param selectedPeriod - The currently selected time period
 */
export declare const SparklineAccessibleView: React.MemoExoticComponent<(<Period extends string>({ data, selectedPeriod }: SparklineAccessibleViewProps<Period>) => import("react/jsx-runtime").JSX.Element)>;
export {};
//# sourceMappingURL=SparklineAccessibleView.d.ts.map