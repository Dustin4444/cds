import React from 'react';
import { Animated } from 'react-native';
import type { SharedValue } from 'react-native-reanimated';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
type SparklineInteractiveProviderProps = {
    children: React.ReactNode;
    compact?: boolean;
    gutter?: ThemeVars.Space;
};
type SparklineInteractiveContextInterface = {
    isFallbackVisible: boolean;
    markerXPosition: SharedValue<number>;
    markerGestureState: SharedValue<0 | 1>;
    showFallback: () => void;
    hideFallback: () => void;
    chartOpacity: Animated.Value;
    animateChartIn: Animated.CompositeAnimation;
    markerOpacity: Animated.Value;
    animateMarkerIn: Animated.CompositeAnimation;
    animateMarkerOut: Animated.CompositeAnimation;
    minMaxOpacity: Animated.Value;
    animateMinMaxIn: Animated.CompositeAnimation;
    animateMinxMaxOut: Animated.CompositeAnimation;
    hoverDateOpacity: Animated.Value;
    animateHoverDateIn: Animated.CompositeAnimation;
    animateHoverDateOut: Animated.CompositeAnimation;
    compact: boolean;
    gutter: ThemeVars.Space;
};
export declare const SparklineInteractiveProvider: React.MemoExoticComponent<({ children, compact, gutter: propGutter }: SparklineInteractiveProviderProps) => import("react/jsx-runtime").JSX.Element>;
export declare function useSparklineInteractiveContext(): SparklineInteractiveContextInterface;
export {};
//# sourceMappingURL=SparklineInteractiveProvider.d.ts.map