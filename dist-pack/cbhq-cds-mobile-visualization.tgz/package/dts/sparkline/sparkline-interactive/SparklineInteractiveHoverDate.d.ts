import React from 'react';
import { Animated } from 'react-native';
import type { ChartScrubParams } from '@cbhq/cds-common/types/Chart';
import type { SparklineInteractiveBaseProps } from './SparklineInteractive';
type Props<Period extends string> = Pick<SparklineInteractiveBaseProps<Period>, 'formatHoverDate'> & {
    shouldTakeUpHeight: boolean;
};
export declare function setTransform(x: number, elWidth: number, containerWidth: number, transform: Animated.ValueXY, gutter: number): void;
export type SparklineInteractiveHoverDateRefProps<Period extends string> = {
    update: (params: ChartScrubParams<Period>) => void;
};
type ForwardRefWithPeriod<Period extends string> = React.ForwardRefExoticComponent<Props<Period> & {
    ref?: React.Ref<SparklineInteractiveHoverDateRefProps<Period>>;
}>;
export declare const SparklineInteractiveHoverDate: ForwardRefWithPeriod<any>;
export {};
//# sourceMappingURL=SparklineInteractiveHoverDate.d.ts.map