import { Animated } from 'react-native';
export declare function useOpacityAnimation(initialValue?: number | undefined, duration?: number | undefined): [Animated.Value, Animated.CompositeAnimation, Animated.CompositeAnimation];
//# sourceMappingURL=useOpacityAnimation.d.ts.map