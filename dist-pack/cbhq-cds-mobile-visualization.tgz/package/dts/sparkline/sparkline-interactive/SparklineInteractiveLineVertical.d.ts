import React from 'react';
type SparklineInteractiveLineVerticalMobileProps = {
    color: string;
    showHoverDate: boolean;
};
export declare const SparklineInteractiveLineVertical: React.MemoExoticComponent<({ color, showHoverDate }: SparklineInteractiveLineVerticalMobileProps) => import("react/jsx-runtime").JSX.Element>;
export {};
//# sourceMappingURL=SparklineInteractiveLineVertical.d.ts.map