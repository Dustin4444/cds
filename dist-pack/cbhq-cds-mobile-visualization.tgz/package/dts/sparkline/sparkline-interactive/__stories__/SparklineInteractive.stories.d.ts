declare const SparklineInteractiveScreen: () => import("react/jsx-runtime").JSX.Element;
export default SparklineInteractiveScreen;
//# sourceMappingURL=SparklineInteractive.stories.d.ts.map