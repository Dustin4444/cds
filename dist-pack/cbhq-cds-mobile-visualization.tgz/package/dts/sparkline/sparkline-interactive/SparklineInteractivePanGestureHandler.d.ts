import React from 'react';
import type { ChartGetMarker, ChartScrubParams } from '@cbhq/cds-common/types/Chart';
import { type SparklineInteractiveProps } from './SparklineInteractive';
export type SparklineInteractivePanGestureHandlerProps<Period extends string> = Pick<SparklineInteractiveProps<Period>, 'allowOverflowGestures'> & {
    onScrub?: (params: ChartScrubParams<Period>) => void;
    getMarker: ChartGetMarker;
    selectedPeriod: Period;
    onScrubEnd?: () => void;
    onScrubStart?: () => void;
    disabled?: boolean;
    children: React.ReactNode;
};
export declare const SparklineInteractivePanGestureHandler: <Period extends string>({ onScrubEnd, onScrubStart, onScrub, getMarker, selectedPeriod, children, disabled, allowOverflowGestures, }: SparklineInteractivePanGestureHandlerProps<Period>) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SparklineInteractivePanGestureHandler.d.ts.map