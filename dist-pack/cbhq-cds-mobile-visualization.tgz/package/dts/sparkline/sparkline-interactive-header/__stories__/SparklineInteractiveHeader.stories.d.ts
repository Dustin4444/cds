export declare const SparklineInteractiveHeaderWithCustomTitle: () => import("react/jsx-runtime").JSX.Element;
declare const SparklineInteractiveHeaderScreen: () => import("react/jsx-runtime").JSX.Element;
export default SparklineInteractiveHeaderScreen;
//# sourceMappingURL=SparklineInteractiveHeader.stories.d.ts.map