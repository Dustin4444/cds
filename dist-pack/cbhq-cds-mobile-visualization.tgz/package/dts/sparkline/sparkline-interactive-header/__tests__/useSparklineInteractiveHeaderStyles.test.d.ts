export {};
//# sourceMappingURL=useSparklineInteractiveHeaderStyles.test.d.ts.map