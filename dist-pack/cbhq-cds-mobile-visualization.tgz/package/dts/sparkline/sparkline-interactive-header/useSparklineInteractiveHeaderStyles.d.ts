import type { StyleProp, TextStyle } from 'react-native';
import type { SparklineInteractiveSubHead } from './SparklineInteractiveHeader';
export type SparklineInteractiveSubHeadIconColor = SparklineInteractiveSubHead['variant'];
export declare const styles: {
    inputReset: {
        padding: number;
        margin: number;
        backgroundColor: string;
        overflow: "visible";
        lineHeight: undefined;
    };
    fullWidth: {
        width: "100%";
    };
    tabularNumbers: {
        fontVariant: "tabular-nums"[];
    };
};
export declare function useSparklineInteractiveHeaderStyles(): {
    readonly title: (text: string) => StyleProp<TextStyle>;
    readonly label: StyleProp<TextStyle>;
    readonly subHeadIcon: (color: SparklineInteractiveSubHeadIconColor) => StyleProp<TextStyle>;
    readonly subHead: (color: SparklineInteractiveSubHeadIconColor, useFullWidth?: boolean) => StyleProp<TextStyle>;
    readonly subHeadAccessory: () => StyleProp<TextStyle>;
};
//# sourceMappingURL=useSparklineInteractiveHeaderStyles.d.ts.map