import React from 'react';
import { Path } from 'react-native-svg';
export type SparklineAreaBaseProps = {
    area?: string;
    patternId?: string;
    maskId?: string;
};
/**
 * @deprecated Use AreaChart instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v4
 */
export declare const SparklineArea: React.MemoExoticComponent<React.ForwardRefExoticComponent<SparklineAreaBaseProps & React.RefAttributes<Path | null>>>;
//# sourceMappingURL=SparklineArea.d.ts.map