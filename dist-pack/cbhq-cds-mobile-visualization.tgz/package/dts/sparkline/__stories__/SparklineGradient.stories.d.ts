declare const PressableOpacityScreen: () => import("react/jsx-runtime").JSX.Element;
export default PressableOpacityScreen;
//# sourceMappingURL=SparklineGradient.stories.d.ts.map