declare const PressableOpacityScreen: () => import("react/jsx-runtime").JSX.Element;
export default PressableOpacityScreen;
//# sourceMappingURL=Sparkline.stories.d.ts.map