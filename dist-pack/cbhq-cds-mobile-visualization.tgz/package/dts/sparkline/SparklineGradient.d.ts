import React from 'react';
import { Path } from 'react-native-svg';
/**
 * @deprecated Use LineChart instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v4
 */
export declare const SparklineGradient: React.MemoExoticComponent<React.ForwardRefExoticComponent<import("@cbhq/cds-common").SharedProps & {
    background?: string;
    color: string;
    height: number;
    path?: string;
    width: number;
    children?: import("@cbhq/cds-common").ElementChildren<import("./SparklineArea").SparklineAreaBaseProps>;
    yAxisScalingFactor?: number;
    strokeType?: import("./Sparkline").SparklineStrokeType;
    fillType?: import("./Sparkline").SparklineFillType;
} & React.RefAttributes<Path | null>>>;
//# sourceMappingURL=SparklineGradient.d.ts.map