export declare function useSparklineInteractiveConstants(): {
    chartWidth: number;
    chartHeight: number;
    chartDimensionStyles: {
        height: number;
        width: number;
    };
    xRange: number[];
    yRange: number[];
    startX: number;
    endX: number;
};
//# sourceMappingURL=useSparklineInteractiveConstants.d.ts.map