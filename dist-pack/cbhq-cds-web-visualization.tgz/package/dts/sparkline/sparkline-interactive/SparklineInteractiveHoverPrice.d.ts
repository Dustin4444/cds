import React from 'react';
export declare const SparklineInteractiveHoverPrice: React.MemoExoticComponent<() => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SparklineInteractiveHoverPrice.d.ts.map