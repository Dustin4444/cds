import React from 'react';
import type { ChartGetMarker } from '@cbhq/cds-common';
import type { SparklineInteractiveBaseProps } from './SparklineInteractive';
export declare const scrubHandlerStaticClassName = "cds-sparkline--scrubhandler";
export declare function fadeInMask(domNode?: HTMLElement | null): void;
type SparklineInteractiveScrubHandlerWebProps<Period extends string> = Pick<SparklineInteractiveBaseProps<Period>, 'onScrub' | 'formatHoverDate' | 'formatHoverPrice'> & {
    getMarker: ChartGetMarker;
    selectedPeriod: Period;
    onScrubEnd?: () => void;
    onScrubStart?: () => void;
    disabled?: boolean;
    children: React.ReactNode;
};
declare const SparklineInteractiveScrubHandlerWithGeneric: <Period extends string>({ onScrubEnd, onScrubStart, children, disabled, onScrub, getMarker, selectedPeriod, formatHoverDate, formatHoverPrice, }: SparklineInteractiveScrubHandlerWebProps<Period>) => import("react/jsx-runtime").JSX.Element;
export declare const SparklineInteractiveScrubHandler: typeof SparklineInteractiveScrubHandlerWithGeneric;
export {};
//# sourceMappingURL=SparklineInteractiveScrubHandler.d.ts.map