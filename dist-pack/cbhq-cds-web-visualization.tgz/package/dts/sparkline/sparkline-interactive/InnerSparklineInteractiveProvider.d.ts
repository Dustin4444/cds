import React from 'react';
type InnerSparklineInteractiveProviderProps = {
    width: number;
    height: number;
    children: React.ReactNode;
};
export declare const InnerSparklineInteractiveProvider: ({ width, height, children, }: InnerSparklineInteractiveProviderProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=InnerSparklineInteractiveProvider.d.ts.map