import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { ChartFormatDate, ChartGetMarker } from './SparklineInteractive';
export type SparklineInteractiveMarkerDatesProps<Period extends string> = {
    getMarker: ChartGetMarker;
    formatDate: ChartFormatDate<Period>;
    selectedPeriod: Period;
    timePeriodGutter?: ThemeVars.Space;
};
declare function SparklineInteractiveMarkerDatesWithGeneric<Period extends string>({ formatDate, selectedPeriod, getMarker, timePeriodGutter, }: SparklineInteractiveMarkerDatesProps<Period>): import("react/jsx-runtime").JSX.Element;
export declare const SparklineInteractiveMarkerDates: typeof SparklineInteractiveMarkerDatesWithGeneric;
export {};
//# sourceMappingURL=SparklineInteractiveMarkerDates.d.ts.map