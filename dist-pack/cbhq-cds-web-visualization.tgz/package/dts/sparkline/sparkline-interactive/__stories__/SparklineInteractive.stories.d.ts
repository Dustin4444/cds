declare const _default: {
    component: <Period extends string>({ compact, ...props }: import("../SparklineInteractive").SparklineInteractiveProps<Period>) => import("react/jsx-runtime").JSX.Element;
    title: string;
    parameters: {
        a11y: {
            test: string;
        };
    };
};
export default _default;
export declare const Default: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const Compact: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const Contained: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const DisableScrubbing: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const HidePeriodSelector: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const yAxisScaling: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const AutoStrokeColor: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const CustomRGBStrokeColor: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const CustomRGBAStrokeColor: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const FillDisabled: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const FallbackPositive: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const FallbackNegative: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const FallbackCompact: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const HoverPrice: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const NoHoverDate: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const WithHeaderNode: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const TimePeriodGutter: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const HoverData: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const HoverDataWithFill: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const BottomPeriodSelector: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const VStackedSparkline: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const NoDataInSelectedPeriod: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const WithCustomStyles: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const DottedFillType: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const YScaleCustom: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const CenteredNarrowOnWideScreen: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
//# sourceMappingURL=SparklineInteractive.stories.d.ts.map