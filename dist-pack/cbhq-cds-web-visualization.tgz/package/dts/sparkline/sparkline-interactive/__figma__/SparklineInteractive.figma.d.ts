export {};
//# sourceMappingURL=SparklineInteractive.figma.d.ts.map