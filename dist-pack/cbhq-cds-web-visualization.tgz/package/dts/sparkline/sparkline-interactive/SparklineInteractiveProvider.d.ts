import React from 'react';
import type { Dispatch, SetStateAction } from 'react';
type SparklineInteractiveProviderProps = {
    children: React.ReactNode;
    compact?: boolean;
};
type SparklineInteractiveContextInterface = {
    isFallbackVisible: boolean;
    compact: boolean;
    width: number;
    height: number;
    showFallback: () => void;
    hideFallback: () => void;
    setWidth: Dispatch<SetStateAction<number>>;
    setHeight: Dispatch<SetStateAction<number>>;
};
export declare const SparklineInteractiveProvider: React.MemoExoticComponent<({ children, compact }: SparklineInteractiveProviderProps) => import("react/jsx-runtime").JSX.Element>;
export declare function useSparklineInteractiveContext(): SparklineInteractiveContextInterface;
export {};
//# sourceMappingURL=SparklineInteractiveProvider.d.ts.map