import React from 'react';
export declare const SparklineInteractiveHoverDate: React.MemoExoticComponent<() => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SparklineInteractiveHoverDate.d.ts.map