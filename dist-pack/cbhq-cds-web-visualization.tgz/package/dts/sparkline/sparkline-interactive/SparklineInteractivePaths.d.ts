import type { SparklineInteractiveBaseProps } from './SparklineInteractive';
export type SparklineInteractivePathsProps<Period extends string> = Pick<SparklineInteractiveBaseProps<Period>, 'fill' | 'fillType' | 'yAxisScalingFactor' | 'strokeColor' | 'hoverData' | 'compact'> & {
    showHoverData: boolean;
    path: string;
    area: string;
    selectedPeriod: Period;
};
declare function SparklineInteractivePathsWithGeneric<Period extends string>({ showHoverData, fill, fillType, path, area, selectedPeriod, yAxisScalingFactor, strokeColor, hoverData, compact, }: SparklineInteractivePathsProps<Period>): import("react/jsx-runtime").JSX.Element;
export declare const SparklineInteractivePaths: typeof SparklineInteractivePathsWithGeneric;
export {};
//# sourceMappingURL=SparklineInteractivePaths.d.ts.map