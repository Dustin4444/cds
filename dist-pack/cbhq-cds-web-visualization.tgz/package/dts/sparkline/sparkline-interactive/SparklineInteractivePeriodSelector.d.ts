export type SparklineInteractivePeriodSelectorProps<Period extends string> = {
    selectedPeriod: Period;
    setSelectedPeriod: (period: Period) => void;
    periods: {
        label: string;
        value: Period;
    }[];
    color: string;
};
export type SparklineInteractivePeriodProps<Period extends string> = {
    period: {
        label: string;
        value: Period;
    };
    selectedPeriod: Period;
    setSelectedPeriod: SparklineInteractivePeriodSelectorProps<Period>['setSelectedPeriod'];
    color: string;
};
export declare const SparklineInteractivePeriodSelector: <Period extends string>({ selectedPeriod, setSelectedPeriod, periods, color, }: SparklineInteractivePeriodSelectorProps<Period>) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SparklineInteractivePeriodSelector.d.ts.map