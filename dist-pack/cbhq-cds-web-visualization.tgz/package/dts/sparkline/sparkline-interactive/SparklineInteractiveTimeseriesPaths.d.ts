import React from 'react';
import type { ChartDataPoint, ChartTimeseries } from '@cbhq/cds-common/types';
import type { Area, Line } from 'd3-shape';
export type TimeseriesPathOnRenderParams = {
    path: string;
    area: string;
};
export type TimeseriesPathProps = {
    lineFn: Line<ChartDataPoint>;
    areaFn: Area<ChartDataPoint>;
    timeseries: ChartTimeseries;
    initialPath: string;
    onRender?: ({ path, area }: TimeseriesPathOnRenderParams) => void;
};
export type SparklineInteractiveTimeseriesPathsProps = {
    initialPath: string;
    data: ChartTimeseries[];
    width: number;
    height: number;
    onRender: ({ path, area }: TimeseriesPathOnRenderParams) => void;
};
export declare const SparklineInteractiveTimeseriesPaths: React.MemoExoticComponent<({ data, width, height, initialPath, onRender }: SparklineInteractiveTimeseriesPathsProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SparklineInteractiveTimeseriesPaths.d.ts.map