import React from 'react';
export type SparklineInteractiveLineVerticalProps = {
    color: string;
};
export declare const SparklineInteractiveLineVertical: React.MemoExoticComponent<({ color }: SparklineInteractiveLineVerticalProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SparklineInteractiveLineVertical.d.ts.map