export {};
//# sourceMappingURL=SparklineInteractivePeriodSelector.test.d.ts.map