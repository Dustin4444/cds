export {};
//# sourceMappingURL=SparklineInteractive.test.d.ts.map