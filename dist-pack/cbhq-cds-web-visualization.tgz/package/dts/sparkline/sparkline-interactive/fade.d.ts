export declare function fadeOut(domNode?: HTMLElement | null): void;
export declare function fadeIn(domNode?: HTMLElement | null): void;
//# sourceMappingURL=fade.d.ts.map