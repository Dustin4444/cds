import React from 'react';
import type { Dispatch, SetStateAction } from 'react';
type SparklineInteractiveScrubContextInterface = {
    setLineDOMNode: Dispatch<SetStateAction<HTMLDivElement | null>>;
    setMaskDOMNode: Dispatch<SetStateAction<HTMLDivElement | null>>;
    setHoverDateDOMNode: Dispatch<SetStateAction<HTMLSpanElement | null>>;
    setHoverPriceDOMNode: Dispatch<SetStateAction<HTMLSpanElement | null>>;
    lineDOMNode: HTMLDivElement | null;
    maskDOMNode: HTMLDivElement | null;
    hoverDateDOMNode: HTMLSpanElement | null;
    hoverPriceDOMNode: HTMLSpanElement | null;
};
export declare const SparklineInteractiveScrubProvider: React.MemoExoticComponent<({ children }: {
    children: React.ReactNode;
}) => import("react/jsx-runtime").JSX.Element>;
export declare function useSparklineInteractiveScrubContext(): SparklineInteractiveScrubContextInterface;
export {};
//# sourceMappingURL=SparklineInteractiveScrubProvider.d.ts.map