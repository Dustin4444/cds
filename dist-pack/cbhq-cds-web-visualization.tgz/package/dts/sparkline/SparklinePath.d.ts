import React from 'react';
export type SparklinePathRef = SVGPathElement | null;
export type SparklinePathBaseProps = {
    /** The svg string path that is generate via useSparklinePath */
    path?: string;
    /** Color of the stroke for the path. */
    stroke: string;
};
export declare const SparklinePath: React.MemoExoticComponent<React.ForwardRefExoticComponent<SparklinePathBaseProps & React.RefAttributes<SparklinePathRef>>>;
//# sourceMappingURL=SparklinePath.d.ts.map