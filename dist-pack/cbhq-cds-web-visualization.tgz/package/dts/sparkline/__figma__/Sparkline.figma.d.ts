export {};
//# sourceMappingURL=Sparkline.figma.d.ts.map