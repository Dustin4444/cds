export type SparklineAreaPatternBaseProps = {
    color: string;
    id: string;
    /**
     * Opacity for the pattern. If not provided, uses theme-based opacity from useSparklineAreaOpacity.
     */
    opacity?: number;
};
export declare const SparklineAreaPattern: ({ color, id, opacity }: SparklineAreaPatternBaseProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SparklineAreaPattern.d.ts.map