import type React from 'react';
import type { ElementChildren } from '@cbhq/cds-common/types';
import type { SparklineAreaBaseProps } from './SparklineArea';
export declare function generateSparklineAreaWithId(id: string, children: ElementChildren<SparklineAreaBaseProps>, maskId?: string): React.ReactElement<SparklineAreaBaseProps, string | React.JSXElementConstructor<any>> | undefined;
//# sourceMappingURL=generateSparklineWithId.d.ts.map