import type { CounterBaseProps } from '@cbhq/cds-web/visualizations/Counter';
export declare const Counter: ({ startNum, endNum, renderNum, durationInMillis }: CounterBaseProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Counter.d.ts.map