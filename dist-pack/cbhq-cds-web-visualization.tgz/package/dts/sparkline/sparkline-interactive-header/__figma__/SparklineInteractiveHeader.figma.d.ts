export {};
//# sourceMappingURL=SparklineInteractiveHeader.figma.d.ts.map