export {};
//# sourceMappingURL=SparklineInteractiveHeader.test.d.ts.map