import React from 'react';
import { type SparklineInteractiveHeaderRef, type SparklineInteractiveSubHead } from '../SparklineInteractiveHeader';
declare const _default: {
    component: React.MemoExoticComponent<React.ForwardRefExoticComponent<import("@cbhq/cds-common").SharedProps & {
        defaultTitle: React.ReactNode;
        defaultLabel?: string;
        defaultSubHead?: SparklineInteractiveSubHead;
        labelNode?: React.ReactNode;
        compact?: boolean;
    } & React.RefAttributes<SparklineInteractiveHeaderRef>>>;
    title: string;
    parameters: {
        a11y: {
            test: string;
        };
    };
};
export default _default;
export declare const Default: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const CustomLabel: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const Compact: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const BottomPeriodSelector: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
    };
};
export declare const AlternatePeriods: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const CustomTitle: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SparklineInteractiveHeader.stories.d.ts.map