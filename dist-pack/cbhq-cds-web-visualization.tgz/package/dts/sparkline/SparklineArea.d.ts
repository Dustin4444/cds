import React from 'react';
export type SparklineAreaBaseProps = {
    area?: string;
    patternId?: string;
    maskId?: string;
};
/**
 * @deprecated Use AreaChart instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v4
 */
export declare const SparklineArea: React.MemoExoticComponent<React.ForwardRefExoticComponent<SparklineAreaBaseProps & React.RefAttributes<SVGPathElement | null>>>;
//# sourceMappingURL=SparklineArea.d.ts.map