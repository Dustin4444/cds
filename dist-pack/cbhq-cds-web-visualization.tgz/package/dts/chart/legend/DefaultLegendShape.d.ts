import React from 'react';
import { type BoxProps } from '@cbhq/cds-web/layout';
import type { LegendShapeProps } from './Legend';
export type DefaultLegendShapeProps = LegendShapeProps & Omit<BoxProps<'div'>, 'children' | 'color'>;
export declare const DefaultLegendShape: React.NamedExoticComponent<DefaultLegendShapeProps>;
//# sourceMappingURL=DefaultLegendShape.d.ts.map