import { type HStackDefaultElement, type HStackProps } from '@cbhq/cds-web/layout';
import type { LegendEntryProps } from './Legend';
export type DefaultLegendEntryProps = LegendEntryProps & Omit<HStackProps<HStackDefaultElement>, 'children' | 'color'>;
export declare const DefaultLegendEntry: import("react").MemoExoticComponent<({ seriesId, label, color, shape, ShapeComponent, gap, className, classNames, style, styles, testID, ...props }: DefaultLegendEntryProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=DefaultLegendEntry.d.ts.map