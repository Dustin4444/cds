declare const _default: {
    component: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Omit<import("..").LegendProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>>;
    title: string;
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Legend.stories.d.ts.map