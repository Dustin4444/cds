export {};
//# sourceMappingURL=AreaChart.test.d.ts.map