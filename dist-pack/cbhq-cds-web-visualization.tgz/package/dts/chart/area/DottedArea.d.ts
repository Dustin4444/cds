import { type PathProps } from '../Path';
import type { AreaComponentProps } from './Area';
export type DottedAreaProps = Pick<PathProps, 'stroke' | 'strokeWidth' | 'strokeOpacity' | 'strokeLinecap' | 'strokeLinejoin' | 'strokeDasharray' | 'strokeDashoffset' | 'clipOffset' | 'children'> & AreaComponentProps & {
    /**
     * Size of the pattern unit (width and height).
     * @default 4
     */
    patternSize?: number;
    /**
     * Size of the dots within the pattern.
     * @default 1
     */
    dotSize?: number;
    /**
     * Opacity at the peak values (top/bottom of gradient).
     * @note only used when no gradient is provided
     * @default 1
     */
    peakOpacity?: number;
    /**
     * Opacity at the baseline (0 or edge closest to 0).
     * @note only used when no gradient is provided
     * @default 0
     */
    baselineOpacity?: number;
};
/**
 * A customizable dotted area gradient component.
 * When no gradient is provided, renders a default gradient based
 * on the fill color and peak/baseline opacities.
 */
export declare const DottedArea: import("react").NamedExoticComponent<DottedAreaProps>;
//# sourceMappingURL=DottedArea.d.ts.map