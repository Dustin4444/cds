import { type PathProps } from '../Path';
import type { AreaComponentProps } from './Area';
export type SolidAreaProps = Pick<PathProps, 'stroke' | 'strokeWidth' | 'strokeOpacity' | 'strokeLinecap' | 'strokeLinejoin' | 'strokeDasharray' | 'strokeDashoffset' | 'clipRect' | 'clipOffset' | 'children'> & AreaComponentProps;
/**
 * A customizable solid area component which uses Path.
 * When a gradient is provided, renders with gradient fill.
 * Otherwise, renders with solid fill.
 */
export declare const SolidArea: import("react").NamedExoticComponent<SolidAreaProps>;
//# sourceMappingURL=SolidArea.d.ts.map