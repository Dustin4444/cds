import { type PathProps } from '../Path';
import type { AreaComponentProps } from './Area';
export type GradientAreaProps = Pick<PathProps, 'stroke' | 'strokeWidth' | 'strokeOpacity' | 'strokeLinecap' | 'strokeLinejoin' | 'strokeDasharray' | 'strokeDashoffset' | 'clipRect' | 'clipOffset' | 'children'> & AreaComponentProps & {
    /**
     * Opacity at peak values.
     * @note only used when no gradient is provided
     * @default 0.3
     */
    peakOpacity?: number;
    /**
     * Opacity at the baseline.
     * @note only used when no gradient is provided
     * @default 0
     */
    baselineOpacity?: number;
};
/**
 * A customizable gradient area component which uses Path with SVG linearGradient.
 *
 * When no gradient is provided, automatically creates an appropriate gradient:
 * - For data crossing zero: Creates a diverging gradient with peak opacity at both extremes
 *   and baseline opacity at zero (or the specified baseline).
 * - For all-positive or all-negative data: Creates a simple gradient from baseline to peak.
 */
export declare const GradientArea: import("react").NamedExoticComponent<GradientAreaProps>;
//# sourceMappingURL=GradientArea.d.ts.map