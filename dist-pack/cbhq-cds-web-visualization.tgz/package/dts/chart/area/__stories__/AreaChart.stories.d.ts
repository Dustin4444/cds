declare const _default: {
    title: string;
    component: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Omit<import("..").AreaChartProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>>;
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=AreaChart.stories.d.ts.map