import React from 'react';
import type { SVGProps } from 'react';
import type { PathBaseProps, PathProps } from '../Path';
import { type ChartPathCurveType, type GradientDefinition } from '../utils';
export type AreaBaseProps = {
    /**
     * The ID of the series to render. Will be used to find the data from the chart context.
     */
    seriesId: string;
    /**
     * The curve interpolation method to use for the line.
     * @default 'bump'
     */
    curve?: ChartPathCurveType;
    /**
     * The type of area to render.
     * @default 'solid'
     */
    type?: 'solid' | 'dotted' | 'gradient';
    /**
     * Component to render the area.
     * Takes precedence over the type prop if provided.
     */
    AreaComponent?: AreaComponent;
    /**
     * When true, the area is connected across null values.
     */
    connectNulls?: boolean;
    /**
     * The color of the area.
     * @default color of the series or 'var(--color-fgPrimary)'
     */
    fill?: PathBaseProps['fill'];
    /**
     * Opacity of the area
     * @note when combined with gradient, both will be applied
     * @default 1
     */
    fillOpacity?: PathBaseProps['fillOpacity'];
    /**
     * Baseline value for the gradient.
     * When set, overrides the default baseline.
     */
    baseline?: number;
    /**
     * Gradient configuration.
     * When provided, creates gradient or threshold-based coloring.
     */
    gradient?: GradientDefinition;
    /**
     * Whether to animate the area.
     * Overrides the animate value from the chart context.
     */
    animate?: PathBaseProps['animate'];
};
export type AreaProps = AreaBaseProps & Pick<PathProps, 'transitions' | 'transition'>;
export type AreaComponentProps = Pick<AreaProps, 'fill' | 'fillOpacity' | 'baseline' | 'gradient' | 'animate' | 'transitions' | 'transition'> & {
    /**
     * Path of the area
     */
    d: SVGProps<SVGPathElement>['d'];
    /**
     * ID of the x-axis to use.
     * If not provided, defaults to the default x-axis.
     * @note Only used for axis selection when layout is 'horizontal'. Vertical layout uses a single x-axis.
     */
    xAxisId?: string;
    /**
     * ID of the y-axis to use.
     * If not provided, defaults to the default y-axis.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    yAxisId?: string;
};
export type AreaComponent = React.FC<AreaComponentProps>;
export declare const Area: React.NamedExoticComponent<AreaProps>;
//# sourceMappingURL=Area.d.ts.map