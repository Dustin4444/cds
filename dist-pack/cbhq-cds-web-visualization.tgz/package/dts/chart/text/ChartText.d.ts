import React from 'react';
import type { Rect, SharedProps } from '@cbhq/cds-common/types';
import { type BoxProps } from '@cbhq/cds-web/layout';
import { type ChartInset } from '../utils';
type ValidChartTextChildElements = React.ReactElement<React.SVGProps<SVGTSpanElement>, 'tspan'> | React.ReactElement<React.SVGProps<SVGTextPathElement>, 'textPath'>;
/**
 * The supported content types for ChartText.
 */
export type ChartTextChildren = string | number | null | undefined | ValidChartTextChildElements | ValidChartTextChildElements[];
/**
 * Horizontal alignment options for chart text.
 */
export type TextHorizontalAlignment = 'left' | 'center' | 'right';
/**
 * Vertical alignment options for chart text.
 */
export type TextVerticalAlignment = 'top' | 'middle' | 'bottom';
export type ChartTextBaseProps = SharedProps & {
    /**
     * The text color.
     * @default 'var(--color-fgMuted)'
     */
    color?: string;
    /**
     * The background color of the text's background rectangle.
     * @default 'var(--color-bg)' if elevated, otherwise 'transparent'
     */
    background?: string;
    /**
     * Whether the text should have an elevated appearance with a shadow.
     * @default false
     */
    elevated?: boolean;
    /**
     * When true, disables automatic repositioning to fit within bounds.
     */
    disableRepositioning?: boolean;
    /**
     * Optional bounds rectangle to constrain the text within. If provided, text will be positioned
     * to stay within these bounds. Defaults to the full chart bounds when not provided.
     */
    bounds?: Rect;
    /**
     * Callback fired when text dimensions change.
     * Used for collision detection and smart positioning.
     * Returns the adjusted position and dimensions.
     */
    onDimensionsChange?: (rect: Rect) => void;
    /**
     * Inset around the text content for the background rect.
     * Only affects the background, text position remains unchanged.
     */
    inset?: number | ChartInset;
    /**
     * Border radius for the background rectangle.
     * @default 4
     */
    borderRadius?: number;
};
export type ChartTextProps = ChartTextBaseProps & Pick<BoxProps<'g'>, 'font' | 'fontFamily' | 'fontSize' | 'fontWeight' | 'opacity'> & {
    /**
     * The desired x offset in SVG pixels.
     */
    dx?: number;
    /**
     * The desired y offset in SVG pixels.
     */
    dy?: number;
    /**
     * The text content to display.
     */
    children: ChartTextChildren;
    /**
     * The desired x position in SVG pixels.
     * @note Text will be automatically positioned to fit within bounds unless `disableRepositioning` is true.
     */
    x: number;
    /**
     * The desired y position in SVG pixels.
     * @note Text will be automatically positioned to fit within bounds unless `disableRepositioning` is true.
     */
    y: number;
    /**
     * Horizontal alignment of the component.
     * @default 'center'
     */
    horizontalAlignment?: TextHorizontalAlignment;
    /**
     * Vertical alignment of the component.
     * @default 'middle'
     */
    verticalAlignment?: TextVerticalAlignment;
    style?: React.CSSProperties;
    styles?: {
        root?: React.CSSProperties;
        text?: React.CSSProperties;
        backgroundRect?: React.CSSProperties;
    };
    className?: string;
    classNames?: {
        root?: string;
        text?: string;
        backgroundRect?: string;
    };
};
export declare const ChartText: React.NamedExoticComponent<ChartTextProps>;
export {};
//# sourceMappingURL=ChartText.d.ts.map