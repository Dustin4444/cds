import { type ChartTextChildren, type ChartTextProps } from './ChartText';
/**
 * Configuration for a single text label in the display list
 */
export type TextLabelData = {
    /**
     * The text content to display
     */
    label: ChartTextChildren;
    /**
     * X coordinate where the text should be positioned
     */
    x: number;
    /**
     * Y coordinate where the text should be positioned
     */
    y: number;
    /**
     * Additional props to pass to the ChartText component for this specific label
     */
    chartTextProps?: Partial<ChartTextProps>;
};
export type TextLabelDataWithKey = TextLabelData & {
    key: string;
};
export type ChartTextGroupBaseProps = {
    /**
     * Array of text labels to display
     */
    labels: TextLabelData[];
    /**
     * Minimum gap between labels in pixels
     * @default 8
     */
    minGap?: number;
    /**
     * Whether to always show first and last labels
     * @default true
     */
    prioritizeEndLabels?: boolean;
    /**
     * Common props to apply to all ChartText components
     */
    chartTextProps?: Partial<ChartTextProps>;
    /**
     * Custom component to render each label
     * @default ChartText
     */
    LabelComponent?: React.FC<ChartTextProps>;
};
export type ChartTextGroupProps = ChartTextGroupBaseProps;
/**
 * A smart text display component that prevents label overlap through collision detection.
 *
 * This component renders a list of ChartText components and automatically hides overlapping elements
 * to ensure readability.
 *
 * The component focuses solely on overlap prevention logic for better separation of concerns.
 */
export declare const ChartTextGroup: import("react").NamedExoticComponent<ChartTextGroupBaseProps>;
//# sourceMappingURL=ChartTextGroup.d.ts.map