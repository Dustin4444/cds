import React from 'react';
import { type BoxBaseProps, type BoxProps } from '@cbhq/cds-web/layout';
import { type ScrubberProviderProps } from './scrubber/ScrubberProvider';
import { type CartesianAxisConfigProps, type CartesianChartLayout, type ChartInset, type LegendPosition, type Series } from './utils';
export type CartesianChartBaseProps = BoxBaseProps & Pick<ScrubberProviderProps, 'enableScrubbing' | 'onScrubberPositionChange'> & {
    /**
     * Configuration objects that define how to visualize the data.
     * Each series contains its own data array.
     */
    series?: Array<Series>;
    /**
     * Chart layout - describes the direction bars/areas grow.
     * - 'vertical' (default): Bars grow vertically. X is category axis, Y is value axis.
     * - 'horizontal': Bars grow horizontally. Y is category axis, X is value axis.
     * @default 'vertical'
     */
    layout?: CartesianChartLayout;
    /**
     * Whether to animate the chart.
     * @default true
     */
    animate?: boolean;
    /**
     * Configuration for x-axis(es). Can be a single config or array of configs.
     *
     * @note Multiple x-axis configs are only supported when `layout="horizontal"`.
     */
    xAxis?: Partial<CartesianAxisConfigProps> | Partial<CartesianAxisConfigProps>[];
    /**
     * Configuration for y-axis(es). Can be a single config or array of configs.
     *
     * @note `layout="horizontal"` supports only one y-axis config.
     */
    yAxis?: Partial<Omit<CartesianAxisConfigProps, 'data'>> | Partial<Omit<CartesianAxisConfigProps, 'data'>>[];
    /**
     * Inset around the entire chart (outside the axes).
     */
    inset?: number | Partial<ChartInset>;
    /**
     * Whether to show the legend or a custom legend element.
     * - `true` renders the default Legend component
     * - A React element renders that element as the legend
     * - `false` or omitted hides the legend
     */
    legend?: boolean | React.ReactNode;
    /**
     * Position of the legend relative to the chart.
     * @default 'bottom'
     */
    legendPosition?: LegendPosition;
    /**
     * Accessibility label for the legend group.
     * @default 'Legend'
     */
    legendAccessibilityLabel?: string;
};
export type CartesianChartProps = Omit<BoxProps<'div'>, 'title'> & CartesianChartBaseProps & {
    /**
     * Custom class name for the root element.
     */
    className?: string;
    /**
     * Custom class names for the component.
     */
    classNames?: {
        /**
         * Custom class name for the root element.
         */
        root?: string;
        /**
         * Custom class name for the chart SVG element.
         */
        chart?: string;
    };
    /**
     * Custom styles for the root element.
     */
    style?: React.CSSProperties;
    /**
     * Custom styles for the component.
     */
    styles?: {
        /**
         * Custom styles for the root element.
         */
        root?: React.CSSProperties;
        /**
         * Custom styles for the chart SVG element.
         */
        chart?: React.CSSProperties;
    };
};
export declare const CartesianChart: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<CartesianChartProps, "ref"> & React.RefAttributes<SVGSVGElement>>>;
//# sourceMappingURL=CartesianChart.d.ts.map