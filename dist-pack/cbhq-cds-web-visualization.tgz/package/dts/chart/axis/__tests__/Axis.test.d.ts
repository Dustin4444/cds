export {};
//# sourceMappingURL=Axis.test.d.ts.map