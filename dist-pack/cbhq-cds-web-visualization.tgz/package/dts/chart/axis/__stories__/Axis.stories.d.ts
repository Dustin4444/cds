import React from 'react';
declare const _default: {
    component: React.NamedExoticComponent<import("..").XAxisProps>;
    title: string;
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Axis.stories.d.ts.map