import { type AxisBaseProps, type AxisProps } from './Axis';
export type XAxisBaseProps = AxisBaseProps & {
    /**
     * The ID of the axis to render.
     * Defaults to defaultAxisId if not specified.
     * @note Only used for axis selection when layout is 'horizontal'. Vertical layout uses a single x-axis.
     */
    axisId?: string;
    /**
     * The position of the axis relative to the chart's drawing area.
     * @default 'bottom'
     */
    position?: 'top' | 'bottom';
    /**
     * Height of the axis. This value is inclusive of the padding.
     * @default 32 when no label is provided, 52 when a label is provided
     */
    height?: number;
};
export type XAxisProps = AxisProps & XAxisBaseProps;
export declare const XAxis: import("react").NamedExoticComponent<XAxisProps>;
//# sourceMappingURL=XAxis.d.ts.map