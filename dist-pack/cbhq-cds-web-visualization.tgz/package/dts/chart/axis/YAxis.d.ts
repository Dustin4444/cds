import { type AxisBaseProps, type AxisProps } from './Axis';
export type YAxisBaseProps = AxisBaseProps & {
    /**
     * The ID of the axis to render.
     * Defaults to defaultAxisId if not specified.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    axisId?: string;
    /**
     * The position of the axis relative to the chart's drawing area.
     * @default 'right'
     */
    position?: 'left' | 'right';
    /**
     * Width of the axis. This value is inclusive of the padding.
     * @default 44 when no label is provided, 64 when a label is provided
     */
    width?: number;
};
export type YAxisProps = AxisProps & YAxisBaseProps;
export declare const YAxis: import("react").NamedExoticComponent<YAxisProps>;
//# sourceMappingURL=YAxis.d.ts.map