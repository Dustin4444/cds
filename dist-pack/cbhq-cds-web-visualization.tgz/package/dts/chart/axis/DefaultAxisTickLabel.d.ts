import type { AxisTickLabelComponentProps } from './Axis';
export type DefaultAxisTickLabelProps = AxisTickLabelComponentProps;
/**
 * DefaultAxisTickLabel is the default label component for axis tick labels.
 * Provides standard styling for both X and Y axis tick labels.
 */
export declare const DefaultAxisTickLabel: import("react").NamedExoticComponent<AxisTickLabelComponentProps>;
//# sourceMappingURL=DefaultAxisTickLabel.d.ts.map