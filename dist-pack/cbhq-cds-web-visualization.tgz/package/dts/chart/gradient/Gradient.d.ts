import { type Transition } from 'framer-motion';
import type { GradientDefinition } from '../utils';
export type GradientBaseProps = {
    /**
     * Gradient definition with stops, axis, and other configuration.
     */
    gradient: GradientDefinition;
    /**
     * X-axis ID to use for gradient processing.
     * When provided, the gradient will align with the specified x-axis range.
     * @note Only used for axis selection when layout is 'horizontal'. Vertical layout uses a single x-axis.
     */
    xAxisId?: string;
    /**
     * Y-axis ID to use for gradient processing.
     * When provided, the gradient will align with the specified y-axis range.
     * This ensures gradients work correctly when the axis has a custom range configuration.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    yAxisId?: string;
};
export type GradientProps = GradientBaseProps & {
    /**
     * Unique ID for the gradient definition.
     * Will be used in `url(#${id})` references.
     */
    id: string;
    /**
     * Whether to animate gradient changes.
     */
    animate?: boolean;
    /**
     * Transition configuration for animation.
     */
    transition?: Transition;
};
/**
 * Renders an SVG linearGradient element based on a GradientDefinition.
 * The gradient can be referenced via `fill="url(#${id})"` or `stroke="url(#${id})"`.
 */
export declare const Gradient: import("react").NamedExoticComponent<GradientProps>;
//# sourceMappingURL=Gradient.d.ts.map