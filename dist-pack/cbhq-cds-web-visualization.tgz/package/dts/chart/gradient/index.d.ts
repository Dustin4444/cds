export { Gradient, type GradientProps } from './Gradient';
//# sourceMappingURL=index.d.ts.map