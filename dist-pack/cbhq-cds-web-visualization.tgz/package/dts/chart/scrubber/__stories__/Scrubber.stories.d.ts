import { type ScrubberBeaconProps } from '../..';
declare const _default: {
    component: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<import("@cbhq/cds-common").SharedProps & Pick<import("../ScrubberBeaconGroup").ScrubberBeaconGroupBaseProps, "idlePulse"> & Pick<import("../..").ReferenceLineBaseProps, "LabelComponent" | "LineComponent" | "labelElevated"> & Pick<import("../ScrubberBeaconGroup").ScrubberBeaconGroupProps, "BeaconComponent"> & Pick<import("../ScrubberBeaconLabelGroup").ScrubberBeaconLabelGroupProps, "BeaconLabelComponent"> & {
        seriesIds?: string[];
        hideBeaconLabels?: boolean;
        hideLine?: boolean;
        hideOverlay?: boolean;
        overlayOffset?: number;
        beaconLabelMinGap?: import("../ScrubberBeaconLabelGroup").ScrubberBeaconLabelGroupBaseProps["labelMinGap"];
        beaconLabelHorizontalOffset?: import("../ScrubberBeaconLabelGroup").ScrubberBeaconLabelGroupBaseProps["labelHorizontalOffset"];
        beaconLabelPreferredSide?: import("../ScrubberBeaconLabelGroup").ScrubberBeaconLabelGroupBaseProps["labelPreferredSide"];
        label?: import("../..").ReferenceLineBaseProps["label"] | ((dataIndex: number) => import("../..").ReferenceLineBaseProps["label"]);
        labelFont?: import("../..").ChartTextProps["font"];
        labelBoundsInset?: number | import("../..").ChartInset;
        beaconLabelFont?: import("../..").ChartTextProps["font"];
        lineStroke?: import("../..").ReferenceLineBaseProps["stroke"];
        beaconStroke?: string;
    } & {
        transitions?: ScrubberBeaconProps["transitions"];
        beaconTransitions?: ScrubberBeaconProps["transitions"];
        accessibilityLabel?: string | ((dataIndex: number) => string);
        styles?: {
            overlay?: React.CSSProperties;
            beacon?: React.CSSProperties;
            line?: React.CSSProperties;
            label?: React.CSSProperties;
            beaconLabel?: React.CSSProperties;
        };
        classNames?: {
            overlay?: string;
            beacon?: string;
            line?: string;
            label?: string;
            beaconLabel?: string;
        };
    } & import("react").RefAttributes<import("../ScrubberBeaconGroup").ScrubberBeaconGroupRef>>>;
    title: string;
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Scrubber.stories.d.ts.map