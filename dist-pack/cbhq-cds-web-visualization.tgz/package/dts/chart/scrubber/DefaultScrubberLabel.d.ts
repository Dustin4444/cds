import type { ScrubberLabelProps } from './Scrubber';
export type DefaultScrubberLabelProps = ScrubberLabelProps;
/**
 * DefaultScrubberLabel is the default label component for the scrubber line.
 * In vertical layout, it positions the label above the scrubber line.
 * In horizontal layout, it centers the label in the chart's right inset.
 */
export declare const DefaultScrubberLabel: import("react").NamedExoticComponent<import("..").ReferenceLineLabelComponentProps>;
//# sourceMappingURL=DefaultScrubberLabel.d.ts.map