import { type Transition } from 'framer-motion';
import type { ScrubberBeaconProps, ScrubberBeaconRef } from './Scrubber';
export type DefaultScrubberBeaconProps = ScrubberBeaconProps & {
    /**
     * Radius of the beacon circle.
     * @default 5
     */
    radius?: number;
    /**
     * Stroke width of the beacon circle.
     * @default 2
     */
    strokeWidth?: number;
};
export declare const DefaultScrubberBeacon: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<import("@cbhq/cds-common").SharedProps & import("./Scrubber").ScrubberBeaconBaseProps & {
    transitions?: {
        enter?: Transition | null;
        update?: Transition | null;
        pulse?: Transition;
        pulseRepeatDelay?: number;
    };
    className?: string;
    style?: React.CSSProperties;
} & {
    /**
     * Radius of the beacon circle.
     * @default 5
     */
    radius?: number;
    /**
     * Stroke width of the beacon circle.
     * @default 2
     */
    strokeWidth?: number;
} & import("react").RefAttributes<ScrubberBeaconRef>>>;
//# sourceMappingURL=DefaultScrubberBeacon.d.ts.map