import { type CSSProperties } from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { ChartTextProps } from '../text';
import { type ScrubberLabelPosition } from '../utils/scrubber';
import type { ScrubberBeaconLabelComponent, ScrubberBeaconLabelProps, ScrubberBeaconProps } from './Scrubber';
export type ScrubberBeaconLabelGroupBaseProps = SharedProps & {
    /**
     * Labels to be displayed.
     */
    labels: Array<Pick<ScrubberBeaconLabelProps, 'seriesId' | 'label' | 'color'>>;
    /**
     * Minimum gap between labels in pixels.
     * @default 4
     */
    labelMinGap?: number;
    /**
     * Horizontal offset of labels from the scrubber line in pixels.
     * @default 16
     */
    labelHorizontalOffset?: number;
    /**
     * Font style for the beacon labels.
     */
    labelFont?: ChartTextProps['font'];
    /**
     * Preferred side for labels.
     * @note labels will switch to the opposite side if there's not enough space on the preferred side.
     * @default 'right'
     */
    labelPreferredSide?: ScrubberLabelPosition;
};
export type ScrubberBeaconLabelGroupProps = ScrubberBeaconLabelGroupBaseProps & {
    /**
     * Custom component to render as a scrubber beacon label.
     * @default DefaultScrubberBeaconLabel
     */
    BeaconLabelComponent?: ScrubberBeaconLabelComponent;
    /**
     * Transition configuration for beacon label animations.
     */
    transitions?: ScrubberBeaconProps['transitions'];
    /**
     * Custom class name for each beacon label.
     */
    className?: string;
    /**
     * Custom inline styles for each beacon label.
     */
    style?: CSSProperties;
};
export declare const ScrubberBeaconLabelGroup: import("react").NamedExoticComponent<ScrubberBeaconLabelGroupProps>;
//# sourceMappingURL=ScrubberBeaconLabelGroup.d.ts.map