import { type ChartTextProps } from '../text';
import type { ScrubberBeaconLabelProps } from './Scrubber';
export type DefaultScrubberBeaconLabelProps = ScrubberBeaconLabelProps & Pick<ChartTextProps, 'background' | 'elevated' | 'borderRadius' | 'font' | 'verticalAlignment' | 'inset' | 'opacity'>;
/**
 * DefaultScrubberBeaconLabel is a special instance of ChartText used to label a series' scrubber beacon (i.e. a point on the series pinned to the scrubber position).
 */
export declare const DefaultScrubberBeaconLabel: import("react").NamedExoticComponent<DefaultScrubberBeaconLabelProps>;
//# sourceMappingURL=DefaultScrubberBeaconLabel.d.ts.map