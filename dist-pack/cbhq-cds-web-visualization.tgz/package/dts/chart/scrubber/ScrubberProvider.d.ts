import React from 'react';
import { type ScrubberContextValue } from '../utils';
export type ScrubberProviderProps = Partial<Pick<ScrubberContextValue, 'enableScrubbing' | 'onScrubberPositionChange'>> & {
    children: React.ReactNode;
    /**
     * A reference to the root SVG element, where interaction event handlers will be attached.
     */
    svgRef: React.RefObject<SVGSVGElement> | null;
};
/**
 * A component which encapsulates the ScrubberContext.
 * It depends on a ChartContext in order to provide accurate mouse tracking.
 */
export declare const ScrubberProvider: React.FC<ScrubberProviderProps>;
//# sourceMappingURL=ScrubberProvider.d.ts.map