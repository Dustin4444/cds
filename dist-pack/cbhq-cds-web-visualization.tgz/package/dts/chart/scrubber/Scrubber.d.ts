import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type Transition } from 'framer-motion';
import { type ReferenceLineBaseProps, type ReferenceLineLabelComponentProps } from '../line';
import type { ChartTextChildren, ChartTextProps } from '../text';
import { type ChartInset, type Series } from '../utils';
import { type ScrubberBeaconGroupBaseProps, type ScrubberBeaconGroupProps, type ScrubberBeaconGroupRef } from './ScrubberBeaconGroup';
import { type ScrubberBeaconLabelGroupBaseProps, type ScrubberBeaconLabelGroupProps } from './ScrubberBeaconLabelGroup';
export type ScrubberBeaconRef = {
    /**
     * Triggers a single pulse animation.
     * Only works when the beacon is in idle state (not actively scrubbing).
     */
    pulse: () => void;
};
export type ScrubberBeaconBaseProps = {
    /**
     * Id of the series.
     */
    seriesId: Series['id'];
    /**
     * Color of the series.
     */
    color?: string;
    /**
     * X coordinate in data space.
     * In vertical layout this is the scrubber index-axis value.
     * In horizontal layout this is the series value.
     */
    dataX: number;
    /**
     * Y coordinate in data space.
     * In vertical layout this is the series value.
     * In horizontal layout this is the scrubber index-axis value.
     */
    dataY: number;
    /**
     * Whether the beacon is in idle state (not actively scrubbing).
     */
    isIdle?: boolean;
    /**
     * Pulse the beacon while it is at rest.
     *
     * @note Only has an effect when `isIdle` is `true`. Pulse animations work
     * regardless of the chart's `animate` prop.
     */
    idlePulse?: boolean;
    /**
     * Whether position animations are enabled.
     * @default to ChartContext's animate value
     */
    animate?: boolean;
    /**
     * Opacity of the beacon.
     * @default 1
     */
    opacity?: number;
    /**
     * Stroke color of the beacon circle.
     * @default 'var(--color-bg)'
     */
    stroke?: string;
};
export type ScrubberBeaconProps = SharedProps & ScrubberBeaconBaseProps & {
    /**
     * Transition configuration for beacon animations.
     */
    transitions?: {
        /**
         * Transition for the initial enter/reveal animation.
         * Set to `null` to disable.
         */
        enter?: Transition | null;
        /**
         * Transition for subsequent data update animations.
         * Set to `null` to disable.
         */
        update?: Transition | null;
        /**
         * Transition used for the pulse animation.
         * @default transition { duration: 1.6, ease: 'easeInOut' }
         */
        pulse?: Transition;
        /**
         * Delay, in seconds between pulse transitions
         * when `idlePulse` is enabled.
         * @default 0.4
         */
        pulseRepeatDelay?: number;
    };
    /**
     * Custom className for styling.
     */
    className?: string;
    /**
     * Custom inline styles.
     */
    style?: React.CSSProperties;
};
export type ScrubberBeaconComponent = React.FC<ScrubberBeaconProps & {
    ref?: React.Ref<ScrubberBeaconRef>;
}>;
export type ScrubberBeaconLabelProps = Pick<Series, 'color'> & Pick<ChartTextProps, 'x' | 'y' | 'dx' | 'horizontalAlignment' | 'onDimensionsChange' | 'opacity' | 'font' | 'className' | 'style'> & {
    /**
     * Label for the series.
     */
    label: ChartTextChildren;
    /**
     * Id of the series.
     */
    seriesId: Series['id'];
    /**
     * Transition configuration for position animations.
     * When provided, the label component should animate its y position using this transition.
     */
    transition?: Transition;
};
export type ScrubberBeaconLabelComponent = React.FC<ScrubberBeaconLabelProps>;
export type ScrubberLabelProps = ReferenceLineLabelComponentProps;
export type ScrubberLabelComponent = React.FC<ScrubberLabelProps>;
export type ScrubberBaseProps = SharedProps & Pick<ScrubberBeaconGroupBaseProps, 'idlePulse'> & Pick<ReferenceLineBaseProps, 'LineComponent' | 'LabelComponent' | 'labelElevated'> & Pick<ScrubberBeaconGroupProps, 'BeaconComponent'> & Pick<ScrubberBeaconLabelGroupProps, 'BeaconLabelComponent'> & {
    /**
     * Array of series IDs to highlight when scrubbing with scrubber beacons.
     * By default, all series will be highlighted.
     */
    seriesIds?: string[];
    /**
     * Hides the beacon labels while keeping the line label visible (if provided).
     * @default true in horizontal layout, false in vertical layout.
     * @note Beacon labels are always hidden in horizontal layout, and cannot be overridden.
     */
    hideBeaconLabels?: boolean;
    /**
     * Hides the scrubber line.
     * @note This hides Scrubber's ReferenceLine including the label.
     */
    hideLine?: boolean;
    /**
     * Hides the overlay rect which obscures data beyond the scrubber position.
     */
    hideOverlay?: boolean;
    /**
     * Offset of the overlay rect relative to the drawing area.
     * Useful for when scrubbing over lines, where the stroke width would cause part of the line to be visible.
     * @default 2
     */
    overlayOffset?: number;
    /**
     * Minimum gap between beacon labels to prevent overlap.
     * Measured in pixels.
     */
    beaconLabelMinGap?: ScrubberBeaconLabelGroupBaseProps['labelMinGap'];
    /**
     * Horizontal offset for beacon labels from their beacon position.
     * Measured in pixels.
     */
    beaconLabelHorizontalOffset?: ScrubberBeaconLabelGroupBaseProps['labelHorizontalOffset'];
    /**
     * Preferred side for beacon labels.
     * @note labels will switch to the opposite side if there's not enough space on the preferred side.
     * @default 'right'
     */
    beaconLabelPreferredSide?: ScrubberBeaconLabelGroupBaseProps['labelPreferredSide'];
    /**
     * Label text displayed above the scrubber line.
     * Can be a static string or a function that receives the current dataIndex.
     */
    label?: ReferenceLineBaseProps['label'] | ((dataIndex: number) => ReferenceLineBaseProps['label']);
    /**
     * Font style for the scrubber line label.
     */
    labelFont?: ChartTextProps['font'];
    /**
     * Bounds inset for the scrubber line label to prevent cutoff at chart edges.
     * @default inset { top: 4, bottom: 20, left: 12, right: 12 } when labelElevated is true, otherwise none
     */
    labelBoundsInset?: number | ChartInset;
    /**
     * Font style for the beacon labels.
     */
    beaconLabelFont?: ChartTextProps['font'];
    /**
     * Stroke color for the scrubber line.
     */
    lineStroke?: ReferenceLineBaseProps['stroke'];
    /**
     * Stroke color of the scrubber beacon circle.
     * @default 'var(--color-bg)'
     */
    beaconStroke?: string;
};
export type ScrubberProps = ScrubberBaseProps & {
    /**
     * Transition configuration for the scrubber.
     * Controls enter, update, and pulse animations for beacons and beacon labels.
     */
    transitions?: ScrubberBeaconProps['transitions'];
    /**
     * Transition configuration for the scrubber beacon.
     * @deprecated Use `transitions` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v4
     */
    beaconTransitions?: ScrubberBeaconProps['transitions'];
    /**
     * Accessibility label for the scrubber. Can be a static string or a function that receives the current dataIndex.
     * If not provided, label will be used if it resolves to a string.
     */
    accessibilityLabel?: string | ((dataIndex: number) => string);
    /** Custom styles for individual elements of the Scrubber component */
    styles?: {
        /** Overlay element */
        overlay?: React.CSSProperties;
        /** Beacon circle element */
        beacon?: React.CSSProperties;
        /** Scrubber line element */
        line?: React.CSSProperties;
        /** Scrubber line label element */
        label?: React.CSSProperties;
        /** Beacon label element */
        beaconLabel?: React.CSSProperties;
    };
    /** Custom class names for individual elements of the Scrubber component */
    classNames?: {
        /** Overlay element */
        overlay?: string;
        /** Beacon circle element */
        beacon?: string;
        /** Scrubber line element */
        line?: string;
        /** Scrubber line label element */
        label?: string;
        /** Beacon label element */
        beaconLabel?: string;
    };
};
export type ScrubberRef = ScrubberBeaconGroupRef;
/**
 * Unified component that manages all scrubber elements (beacons, line, labels).
 */
export declare const Scrubber: React.MemoExoticComponent<React.ForwardRefExoticComponent<SharedProps & Pick<ScrubberBeaconGroupBaseProps, "idlePulse"> & Pick<ReferenceLineBaseProps, "LabelComponent" | "LineComponent" | "labelElevated"> & Pick<ScrubberBeaconGroupProps, "BeaconComponent"> & Pick<ScrubberBeaconLabelGroupProps, "BeaconLabelComponent"> & {
    /**
     * Array of series IDs to highlight when scrubbing with scrubber beacons.
     * By default, all series will be highlighted.
     */
    seriesIds?: string[];
    /**
     * Hides the beacon labels while keeping the line label visible (if provided).
     * @default true in horizontal layout, false in vertical layout.
     * @note Beacon labels are always hidden in horizontal layout, and cannot be overridden.
     */
    hideBeaconLabels?: boolean;
    /**
     * Hides the scrubber line.
     * @note This hides Scrubber's ReferenceLine including the label.
     */
    hideLine?: boolean;
    /**
     * Hides the overlay rect which obscures data beyond the scrubber position.
     */
    hideOverlay?: boolean;
    /**
     * Offset of the overlay rect relative to the drawing area.
     * Useful for when scrubbing over lines, where the stroke width would cause part of the line to be visible.
     * @default 2
     */
    overlayOffset?: number;
    /**
     * Minimum gap between beacon labels to prevent overlap.
     * Measured in pixels.
     */
    beaconLabelMinGap?: ScrubberBeaconLabelGroupBaseProps["labelMinGap"];
    /**
     * Horizontal offset for beacon labels from their beacon position.
     * Measured in pixels.
     */
    beaconLabelHorizontalOffset?: ScrubberBeaconLabelGroupBaseProps["labelHorizontalOffset"];
    /**
     * Preferred side for beacon labels.
     * @note labels will switch to the opposite side if there's not enough space on the preferred side.
     * @default 'right'
     */
    beaconLabelPreferredSide?: ScrubberBeaconLabelGroupBaseProps["labelPreferredSide"];
    /**
     * Label text displayed above the scrubber line.
     * Can be a static string or a function that receives the current dataIndex.
     */
    label?: ReferenceLineBaseProps["label"] | ((dataIndex: number) => ReferenceLineBaseProps["label"]);
    /**
     * Font style for the scrubber line label.
     */
    labelFont?: ChartTextProps["font"];
    /**
     * Bounds inset for the scrubber line label to prevent cutoff at chart edges.
     * @default inset { top: 4, bottom: 20, left: 12, right: 12 } when labelElevated is true, otherwise none
     */
    labelBoundsInset?: number | ChartInset;
    /**
     * Font style for the beacon labels.
     */
    beaconLabelFont?: ChartTextProps["font"];
    /**
     * Stroke color for the scrubber line.
     */
    lineStroke?: ReferenceLineBaseProps["stroke"];
    /**
     * Stroke color of the scrubber beacon circle.
     * @default 'var(--color-bg)'
     */
    beaconStroke?: string;
} & {
    /**
     * Transition configuration for the scrubber.
     * Controls enter, update, and pulse animations for beacons and beacon labels.
     */
    transitions?: ScrubberBeaconProps["transitions"];
    /**
     * Transition configuration for the scrubber beacon.
     * @deprecated Use `transitions` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v4
     */
    beaconTransitions?: ScrubberBeaconProps["transitions"];
    /**
     * Accessibility label for the scrubber. Can be a static string or a function that receives the current dataIndex.
     * If not provided, label will be used if it resolves to a string.
     */
    accessibilityLabel?: string | ((dataIndex: number) => string);
    /** Custom styles for individual elements of the Scrubber component */
    styles?: {
        /** Overlay element */
        overlay?: React.CSSProperties;
        /** Beacon circle element */
        beacon?: React.CSSProperties;
        /** Scrubber line element */
        line?: React.CSSProperties;
        /** Scrubber line label element */
        label?: React.CSSProperties;
        /** Beacon label element */
        beaconLabel?: React.CSSProperties;
    };
    /** Custom class names for individual elements of the Scrubber component */
    classNames?: {
        /** Overlay element */
        overlay?: string;
        /** Beacon circle element */
        beacon?: string;
        /** Scrubber line element */
        line?: string;
        /** Scrubber line label element */
        label?: string;
        /** Beacon label element */
        beaconLabel?: string;
    };
} & React.RefAttributes<ScrubberBeaconGroupRef>>>;
//# sourceMappingURL=Scrubber.d.ts.map