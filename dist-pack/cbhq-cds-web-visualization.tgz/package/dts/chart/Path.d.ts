import type { SVGProps } from 'react';
import type { Rect, SharedProps } from '@cbhq/cds-common/types';
import { type Transition } from 'framer-motion';
/**
 * Duration in seconds for path enter transition.
 * @deprecated Use `transitions.enter` on the Path component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v4
 */
export declare const pathEnterTransitionDuration = 0.5;
export type PathBaseProps = SharedProps & {
    /**
     * Whether to animate this path. Overrides the animate prop on the Chart component.
     */
    animate?: boolean;
    /**
     * Initial path for enter animation.
     * When provided, the first animation will go from initialPath to d.
     * If not provided, defaults to d (no path enter animation).
     */
    initialPath?: string;
    /**
     * Fill color for the path.
     */
    fill?: string;
    /**
     * Opacity for the path fill.
     */
    fillOpacity?: number;
};
export type PathProps = PathBaseProps & Omit<SVGProps<SVGPathElement>, 'onAnimationStart' | 'onAnimationEnd' | 'onAnimationIteration' | 'onAnimationStartCapture' | 'onAnimationEndCapture' | 'onAnimationIterationCapture' | 'onDrag' | 'onDragEnd' | 'onDragStart' | 'onDragCapture' | 'onDragEndCapture' | 'onDragStartCapture'> & {
    /**
     * Transition configuration for enter and update animations.
     * @note Disable an animation by passing in null.
     *
     * @default transitions = {{
     *   enter: { type: 'tween', duration: 0.5 },
     *   update: { type: 'spring', stiffness: 900, damping: 120, mass: 4 }
     * }}
     *
     * @example
     * // Custom enter and update transitions
     * transitions={{ enter: { type: 'tween', duration: 0.3 }, update: { type: 'spring', damping: 20 } }}
     *
     * @example
     * // Disable enter animation
     * transitions={{ enter: null }}
     */
    transitions?: {
        /**
         * Transition for the initial enter/reveal animation.
         * Set to `null` to disable.
         */
        enter?: Transition | null;
        /**
         * Transition for subsequent data update animations.
         * Set to `null` to disable.
         */
        update?: Transition | null;
    };
    /**
     * Transition for updates.
     * @deprecated Use `transitions.update` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v4
     */
    transition?: Transition;
    /**
     * Offset added to the clip rect boundaries.
     */
    clipOffset?: number;
    /**
     * Custom clip path rect. If provided, this overrides the default chart rect for clipping.
     * Pass null to disable clipping.
     * @default drawingArea of chart + clipOffset
     */
    clipRect?: Rect | null;
};
export declare const Path: import("react").NamedExoticComponent<PathProps>;
//# sourceMappingURL=Path.d.ts.map