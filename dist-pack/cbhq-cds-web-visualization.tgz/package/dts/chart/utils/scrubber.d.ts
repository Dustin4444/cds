import type { Rect } from '@cbhq/cds-common/types';
export type ScrubberLabelPosition = 'left' | 'right';
export type LabelPosition = {
    seriesId: string;
    x: number;
    y: number;
};
export type LabelDimensions = {
    width: number;
    height: number;
};
/**
 * Determines which side (left/right) to place scrubber labels based on available space.
 * Honors the preferred side when there's enough space, otherwise switches to the opposite side.
 */
export declare const getLabelPosition: (beaconX: number, maxLabelWidth: number, drawingArea: Rect, xOffset?: number, preferredSide?: ScrubberLabelPosition) => ScrubberLabelPosition;
type LabelDimension = {
    seriesId: string;
    width: number;
    height: number;
    preferredX: number;
    preferredY: number;
};
/**
 * Calculates Y positions for all labels avoiding overlaps while maintaining order.
 */
export declare const calculateLabelYPositions: (dimensions: LabelDimension[], drawingArea: Rect, labelHeight: number, minGap: number) => Map<string, number>;
export {};
//# sourceMappingURL=scrubber.d.ts.map