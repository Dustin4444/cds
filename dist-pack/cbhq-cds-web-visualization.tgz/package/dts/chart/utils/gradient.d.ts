import type { AxisBounds } from './chart';
import { type ChartScaleFunction } from './scale';
/**
 * Defines a color transition point in the gradient
 */
export type GradientStop = {
    /**
     * Position in data space.
     * Multiple stops at the same offset create hard color transitions.
     */
    offset: number;
    /**  Color at the stop (any valid CSS color) */
    color: string;
    /** Optional opacity (0-1). Defaults to 1. */
    opacity?: number;
};
/**
 * Defines a gradient.
 */
export type GradientDefinition = {
    /**
     * Axis that the gradient maps to.
     * @default 'y'
     */
    axis?: 'x' | 'y';
    /**
     * Gradient stops with colors and positions.
     * Can be an array of stop objects or a function that receives domain bounds.
     */
    stops: GradientStop[] | ((domain: AxisBounds) => GradientStop[]);
};
/**
 * Evaluates the color at a specific data value based on the gradient stops, ignoring opacity.
 * @param stops - The gradient stops configuration
 * @param dataValue - The data value to evaluate (for band scales, this is the index)
 * @param scale - The scale to use for value mapping (handles log scales correctly)
 * @returns The color string at this data value, or undefined if invalid
 */
export declare const evaluateGradientAtValue: (stops: GradientStop[], dataValue: number, scale: ChartScaleFunction) => string | undefined;
/**
 * Creates a gradient configuration for SVG components.
 * Processes a GradientDefinition into a renderable GradientConfig.
 * Supports both numeric scales (linear, log) and categorical scales (band).
 *
 * @param gradient - GradientDefinition configuration (required)
 * @param xScale - X-axis scale (required)
 * @param yScale - Y-axis scale (required)
 * @returns GradientConfig or null if gradient processing fails
 *
 * @example
 * const gradientConfig = useMemo(() => {
 *   if (!gradient || !xScale || !yScale) return;
 *   return getGradientConfig(gradient, xScale, yScale);
 * }, [gradient, xScale, yScale]);
 *
 * if (gradientConfig) {
 *   return (
 *     <defs>
 *       <Gradient
 *         config={gradientConfig}
 *         direction={gradient.axis === 'x' ? 'horizontal' : 'vertical'}
 *         id={gradientId}
 *       />
 *     </defs>
 *   );
 * }
 */
export declare const getGradientConfig: (gradient: GradientDefinition, xScale: ChartScaleFunction, yScale: ChartScaleFunction) => GradientStop[] | undefined;
/**
 * Determines the baseline value for the gradient area by finding the value
 * within the axis bounds that is closest to the target baseline.
 *
 * @param axisBounds - The min and max bounds of the axis
 * @param baseline - The target baseline value (defaults to 0)
 * @returns The value within bounds closest to the baseline
 */
export declare const getBaseline: (axisBounds: AxisBounds, baseline?: number) => number;
/**
 * Generates a gradient definition for the area chart based on the axis bounds
 * and styling parameters. Ensures gradient stops are in ascending order.
 *
 * @param axisBounds - The min and max bounds of the axis
 * @param baselineValue - The baseline value for the gradient
 * @param fill - The color to use for the gradient
 * @param peakOpacity - Opacity at the peak of the gradient
 * @param baselineOpacity - Opacity at the baseline
 * @param axis - The axis the gradient maps to ('y' for vertical, 'x' for horizontal layout)
 * @returns A gradient definition with stops in ascending order
 */
export declare const createGradient: (axisBounds: AxisBounds, baselineValue: number, fill: string, peakOpacity: number, baselineOpacity: number, axis?: "x" | "y") => GradientDefinition;
//# sourceMappingURL=gradient.d.ts.map