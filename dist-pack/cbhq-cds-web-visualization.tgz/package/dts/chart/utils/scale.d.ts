import type { ScaleBand, ScaleLinear, ScaleLogarithmic } from 'd3-scale';
import type { AxisBounds } from './chart';
export type ChartAxisScaleType = 'linear' | 'log' | 'band';
export type NumericScale = ScaleLinear<number, number, never> | ScaleLogarithmic<number, number, never>;
export type CategoricalScale = ScaleBand<number>;
export type ChartScaleFunction = NumericScale | CategoricalScale;
export declare const isCategoricalScale: (scale: ChartScaleFunction) => scale is CategoricalScale;
export declare const isNumericScale: (scale: ChartScaleFunction) => scale is NumericScale;
/**
 * Type guard to check if a scale is logarithmic.
 */
export declare const isLogScale: (scale: ChartScaleFunction) => scale is ScaleLogarithmic<number, number, never>;
/**
 * Create a numeric scale (linear or logarithmic)
 * @returns A numeric scale function
 */
export declare const getNumericScale: ({ scaleType, domain, range, }: {
    scaleType: "linear" | "log";
    domain: AxisBounds;
    range: AxisBounds;
}) => NumericScale;
/**
 * Create a categorical scale (band)
 * @returns A categorical scale function
 */
export declare const getCategoricalScale: ({ domain, range, padding, }: {
    domain: AxisBounds;
    range: AxisBounds;
    padding?: number;
}) => CategoricalScale;
/**
 * Anchor position for points on a scale. Currently used only for band scales.
 *
 * For band scales, this determines where within the band to position a point:
 * - `'stepStart'` - At the start of the step
 * - `'bandStart'` - At the start of the band
 * - `'middle'` - At the center of the band
 * - `'bandEnd'` - At the end of the band
 * - `'stepEnd'` - At the end of the step
 */
export type PointAnchor = 'stepStart' | 'bandStart' | 'middle' | 'bandEnd' | 'stepEnd';
//# sourceMappingURL=scale.d.ts.map