import type { GradientDefinition } from './gradient';
export declare const defaultStackId = "DEFAULT_STACK_ID";
/**
 * Shape variants available for legend items.
 */
export type LegendShapeVariant = 'circle' | 'square' | 'squircle' | 'pill';
/**
 * Shape for legend items. Can be a preset variant or a custom ReactNode.
 */
export type LegendShape = LegendShapeVariant | React.ReactNode;
/**
 * Position of the legend relative to the chart.
 */
export type LegendPosition = 'top' | 'bottom' | 'left' | 'right';
export type AxisBounds = {
    min: number;
    max: number;
};
/**
 * Type guard to check if bounds are complete with both min and max values.
 * @param bounds - The bounds to validate
 * @returns True if bounds has both min and max defined
 */
export declare const isValidBounds: (bounds: Partial<AxisBounds>) => bounds is AxisBounds;
export type Series = {
    /**
     * Id of the series.
     */
    id: string;
    /**
     * Data array for this series. Use null values to create gaps in the visualization.
     *
     * Can be either:
     * - Array of numbers: `[10, -5, 20]`
     * - Array of tuples: `[[0, 10], [0, -5], [0, 20]]` [baseline, value] pairs
     */
    data?: Array<number | null> | Array<[number, number] | null>;
    /**
     * Label of the series.
     * Used for scrubber beacon labels.
     */
    label?: string;
    /**
     * Color of the series.
     * If gradient is provided, that will be used for chart components
     * Color will still be used by scrubber beacon labels
     */
    color?: string;
    /**
     * Color gradient configuration.
     * Takes precedence over color except for scrubber beacon labels.
     */
    gradient?: GradientDefinition;
    /**
     * Id of the x-axis this series uses.
     * Defaults to defaultAxisId if not specified.
     * @note Only used for axis selection when layout is 'horizontal'. Vertical layout uses a single x-axis.
     */
    xAxisId?: string;
    /**
     * Id of the y-axis this series uses.
     * Defaults to defaultAxisId if not specified.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    yAxisId?: string;
    /**
     * Id of the stack group this series belongs to.
     * Series with the same stackId value will be stacked together.
     * If not specified, the series will not be stacked.
     */
    stackId?: string;
    /**
     * Shape of the legend item for this series.
     * Can be a preset shape variant or a custom ReactNode.
     * @default 'circle'
     */
    legendShape?: LegendShape;
};
/**
 * Calculates the domain of a chart from series data.
 * Domain represents the range of x-values from the data.
 */
export declare const getChartDomain: (series: Series[], min?: number, max?: number) => Partial<AxisBounds>;
/**
 * Transforms series data into stacked data using D3's stack algorithm.
 * Returns a map of series ID to transformed [baseline, value] tuples.
 *
 * @param series - Array of series with potential stack properties
 * @returns Map of series ID to stacked data arrays
 */
export declare const getStackedSeriesData: (series: Series[]) => Map<string, Array<[number, number] | null>>;
/**
 * Extracts line data values from series data that may contain tuples.
 * For tuple data [[baseline, value]], extracts the last value.
 * For numeric data [value], returns as-is.
 *
 * @param data - Array of numbers, tuples, or null values
 * @returns Array of numbers or null values
 */
export declare const getLineData: (data?: Array<number | null> | Array<[number, number] | null>) => Array<number | null>;
/**
 * Calculates the range of a chart from series data.
 * Range represents the range of y-values from the data.
 * Handles stacking by transforming data when series have stack properties.
 */
export declare const getChartRange: (series: Series[], min?: number, max?: number) => Partial<AxisBounds>;
export type ChartInset = {
    top: number;
    left: number;
    bottom: number;
    right: number;
};
export declare const defaultVerticalLayoutChartInset: ChartInset;
export declare const defaultHorizontalLayoutChartInset: ChartInset;
/**
 * @deprecated Use `defaultVerticalLayoutChartInset` for vertical layout charts or. This will be removed in a future major release.
 * @deprecationExpectedRemoval v4
 * `defaultHorizontalLayoutChartInset` for horizontal layout charts.
 */
export declare const defaultChartInset: ChartInset;
/**
 * Normalize padding to include all sides with a value.
 * @param padding - The padding to get.
 * @param defaults - Optional complete default values to use instead of 0.
 * @returns The calculated padding.
 */
/**
 * Normalize inset to include all sides with a value.
 * @param inset - The inset to get.
 * @param defaults - Optional complete default values to use instead of 0.
 * @returns The calculated inset.
 */
export declare const getChartInset: (inset?: number | Partial<ChartInset>, defaults?: ChartInset) => ChartInset;
//# sourceMappingURL=chart.d.ts.map