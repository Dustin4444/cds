type CommandType = 'M' | 'L' | 'H' | 'V' | 'C' | 'S' | 'Q' | 'T' | 'A' | 'Z' | 'm' | 'l' | 'h' | 'v' | 'c' | 's' | 'q' | 't' | 'a' | 'z';
type PathCommand = {
    type: CommandType;
    x?: number;
    y?: number;
    x1?: number;
    y1?: number;
    x2?: number;
    y2?: number;
    rx?: number;
    ry?: number;
    xAxisRotation?: number;
    largeArcFlag?: number;
    sweepFlag?: number;
    [key: string]: any;
};
/**
 * Convert command objects to arrays of points, run de Casteljau's algorithm on it
 * to split into to the desired number of segments.
 *
 * @param {Object} commandStart The start command object
 * @param {Object} commandEnd The end command object
 * @param {Number} segmentCount The number of segments to create
 * @return {Object[]} An array of commands representing the segments in sequence
 */
export declare function splitCurve(commandStart: PathCommand, commandEnd: PathCommand, segmentCount?: number): PathCommand[];
type ExcludeSegmentFn = (commandStart: PathCommand, commandEnd: PathCommand) => boolean;
/**
 * Takes a path `d` string and converts it into an array of command
 * objects. Drops the `Z` character.
 *
 * @param {String|null} d A path `d` string
 */
export declare function pathCommandsFromString(d: string | null | undefined): PathCommand[];
type InterpolateOptions = {
    excludeSegment?: ExcludeSegmentFn;
    snapEndsToInput?: boolean;
};
/**
 * Interpolate from A to B by extending A and B during interpolation to have
 * the same number of points. This allows for a smooth transition when they
 * have a different number of points.
 *
 * Ignores the `Z` command in paths unless both A and B end with it.
 *
 * This function works directly with arrays of command objects instead of with
 * path `d` strings (see interpolatePath for working with `d` strings).
 *
 * @param {Object[]} aCommandsInput Array of path commands
 * @param {Object[]} bCommandsInput Array of path commands
 * @param {(Function|Object)} interpolateOptions
 * @param {Function} interpolateOptions.excludeSegment a function that takes a start command object and
 *   end command object and returns true if the segment should be excluded from splitting.
 * @param {Boolean} interpolateOptions.snapEndsToInput a boolean indicating whether end of input should
 *   be sourced from input argument or computed.
 * @returns {Function} Interpolation function that maps t ([0, 1]) to an array of path commands.
 */
export declare function interpolatePathCommands(aCommandsInput: PathCommand[] | null | undefined, bCommandsInput: PathCommand[] | null | undefined, interpolateOptions?: ExcludeSegmentFn | InterpolateOptions): (t: number) => PathCommand[];
/**
 * Interpolate from A to B by extending A and B during interpolation to have
 * the same number of points. This allows for a smooth transition when they
 * have a different number of points.
 *
 * Ignores the `Z` character in paths unless both A and B end with it.
 *
 * @param {String} a The `d` attribute for a path
 * @param {String} b The `d` attribute for a path
 * @param {((command1, command2) => boolean|{
 *   excludeSegment?: (command1, command2) => boolean;
 *   snapEndsToInput?: boolean
 * })} interpolateOptions The excludeSegment function or an options object
 *    - interpolateOptions.excludeSegment a function that takes a start command object and
 *      end command object and returns true if the segment should be excluded from splitting.
 *    - interpolateOptions.snapEndsToInput a boolean indicating whether end of input should
 *      be sourced from input argument or computed.
 * @returns {Function} Interpolation function that maps t ([0, 1]) to a path `d` string.
 */
export declare function interpolatePath(a: string | null | undefined, b: string | null | undefined, interpolateOptions?: ExcludeSegmentFn | InterpolateOptions): (t: number) => string;
export {};
//# sourceMappingURL=interpolate.d.ts.map