import type { Transition } from 'framer-motion';
import type { CartesianChartLayout } from './context';
import { type ChartScaleFunction } from './scale';
/**
 * Default enter transition for path-based components (Line, Area).
 * `{ type: 'tween', duration: 0.5 }`
 */
export declare const defaultPathEnterTransition: Transition;
export type ChartPathCurveType = 'bump' | 'catmullRom' | 'linear' | 'linearClosed' | 'monotone' | 'natural' | 'step' | 'stepBefore' | 'stepAfter';
/**
 * Get the d3 curve function for a path.
 * See https://d3js.org/d3-shape/curve
 * @param curve - The curve type. Defaults to 'linear'.
 * @param layout - The chart layout. Defaults to 'vertical'.
 * @returns The d3 curve function.
 */
export declare const getPathCurveFunction: (curve?: ChartPathCurveType, layout?: CartesianChartLayout) => import("d3-shape").CurveFactory;
/**
 * Generates an SVG line path string from data using chart scale functions.
 *
 * @example
 * ```typescript
 * const chartScale = getChartScale({ chartRect, domain, range, xScale, yScale });
 * const path = getLinePath({ data: [1, 2, 3], chartScale, curve: 'bump' });
 * ```
 */
export declare const getLinePath: ({ data, curve, xScale, yScale, xData, yData, connectNulls, layout, }: {
    data: (number | null | {
        x: number;
        y: number;
    })[];
    curve?: ChartPathCurveType;
    xScale: ChartScaleFunction;
    yScale: ChartScaleFunction;
    xData?: number[];
    yData?: number[];
    /**
     * When true, null values are skipped and the line connects across gaps.
     * By default, null values create gaps in the line.
     */
    connectNulls?: boolean;
    /**
     * Chart layout.
     * @default 'horizontal'
     */
    layout?: CartesianChartLayout;
}) => string;
/**
 * Generates an SVG area path string from data using chart scale functions.
 * Supports both single values (area from baseline to value) and tuples ([baseline, value]).
 *
 * @example
 * ```typescript
 * // Single values - area from baseline to value
 * const area = getAreaPath({
 *   data: [1, 2, 3],
 *   xScale,
 *   yScale,
 * });
 *
 * // Range values - area from low to high
 * const rangeArea = getAreaPath({
 *   data: [[0, 3], [2, 4], [1, 5]],
 *   xScale,
 *   yScale,
 *   curve: 'monotone'
 * });
 * ```
 */
export declare const getAreaPath: ({ data, curve, xScale, yScale, xData, yData, connectNulls, layout, }: {
    data: (number | null)[] | Array<[number, number] | null>;
    xScale: ChartScaleFunction;
    yScale: ChartScaleFunction;
    curve: ChartPathCurveType;
    xData?: number[];
    yData?: number[];
    /**
     * When true, null values are skipped and the area connects across gaps.
     * By default null values create gaps in the area.
     */
    connectNulls?: boolean;
    /**
     * Chart layout.
     * @default 'horizontal'
     */
    layout?: CartesianChartLayout;
}) => string;
/**
 * Converts line coordinates to an SVG path string.
 * Useful for rendering axis lines and tick marks.
 *
 * @example
 * ```typescript
 * const path = lineToPath(0, 0, 100, 100);
 * // Returns: "M 0 0 L 100 100"
 * ```
 */
export declare const lineToPath: (x1: number, y1: number, x2: number, y2: number) => string;
/**
 * Creates an SVG path string for a rectangle with selective corner rounding.
 * Useful for creating bars in charts with optional rounded corners.
 *
 * @example
 * ```typescript
 * // Simple rectangle bar
 * const barPath = getBarPath(10, 20, 50, 100, 0, false, false);
 *
 * // Bar with rounded top corners
 * const roundedPath = getBarPath(10, 20, 50, 100, 8, true, false);
 * ```
 */
export declare const getBarPath: (x: number, y: number, width: number, height: number, radius: number, roundTop: boolean, roundBottom: boolean, layout?: CartesianChartLayout) => string;
//# sourceMappingURL=path.d.ts.map