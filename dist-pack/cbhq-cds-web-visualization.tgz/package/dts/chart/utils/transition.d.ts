import { type MotionValue, type Transition } from 'framer-motion';
/**
 * Default update transition used across all chart components.
 * `{ type: 'spring', stiffness: 900, damping: 120, mass: 4 }`
 */
export declare const defaultTransition: Transition;
/**
 * Instant transition that completes immediately with no animation.
 * Used when a transition is set to `null`.
 */
export declare const instantTransition: Transition;
/**
 * Duration in seconds for accessory elements to fade in.
 */
export declare const accessoryFadeTransitionDuration = 0.15;
/**
 * Delay in seconds before accessory elements fade in.
 */
export declare const accessoryFadeTransitionDelay = 0.35;
/**
 * Default enter transition for accessory elements (Point, Scrubber beacons).
 * `{ type: 'tween', duration: 0.15, delay: 0.35 }`
 */
export declare const defaultAccessoryEnterTransition: Transition;
/**
 * Resolves a transition value based on the animation state and a default.
 * @note Passing in null will disable an animation.
 * @note Passing in undefined will use the provided default.
 */
export declare const getTransition: (value: Transition | null | undefined, animate: boolean, defaultValue: Transition) => Transition | null;
/**
 * Hook for path animation state and transitions.
 *
 * @param currentPath - Current target path to animate to
 * @param initialPath - Initial path for enter animation. When provided, the first animation will go from initialPath to currentPath.
 * @param transitions - Transition configuration for enter and update animations
 * @returns MotionValue containing the current interpolated path string
 *
 * @example
 * // Simple path transition
 * const animatedPath = usePathTransition({
 *   currentPath: d ?? '',
 *   transitions: {
 *     update: { type: 'spring', stiffness: 300, damping: 20 },
 *   },
 * });
 *
 * @example
 * // Enter animation with different initial config (like DefaultBar)
 * const animatedPath = usePathTransition({
 *   currentPath: targetPath,
 *   initialPath: baselinePath,
 *   transitions: {
 *     enter: { type: 'tween', duration: 0.5 },
 *     update: { type: 'spring', stiffness: 900, damping: 120, mass: 4 },
 *   },
 * });
 */
export declare const usePathTransition: ({ currentPath, initialPath, transitions, transition, }: {
    /**
     * Current target path to animate to.
     */
    currentPath: string;
    /**
     * Initial path for enter animation.
     * When provided, the first animation will go from initialPath to currentPath.
     * If not provided, defaults to currentPath (no enter animation).
     */
    initialPath?: string;
    /**
     * Transition configuration for enter and update animations.
     */
    transitions?: {
        /**
         * Transition for the initial enter animation (initialPath → currentPath).
         * Only used when `initialPath` is provided.
         * If not provided, falls back to `update`.
         */
        enter?: Transition | null;
        /**
         * Transition for subsequent data update animations.
         * @default defaultTransition
         */
        update?: Transition | null;
    };
    /**
     * Transition for updates.
     * @deprecated Use `transitions.update` instead.
     */
    transition?: Transition;
}) => MotionValue<string>;
//# sourceMappingURL=transition.d.ts.map