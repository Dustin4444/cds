export {};
//# sourceMappingURL=point.test.d.ts.map