export {};
//# sourceMappingURL=axis.test.d.ts.map