import { type ChartTextProps } from '../text';
import type { PointLabelProps } from './Point';
export type DefaultPointLabelProps = PointLabelProps & Omit<ChartTextProps, 'children' | 'x' | 'y' | 'horizontalAlignment' | 'verticalAlignment'>;
/**
 * DefaultPointLabel is the default label component for point labels.
 * It renders text at the specified position relative to the point.
 */
export declare const DefaultPointLabel: import("react").NamedExoticComponent<DefaultPointLabelProps>;
//# sourceMappingURL=DefaultPointLabel.d.ts.map