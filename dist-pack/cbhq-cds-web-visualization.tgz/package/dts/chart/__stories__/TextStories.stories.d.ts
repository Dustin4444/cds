declare const _default: {
    component: import("react").NamedExoticComponent<import("..").ChartTextProps>;
    title: string;
    parameters: {
        a11y: {
            test: string;
        };
    };
};
export default _default;
export declare const InteractiveChartText: () => import("react/jsx-runtime").JSX.Element;
export declare const InteractiveChartTextGroup: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TextStories.stories.d.ts.map