declare const _default: {
    component: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Partial<Pick<import("@cbhq/cds-web/tabs").TabsBaseProps<string>, "TabComponent" | "TabsActiveIndicatorComponent">> & Omit<import("@cbhq/cds-web/tabs").TabsBaseProps<string>, "classNames" | "styles" | "TabComponent" | "TabsActiveIndicatorComponent"> & Partial<Pick<import("@cbhq/cds-web/tabs").TabsProps<string>, "TabComponent" | "TabsActiveIndicatorComponent">> & Omit<import("@cbhq/cds-web/tabs").TabsProps<string>, "classNames" | "styles" | "TabComponent" | "TabsActiveIndicatorComponent"> & {
        styles?: {
            root?: React.CSSProperties;
            tab?: React.CSSProperties;
            activeIndicator?: React.CSSProperties;
        };
        classNames?: {
            root?: string;
            tab?: string;
            activeIndicator?: string;
        };
    } & import("react").RefAttributes<HTMLElement>>>;
    title: string;
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=PeriodSelector.stories.d.ts.map