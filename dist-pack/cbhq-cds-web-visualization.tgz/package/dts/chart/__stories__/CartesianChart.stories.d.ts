import React from 'react';
declare const _default: {
    component: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<import("../CartesianChart").CartesianChartProps, "ref"> & React.RefAttributes<SVGSVGElement>>>;
    title: string;
    parameters: {
        a11y: {
            test: string;
        };
    };
};
export default _default;
export declare const Miscellaneous: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CartesianChart.stories.d.ts.map