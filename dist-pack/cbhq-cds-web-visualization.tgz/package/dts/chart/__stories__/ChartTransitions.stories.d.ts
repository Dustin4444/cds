declare const _default: {
    title: string;
    component: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Omit<import("..").CartesianChartProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>>;
    parameters: {
        percy: {
            skip: boolean;
        };
    };
};
export default _default;
export declare const Transitions: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ChartTransitions.stories.d.ts.map