import { type SVGProps } from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type PathProps } from '../Path';
import type { LineComponentProps } from './Line';
export type SolidLineProps = SharedProps & Pick<PathProps, 'className' | 'clipOffset' | 'clipRect' | 'strokeLinecap' | 'strokeLinejoin' | 'strokeDasharray' | 'strokeDashoffset' | 'style'> & LineComponentProps & {
    fill?: SVGProps<SVGPathElement>['fill'];
};
/**
 * A customizable solid line component.
 * Supports gradient for gradient effects and smooth data transitions.
 */
export declare const SolidLine: import("react").NamedExoticComponent<SolidLineProps>;
//# sourceMappingURL=SolidLine.d.ts.map