import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { ChartTextChildren, ChartTextProps, TextHorizontalAlignment, TextVerticalAlignment } from '../text/ChartText';
import type { ChartInset } from '../utils';
import type { LineComponent } from './Line';
export type ReferenceLineLabelComponentProps = Pick<ChartTextProps, 'x' | 'y' | 'children' | 'testID' | 'dx' | 'dy' | 'font' | 'fontFamily' | 'fontSize' | 'fontWeight' | 'color' | 'elevated' | 'inset' | 'background' | 'borderRadius' | 'disableRepositioning' | 'styles' | 'classNames' | 'horizontalAlignment' | 'verticalAlignment' | 'className' | 'style' | 'opacity'> & {
    /**
     * Bounds inset for label to prevent cutoff at chart edges.
     * @default { top: 4, bottom: 20, left: 12, right: 12 } when elevated is true, otherwise undefined
     */
    boundsInset?: number | ChartInset;
};
export type ReferenceLineLabelComponent = React.FC<ReferenceLineLabelComponentProps>;
export type ReferenceLineBaseProps = SharedProps & {
    /**
     * Label content to display near the reference line.
     * Can be a string or ReactNode for rich formatting.
     *
     * @example
     * // Simple string label
     * label="Target Price"
     *
     * @example
     * // ReactNode with styling
     * label={<tspan style={{ fontWeight: 'bold', fill: 'red' }}>Stop Loss</tspan>}
     */
    label?: ChartTextChildren;
    /**
     * Component to render the line.
     * @default DottedLine
     */
    LineComponent?: LineComponent;
    /**
     * Component to render the label.
     * @default DefaultReferenceLineLabel
     */
    LabelComponent?: ReferenceLineLabelComponent;
    /**
     * Whether to elevate the label with a shadow.
     * When true, applies elevation and automatically adds bounds to keep label within chart area.
     */
    labelElevated?: boolean;
    /**
     * Font style for the label text.
     */
    labelFont?: ChartTextProps['font'];
    /**
     * Horizontal offset for the label in pixels.
     */
    labelDx?: number;
    /**
     * Vertical offset for the label in pixels.
     */
    labelDy?: number;
    /**
     * Horizontal alignment of the label text.
     */
    labelHorizontalAlignment?: TextHorizontalAlignment;
    /**
     * Vertical alignment of the label text.
     */
    labelVerticalAlignment?: TextVerticalAlignment;
    /**
     * Bounds inset for the label to prevent cutoff at chart edges.
     * Especially useful when labelElevated is true to prevent shadow clipping.
     * Can be a number (applied to all sides) or a ChartInset object.
     * @default { top: 4, bottom: 20, left: 12, right: 12 } when labelElevated is true, otherwise none
     */
    labelBoundsInset?: number | ChartInset;
    /**
     * The color of the line.
     * @default 'var(--color-bgLine)'
     */
    stroke?: string;
    /**
     * Opacity applied to both the line and label.
     * @default 1
     */
    opacity?: number;
};
export type HorizontalReferenceLineProps = ReferenceLineBaseProps & {
    /**
     * Y-value for horizontal reference line (data value).
     */
    dataY: number;
    /**
     * The ID of the y-axis to use for positioning.
     * Defaults to defaultAxisId if not specified.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    yAxisId?: string;
    /**
     * Position of the label along the horizontal line.
     * @default 'right'
     */
    labelPosition?: TextHorizontalAlignment;
    dataX?: never;
};
export type VerticalReferenceLineProps = ReferenceLineBaseProps & {
    /**
     * X-value for vertical reference line (data index).
     */
    dataX: number;
    /**
     * Position of the label along the vertical line.
     * @default 'top'
     */
    labelPosition?: TextVerticalAlignment;
    dataY?: never;
    yAxisId?: never;
};
export type ReferenceLineProps = (HorizontalReferenceLineProps | VerticalReferenceLineProps) & {
    /**
     * Custom class name for the root element.
     */
    className?: string;
    /**
     * Custom inline styles for the root element.
     */
    style?: React.CSSProperties;
    /**
     * Custom class names for the component parts.
     */
    classNames?: {
        /**
         * Custom class name for the root element.
         */
        root?: string;
        /**
         * Custom class name for the line path.
         */
        line?: string;
        /**
         * Custom class name for the text label.
         */
        label?: string;
    };
    /**
     * Custom styles for the component parts.
     */
    styles?: {
        /**
         * Custom styles for the root element.
         */
        root?: React.CSSProperties;
        /**
         * Custom styles for the line path.
         */
        line?: React.CSSProperties;
        /**
         * Custom styles for the text label.
         */
        label?: React.CSSProperties;
    };
};
export declare const ReferenceLine: React.NamedExoticComponent<ReferenceLineProps>;
//# sourceMappingURL=ReferenceLine.d.ts.map