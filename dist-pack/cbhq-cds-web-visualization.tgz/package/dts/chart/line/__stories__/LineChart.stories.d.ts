declare const _default: {
    component: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<Omit<import("..").LineChartProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>>;
    title: string;
    parameters: {
        a11y: {
            test: string;
        };
    };
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=LineChart.stories.d.ts.map