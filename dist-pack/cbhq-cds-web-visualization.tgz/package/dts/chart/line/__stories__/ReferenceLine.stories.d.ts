declare const _default: {
    component: import("react").NamedExoticComponent<import("..").ReferenceLineProps>;
    title: string;
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ReferenceLine.stories.d.ts.map