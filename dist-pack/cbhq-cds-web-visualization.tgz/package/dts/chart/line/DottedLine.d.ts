import { type SVGProps } from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type PathProps } from '../Path';
import type { LineComponentProps } from './Line';
export type DottedLineProps = SharedProps & Pick<PathProps, 'className' | 'clipOffset' | 'clipRect' | 'strokeLinecap' | 'strokeLinejoin' | 'strokeDasharray' | 'strokeDashoffset' | 'style' | 'vectorEffect'> & LineComponentProps & {
    fill?: SVGProps<SVGPathElement>['fill'];
};
/**
 * A customizable dotted line component.
 * Supports gradient for gradient effects on the dots.
 */
export declare const DottedLine: import("react").NamedExoticComponent<DottedLineProps>;
//# sourceMappingURL=DottedLine.d.ts.map