import type { ReferenceLineLabelComponentProps } from './ReferenceLine';
export type DefaultReferenceLineLabelProps = ReferenceLineLabelComponentProps;
/**
 * DefaultReferenceLineLabel is the default label component for ReferenceLine.
 * Provides standard styling with elevation, inset, and color defaults.
 * When elevated, automatically adds bounds to prevent shadow cutoff at chart edges.
 */
export declare const DefaultReferenceLineLabel: import("react").NamedExoticComponent<ReferenceLineLabelComponentProps>;
//# sourceMappingURL=DefaultReferenceLineLabel.d.ts.map