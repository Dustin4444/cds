import React from 'react';
import type { SVGProps } from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type AreaComponent } from '../area/Area';
import type { PathProps } from '../Path';
import { type PointBaseProps, type PointProps } from '../point';
import { type ChartPathCurveType, type GradientDefinition } from '../utils';
export type LineBaseProps = SharedProps & {
    /**
     * The ID of the series to render. Will be used to find the data from the chart context.
     */
    seriesId: string;
    /**
     * The curve interpolation method to use for the line.
     * @default 'bump'
     */
    curve?: ChartPathCurveType;
    /**
     * The type of line to render.
     * @default 'solid'
     */
    type?: 'solid' | 'dotted';
    /**
     * Whether to show area fill under the line.
     */
    showArea?: boolean;
    /**
     * The type of area fill to add to the line.
     * @default 'gradient'
     */
    areaType?: 'gradient' | 'solid' | 'dotted';
    /**
     * Baseline value for the area.
     * When set, overrides the default baseline.
     */
    areaBaseline?: number;
    /**
     * Component to render the line.
     * Takes precedence over the type prop if provided.
     */
    LineComponent?: LineComponent;
    /**
     * Custom component to render line area fill.
     */
    AreaComponent?: AreaComponent;
    /**
     * Opacity of the line's stroke.
     * Will also be applied to points and area fill.
     * @default 1
     */
    opacity?: number;
    /**
     * Controls whether and how to render points at each data point in the series.
     * - `true`: Show all points with default styling
     * - `false` or `undefined`: Hide all points
     * - Function: Called for every entry in the data array to customize individual points
     *
     * @param defaults - The default point props computed by the Line component
     * @returns true for default point, false/null/undefined for no point, or Partial<PointProps> to customize
     */
    points?: boolean | ((defaults: PointBaseProps) => boolean | null | undefined | Partial<PointProps>);
    /**
     * When true, the area is connected across null values.
     */
    connectNulls?: boolean;
    /**
     * The color of the line.
     * @default color of the series or 'var(--color-fgPrimary)'
     */
    stroke?: string;
    /**
     * Opacity of the line
     * @note when combined with gradient, both will be applied
     * @default 1
     */
    strokeOpacity?: number;
    /**
     * Width of the line
     * @default 2
     */
    strokeWidth?: number;
    /**
     * Gradient configuration.
     * When provided, creates gradient or threshold-based coloring.
     */
    gradient?: GradientDefinition;
    /**
     * Whether to animate the line.
     * Overrides the animate value from the chart context.
     */
    animate?: boolean;
};
export type LineProps = LineBaseProps & Pick<PathProps, 'transitions' | 'transition'> & {
    /**
     * Handler for when a point is clicked.
     * Passed through to Point components rendered via points.
     */
    onPointClick?: PointProps['onClick'];
    /**
     * Custom style for the line.
     */
    style?: React.CSSProperties;
    /**
     * Custom className for the line.
     */
    className?: string;
};
export type LineComponentProps = Pick<LineProps, 'stroke' | 'strokeOpacity' | 'strokeWidth' | 'gradient' | 'animate' | 'transitions' | 'transition' | 'style' | 'className'> & Pick<PathProps, 'clipRect' | 'strokeLinecap'> & {
    /**
     * Path of the line.
     */
    d: SVGProps<SVGPathElement>['d'];
    /**
     * ID of the x-axis to use.
     * If not provided, defaults to the default x-axis.
     * @note Only used for axis selection when layout is 'horizontal'. Vertical layout uses a single x-axis.
     */
    xAxisId?: string;
    /**
     * ID of the y-axis to use.
     * If not provided, defaults to the default y-axis.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    yAxisId?: string;
};
export type LineComponent = React.FC<LineComponentProps>;
export declare const Line: React.NamedExoticComponent<LineProps>;
//# sourceMappingURL=Line.d.ts.map