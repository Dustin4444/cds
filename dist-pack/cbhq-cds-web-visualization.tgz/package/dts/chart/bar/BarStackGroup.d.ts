import type { BarStackProps } from './BarStack';
export type BarStackGroupProps = Pick<BarStackProps, 'BarComponent' | 'fillOpacity' | 'stroke' | 'strokeWidth' | 'borderRadius' | 'roundBaseline' | 'stackGap' | 'barMinSize' | 'stackMinSize' | 'BarStackComponent' | 'transitions' | 'transition'> & Pick<BarStackProps, 'series' | 'xAxisId' | 'yAxisId'> & {
    /**
     * Index of this stack within the category (0-based).
     */
    stackIndex: number;
    /**
     * Total number of stacks per category.
     */
    totalStacks: number;
    /**
     * Padding between bar groups (0-1).
     * @default 0.1
     */
    barPadding?: number;
};
/**
 * BarStackGroup component that renders a group of stacks across all categories.
 * Delegates the actual stacking logic to BarStack for each category.
 */
export declare const BarStackGroup: import("react").NamedExoticComponent<BarStackGroupProps>;
//# sourceMappingURL=BarStackGroup.d.ts.map