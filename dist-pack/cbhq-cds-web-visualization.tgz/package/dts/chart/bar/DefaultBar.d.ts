import React from 'react';
import type { BarComponentProps } from './Bar';
export type DefaultBarProps = BarComponentProps & {
    /**
     * Custom class name for the bar.
     */
    className?: string;
    /**
     * Custom styles for the bar.
     */
    style?: React.CSSProperties;
};
/**
 * Default bar component that renders a solid bar with animation.
 */
export declare const DefaultBar: React.NamedExoticComponent<DefaultBarProps>;
//# sourceMappingURL=DefaultBar.d.ts.map