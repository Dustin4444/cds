import React from 'react';
import type { Rect } from '@cbhq/cds-common';
import type { Transition } from 'framer-motion';
import type { ChartScaleFunction, Series } from '../utils';
import { type BarBaseProps, type BarComponent, type BarProps } from './Bar';
/**
 * Extended series type that includes bar-specific properties.
 */
export type BarSeries = Series & {
    /**
     * Custom component to render bars for this series.
     */
    BarComponent?: BarComponent;
};
export type BarStackBaseProps = Pick<BarBaseProps, 'BarComponent' | 'fillOpacity' | 'stroke' | 'strokeWidth' | 'borderRadius'> & {
    /**
     * Array of series configurations that belong to this stack.
     */
    series: BarSeries[];
    /**
     * The category index for this stack.
     */
    categoryIndex: number;
    /**
     * Position of this stack along the index (categorical) axis.
     */
    indexPos: number;
    /**
     * Thickness of this stack.
     */
    thickness: number;
    /**
     * Scale for the independent (categorical) axis.
     */
    indexScale: ChartScaleFunction;
    /**
     * Scale for the dependent (magnitude) axis.
     */
    valueScale: ChartScaleFunction;
    /**
     * Chart rect for bounds.
     */
    rect: Rect;
    /**
     * X axis ID to use.
     * If not provided, defaults to defaultAxisId.
     * @note Only used for axis selection when layout is 'horizontal'. Vertical layout uses a single x-axis.
     */
    xAxisId?: string;
    /**
     * Y axis ID to use.
     * If not provided, defaults to defaultAxisId.
     * @note Only used for axis selection when layout is 'vertical'. Horizontal layout supports a single y-axis.
     */
    yAxisId?: string;
    /**
     * Custom component to render the stack container.
     * Can be used to add clip paths, outlines, or other custom styling.
     * @default DefaultBarStack
     */
    BarStackComponent?: BarStackComponent;
    /**
     * Whether to round the baseline of a bar (where the value is 0).
     */
    roundBaseline?: boolean;
    /**
     * Gap between bars in the stack.
     */
    stackGap?: number;
    /**
     * Minimum size for individual bars in the stack.
     */
    barMinSize?: number;
    /**
     * Minimum size for the entire stack.
     */
    stackMinSize?: number;
};
export type BarStackProps = BarStackBaseProps & Pick<BarProps, 'transitions' | 'transition'>;
export type BarStackComponentProps = {
    /**
     * The x position of the stack.
     */
    x: number;
    /**
     * The y position of the stack.
     */
    y: number;
    /**
     * The width of the stack.
     */
    width: number;
    /**
     * The height of the stack.
     */
    height: number;
    /**
     * The category index for this stack.
     */
    categoryIndex: number;
    /**
     * Transition configuration for animation.
     */
    transition?: Transition;
    /**
     * Transition configuration for enter and update animations.
     */
    transitions?: BarProps['transitions'];
    /**
     * Border radius for the bars.
     */
    borderRadius?: number;
    /**
     * The bar elements to render within the stack.
     */
    children: React.ReactNode;
    /**
     * Whether to round the top corners.
     */
    roundTop?: boolean;
    /**
     * Whether to round the bottom corners.
     */
    roundBottom?: boolean;
    /**
     * Stack animation origin.
     * - number: baseline on the value axis
     * - tuple: [start, end] clip range for stacked min-size enter animation
     */
    origin?: number | [number, number];
};
export type BarStackComponent = React.FC<BarStackComponentProps>;
/**
 * BarStack component that renders a single stack of bars at a specific category index.
 * Handles the stacking logic for bars within a single category.
 */
export declare const BarStack: React.NamedExoticComponent<BarStackProps>;
//# sourceMappingURL=BarStack.d.ts.map