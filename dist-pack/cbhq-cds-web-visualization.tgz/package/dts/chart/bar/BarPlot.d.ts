import type { BarStackGroupProps } from './BarStackGroup';
export type BarPlotBaseProps = Pick<BarStackGroupProps, 'barPadding' | 'BarComponent' | 'fillOpacity' | 'stroke' | 'strokeWidth' | 'borderRadius' | 'roundBaseline' | 'stackGap' | 'barMinSize' | 'stackMinSize' | 'BarStackComponent'> & {
    /**
     * Array of series IDs to render.
     * If not provided, renders all series in the chart.
     */
    seriesIds?: string[];
};
export type BarPlotProps = BarPlotBaseProps & Pick<BarStackGroupProps, 'transitions' | 'transition'>;
/**
 * BarPlot component that handles multiple series with proper stacking coordination.
 * Groups series by stack ID + y-axis ID combination and renders BarStackGroup for each group.
 * This allows series with different y-axes to be rendered side by side while preventing
 * cross-axis stacking (e.g., comparing $1M vs $1B companies on different scales).
 */
export declare const BarPlot: import("react").NamedExoticComponent<BarPlotProps>;
//# sourceMappingURL=BarPlot.d.ts.map