import React from 'react';
declare const _default: {
    title: string;
    component: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<import("..").BarChartProps, "ref"> & React.RefAttributes<SVGSVGElement>>>;
    parameters: {
        a11y: {
            test: string;
        };
    };
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BarChart.stories.d.ts.map