import type { BarStackComponentProps } from './BarStack';
export type DefaultBarStackProps = BarStackComponentProps & {
    /**
     * Custom class name for the stack group.
     */
    className?: string;
    /**
     * Custom styles for the stack group.
     */
    style?: React.CSSProperties;
};
/**
 * Default stack component that renders children in a group with animated clip path.
 */
export declare const DefaultBarStack: import("react").NamedExoticComponent<DefaultBarStackProps>;
//# sourceMappingURL=DefaultBarStack.d.ts.map