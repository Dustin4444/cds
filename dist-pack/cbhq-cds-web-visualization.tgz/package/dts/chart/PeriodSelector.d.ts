import React from 'react';
import type { Polymorphic } from '@cbhq/cds-web/core/polymorphism';
import { type SegmentedTabsProps, type TabsActiveIndicatorProps } from '@cbhq/cds-web/tabs';
import { type TextBaseProps } from '@cbhq/cds-web/typography';
export declare const PeriodSelectorActiveIndicator: React.MemoExoticComponent<({ activeTabRect, background, position, borderRadius, style, ...props }: TabsActiveIndicatorProps) => import("react/jsx-runtime").JSX.Element | null>;
export declare const liveTabLabelDefaultElement = "span";
export type LiveTabLabelDefaultElement = typeof liveTabLabelDefaultElement;
export type LiveTabLabelBaseProps = TextBaseProps & {
    /**
     * The label to display.
     * @default 'LIVE'
     */
    label?: string;
    /**
     * Whether to hide the dot.
     */
    hideDot?: boolean;
};
export type LiveTabLabelProps<AsComponent extends React.ElementType> = Polymorphic.Props<AsComponent, LiveTabLabelBaseProps>;
type LiveTabLabelComponent = (<AsComponent extends React.ElementType = LiveTabLabelDefaultElement>(props: LiveTabLabelProps<AsComponent>) => Polymorphic.ReactReturn) & Polymorphic.ReactNamed;
export declare const LiveTabLabel: LiveTabLabelComponent;
export type PeriodSelectorProps = SegmentedTabsProps;
/**
 * PeriodSelector is a specialized version of SegmentedTabs optimized for chart period selection.
 * It provides transparent background, primary wash active state, and full-width layout by default.
 */
export declare const PeriodSelector: React.MemoExoticComponent<React.ForwardRefExoticComponent<Partial<Pick<import("@cbhq/cds-web/tabs").TabsBaseProps<string>, "TabComponent" | "TabsActiveIndicatorComponent">> & Omit<import("@cbhq/cds-web/tabs").TabsBaseProps<string>, "classNames" | "styles" | "TabComponent" | "TabsActiveIndicatorComponent"> & Partial<Pick<import("@cbhq/cds-web/tabs").TabsProps<string>, "TabComponent" | "TabsActiveIndicatorComponent">> & Omit<import("@cbhq/cds-web/tabs").TabsProps<string>, "classNames" | "styles" | "TabComponent" | "TabsActiveIndicatorComponent"> & {
    styles?: {
        root?: React.CSSProperties;
        tab?: React.CSSProperties;
        activeIndicator?: React.CSSProperties;
    };
    classNames?: {
        root?: string;
        tab?: string;
        activeIndicator?: string;
    };
} & React.RefAttributes<HTMLElement>>>;
export {};
//# sourceMappingURL=PeriodSelector.d.ts.map