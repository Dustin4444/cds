import type { CartesianChartContextValue } from './utils/context';
export declare const CartesianChartContext: import("react").Context<CartesianChartContextValue | undefined>;
export declare const useCartesianChartContext: () => CartesianChartContextValue;
export declare const CartesianChartProvider: import("react").Provider<CartesianChartContextValue | undefined>;
//# sourceMappingURL=ChartProvider.d.ts.map