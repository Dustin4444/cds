import React from 'react';
import type { ViewStyle } from 'react-native';
import type { PinningDirection, SharedProps } from '@cbhq/cds-common';
export type OverflowGradientProps = {
    pin?: Exclude<PinningDirection, 'all'>;
    style?: ViewStyle;
} & SharedProps;
export declare const OverflowGradient: React.NamedExoticComponent<OverflowGradientProps>;
//# sourceMappingURL=OverflowGradient.d.ts.map