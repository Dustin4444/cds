import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { BoxProps } from './Box';
export type DividerBaseProps = {
  /**
   * Color of the divider line.
   * @default bgLine
   */
  color?: ThemeVars.Color;
  /**
   * The direction to render the divider line.
   * @default horizontal
   */
  direction?: 'horizontal' | 'vertical';
};
export type DividerProps = DividerBaseProps & BoxProps;
export declare const Divider: import('react').MemoExoticComponent<
  (_props: DividerProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=Divider.d.ts.map
