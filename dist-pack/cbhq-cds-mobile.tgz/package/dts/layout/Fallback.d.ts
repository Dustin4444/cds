import React from 'react';
import type { DimensionValue } from 'react-native';
import type { Shape } from '@cbhq/cds-common/types/Shape';
import type { BoxProps } from './Box';
export type FallbackBaseProps = {
    height: number | string;
    /**
     * @default rectangle
     */
    shape?: Shape;
    width: DimensionValue;
    /** Disables randomization of rectangle shape width. */
    disableRandomRectWidth?: boolean;
    /**
     * When shape is a rectangle, creates a variant with deterministic width.
     * Variants map to a predetermined set of width values, which are cycled through repeatedly when the set is exhausted.
     */
    rectWidthVariant?: number;
};
export type FallbackProps = Omit<BoxProps, 'borderRadius' | 'height' | 'width'> & FallbackBaseProps;
export declare const Fallback: React.MemoExoticComponent<(_props: FallbackProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=Fallback.d.ts.map