export {};
//# sourceMappingURL=Divider.perf-test.d.ts.map
