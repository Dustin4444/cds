declare const BoxScreen: () => import('react/jsx-runtime').JSX.Element;
export default BoxScreen;
//# sourceMappingURL=Box.stories.d.ts.map
