declare const FallbackScreen: () => import('react/jsx-runtime').JSX.Element;
export default FallbackScreen;
//# sourceMappingURL=Fallback.stories.d.ts.map
