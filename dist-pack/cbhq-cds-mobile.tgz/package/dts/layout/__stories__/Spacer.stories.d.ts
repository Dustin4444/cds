declare const SpacerScreen: () => import('react/jsx-runtime').JSX.Element;
export default SpacerScreen;
//# sourceMappingURL=Spacer.stories.d.ts.map
