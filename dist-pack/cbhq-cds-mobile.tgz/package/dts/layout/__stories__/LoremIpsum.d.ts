import type { ThemeVars } from '@cbhq/cds-common/core/theme';
export type LoremIpsumProps = {
  title?: string;
  color?: ThemeVars.Color;
  concise?: boolean;
  repeat?: number;
};
export declare const LoremIpsum: ({
  color,
  concise,
  title,
  repeat,
}: LoremIpsumProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=LoremIpsum.d.ts.map
