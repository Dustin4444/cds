declare const GroupScreen: () => import('react/jsx-runtime').JSX.Element;
export default GroupScreen;
//# sourceMappingURL=Group.stories.d.ts.map
