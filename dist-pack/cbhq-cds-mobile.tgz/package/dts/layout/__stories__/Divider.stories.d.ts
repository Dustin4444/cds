declare const DividerScreen: () => import('react/jsx-runtime').JSX.Element;
export default DividerScreen;
//# sourceMappingURL=Divider.stories.d.ts.map
