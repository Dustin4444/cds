import React from 'react';
import { Animated } from 'react-native';
import type { StyleProp, ViewProps, ViewStyle } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { FlexStyles, SharedProps } from '@cbhq/cds-common/types';
export type SpacerBaseProps = SharedProps &
  Pick<FlexStyles, 'flexGrow' | 'flexShrink' | 'flexBasis'> & {
    /** Padding in the horizontal direction */
    horizontal?: ThemeVars.Space;
    /** Padding in the vertical direction */
    vertical?: ThemeVars.Space;
    /** Max padding in the horizontal direction */
    maxHorizontal?: ThemeVars.Space;
    /** Max padding in the vertical direction */
    maxVertical?: ThemeVars.Space;
    /** Min padding in the horizontal direction */
    minHorizontal?: ThemeVars.Space;
    /** Min padding in the vertical direction */
    minVertical?: ThemeVars.Space;
    animated?: boolean;
    style?: Animated.WithAnimatedValue<StyleProp<ViewStyle>>;
  };
export type SpacerProps = SpacerBaseProps & Omit<ViewProps, 'style'>;
/**
 * Spacer component is for adding spacing gap between two dom nodes. If no horizontal or vertical
 * spacing size is provided, Spacer will stretch to fill up available space left in the parent container.
 */
export declare const Spacer: React.NamedExoticComponent<SpacerProps>;
//# sourceMappingURL=Spacer.d.ts.map
