import React from 'react';
import { Animated, type StyleProp, View, type ViewProps, type ViewStyle } from 'react-native';
import type { PinningDirection, SharedProps } from '@cbhq/cds-common';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { ElevationLevels } from '@cbhq/cds-common/types/ElevationLevels';
import type { Theme } from '../core/theme';
import { type StyleProps } from '../styles/styleProps';
export type BoxBaseProps = SharedProps & StyleProps & {
    children?: React.ReactNode;
    style?: Animated.WithAnimatedValue<StyleProp<ViewStyle>>;
    animated?: boolean;
    /** Determines box shadow styles. Parent should have overflow set to visible to ensure styles are not clipped. */
    elevation?: ElevationLevels;
    font?: ThemeVars.FontFamily | 'inherit';
    /** Direction in which to absolutely pin the box. */
    pin?: PinningDirection;
    /** Add a border around all sides of the box. */
    bordered?: boolean;
    /** Add a border to the top side of the box. */
    borderedTop?: boolean;
    /** Add a border to the bottom side of the box. */
    borderedBottom?: boolean;
    /** Add a border to the leading side of the box. */
    borderedStart?: boolean;
    /** Add a border to the trailing side of the box. */
    borderedEnd?: boolean;
    /** Add a border to the leading and trailing sides of the box. */
    borderedHorizontal?: boolean;
    /** Add a border to the top and bottom sides of the box. */
    borderedVertical?: boolean;
    /**
     * @deprecated Use `style` or the `background` style prop to set custom background colors. This will be removed in a future major release.
     * @deprecationExpectedRemoval v10
     */
    dangerouslySetBackground?: string;
};
export type BoxProps = BoxBaseProps & Omit<ViewProps, 'style'>;
export declare const getElevationStyles: (elevation: ElevationLevels, theme: Theme, background?: ThemeVars.Color) => ViewStyle;
export declare const Box: React.NamedExoticComponent<SharedProps & StyleProps & {
    children?: React.ReactNode;
    style?: Animated.WithAnimatedValue<StyleProp<ViewStyle>>;
    animated?: boolean;
    /** Determines box shadow styles. Parent should have overflow set to visible to ensure styles are not clipped. */
    elevation?: ElevationLevels;
    font?: ThemeVars.FontFamily | "inherit";
    /** Direction in which to absolutely pin the box. */
    pin?: PinningDirection;
    /** Add a border around all sides of the box. */
    bordered?: boolean;
    /** Add a border to the top side of the box. */
    borderedTop?: boolean;
    /** Add a border to the bottom side of the box. */
    borderedBottom?: boolean;
    /** Add a border to the leading side of the box. */
    borderedStart?: boolean;
    /** Add a border to the trailing side of the box. */
    borderedEnd?: boolean;
    /** Add a border to the leading and trailing sides of the box. */
    borderedHorizontal?: boolean;
    /** Add a border to the top and bottom sides of the box. */
    borderedVertical?: boolean;
    /**
     * @deprecated Use `style` or the `background` style prop to set custom background colors. This will be removed in a future major release.
     * @deprecationExpectedRemoval v10
     */
    dangerouslySetBackground?: string;
} & Omit<ViewProps, "style"> & React.RefAttributes<View>>;
//# sourceMappingURL=Box.d.ts.map