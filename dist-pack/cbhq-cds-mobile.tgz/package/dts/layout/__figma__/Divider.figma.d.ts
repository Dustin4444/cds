export {};
//# sourceMappingURL=Divider.figma.d.ts.map
