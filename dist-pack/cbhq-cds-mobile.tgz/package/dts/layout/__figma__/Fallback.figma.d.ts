export {};
//# sourceMappingURL=Fallback.figma.d.ts.map
