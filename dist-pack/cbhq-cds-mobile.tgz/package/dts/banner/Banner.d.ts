import React from 'react';
import type { StyleProp, TextStyle, View, ViewStyle } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { BannerStyleVariant, BannerVariant, IconName, SharedProps } from '@cbhq/cds-common/types';
import type { HStackProps } from '../layout';
export type BannerBaseProps = SharedProps & {
    /** Sets the variant of the banner - which is responsible for foreground and background color assignment */
    variant: BannerVariant;
    /** Name of icon to be shown in the banner */
    startIcon: IconName;
    /** Whether the start icon is active */
    startIconActive?: boolean;
    /** Provide a CDS Link component to be used as a primary action. It will inherit colors depending on the provided variant */
    primaryAction?: React.ReactNode;
    /** Provide a CDS Link component to be used as a secondary action. It will inherit colors depending on the provided tone */
    secondaryAction?: React.ReactNode;
    /** Title of banner. Indicates the intent of this banner */
    title?: React.ReactNode;
    /** Message of banner */
    children?: React.ReactNode;
    /**
     * Determines whether banner can be dismissed or not. Banner is not dismisable when styleVariant is set to global.
     * @default true
     * */
    showDismiss?: boolean;
    /** A callback fired when banner is dismissed */
    onClose?: () => void;
    /** Indicates the max number of lines after which body text will be truncated */
    numberOfLines?: number;
    /** Use for supplemental data */
    label?: React.ReactNode;
    /**
     * Determines the banner style and indicates the suggested positioning for the banner
     * @default 'contextual'
     * */
    styleVariant?: BannerStyleVariant;
    /** Accessibility label for start icon on the banner */
    startIconAccessibilityLabel?: string;
    /** Accessibility label for close button on the banner
     * @default 'close'
     */
    closeAccessibilityLabel?: string;
    /**
     * Determines whether banner has a border or not
     * @default true
     * */
    bordered?: boolean;
    /**
     * Determines banner's border radius
     *
     * @default 400 for contextual, undefined for global and inline
     * */
    borderRadius?: ThemeVars.BorderRadius;
};
/**
 * Canonical props type for Banner.
 *
 * Note: docs docgen expects a `${ComponentName}Props` export (for Banner -> BannerProps)
 * to generate styles selector metadata used by the docs Styles tab.
 */
export type BannerProps = BannerBaseProps & Omit<HStackProps, 'children'> & {
    /** Slot-level styles for Banner. */
    styles?: {
        /** Persistent outer wrapper around both dismissible and non-dismissible variants. */
        root?: StyleProp<ViewStyle>;
        /** Main content container (`HStack`) for banner body. */
        content?: StyleProp<ViewStyle>;
        /** Start icon wrapper. */
        start?: StyleProp<ViewStyle>;
        /** Right-side body wrapper containing middle content and actions. */
        body?: StyleProp<ViewStyle>;
        /** Middle content wrapper containing title/message/label region. */
        middle?: StyleProp<ViewStyle>;
        /**
         * Label text style.
         * Applies only when `label` is a string rendered by Banner.
         * If `label` is a custom node, style that node directly.
         */
        label?: StyleProp<TextStyle>;
        /**
         * Actions row style.
         * Applies only when at least one action (`primaryAction` or `secondaryAction`) is rendered.
         */
        actions?: StyleProp<ViewStyle>;
        /**
         * Dismiss button wrapper style.
         * Applies only when `showDismiss` is true.
         */
        dismiss?: StyleProp<ViewStyle>;
    };
};
/**
 * @deprecated Use `BannerProps` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type MobileBannerProps = BannerProps;
export declare const Banner: React.NamedExoticComponent<SharedProps & {
    /** Sets the variant of the banner - which is responsible for foreground and background color assignment */
    variant: BannerVariant;
    /** Name of icon to be shown in the banner */
    startIcon: IconName;
    /** Whether the start icon is active */
    startIconActive?: boolean;
    /** Provide a CDS Link component to be used as a primary action. It will inherit colors depending on the provided variant */
    primaryAction?: React.ReactNode;
    /** Provide a CDS Link component to be used as a secondary action. It will inherit colors depending on the provided tone */
    secondaryAction?: React.ReactNode;
    /** Title of banner. Indicates the intent of this banner */
    title?: React.ReactNode;
    /** Message of banner */
    children?: React.ReactNode;
    /**
     * Determines whether banner can be dismissed or not. Banner is not dismisable when styleVariant is set to global.
     * @default true
     * */
    showDismiss?: boolean;
    /** A callback fired when banner is dismissed */
    onClose?: () => void;
    /** Indicates the max number of lines after which body text will be truncated */
    numberOfLines?: number;
    /** Use for supplemental data */
    label?: React.ReactNode;
    /**
     * Determines the banner style and indicates the suggested positioning for the banner
     * @default 'contextual'
     * */
    styleVariant?: BannerStyleVariant;
    /** Accessibility label for start icon on the banner */
    startIconAccessibilityLabel?: string;
    /** Accessibility label for close button on the banner
     * @default 'close'
     */
    closeAccessibilityLabel?: string;
    /**
     * Determines whether banner has a border or not
     * @default true
     * */
    bordered?: boolean;
    /**
     * Determines banner's border radius
     *
     * @default 400 for contextual, undefined for global and inline
     * */
    borderRadius?: ThemeVars.BorderRadius;
} & Omit<import("../layout").BoxProps, "children"> & {
    /** Slot-level styles for Banner. */
    styles?: {
        /** Persistent outer wrapper around both dismissible and non-dismissible variants. */
        root?: StyleProp<ViewStyle>;
        /** Main content container (`HStack`) for banner body. */
        content?: StyleProp<ViewStyle>;
        /** Start icon wrapper. */
        start?: StyleProp<ViewStyle>;
        /** Right-side body wrapper containing middle content and actions. */
        body?: StyleProp<ViewStyle>;
        /** Middle content wrapper containing title/message/label region. */
        middle?: StyleProp<ViewStyle>;
        /**
         * Label text style.
         * Applies only when `label` is a string rendered by Banner.
         * If `label` is a custom node, style that node directly.
         */
        label?: StyleProp<TextStyle>;
        /**
         * Actions row style.
         * Applies only when at least one action (`primaryAction` or `secondaryAction`) is rendered.
         */
        actions?: StyleProp<ViewStyle>;
        /**
         * Dismiss button wrapper style.
         * Applies only when `showDismiss` is true.
         */
        dismiss?: StyleProp<ViewStyle>;
    };
} & React.RefAttributes<View>>;
//# sourceMappingURL=Banner.d.ts.map