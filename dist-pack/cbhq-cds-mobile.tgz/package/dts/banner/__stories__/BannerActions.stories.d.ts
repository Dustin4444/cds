declare const BannerActionsScreen: () => import('react/jsx-runtime').JSX.Element;
export default BannerActionsScreen;
//# sourceMappingURL=BannerActions.stories.d.ts.map
