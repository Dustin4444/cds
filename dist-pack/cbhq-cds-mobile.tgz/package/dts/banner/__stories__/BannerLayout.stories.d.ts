declare const BannerLayoutScreen: () => import('react/jsx-runtime').JSX.Element;
export default BannerLayoutScreen;
//# sourceMappingURL=BannerLayout.stories.d.ts.map
