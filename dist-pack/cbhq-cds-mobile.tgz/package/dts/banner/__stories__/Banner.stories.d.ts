declare const BannerScreen: () => import('react/jsx-runtime').JSX.Element;
export default BannerScreen;
//# sourceMappingURL=Banner.stories.d.ts.map
