import React from 'react';
import type { ViewStyle } from 'react-native';
import type {
  AvatarSize,
  Shape,
  SharedAccessibilityProps,
  SharedProps,
} from '@cbhq/cds-common/types';
import { type BoxProps } from '../layout/Box';
export type RemoteImageGroupBaseProps = SharedProps &
  SharedAccessibilityProps &
  Pick<BoxProps, 'borderWidth' | 'borderColor'> & {
    /**
     * Indicates the number of remote image before it collapses
     * @default 4
     */
    max?: number;
    /**
     * Size of all RemoteImage children in the group.
     * @default m
     */
    size?: AvatarSize | number;
    /**
     * Shape of all RemoteImage children in the group
     * @default circle
     */
    shape?: Shape;
    /** Children content */
    children?: React.ReactNode;
  };
export type RemoteImageGroupProps = RemoteImageGroupBaseProps;
export declare const RemoteImageGroup: (
  _props: RemoteImageGroupProps,
) => import('react/jsx-runtime').JSX.Element;
export declare const shapeStyles: Record<Shape, ViewStyle>;
//# sourceMappingURL=RemoteImageGroup.d.ts.map
