export {};
//# sourceMappingURL=RemoteImageGroup.test.d.ts.map
