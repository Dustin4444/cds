export {};
//# sourceMappingURL=RemoteImage.test.d.ts.map
