export let content: string;
//# sourceMappingURL=light.d.ts.map
