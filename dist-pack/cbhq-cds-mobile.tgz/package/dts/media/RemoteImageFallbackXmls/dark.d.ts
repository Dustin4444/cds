export let content: string;
//# sourceMappingURL=dark.d.ts.map
