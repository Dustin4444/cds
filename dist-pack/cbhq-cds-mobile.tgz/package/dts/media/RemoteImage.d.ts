import React from 'react';
import type { AccessibilityProps, ImageProps, ImageResizeMode, ImageSourcePropType, ImageStyle, ImageURISource, StyleProp } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { AspectRatio, AvatarSize, FixedValue, Shape } from '@cbhq/cds-common/types';
type SourceProp = string | ImageProps['source'];
type BaseRemoteImageProps = Omit<ImageProps, 'style' | 'width' | 'height' | 'source'> & {
    /** Scale image based on this aspect-ratio */
    aspectRatio?: AspectRatio;
    /** Height of RemoteImage. Height takes precedence over size */
    height?: FixedValue;
    /**
     * Shape of RemoteImage
     * @default square
     * */
    shape?: Shape;
    /** Width of RemoteImage. Width takes precedence over size */
    width?: FixedValue;
    /**
     * Size for a given RemoteImage. If width or height is not defined,
     * it will set size = m as default
     *
     * @default m
     * */
    size?: AvatarSize;
    /** Adds a custom border color */
    borderColor?: ThemeVars.Color;
    /**
     * @deprecated Use `darkModeEnhancementsApplied` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v6
     * Fill in transparent background with inverted background color and add border. This solves issue of transparent, stamped out asset icons not being visible on dark backgrounds.
     */
    shouldApplyDarkModeEnhacements?: boolean;
    /**
     * Fill in transparent background with inverted background color and add border. This solves issue of transparent, stamped out asset icons not being visible on dark backgrounds.
     */
    darkModeEnhancementsApplied?: boolean;
    source?: SourceProp;
    fallbackAccessibilityLabel?: AccessibilityProps['accessibilityLabel'];
    fallbackAccessibilityHint?: AccessibilityProps['accessibilityHint'];
    style?: StyleProp<ImageStyle>;
};
type RemoteImagePropsWithSource = {
    source?: SourceProp;
} & BaseRemoteImageProps;
type RemoteImagePropsWithWidth = {
    width: FixedValue;
    aspectRatio: AspectRatio;
} & BaseRemoteImageProps;
type RemoteImagePropsWithHeight = {
    height: FixedValue;
    aspectRatio: AspectRatio;
} & BaseRemoteImageProps;
type RemoteImagePropsWidthAndHeight = {
    width: FixedValue;
    height: FixedValue;
    resizeMode: ImageResizeMode;
} & BaseRemoteImageProps;
export type RemoteImageBaseProps = RemoteImagePropsWithWidth | RemoteImagePropsWithHeight | RemoteImagePropsWidthAndHeight | RemoteImagePropsWithSource;
export type RemoteImageProps = RemoteImageBaseProps;
declare function getSource(source: string | number | ImageURISource, cachePolicy?: ImageURISource['cache']): ImageSourcePropType;
type HexagonClipPathProps = {
    image: React.ReactElement;
} & AccessibilityProps;
declare const HexagonClipPath: ({ image, ...props }: HexagonClipPathProps) => import("react/jsx-runtime").JSX.Element;
export declare const RemoteImage: React.NamedExoticComponent<RemoteImageBaseProps>;
export { getSource, HexagonClipPath };
//# sourceMappingURL=RemoteImage.d.ts.map