declare const AvatarScreen: () => import('react/jsx-runtime').JSX.Element;
export default AvatarScreen;
//# sourceMappingURL=Avatar.stories.d.ts.map
