import type { AnnouncementCardProps } from '../../cards/AnnouncementCard';
export declare function CarouselItem({
  pictogram,
  spotSquare,
  ...props
}: AnnouncementCardProps): import('react/jsx-runtime').JSX.Element;
export declare function CarouselItemImage({
  image,
  ...props
}: {
  image: string;
} & AnnouncementCardProps): import('react/jsx-runtime').JSX.Element;
export declare function ProgressBarsExample(): import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=CarouselAlphaExample.d.ts.map
