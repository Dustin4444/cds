declare const CarouselScreen: () => import('react/jsx-runtime').JSX.Element;
export default CarouselScreen;
//# sourceMappingURL=CarouselMedia.stories.d.ts.map
