declare const RemoteImageScreen: () => import('react/jsx-runtime').JSX.Element;
export default RemoteImageScreen;
//# sourceMappingURL=RemoteImage.stories.d.ts.map
