declare const All: () => import('react/jsx-runtime').JSX.Element;
export { All };
declare const RemoteImageGroupScreen: () => import('react/jsx-runtime').JSX.Element;
export default RemoteImageGroupScreen;
//# sourceMappingURL=RemoteImageGroup.stories.d.ts.map
