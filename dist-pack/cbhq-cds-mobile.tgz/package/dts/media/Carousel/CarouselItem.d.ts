import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { CarouselDismissItemInternal, CarouselItemId, CarouselUpdateLayoutMap } from './types';
type CarouselItemProps = {
  /** Dismiss a CarouselItem. Requires an index and animated opacity from each CarouselItem. */
  dismiss: CarouselDismissItemInternal;
  /** Id of CarouselItem. Set via key prop when passing in items to parent Carousel component. */
  id: CarouselItemId;
  /** Determines how much padding should be between this CarouselItem and the next one. */
  paddingEnd: ThemeVars.Space;
  /** Save the CarouselItem x position to Carousel's layoutMap. The layoutMap is used for the snapPoints of the ScrollView. */
  updateLayoutMap: CarouselUpdateLayoutMap;
};
export declare const CarouselItem: React.FC<React.PropsWithChildren<CarouselItemProps>>;
export {};
//# sourceMappingURL=CarouselItem.d.ts.map
