import React from 'react';
import type { ScrollView, ScrollViewProps } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { CarouselOnReady, CarouselRef } from './types';
export type CarouselProps = {
    items: React.ReactElement[];
    /** Return value from useCarousel hook. Allows access to certain internal data/methods of Carousel. */
    carouselRef?: React.MutableRefObject<CarouselRef | undefined>;
    /** Gap to insert between siblings. The last item will exclude additional spacing. */
    gap?: ThemeVars.Space;
    /** Callback that fires when the Carousel is ready to be interacted with. */
    onReady?: CarouselOnReady;
} & Omit<ScrollViewProps, 'style'> & SharedProps;
/**
 * @deprecated Use new Carousel component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export declare const Carousel: React.NamedExoticComponent<{
    items: React.ReactElement[];
    /** Return value from useCarousel hook. Allows access to certain internal data/methods of Carousel. */
    carouselRef?: React.MutableRefObject<CarouselRef | undefined>;
    /** Gap to insert between siblings. The last item will exclude additional spacing. */
    gap?: ThemeVars.Space;
    /** Callback that fires when the Carousel is ready to be interacted with. */
    onReady?: CarouselOnReady;
} & Omit<ScrollViewProps, "style"> & SharedProps & React.RefAttributes<ScrollView>>;
//# sourceMappingURL=Carousel.d.ts.map