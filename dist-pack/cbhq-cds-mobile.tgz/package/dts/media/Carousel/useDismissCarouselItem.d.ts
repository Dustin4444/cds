import type { LayoutChangeEvent, NativeScrollEvent, NativeSyntheticEvent } from 'react-native';
import type { ScrollToFn } from '../../hooks/useScrollTo';
import type { CarouselDismissItemParams, CarouselItemId } from './types';
export declare const useDismissCarouselItem: (
  itemsLength: number,
  scrollTo: ScrollToFn,
) => {
  dismiss: ({ height, id, opacity, width, callbackFn }: CarouselDismissItemParams) => void;
  dismissedItems: Set<CarouselItemId>;
  resetDismissedItems: () => void;
  onLayout: (event: LayoutChangeEvent) => void;
  onContentSizeChange: (width: number) => void;
  onScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void;
};
//# sourceMappingURL=useDismissCarouselItem.d.ts.map
