export {};
//# sourceMappingURL=useCarouselItem.test.d.ts.map
