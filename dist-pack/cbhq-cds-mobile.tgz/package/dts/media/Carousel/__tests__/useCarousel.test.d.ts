export {};
//# sourceMappingURL=useCarousel.test.d.ts.map
