import type { CarouselItemContextValue } from './types';
/**
 * Used internally within CarouselItem component to provide access to id and dismiss.
 * @example
 * ```
 * const MyCarouselItem = () => {
 * const { id, dismiss } = useCarouselItem()
 *  return <Card onPress={dismiss}><Text>{`Carousel item ${id}`}</Text></Card>
 * }
 *
 * const MyCarousel = () => {
 *  return (
 *    <Carousel>
 *      <MyCarouselItem />
 *      <MyCarouselItem />
 *      <MyCarouselItem />
 *    </Carousel>
 * )
 * }
 * ```
 */
export declare const CarouselItemContext: import('react').Context<
  CarouselItemContextValue | undefined
>;
//# sourceMappingURL=CarouselItemContext.d.ts.map
