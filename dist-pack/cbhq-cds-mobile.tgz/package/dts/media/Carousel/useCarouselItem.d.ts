import type { CarouselItemContextValue } from './types';
/** Access the index and dismiss function for a CarouselItem. */
export declare const useCarouselItem: () => CarouselItemContextValue;
//# sourceMappingURL=useCarouselItem.d.ts.map
