export {};
//# sourceMappingURL=Avatar.figma.d.ts.map
