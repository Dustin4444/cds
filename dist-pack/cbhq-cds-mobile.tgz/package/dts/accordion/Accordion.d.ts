import type { ViewProps } from 'react-native';
import { type AccordionProviderProps } from '@cbhq/cds-common/accordion/AccordionProvider';
import type { SharedProps } from '@cbhq/cds-common/types';
export type AccordionBaseProps = SharedProps & AccordionProviderProps;
export type AccordionProps = AccordionBaseProps & Pick<ViewProps, 'style'>;
export declare const Accordion: import('react').MemoExoticComponent<
  (_props: AccordionProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=Accordion.d.ts.map
