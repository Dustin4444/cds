import React from 'react';
import type { View, ViewProps } from 'react-native';
import { type AccordionHeaderBaseProps } from './AccordionHeader';
import { type AccordionPanelBaseProps } from './AccordionPanel';
export type AccordionItemBaseProps = Pick<ViewProps, 'style'> & Omit<AccordionHeaderBaseProps, 'collapsed'> & Omit<AccordionPanelBaseProps, 'collapsed'> & {
    headerRef?: React.RefObject<View | null>;
    panelRef?: React.RefObject<View | null>;
};
export type AccordionItemProps = AccordionItemBaseProps;
/**
 * A component that represents a single item within an Accordion.
 * It composes together an AccordionHeader and a collapsible AccordionPanel.
 * Accepts a unique `itemKey` prop to uniquely identify one item from another within the same Accordion.
 */
export declare const AccordionItem: React.MemoExoticComponent<({ itemKey, title, subtitle, children, onPress, media, testID, headerRef, panelRef, style, }: AccordionItemProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=AccordionItem.d.ts.map