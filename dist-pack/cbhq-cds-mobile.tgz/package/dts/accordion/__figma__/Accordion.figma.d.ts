export {};
//# sourceMappingURL=Accordion.figma.d.ts.map
