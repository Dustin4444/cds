declare const AccordionScreen: () => import('react/jsx-runtime').JSX.Element;
export default AccordionScreen;
//# sourceMappingURL=Accordion.stories.d.ts.map
