import React from 'react';
import type { View } from 'react-native';
import type { SlideButtonBaseProps } from './SlideButton';
export declare const slideButtonSpringConfig: {
    readonly stiffness: 300;
    readonly damping: 26;
    readonly mass: 1;
    readonly overshootClamping: true;
};
/**
 * @deprecated SlideButton no longer uses react-spring; this value no longer used by {@link DefaultSlideButtonHandle} but retained for migration only. Use {@link slideButtonSpringConfig} with Reanimated `withSpring` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const animationConfig: {
    readonly tension: 300;
    readonly clamp: true;
};
export type SlideButtonHandleCheckedProps = Pick<SlideButtonBaseProps, 'variant' | 'compact'> & {
    label?: React.ReactNode;
    end?: React.ReactNode;
    disabled?: boolean;
};
export type SlideButtonHandleCheckedComponent = (props: SlideButtonHandleCheckedProps) => React.ReactElement | null;
export type SlideButtonHandleUncheckedProps = Pick<SlideButtonBaseProps, 'variant' | 'compact'> & {
    disabled?: boolean;
    start?: React.ReactNode;
};
export type SlideButtonHandleUncheckedComponent = (props: SlideButtonHandleUncheckedProps) => React.ReactElement | null;
export declare const styles: {
    base: {
        width: "100%";
        height: "100%";
    };
    absoluteContainer: {
        position: "absolute";
        width: "100%";
        height: "100%";
        display: "flex";
        alignItems: "center";
        justifyContent: "center";
    };
    icon: {
        flexShrink: number;
    };
};
export declare const SlideButtonHandleChecked: React.MemoExoticComponent<({ label, end, compact }: SlideButtonHandleCheckedProps) => import("react/jsx-runtime").JSX.Element>;
export declare const SlideButtonHandleUnchecked: React.MemoExoticComponent<({ start, compact }: SlideButtonHandleUncheckedProps) => import("react/jsx-runtime").JSX.Element>;
export declare const DefaultSlideButtonHandle: React.NamedExoticComponent<import("react-native").AccessibilityProps & import("@cbhq/cds-common").ComponentEventHandlerProps & Pick<import("react-native").PressableProps, "style" | "hitSlop" | "onPress"> & Omit<import("../system").InteractableBaseProps, "style" | "pressed"> & {
    noScaleOnPress?: boolean;
    onPressIn?: (event: import("react-native").GestureResponderEvent) => void;
    onPressOut?: (event: import("react-native").GestureResponderEvent) => void;
    feedback?: import("../system").HapticFeedbackType;
    loading?: boolean;
    debounceTime?: number;
    disableDebounce?: boolean;
} & import("react-native").PressableProps & Pick<SlideButtonBaseProps, "disabled" | "checked" | "variant" | "compact" | "checkedLabel" | "startUncheckedNode" | "endCheckedNode"> & {
    progress: import("react-native-reanimated").SharedValue<number>;
    style?: import("react-native").StyleProp<import("react-native").ViewStyle>;
} & React.RefAttributes<View>>;
//# sourceMappingURL=DefaultSlideButtonHandle.d.ts.map