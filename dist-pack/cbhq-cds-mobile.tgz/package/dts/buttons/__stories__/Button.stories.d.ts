declare const ButtonScreen: () => import('react/jsx-runtime').JSX.Element;
export default ButtonScreen;
//# sourceMappingURL=Button.stories.d.ts.map
