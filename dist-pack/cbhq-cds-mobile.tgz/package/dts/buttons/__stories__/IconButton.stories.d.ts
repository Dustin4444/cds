declare const IconButtonScreen: () => import('react/jsx-runtime').JSX.Element;
export default IconButtonScreen;
//# sourceMappingURL=IconButton.stories.d.ts.map
