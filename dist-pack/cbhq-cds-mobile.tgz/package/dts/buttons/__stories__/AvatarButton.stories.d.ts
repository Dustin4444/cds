declare const AvatarButtonScreen: () => import('react/jsx-runtime').JSX.Element;
export default AvatarButtonScreen;
//# sourceMappingURL=AvatarButton.stories.d.ts.map
