export declare const SlideButtonStories: () => import('react/jsx-runtime').JSX.Element;
export default SlideButtonStories;
//# sourceMappingURL=SlideButton.stories.d.ts.map
