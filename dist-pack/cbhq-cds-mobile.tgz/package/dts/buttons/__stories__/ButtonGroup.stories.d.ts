declare const ButtonGroupScreen: () => import('react/jsx-runtime').JSX.Element;
export default ButtonGroupScreen;
//# sourceMappingURL=ButtonGroup.stories.d.ts.map
