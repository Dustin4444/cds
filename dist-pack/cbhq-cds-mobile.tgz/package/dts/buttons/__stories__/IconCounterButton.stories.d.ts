declare const IconCounterButtonScreen: () => import('react/jsx-runtime').JSX.Element;
export default IconCounterButtonScreen;
//# sourceMappingURL=IconCounterButton.stories.d.ts.map
