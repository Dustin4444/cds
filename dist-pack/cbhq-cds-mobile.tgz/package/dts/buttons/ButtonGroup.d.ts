import React from 'react';
import type {
  ElementChildren,
  SharedAccessibilityProps,
  SharedProps,
} from '@cbhq/cds-common/types';
import { type GroupDirection } from '../layout';
import type { ButtonBaseProps } from './Button';
export type ButtonGroupBaseProps = SharedProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabel'> & {
    /** Expand buttons to fill available space within the group. */
    block?: boolean;
    /** Buttons to render as a group. */
    children: ElementChildren<ButtonBaseProps>;
    /**
     * @default horizontal
     * Stack buttons vertically or horizontally.
     */
    direction?: GroupDirection;
  };
export type ButtonGroupProps = ButtonGroupBaseProps;
export declare const ButtonGroup: React.MemoExoticComponent<
  (_props: ButtonGroupProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=ButtonGroup.d.ts.map
