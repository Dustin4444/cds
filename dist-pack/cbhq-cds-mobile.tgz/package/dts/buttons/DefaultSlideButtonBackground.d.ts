import React from 'react';
import type { View } from 'react-native';
export declare const DefaultSlideButtonBackground: React.NamedExoticComponent<Pick<import("./SlideButton").SlideButtonBaseProps, "borderRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "disabled" | "checked" | "variant" | "compact" | "uncheckedLabel"> & {
    progress: import("react-native-reanimated").SharedValue<number>;
    style?: import("react-native").StyleProp<import("react-native").ViewStyle>;
} & React.RefAttributes<View>>;
//# sourceMappingURL=DefaultSlideButtonBackground.d.ts.map