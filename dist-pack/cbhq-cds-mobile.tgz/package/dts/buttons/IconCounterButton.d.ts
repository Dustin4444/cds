import React from 'react';
import type { StyleProp, TextStyle, View } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { IconSize } from '@cbhq/cds-common/types';
import type { IconName } from '@cbhq/cds-icons';
import type { PressableProps } from '../system';
export type IconCounterButtonBaseProps = {
    /** Name of the icon or a ReactNode */
    icon: Exclude<React.ReactNode, 'string'> | IconName;
    /**
     * @deprecated Use `size` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v8
     */
    iconSize?: IconSize;
    /** Size for given icon. */
    size?: IconSize;
    /** Whether the icon is active */
    active?: boolean;
    /** Number to display */
    count?: number;
    /** Color of the icon */
    color?: ThemeVars.Color;
    /**
     * @deprecated Use `styles.icon` or `color` to customize icon color. This will be removed in a future major release.
     * @deprecationExpectedRemoval v10
     */
    dangerouslySetColor?: string;
};
export type IconCounterButtonProps = IconCounterButtonBaseProps & PressableProps & {
    /** Custom styles for individual elements of the IconCounterButton component */
    styles?: {
        /** Root Pressable element */
        root?: PressableProps['style'];
        /** Icon element rendered when `icon` is an icon name */
        icon?: StyleProp<TextStyle>;
    };
};
export declare const IconCounterButton: React.NamedExoticComponent<IconCounterButtonBaseProps & import("react-native").AccessibilityProps & import("@cbhq/cds-common").ComponentEventHandlerProps & Pick<import("react-native").PressableProps, "style" | "hitSlop" | "onPress"> & Omit<import("../system").InteractableBaseProps, "style" | "pressed"> & {
    noScaleOnPress?: boolean;
    onPressIn?: (event: import("react-native").GestureResponderEvent) => void;
    onPressOut?: (event: import("react-native").GestureResponderEvent) => void;
    feedback?: import("../system").HapticFeedbackType;
    loading?: boolean;
    debounceTime?: number;
    disableDebounce?: boolean;
} & import("react-native").PressableProps & {
    /** Custom styles for individual elements of the IconCounterButton component */
    styles?: {
        /** Root Pressable element */
        root?: PressableProps["style"];
        /** Icon element rendered when `icon` is an icon name */
        icon?: StyleProp<TextStyle>;
    };
} & React.RefAttributes<View>>;
//# sourceMappingURL=IconCounterButton.d.ts.map