export {};
//# sourceMappingURL=IconButton.figma.d.ts.map
