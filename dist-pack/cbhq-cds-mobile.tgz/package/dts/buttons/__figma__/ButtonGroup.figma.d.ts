export {};
//# sourceMappingURL=ButtonGroup.figma.d.ts.map
