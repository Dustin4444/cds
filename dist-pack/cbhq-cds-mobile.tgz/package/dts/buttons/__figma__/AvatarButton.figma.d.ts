export {};
//# sourceMappingURL=AvatarButton.figma.d.ts.map
