export {};
//# sourceMappingURL=SlideButton.figma.d.ts.map
