import '@testing-library/jest-dom';
//# sourceMappingURL=IconCounterButton.test.d.ts.map
