export {};
//# sourceMappingURL=Button.perf-test.d.ts.map
