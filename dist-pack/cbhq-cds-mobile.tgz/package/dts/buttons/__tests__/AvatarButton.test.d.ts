export {};
//# sourceMappingURL=AvatarButton.test.d.ts.map
