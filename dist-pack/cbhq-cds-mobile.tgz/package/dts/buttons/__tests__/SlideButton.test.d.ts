export {};
//# sourceMappingURL=SlideButton.test.d.ts.map
