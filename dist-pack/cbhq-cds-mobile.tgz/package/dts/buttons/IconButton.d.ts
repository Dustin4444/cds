import { type View } from 'react-native';
import type { IconButtonVariant, IconName, IconSize, SharedProps } from '@cbhq/cds-common/types';
import { type PressableBaseProps } from '../system/Pressable';
import { type ButtonBaseProps } from './Button';
export type IconButtonBaseProps = SharedProps & Omit<PressableBaseProps, 'children'> & Pick<ButtonBaseProps, 'disabled' | 'transparent' | 'compact' | 'flush' | 'loading' | 'progressCircleSize'> & {
    /** Name of the icon, as defined in Figma. */
    name: IconName;
    /**
     * Size for the icon rendered inside the button.
     * @default compact ? 's' : 'm'
     */
    iconSize?: IconSize;
    /** Whether the icon is active */
    active?: boolean;
    /**
     * Toggle design and visual variants.
     * @default primary
     */
    variant?: IconButtonVariant;
};
export type IconButtonProps = IconButtonBaseProps;
export declare const IconButton: import("react").NamedExoticComponent<SharedProps & Omit<PressableBaseProps, "children"> & Pick<ButtonBaseProps, "transparent" | "disabled" | "loading" | "progressCircleSize" | "compact" | "flush"> & {
    /** Name of the icon, as defined in Figma. */
    name: IconName;
    /**
     * Size for the icon rendered inside the button.
     * @default compact ? 's' : 'm'
     */
    iconSize?: IconSize;
    /** Whether the icon is active */
    active?: boolean;
    /**
     * Toggle design and visual variants.
     * @default primary
     */
    variant?: IconButtonVariant;
} & import("react").RefAttributes<View>>;
//# sourceMappingURL=IconButton.d.ts.map