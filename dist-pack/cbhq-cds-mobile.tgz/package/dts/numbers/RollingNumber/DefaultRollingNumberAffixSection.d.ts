import type { RollingNumberAffixSectionComponent } from './RollingNumber';
export declare const DefaultRollingNumberAffixSection: RollingNumberAffixSectionComponent;
//# sourceMappingURL=DefaultRollingNumberAffixSection.d.ts.map
