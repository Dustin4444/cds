import type { RollingNumberSymbolComponent } from './RollingNumber';
export declare const DefaultRollingNumberSymbol: RollingNumberSymbolComponent;
//# sourceMappingURL=DefaultRollingNumberSymbol.d.ts.map
