import { type RollingNumberDigitComponent } from './RollingNumber';
/**
 * Default digit component for RollingNumber on mobile.
 *
 * The mobile implementation differs from web due to platform-specific animation libraries:
 * - Mobile uses react-native-reanimated with shared values and worklets
 * - Web uses framer-motion with imperative `animate` calls
 *
 * For the "every" variant, mobile renders all 10 digits (0-9) stacked with absolute
 * positioning and animates the container's translateY. Web renders only the necessary
 * digits above/below the current value.
 *
 * For the "single" variant, mobile uses reanimated's `entering`/`exiting` props with
 * custom animation worklets. Web uses imperative opacity crossfades on DOM sections.
 */
export declare const DefaultRollingNumberDigit: RollingNumberDigitComponent;
//# sourceMappingURL=DefaultRollingNumberDigit.d.ts.map
