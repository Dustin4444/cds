import type { RollingNumberValueSectionComponent } from './RollingNumber';
export declare const DefaultRollingNumberValueSection: RollingNumberValueSectionComponent;
//# sourceMappingURL=DefaultRollingNumberValueSection.d.ts.map
