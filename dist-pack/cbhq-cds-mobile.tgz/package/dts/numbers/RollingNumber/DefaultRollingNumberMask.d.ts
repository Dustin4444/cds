import { type RollingNumberMaskComponent } from './RollingNumber';
export declare const DefaultRollingNumberMask: RollingNumberMaskComponent;
//# sourceMappingURL=DefaultRollingNumberMask.d.ts.map
