declare const LinearGradientScreen: () => import('react/jsx-runtime').JSX.Element;
export default LinearGradientScreen;
//# sourceMappingURL=LinearGradient.stories.d.ts.map
