import React from 'react';
import { View } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common';
type Coordinate = {
    x: number;
    y: number;
};
type LinearGradientProps = {
    /**
     * [Optional] pointerEvents determines how the view will handle touch events.
     */
    pointerEvents?: React.ComponentProps<typeof View>['pointerEvents'];
    /**
     * [Optional] The style for the LinearGradiend wrapper.
     */
    style?: React.ComponentProps<typeof View>['style'];
    /**
     * [Optional] Start position of the gradient. By default start is calculated
     * based on the angle prop.
     */
    start?: Coordinate;
    /**
     * [Optional] End position of the gradient. By default end is calculated
     * based on the angle prop.
     * */
    end?: Coordinate;
    /**
     * The relative positions of colors. If supplied, it must be of the same length as colors.
     * @default [0, 1]
     */
    stops?: number[];
    /**
     * React children
     */
    children?: React.ReactNode;
    /**
     * Colors to be distributed between start and end.
     */
    colors: NonNullable<string>[];
    /**
     * Sets layout position between SVG and children. Set it to false when gradient should overlay children content.
     *
     * @deprecated Use the `elevated` prop instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v6
     * @default true
     */
    isBelowChildren?: boolean;
    /**
     * @default false
     * Linear gradient will overlay the children content when true
     */
    elevated?: boolean;
    /**
     * Sets gradient angle.
     * @default 180
     */
    angle?: number;
} & SharedProps;
export declare function LinearGradient({ children, start, end, stops, colors, isBelowChildren, elevated, angle, style, pointerEvents, testID, }: LinearGradientProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=LinearGradient.d.ts.map