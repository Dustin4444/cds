import React from 'react';
import type { ScrollView, ScrollViewProps } from 'react-native';
import type { SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { CarouselId, CarouselOnDismissItem, CarouselOnDismissLastItem, CarouselRef } from './types';
export type { CarouselId, CarouselRef };
export type CarouselProps = {
    /** Determines whether progress indicators are shown in top left of Carousel. */
    showProgress?: boolean;
    /** Determines where dismiss IconButton is shown in each Carousel slide. */
    showDismiss?: boolean;
    /** An array of React.Elements to use as child for each Carousel slide. A unique key, not based on index must be provided. */
    items: React.ReactElement[];
    /** Return value from useCarousel hook. Allows access to certain internal data/methods of Carousel. */
    carouselRef?: React.MutableRefObject<CarouselRef | undefined>;
    /** Gap to insert between siblings. The last item will exclude additional spacing. */
    gap?: ThemeVars.Space;
    /** Optional callback function which will run after a Carousel item is dismissed. */
    onDismissItem?: CarouselOnDismissItem;
    /** Optional callback function which will run after the last item is dismissed and Carousel height is collapsed. */
    onDismissLastItem?: CarouselOnDismissLastItem;
    /** The width of each Carousel item. */
    itemWidth?: number;
    /** Optional boolean to have the Carousel calculate the Carousel Item height */
    autoHeight?: boolean;
    /** Accessibility label of CarouselItem dismiss button */
    dismissButtonAccessibilityLabel?: SharedAccessibilityProps['accessibilityLabel'];
    /** Accessibility hint of CarouselItem dismiss button */
    dismissButtonAccessibilityHint?: SharedAccessibilityProps['accessibilityHint'];
} & Omit<ScrollViewProps, 'style'> & SharedProps;
/**
 * @deprecated Use new Carousel component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export declare const Carousel: React.NamedExoticComponent<{
    /** Determines whether progress indicators are shown in top left of Carousel. */
    showProgress?: boolean;
    /** Determines where dismiss IconButton is shown in each Carousel slide. */
    showDismiss?: boolean;
    /** An array of React.Elements to use as child for each Carousel slide. A unique key, not based on index must be provided. */
    items: React.ReactElement[];
    /** Return value from useCarousel hook. Allows access to certain internal data/methods of Carousel. */
    carouselRef?: React.MutableRefObject<CarouselRef | undefined>;
    /** Gap to insert between siblings. The last item will exclude additional spacing. */
    gap?: ThemeVars.Space;
    /** Optional callback function which will run after a Carousel item is dismissed. */
    onDismissItem?: CarouselOnDismissItem;
    /** Optional callback function which will run after the last item is dismissed and Carousel height is collapsed. */
    onDismissLastItem?: CarouselOnDismissLastItem;
    /** The width of each Carousel item. */
    itemWidth?: number;
    /** Optional boolean to have the Carousel calculate the Carousel Item height */
    autoHeight?: boolean;
    /** Accessibility label of CarouselItem dismiss button */
    dismissButtonAccessibilityLabel?: SharedAccessibilityProps["accessibilityLabel"];
    /** Accessibility hint of CarouselItem dismiss button */
    dismissButtonAccessibilityHint?: SharedAccessibilityProps["accessibilityHint"];
} & Omit<ScrollViewProps, "style"> & SharedProps & React.RefAttributes<ScrollView>>;
//# sourceMappingURL=Carousel.d.ts.map