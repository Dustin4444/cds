import React from 'react';
import { Animated } from 'react-native';
import type { SharedAccessibilityProps } from '@cbhq/cds-common';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { CarouselHandleDismissItem, CarouselId, CarouselOnItemMount } from './types';
export type CarouselItemContextValue = {
  id: CarouselId;
  dismiss: CarouselHandleDismissItem;
};
/**
 * Used internally within CarouselItem component to provide access to id and dismiss.
 */
export declare const CarouselItemContext: React.Context<CarouselItemContextValue | undefined>;
type CarouselItemProps = {
  /** Id of CarouselItem. Set via key prop when passing in items to parent Carousel component. */
  id: CarouselId;
  /** Index of the CarouselItem. This changes based on dismissedItems. */
  index: number;
  /** Determines how much padding should be between this CarouselItem and the next one. */
  paddingEnd: ThemeVars.Space;
  /** Show the dismiss IconButton in each CarouselItem.  */
  showDismiss?: boolean;
  /** x position of the Carousel scroll view. Used to interpolate opacity of dismiss button when showDismiss is true. */
  xOffset: Animated.Value;
  /** The total number of slides in a Carousel. Is used to understand certain conditions such as if is the last or only item. */
  totalItems: number;
  /** The width for Carousel slide. */
  width: number;
  /** The animated opacity for progress indicators. When the second to last item is dismissed we want to fade out progress indicators. */
  progressOpacity?: Animated.Value;
  /** Optional callback function which will run after a Carousel item is dismissed. */
  onDismiss?: () => void;
  /** Optional callback function which will run after the last item is dismissed and Carousel height is collapsed. */
  onDismissLastItem?: () => void;
  onMount: CarouselOnItemMount;
  dismissButtonAccessibilityLabel?: SharedAccessibilityProps['accessibilityLabel'];
  dismissButtonAccessibilityHint?: SharedAccessibilityProps['accessibilityHint'];
};
export declare const CarouselItem: React.FC<React.PropsWithChildren<CarouselItemProps>>;
export {};
//# sourceMappingURL=CarouselItem.d.ts.map
