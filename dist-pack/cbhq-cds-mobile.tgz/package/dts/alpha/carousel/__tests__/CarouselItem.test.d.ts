export {};
//# sourceMappingURL=CarouselItem.test.d.ts.map
