import type { CarouselRef } from './types';
/**
 * Useful if you need to access internal data or methods from Carousel outside of its immediate children.
 * @returns Object with internal data/methods from Carousel component.
 * @example
 * ```
 * const carouselRef = useCarousel()
 * const handlePress = () => carouselRef.current.scrollToId('item1');
 * <Button onPress={handlePress}>Press me</Button>
 * <Carousel carouselRef={carouselRef} />
 * ```
 */
export declare const useCarousel: () => import("react").RefObject<CarouselRef>;
//# sourceMappingURL=useCarousel.d.ts.map