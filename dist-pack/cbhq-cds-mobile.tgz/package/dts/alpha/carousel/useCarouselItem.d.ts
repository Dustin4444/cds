import type { CarouselItemContextValue } from './CarouselItem';
/** Access the index and dismiss function for a CarouselItem.
 * @example
 * ```
 * const MyCarouselItem = () => {
 * const { id, dismiss } = useCarouselItem()
 *  return <Card onPress={dismiss}><Text>{`Carousel item ${id}`}</Text></Card>
 * }
 *
 * const MyCarousel = () => {
 *  return (
 *    <Carousel>
 *      <MyCarouselItem />
 *      <MyCarouselItem />
 *      <MyCarouselItem />
 *    </Carousel>
 * )
 * }
 * ```
 */
export declare const useCarouselItem: () => CarouselItemContextValue;
//# sourceMappingURL=useCarouselItem.d.ts.map
