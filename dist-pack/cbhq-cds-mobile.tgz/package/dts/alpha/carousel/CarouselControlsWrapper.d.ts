import React from 'react';
import type { HStackProps } from '../../layout/HStack';
export type CarouselControlsWrapperProps = HStackProps & {
  children?: React.ReactNode;
};
/** Wrapper to house ProgressIndicators and Dismiss IconButton when controls are shown in Carousel */
export declare const CarouselControlsWrapper: React.NamedExoticComponent<CarouselControlsWrapperProps>;
//# sourceMappingURL=CarouselControlsWrapper.d.ts.map
