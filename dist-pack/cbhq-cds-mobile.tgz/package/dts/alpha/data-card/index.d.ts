export type { DataCardBaseProps, DataCardProps } from './DataCard';
export { DataCard } from './DataCard';
//# sourceMappingURL=index.d.ts.map
