import React from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
export type DataCardLayoutBaseProps = {
  /** Text or React node to display as the card title. Use a Text component to override default color and font. */
  title: React.ReactNode;
  /** Text or React node to display as the card subtitle. Use a Text component to override default color and font. */
  subtitle?: React.ReactNode;
  /** React node to display as a title accessory. */
  titleAccessory?: React.ReactNode;
  /** React node to display as a thumbnail in the header area. */
  thumbnail?: React.ReactNode;
  /** Layout orientation of the card. Horizontal places header and visualization side by side, vertical stacks them.
   * @default 'vertical'
   */
  layout: 'horizontal' | 'vertical';
  /** Child node to display as the visualization (e.g., ProgressBar or ProgressCircle). */
  children?: React.ReactNode;
};
export type DataCardLayoutProps = DataCardLayoutBaseProps & {
  styles?: {
    /** Layout container element */
    layoutContainer?: StyleProp<ViewStyle>;
    /** Header container element */
    headerContainer?: StyleProp<ViewStyle>;
    /** Text container element */
    textContainer?: StyleProp<ViewStyle>;
    /** Title container element */
    titleContainer?: StyleProp<ViewStyle>;
  };
};
export declare const DataCardLayout: React.MemoExoticComponent<
  ({
    title,
    subtitle,
    titleAccessory,
    thumbnail,
    layout,
    children,
    styles,
  }: DataCardLayoutProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=DataCardLayout.d.ts.map
