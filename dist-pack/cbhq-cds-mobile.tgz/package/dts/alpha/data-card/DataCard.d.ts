import type { StyleProp, View, ViewStyle } from 'react-native';
import { type CardRootProps } from '../../cards/CardRoot';
import { type DataCardLayoutProps } from './DataCardLayout';
export type DataCardBaseProps = DataCardLayoutProps & {
    styles?: {
        /** Root element */
        root?: StyleProp<ViewStyle>;
    };
};
export type DataCardProps = Omit<CardRootProps, 'children'> & DataCardBaseProps;
export declare const DataCard: import("react").NamedExoticComponent<Omit<CardRootProps, "children"> & import("./DataCardLayout").DataCardLayoutBaseProps & {
    styles?: {
        layoutContainer?: StyleProp<ViewStyle>;
        headerContainer?: StyleProp<ViewStyle>;
        textContainer?: StyleProp<ViewStyle>;
        titleContainer?: StyleProp<ViewStyle>;
    };
} & {
    styles?: {
        /** Root element */
        root?: StyleProp<ViewStyle>;
    };
} & import("react").RefAttributes<View>>;
//# sourceMappingURL=DataCard.d.ts.map