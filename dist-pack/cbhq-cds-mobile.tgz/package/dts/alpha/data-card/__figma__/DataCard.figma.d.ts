export {};
//# sourceMappingURL=DataCard.figma.d.ts.map
