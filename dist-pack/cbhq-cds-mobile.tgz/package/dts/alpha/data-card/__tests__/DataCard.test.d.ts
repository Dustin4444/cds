export {};
//# sourceMappingURL=DataCard.test.d.ts.map
