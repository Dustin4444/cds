declare const DataCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default DataCardScreen;
//# sourceMappingURL=DataCard.stories.d.ts.map
