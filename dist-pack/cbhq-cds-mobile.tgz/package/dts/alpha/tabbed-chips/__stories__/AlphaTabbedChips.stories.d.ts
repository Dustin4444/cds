declare const TabbedChipsScreen: () => import('react/jsx-runtime').JSX.Element;
export default TabbedChipsScreen;
//# sourceMappingURL=AlphaTabbedChips.stories.d.ts.map
