export {};
//# sourceMappingURL=TabbedChips.test.d.ts.map
