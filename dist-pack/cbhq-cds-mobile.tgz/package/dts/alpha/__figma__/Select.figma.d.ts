export {};
//# sourceMappingURL=Select.figma.d.ts.map
