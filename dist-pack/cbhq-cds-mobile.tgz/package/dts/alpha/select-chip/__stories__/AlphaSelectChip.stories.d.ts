export declare const DefaultSingle: () => import('react/jsx-runtime').JSX.Element;
export declare const DefaultMulti: () => import('react/jsx-runtime').JSX.Element;
export declare const Compact: () => import('react/jsx-runtime').JSX.Element;
export declare const WithStartEndNodes: () => import('react/jsx-runtime').JSX.Element;
export declare const MultiSelectWithAssets: () => import('react/jsx-runtime').JSX.Element;
export declare const InvertColorScheme: () => import('react/jsx-runtime').JSX.Element;
export declare const EmptyOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const WithGroups: () => import('react/jsx-runtime').JSX.Element;
export declare const MultiWithGroups: () => import('react/jsx-runtime').JSX.Element;
export declare const WithDisabledGroup: () => import('react/jsx-runtime').JSX.Element;
export declare const MultiWithDisabledGroup: () => import('react/jsx-runtime').JSX.Element;
export declare const FullyDisabled: () => import('react/jsx-runtime').JSX.Element;
export declare const WithDisabledOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const WithDescriptions: () => import('react/jsx-runtime').JSX.Element;
export declare const WithDisplayValue: () => import('react/jsx-runtime').JSX.Element;
declare const SelectChipScreen: () => import('react/jsx-runtime').JSX.Element;
export default SelectChipScreen;
//# sourceMappingURL=AlphaSelectChip.stories.d.ts.map
