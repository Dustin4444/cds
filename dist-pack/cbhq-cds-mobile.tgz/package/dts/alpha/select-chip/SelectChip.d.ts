import React from 'react';
import type { ChipBaseProps } from '../../chips/ChipProps';
import { type SelectRef } from '../select/Select';
import type { SelectProps, SelectType } from '../select/types';
export type SelectChipBaseProps = Pick<
  ChipBaseProps,
  'invertColorScheme' | 'numberOfLines' | 'maxWidth'
> & {
  /**
   * Override the displayed value in the chip control.
   * Useful for avoiding truncation, especially in multi-select scenarios where multiple option labels might be too long to display.
   * When provided, this value takes precedence over the default label generation.
   */
  displayValue?: React.ReactNode;
};
export type SelectChipProps<
  Type extends SelectType = 'single',
  SelectOptionValue extends string = string,
> = SelectChipBaseProps &
  Omit<
    SelectProps<Type, SelectOptionValue>,
    'SelectControlComponent' | 'helperText' | 'labelVariant' | 'variant' | 'maxWidth'
  >;
export declare const SelectChip: <
  Type extends SelectType = 'single',
  SelectOptionValue extends string = string,
>(
  props: SelectChipProps<Type, SelectOptionValue> & {
    ref?: React.Ref<SelectRef>;
  },
) => React.ReactElement;
//# sourceMappingURL=SelectChip.d.ts.map
