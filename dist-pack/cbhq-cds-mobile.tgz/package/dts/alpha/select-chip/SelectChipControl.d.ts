import React from 'react';
import type { View } from 'react-native';
import type { ChipBaseProps } from '../../chips/ChipProps';
import { type SelectControlProps, type SelectType } from '../select/types';
export declare const SelectChipControl: <
  Type extends SelectType,
  SelectOptionValue extends string = string,
>(
  props: SelectControlProps<Type, SelectOptionValue> &
    Partial<Pick<ChipBaseProps, 'invertColorScheme' | 'numberOfLines'>> & {
      ref?: React.Ref<View>;
      displayValue?: React.ReactNode;
    },
) => React.ReactElement;
//# sourceMappingURL=SelectChipControl.d.ts.map
