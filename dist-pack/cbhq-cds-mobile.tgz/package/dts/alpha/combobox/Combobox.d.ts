import { type TextInput } from 'react-native';
import { type SelectBaseProps, type SelectControlComponent, type SelectControlProps, type SelectOption, type SelectProps, type SelectRef, type SelectType } from '../select/Select';
import type { SelectDropdownComponent, SelectOptionList } from '../select/types';
export type ComboboxControlProps<Type extends SelectType = 'single', SelectOptionValue extends string = string> = SelectControlProps<Type, SelectOptionValue> & Pick<ComboboxBaseProps<Type, SelectOptionValue>, 'hideSearchInput' | 'font'> & {
    /** Search text value */
    searchText: string;
    /** Search text change handler */
    onSearch: (searchText: string) => void;
    /** Reference to the search input */
    searchInputRef: React.RefObject<TextInput | null>;
    /** Reference to the combobox control for positioning */
    controlRef: React.RefObject<ComboboxRef | null>;
    /** Custom SelectControlComponent to wrap */
    SelectControlComponent?: SelectControlComponent<Type, SelectOptionValue>;
};
export type ComboboxControlComponent = <Type extends SelectType = 'single', SelectOptionValue extends string = string>(props: ComboboxControlProps<Type, SelectOptionValue>) => React.ReactElement;
export type ComboboxBaseProps<Type extends SelectType = 'single', SelectOptionValue extends string = string> = SelectBaseProps<Type, SelectOptionValue> & {
    /** Controlled search text value */
    searchText?: string;
    /** Search text change handler */
    onSearch?: (searchText: string) => void;
    /** Custom filter function for searching options */
    filterFunction?: (options: SelectOptionList<Type, SelectOptionValue>, searchText: string) => SelectOption<SelectOptionValue>[];
    /** Default search text value for uncontrolled mode */
    defaultSearchText?: string;
    /** Hide the search input */
    hideSearchInput?: boolean;
    /** Label for close button when combobox is open (mobile only) */
    closeButtonLabel?: string;
};
export type ComboboxProps<Type extends SelectType = 'single', SelectOptionValue extends string = string> = ComboboxBaseProps<Type, SelectOptionValue> & Pick<SelectProps<Type, SelectOptionValue>, 'styles'> & {
    ComboboxControlComponent?: ComboboxControlComponent;
    ComboboxDropdownComponent?: SelectDropdownComponent;
};
export type ComboboxRef = SelectRef;
type ComboboxComponent = <Type extends SelectType = 'single', SelectOptionValue extends string = string>(props: ComboboxProps<Type, SelectOptionValue> & {
    ref?: React.Ref<ComboboxRef>;
}) => React.ReactElement;
export declare const Combobox: ComboboxComponent;
export {};
//# sourceMappingURL=Combobox.d.ts.map