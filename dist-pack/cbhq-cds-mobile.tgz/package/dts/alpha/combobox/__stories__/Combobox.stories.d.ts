export declare const CompactSingleSelect: () => import('react/jsx-runtime').JSX.Element;
declare const Default: () => import('react/jsx-runtime').JSX.Element;
export default Default;
//# sourceMappingURL=Combobox.stories.d.ts.map
