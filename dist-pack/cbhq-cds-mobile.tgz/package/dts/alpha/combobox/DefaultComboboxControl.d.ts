import type { SelectType } from '../select/Select';
import type { ComboboxControlProps } from './Combobox';
export declare const DefaultComboboxControl: <Type extends SelectType = "single", SelectOptionValue extends string = string>({ SelectControlComponent, value, placeholder, open, setOpen, align, disabled, options, searchText, onSearch, font, searchInputRef, hideSearchInput, accessibilityLabel, styles, ...props }: ComboboxControlProps<Type, SelectOptionValue>) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=DefaultComboboxControl.d.ts.map