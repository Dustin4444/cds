import { isSelectOptionGroup, type SelectComponent, type SelectDropdownProps } from './types';
export declare const defaultAccessibilityRoles: SelectDropdownProps['accessibilityRoles'];
export type {
  SelectBaseProps,
  SelectComponent,
  SelectControlComponent,
  SelectControlProps,
  SelectDropdownComponent,
  SelectDropdownProps,
  SelectEmptyDropdownContentComponent,
  SelectEmptyDropdownContentProps,
  SelectOption,
  SelectOptionComponent,
  SelectOptionCustomUI,
  SelectOptionGroup,
  SelectOptionGroupComponent,
  SelectOptionGroupCustomUI,
  SelectOptionGroupProps,
  SelectOptionProps,
  SelectProps,
  SelectRef,
  SelectType,
} from './types';
export { isSelectOptionGroup };
export declare const Select: SelectComponent;
//# sourceMappingURL=Select.d.ts.map
