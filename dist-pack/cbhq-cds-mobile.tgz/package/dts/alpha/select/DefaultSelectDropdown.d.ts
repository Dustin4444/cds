import type { DrawerRefBaseProps } from '../../overlays/drawer/Drawer';
import type { SelectDropdownProps, SelectType } from './Select';
type DefaultSelectDropdownBase = <
  Type extends SelectType = 'single',
  SelectOptionValue extends string = string,
>(
  props: SelectDropdownProps<Type, SelectOptionValue> & {
    ref?: React.Ref<DrawerRefBaseProps>;
  },
) => React.ReactElement;
export declare const DefaultSelectDropdown: DefaultSelectDropdownBase;
export {};
//# sourceMappingURL=DefaultSelectDropdown.d.ts.map
