import { type View } from 'react-native';
import type { SelectOptionProps, SelectType } from './Select';
export declare const DefaultSelectOption: <
  Type extends SelectType = 'single',
  SelectOptionValue extends string = string,
>(
  props: SelectOptionProps<Type, SelectOptionValue> & {
    ref?: React.Ref<View>;
  },
) => React.ReactElement;
//# sourceMappingURL=DefaultSelectOption.d.ts.map
