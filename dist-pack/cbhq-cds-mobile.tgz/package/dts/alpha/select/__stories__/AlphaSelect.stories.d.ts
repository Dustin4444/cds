declare const SelectV3Screen: () => import('react/jsx-runtime').JSX.Element;
export default SelectV3Screen;
//# sourceMappingURL=AlphaSelect.stories.d.ts.map
