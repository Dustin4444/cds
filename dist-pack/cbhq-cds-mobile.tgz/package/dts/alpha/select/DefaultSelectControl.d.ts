import { TouchableOpacity } from 'react-native';
import type { SelectControlProps, SelectType } from './Select';
type DefaultSelectControlComponent = <Type extends SelectType, SelectOptionValue extends string = string>(props: SelectControlProps<Type, SelectOptionValue> & {
    ref?: React.Ref<React.ComponentRef<typeof TouchableOpacity>>;
}) => React.ReactElement;
export declare const DefaultSelectControlComponent: import("react").NamedExoticComponent<Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityHint"> & Omit<import("../../layout").BoxProps, "borderWidth" | "font" | "onChange"> & Pick<import("../../controls/InputStack").InputStackBaseProps, "borderWidth" | "testID" | "disabled" | "variant" | "endNode" | "startNode" | "labelVariant" | "focusedBorderWidth"> & Pick<import("../../controls").TextInputBaseProps, "font"> & {
    value: string | string[] | null;
    onChange: (value: string | string[] | null) => void;
} & {
    align?: "start" | "center" | "end";
    bordered?: boolean;
    options: import("./types").SelectOptionList<SelectType, string>;
    label?: React.ReactNode;
    placeholder?: React.ReactNode;
    helperText?: React.ReactNode;
    contentNode?: React.ReactNode;
    type?: SelectType | undefined;
    open: boolean;
    setOpen: (open: boolean | ((open: boolean) => boolean)) => void;
    maxSelectedOptionsToShow?: number;
    hiddenSelectedOptionsLabel?: string;
    removeSelectedOptionAccessibilityLabel?: string;
    blendStyles?: import("../../system").InteractableBlendStyles;
    compact?: boolean;
    style?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    styles?: {
        controlStartNode?: import("react-native").StyleProp<import("react-native").ViewStyle>;
        controlInputNode?: import("react-native").StyleProp<import("react-native").ViewStyle>;
        controlValueNode?: import("react-native").StyleProp<import("react-native").ViewStyle>;
        controlLabelNode?: import("react-native").StyleProp<import("react-native").ViewStyle>;
        controlHelperTextNode?: import("react-native").StyleProp<import("react-native").ViewStyle>;
        controlEndNode?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    };
} & import("react").RefAttributes<import("react-native").View>>;
export declare const DefaultSelectControl: DefaultSelectControlComponent;
export {};
//# sourceMappingURL=DefaultSelectControl.d.ts.map