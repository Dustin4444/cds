import type { SelectEmptyDropdownContentComponent } from './Select';
export declare const DefaultSelectEmptyDropdownContents: SelectEmptyDropdownContentComponent;
//# sourceMappingURL=DefaultSelectEmptyDropdownContents.d.ts.map
