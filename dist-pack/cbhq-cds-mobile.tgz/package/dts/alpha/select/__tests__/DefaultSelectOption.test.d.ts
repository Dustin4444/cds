export {};
//# sourceMappingURL=DefaultSelectOption.test.d.ts.map
