import type { SelectOptionGroupProps, SelectType } from './Select';
export declare const DefaultSelectOptionGroup: <
  Type extends SelectType = 'single',
  SelectOptionValue extends string = string,
>(
  props: SelectOptionGroupProps<Type, SelectOptionValue>,
) => React.ReactElement;
//# sourceMappingURL=DefaultSelectOptionGroup.d.ts.map
