import type { CollapsibleProps } from './Collapsible';
export type UseCollapsibleDirectionReturn = ReturnType<typeof useCollapsibleDirection>;
export declare const useCollapsibleDirection: ({
  direction,
  maxHeight,
  maxWidth,
  contentWidth,
  contentHeight,
}: Pick<CollapsibleProps, 'direction' | 'maxHeight' | 'maxWidth'> & {
  contentWidth: number;
  contentHeight: number;
}) => {
  shouldEnableScroll: boolean;
  animateTo: number;
  animateProperty: string;
  horizontal: boolean;
};
//# sourceMappingURL=useCollapsibleDirection.d.ts.map
