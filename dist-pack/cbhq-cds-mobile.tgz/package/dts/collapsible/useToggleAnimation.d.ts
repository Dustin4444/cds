import type { Animated } from 'react-native';
type ToggleAnimation = {
  animateIn: Animated.CompositeAnimation;
  animateOut: Animated.CompositeAnimation;
  on: boolean;
};
export declare const useToggleAnimation: ({ on, animateIn, animateOut }: ToggleAnimation) => void;
export {};
//# sourceMappingURL=useToggleAnimation.d.ts.map
