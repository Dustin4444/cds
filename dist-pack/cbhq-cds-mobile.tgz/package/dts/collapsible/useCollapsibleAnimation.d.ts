import { Animated } from 'react-native';
import type { CollapsibleDirection } from '@cbhq/cds-common';
import type { UseCollapsibleDirectionReturn } from './useCollapsibleDirection';
type UseCollapsibleAnimationParams = {
  collapsed: boolean;
  animateTo: UseCollapsibleDirectionReturn['animateTo'];
  animateProperty: UseCollapsibleDirectionReturn['animateProperty'];
  direction: CollapsibleDirection;
};
export declare const useCollapsibleAnimation: ({
  collapsed,
  animateTo,
  animateProperty,
  direction,
}: UseCollapsibleAnimationParams) => {
  animatedStyles: {
    [x: string]: Animated.Value;
    opacity: Animated.Value;
  };
  animateIn: Animated.CompositeAnimation;
  animateOut: Animated.CompositeAnimation;
};
export {};
//# sourceMappingURL=useCollapsibleAnimation.d.ts.map
