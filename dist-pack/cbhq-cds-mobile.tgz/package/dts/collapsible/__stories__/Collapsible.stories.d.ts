declare const CollapseScreen: () => import('react/jsx-runtime').JSX.Element;
export default CollapseScreen;
//# sourceMappingURL=Collapsible.stories.d.ts.map
