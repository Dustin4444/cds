import React from 'react';
import { View } from 'react-native';
import type { ScrollViewProps } from 'react-native';
import type { CollapsibleDirection, PaddingProps, SharedProps } from '@cbhq/cds-common/types';
export type CollapsibleBaseProps = SharedProps & PaddingProps & {
    /**
     * Expand/collapse state of the content.
     * @default true
     */
    collapsed: boolean;
    /**
     * Collapsible content
     */
    children: React.ReactNode;
    /**
     * Direction the content should expand/collapse to
     * @default vertical
     */
    direction?: CollapsibleDirection;
    /**
     * RN ScrollView props. Use with caution as it might break default settings.
     */
    scrollViewProps?: ScrollViewProps;
    /**
     * Max height of the content. Overflow content will be scrollable.
     */
    maxHeight?: number;
    /**
     * Max width of the content. Overflow content will be scrollable.
     */
    maxWidth?: number;
};
export type CollapsibleProps = CollapsibleBaseProps;
export declare const Collapsible: React.NamedExoticComponent<SharedProps & PaddingProps & {
    /**
     * Expand/collapse state of the content.
     * @default true
     */
    collapsed: boolean;
    /**
     * Collapsible content
     */
    children: React.ReactNode;
    /**
     * Direction the content should expand/collapse to
     * @default vertical
     */
    direction?: CollapsibleDirection;
    /**
     * RN ScrollView props. Use with caution as it might break default settings.
     */
    scrollViewProps?: ScrollViewProps;
    /**
     * Max height of the content. Overflow content will be scrollable.
     */
    maxHeight?: number;
    /**
     * Max width of the content. Overflow content will be scrollable.
     */
    maxWidth?: number;
} & React.RefAttributes<View>>;
//# sourceMappingURL=Collapsible.d.ts.map