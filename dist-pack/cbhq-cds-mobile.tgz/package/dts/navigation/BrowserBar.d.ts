import React from 'react';
import type { SharedProps } from '@cbhq/cds-common';
import { type BoxBaseProps, type HStackProps } from '../layout';
export type BrowserBarBaseProps = SharedProps &
  Omit<BoxBaseProps, 'children'> & {
    children: React.ReactNode;
    /**
     * start node
     */
    start?: React.ReactNode;
    /**
     * end node
     */
    end?: React.ReactNode;
  };
export type BrowserBarProps = BrowserBarBaseProps & Omit<HStackProps, 'children'>;
export declare const BrowserBarContext: React.Context<{
  hideStart: boolean;
  hideEnd: boolean;
  setHideStart: React.Dispatch<React.SetStateAction<boolean>>;
  setHideEnd: React.Dispatch<React.SetStateAction<boolean>>;
  isWithinBrowserBar: boolean;
}>;
export declare const useBrowserBarContext: () => {
  hideStart: boolean;
  hideEnd: boolean;
  setHideStart: React.Dispatch<React.SetStateAction<boolean>>;
  setHideEnd: React.Dispatch<React.SetStateAction<boolean>>;
  isWithinBrowserBar: boolean;
};
export declare const BrowserBar: React.MemoExoticComponent<
  (_props: BrowserBarProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=BrowserBar.d.ts.map
