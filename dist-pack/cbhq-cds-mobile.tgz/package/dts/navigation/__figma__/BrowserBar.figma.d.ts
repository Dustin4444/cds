export {};
//# sourceMappingURL=BrowserBar.figma.d.ts.map
