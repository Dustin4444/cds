export {};
//# sourceMappingURL=TopNavBar.figma.d.ts.map
