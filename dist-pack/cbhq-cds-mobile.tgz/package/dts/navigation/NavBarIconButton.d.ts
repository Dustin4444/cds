import type { IconName, IconSize, SharedProps } from '@cbhq/cds-common/types';
import type { ButtonBaseProps } from '../buttons/Button';
import { type PressableBaseProps } from '../system/Pressable';
export type NavBarButtonProps = SharedProps &
  Omit<PressableBaseProps, 'children'> &
  Pick<ButtonBaseProps, 'disabled'> & {
    /** Name of the icon, as defined in Figma. */
    name: IconName;
    size?: IconSize;
    /** Whether the icon is active */
    active?: boolean;
  };
/**
 * This component is used to render an icon button in the navigation bar.
 * It has the same pressable size as a compact IconButton but with a medium-sized icon.
 */
export declare const NavBarIconButton: import('react').MemoExoticComponent<
  ({
    name,
    color,
    height,
    width,
    size,
    borderWidth,
    borderRadius,
    active,
    ...props
  }: NavBarButtonProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=NavBarIconButton.d.ts.map
