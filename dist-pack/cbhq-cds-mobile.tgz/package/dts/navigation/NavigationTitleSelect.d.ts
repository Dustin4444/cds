import React from 'react';
import { type TextBaseProps, type TextProps } from '../typography/Text';
export type NavigationTitleSelectBaseProps = Omit<TextBaseProps, 'onChange'> & {
  options: {
    label: React.ReactNode;
    id: string;
  }[];
  value: string;
  onChange: (value: string) => void;
};
export type NavigationTitleSelectProps = NavigationTitleSelectBaseProps &
  Omit<TextProps, 'onChange'>;
export declare const NavigationTitleSelect: React.MemoExoticComponent<
  (_props: NavigationTitleSelectProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=NavigationTitleSelect.d.ts.map
