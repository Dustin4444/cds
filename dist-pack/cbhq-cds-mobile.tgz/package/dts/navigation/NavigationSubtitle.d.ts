import { type TextProps } from '../typography/Text';
export type NavigationSubtitleProps = TextProps;
export declare const NavigationSubtitle: {
  ({
    accessibilityRole,
    color,
    font,
    ...props
  }: NavigationSubtitleProps): import('react/jsx-runtime').JSX.Element;
  displayName: string;
};
//# sourceMappingURL=NavigationSubtitle.d.ts.map
