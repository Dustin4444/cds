import { type SearchInputProps } from '../controls/SearchInput';
export type BrowserBarSearchInputProps = SearchInputProps & {
  /**
   * Whether to expand itself and collapse the start and end node of the browser bar when the input is focused.
   * @default true
   */
  expandOnFocus?: boolean;
};
/**
 * This component is used to render the search input in the browser bar.
 * It wraps around the existing SearchInput component and handles the logic
 * for collapsing the start and end node of the browser bar when the input is focused.
 */
export declare const BrowserBarSearchInput: import('react').MemoExoticComponent<
  ({
    onFocus,
    onBlur,
    compact,
    expandOnFocus,
    ...props
  }: BrowserBarSearchInputProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=BrowserBarSearchInput.d.ts.map
