declare const NavBarIconButtonScreen: () => import('react/jsx-runtime').JSX.Element;
export default NavBarIconButtonScreen;
//# sourceMappingURL=NavBarIconButton.stories.d.ts.map
