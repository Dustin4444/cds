declare const NavigationTitleSelectScreen: () => import('react/jsx-runtime').JSX.Element;
export default NavigationTitleSelectScreen;
//# sourceMappingURL=NavigationTitleSelect.stories.d.ts.map
