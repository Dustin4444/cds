declare const BrowserBarSearchInputScreen: () => import('react/jsx-runtime').JSX.Element;
export default BrowserBarSearchInputScreen;
//# sourceMappingURL=BrowserBarSearchInput.stories.d.ts.map
