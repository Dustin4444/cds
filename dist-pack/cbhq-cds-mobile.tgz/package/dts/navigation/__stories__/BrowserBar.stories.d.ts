declare const BrowserBarScreen: () => import('react/jsx-runtime').JSX.Element;
export default BrowserBarScreen;
//# sourceMappingURL=BrowserBar.stories.d.ts.map
