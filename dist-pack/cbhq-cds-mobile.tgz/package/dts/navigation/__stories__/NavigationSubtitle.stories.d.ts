declare const NavigationSubtitleScreen: () => import('react/jsx-runtime').JSX.Element;
export default NavigationSubtitleScreen;
//# sourceMappingURL=NavigationSubtitle.stories.d.ts.map
