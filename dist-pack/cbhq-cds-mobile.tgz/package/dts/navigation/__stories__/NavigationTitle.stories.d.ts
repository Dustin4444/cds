declare const NavigationTitleScreen: () => import('react/jsx-runtime').JSX.Element;
export default NavigationTitleScreen;
//# sourceMappingURL=NavigationTitle.stories.d.ts.map
