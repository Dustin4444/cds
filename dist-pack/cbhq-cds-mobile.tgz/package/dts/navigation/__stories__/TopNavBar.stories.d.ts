declare const NavigationBarScreen: () => import('react/jsx-runtime').JSX.Element;
export default NavigationBarScreen;
//# sourceMappingURL=TopNavBar.stories.d.ts.map
