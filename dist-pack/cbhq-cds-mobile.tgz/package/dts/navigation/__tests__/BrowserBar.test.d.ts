export {};
//# sourceMappingURL=BrowserBar.test.d.ts.map
