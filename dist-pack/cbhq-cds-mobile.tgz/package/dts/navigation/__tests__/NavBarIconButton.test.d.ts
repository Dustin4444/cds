export {};
//# sourceMappingURL=NavBarIconButton.test.d.ts.map
