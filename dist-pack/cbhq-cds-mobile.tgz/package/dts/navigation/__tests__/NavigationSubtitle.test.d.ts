export {};
//# sourceMappingURL=NavigationSubtitle.test.d.ts.map
