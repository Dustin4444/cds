export {};
//# sourceMappingURL=NavigationTitle.test.d.ts.map
