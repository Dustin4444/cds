export {};
//# sourceMappingURL=BrowserBarSearchInput.test.d.ts.map
