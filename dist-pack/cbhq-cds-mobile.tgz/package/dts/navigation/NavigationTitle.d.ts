import { type TextBaseProps, type TextProps } from '../typography/Text';
export type NavigationTitleBaseProps = TextBaseProps;
export type NavigationTitleProps = NavigationTitleBaseProps & TextProps;
export declare const NavigationTitle: import('react').MemoExoticComponent<
  (_props: NavigationTitleProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=NavigationTitle.d.ts.map
