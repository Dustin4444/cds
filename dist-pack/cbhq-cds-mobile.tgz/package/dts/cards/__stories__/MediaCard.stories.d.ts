declare const MediaCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default MediaCardScreen;
//# sourceMappingURL=MediaCard.stories.d.ts.map
