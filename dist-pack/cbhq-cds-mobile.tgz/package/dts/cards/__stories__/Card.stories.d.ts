declare const CardScreen: () => import('react/jsx-runtime').JSX.Element;
export default CardScreen;
//# sourceMappingURL=Card.stories.d.ts.map
