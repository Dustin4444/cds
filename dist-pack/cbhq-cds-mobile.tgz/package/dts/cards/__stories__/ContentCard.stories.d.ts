declare const ContentCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default ContentCardScreen;
//# sourceMappingURL=ContentCard.stories.d.ts.map
