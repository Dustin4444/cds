declare const NudgeCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default NudgeCardScreen;
//# sourceMappingURL=NudgeCard.stories.d.ts.map
