declare const ContainedAssetCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default ContainedAssetCardScreen;
//# sourceMappingURL=ContainedAssetCard.stories.d.ts.map
