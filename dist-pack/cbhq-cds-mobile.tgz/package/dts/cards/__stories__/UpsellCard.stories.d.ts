declare const UpsellCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default UpsellCardScreen;
//# sourceMappingURL=UpsellCard.stories.d.ts.map
