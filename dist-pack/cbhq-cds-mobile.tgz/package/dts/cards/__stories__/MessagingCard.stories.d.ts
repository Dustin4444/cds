declare const MessagingCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default MessagingCardScreen;
//# sourceMappingURL=MessagingCard.stories.d.ts.map
