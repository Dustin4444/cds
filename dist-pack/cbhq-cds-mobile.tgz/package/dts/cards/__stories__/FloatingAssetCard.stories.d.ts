declare const FloatingAssetCardScreen: () => import('react/jsx-runtime').JSX.Element;
export default FloatingAssetCardScreen;
//# sourceMappingURL=FloatingAssetCard.stories.d.ts.map
