export {};
//# sourceMappingURL=FloatingAssetCard.figma.d.ts.map
