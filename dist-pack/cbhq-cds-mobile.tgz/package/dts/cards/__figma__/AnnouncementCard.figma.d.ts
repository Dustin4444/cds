export {};
//# sourceMappingURL=AnnouncementCard.figma.d.ts.map
