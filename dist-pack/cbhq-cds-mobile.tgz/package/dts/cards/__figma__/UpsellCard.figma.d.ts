export {};
//# sourceMappingURL=UpsellCard.figma.d.ts.map
