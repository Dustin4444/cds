export {};
//# sourceMappingURL=ContainedAssetCard.figma.d.ts.map
