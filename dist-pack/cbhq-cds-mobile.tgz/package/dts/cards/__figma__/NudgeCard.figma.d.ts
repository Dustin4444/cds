export {};
//# sourceMappingURL=NudgeCard.figma.d.ts.map
