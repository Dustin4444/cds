import React from 'react';
import type { PressableProps } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { HStackProps } from '../layout';
export type ContainedAssetCardBaseProps = {
  /** Text or ReactNode to be displayed above Title */
  subtitle?: React.ReactNode;
  /** Text or ReactNode to be displayed in TextHeadline */
  title: React.ReactNode;
  /** Content to be displayed below the title */
  description?: React.ReactNode;
  /**
   * Header to display Remote Image or other content.
   */
  header: React.ReactNode;
  /**
   * Variant for card size. Can be small or large.
   * @default 's'
   */
  size?: 's' | 'l';
  /**
   * Children to be rendered in the card
   */
  children?: React.ReactNode;
} & SharedProps;
export type ContainedAssetCardProps = ContainedAssetCardBaseProps &
  Pick<PressableProps, 'onPress'> &
  Pick<HStackProps, 'minWidth' | 'maxWidth'>;
/**
 * @deprecated Use `MediaCard` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 *
 * Migration guide:
 * ```tsx
 * // Before
 * <ContainedAssetCard
 *   header={<Avatar ... />}
 *   title="Asset Title"
 *   subtitle="Subtitle"
 *   description="Description"
 *   size="l"
 * >
 *   <RemoteImage ... />
 * </ContainedAssetCard>
 *
 * // After
 * <MediaCard
 *   thumbnail={<Avatar ... />}
 *   title="Asset Title"
 *   subtitle="Subtitle"
 *   description="Description"
 *   media={<RemoteImage ... />}
 *   mediaPlacement="end"
 * />
 * ```
 */
export declare const ContainedAssetCard: React.MemoExoticComponent<
  ({
    title,
    description,
    subtitle,
    header,
    testID,
    size,
    children,
    onPress,
    maxWidth: propMaxWidth,
    minWidth: propMinWidth,
  }: ContainedAssetCardProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=ContainedAssetCard.d.ts.map
