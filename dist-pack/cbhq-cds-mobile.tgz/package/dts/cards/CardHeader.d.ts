import React from 'react';
import type { CardHeaderProps as CardHeaderBaseProps } from '@cbhq/cds-common/types';
/**
 * @deprecated Use ContentCardHeaderProps instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardHeaderProps = CardHeaderBaseProps;
/**
 * @deprecated Use ContentCardHeader instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const CardHeader: React.MemoExoticComponent<
  ({
    avatar,
    metaData,
    description,
    action,
    testID,
  }: CardHeaderProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=CardHeader.d.ts.map
