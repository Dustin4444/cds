import React from 'react';
import type { StyleProp, View, ViewStyle } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { HStackProps } from '../../layout';
export type ContentCardHeaderBaseProps = SharedProps & {
    /**
     * @deprecated Use `thumbnail` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    avatar?: React.ReactNode;
    /** A media object like an image, avatar, illustration, or cryptocurrency asset. */
    thumbnail?: React.ReactNode;
    /** Text or React node to display as the header title. Use a Text component to override default color and font. */
    title: React.ReactNode;
    /**
     * @deprecated Use `subtitle` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    meta?: React.ReactNode;
    /** Text or React node to display as the header subtitle. Use a Text component to override default color and font. */
    subtitle?: React.ReactNode;
    /**
     * @deprecated Use `actions` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    end?: React.ReactNode;
    /** Slot for action buttons. */
    actions?: React.ReactNode;
    styles?: {
        /** Root container element */
        root?: StyleProp<ViewStyle>;
        /** Text content container (title + subtitle) */
        textContainer?: StyleProp<ViewStyle>;
        /** Content container (thumbnail + text content) */
        contentContainer?: StyleProp<ViewStyle>;
    };
};
export type ContentCardHeaderProps = ContentCardHeaderBaseProps & HStackProps;
export declare const ContentCardHeader: React.NamedExoticComponent<SharedProps & {
    /**
     * @deprecated Use `thumbnail` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    avatar?: React.ReactNode;
    /** A media object like an image, avatar, illustration, or cryptocurrency asset. */
    thumbnail?: React.ReactNode;
    /** Text or React node to display as the header title. Use a Text component to override default color and font. */
    title: React.ReactNode;
    /**
     * @deprecated Use `subtitle` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    meta?: React.ReactNode;
    /** Text or React node to display as the header subtitle. Use a Text component to override default color and font. */
    subtitle?: React.ReactNode;
    /**
     * @deprecated Use `actions` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    end?: React.ReactNode;
    /** Slot for action buttons. */
    actions?: React.ReactNode;
    styles?: {
        /** Root container element */
        root?: StyleProp<ViewStyle>;
        /** Text content container (title + subtitle) */
        textContainer?: StyleProp<ViewStyle>;
        /** Content container (thumbnail + text content) */
        contentContainer?: StyleProp<ViewStyle>;
    };
} & import("../../styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: import("react-native").Animated.WithAnimatedValue<StyleProp<ViewStyle>>;
    animated?: boolean;
    elevation?: import("@cbhq/cds-common").ElevationLevels;
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & Omit<import("react-native").ViewProps, "style"> & React.RefAttributes<View>>;
//# sourceMappingURL=ContentCardHeader.d.ts.map