import React from 'react';
import type { View } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { HStackProps } from '../../layout';
export type ContentCardFooterBaseProps = SharedProps & {
    children?: React.ReactNode;
};
export type ContentCardFooterProps = ContentCardFooterBaseProps & HStackProps;
export declare const ContentCardFooter: React.NamedExoticComponent<SharedProps & {
    children?: React.ReactNode;
} & import("../../styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: import("react-native").Animated.WithAnimatedValue<import("react-native").StyleProp<import("react-native").ViewStyle>>;
    animated?: boolean;
    elevation?: import("@cbhq/cds-common").ElevationLevels;
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & Omit<import("react-native").ViewProps, "style"> & React.RefAttributes<View>>;
//# sourceMappingURL=ContentCardFooter.d.ts.map