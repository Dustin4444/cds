export {};
//# sourceMappingURL=ContentCard.figma.d.ts.map
