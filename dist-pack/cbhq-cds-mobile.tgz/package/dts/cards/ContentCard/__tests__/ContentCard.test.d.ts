export {};
//# sourceMappingURL=ContentCard.test.d.ts.map
