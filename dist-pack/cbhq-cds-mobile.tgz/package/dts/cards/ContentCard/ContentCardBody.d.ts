import React from 'react';
import type { StyleProp, View, ViewStyle } from 'react-native';
import { type SharedProps } from '@cbhq/cds-common/types';
import type { VStackProps } from '../../layout';
export type ContentCardBodyBaseProps = SharedProps & {
    /** Text or React node to display as the card title. Use a Text component to override default color and font. */
    title?: React.ReactNode;
    /**
     * @deprecated Use description instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * Main body copy
     */
    body?: React.ReactNode;
    /** Text or React node to display as the card description. Use a Text component to override default color and font. */
    description?: React.ReactNode;
    /**
     * @deprecated Use a ReactNode as `description` instead if you need to display content below the description. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * Use for supplemental data.
     */
    label?: React.ReactNode;
    /** React node to display as media content (e.g., Image or RemoteImage). */
    media?: React.ReactNode;
    /**
     * @deprecated Use mediaPlacement instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * The position of the media within the card.
     * Can be one of: 'top', 'bottom', 'right' or 'left'.
     */
    mediaPosition?: 'top' | 'bottom' | 'right' | 'left';
    /** Placement of the media content relative to the text content.
     * @default 'top'
     */
    mediaPlacement?: 'top' | 'bottom' | 'start' | 'end';
    /**
     * Custom content to display below the main content box (title/description/media).
     * Use this when you need to render custom content that doesn't fit the standard media/title/description layout.
     */
    children?: React.ReactNode;
    styles?: {
        /** Root container element (content container + children) */
        root?: StyleProp<ViewStyle>;
        /** Content container (media + text content) */
        contentContainer?: StyleProp<ViewStyle>;
        /** Text content container (title + description + label) */
        textContainer?: StyleProp<ViewStyle>;
        /** Media container element */
        mediaContainer?: StyleProp<ViewStyle>;
    };
};
export type ContentCardBodyProps = ContentCardBodyBaseProps & VStackProps;
export declare const ContentCardBody: React.NamedExoticComponent<SharedProps & {
    /** Text or React node to display as the card title. Use a Text component to override default color and font. */
    title?: React.ReactNode;
    /**
     * @deprecated Use description instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * Main body copy
     */
    body?: React.ReactNode;
    /** Text or React node to display as the card description. Use a Text component to override default color and font. */
    description?: React.ReactNode;
    /**
     * @deprecated Use a ReactNode as `description` instead if you need to display content below the description. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * Use for supplemental data.
     */
    label?: React.ReactNode;
    /** React node to display as media content (e.g., Image or RemoteImage). */
    media?: React.ReactNode;
    /**
     * @deprecated Use mediaPlacement instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * The position of the media within the card.
     * Can be one of: 'top', 'bottom', 'right' or 'left'.
     */
    mediaPosition?: "top" | "bottom" | "right" | "left";
    /** Placement of the media content relative to the text content.
     * @default 'top'
     */
    mediaPlacement?: "top" | "bottom" | "start" | "end";
    /**
     * Custom content to display below the main content box (title/description/media).
     * Use this when you need to render custom content that doesn't fit the standard media/title/description layout.
     */
    children?: React.ReactNode;
    styles?: {
        /** Root container element (content container + children) */
        root?: StyleProp<ViewStyle>;
        /** Content container (media + text content) */
        contentContainer?: StyleProp<ViewStyle>;
        /** Text content container (title + description + label) */
        textContainer?: StyleProp<ViewStyle>;
        /** Media container element */
        mediaContainer?: StyleProp<ViewStyle>;
    };
} & import("../../styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: import("react-native").Animated.WithAnimatedValue<StyleProp<ViewStyle>>;
    animated?: boolean;
    elevation?: import("@cbhq/cds-common").ElevationLevels;
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & Omit<import("react-native").ViewProps, "style"> & React.RefAttributes<View>>;
//# sourceMappingURL=ContentCardBody.d.ts.map