export {};
//# sourceMappingURL=MediaCard.figma.d.ts.map
