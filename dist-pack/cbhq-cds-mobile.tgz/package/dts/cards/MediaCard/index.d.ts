import type { StyleProp, View, ViewStyle } from 'react-native';
import { type CardRootProps } from '../CardRoot';
import { type MediaCardLayoutProps } from './MediaCardLayout';
export type MediaCardBaseProps = MediaCardLayoutProps;
export type MediaCardProps = MediaCardBaseProps & Omit<CardRootProps, 'children'> & {
    styles?: {
        /** Root element */
        root?: StyleProp<ViewStyle>;
    };
};
export declare const MediaCard: import("react").NamedExoticComponent<import("./MediaCardLayout").MediaCardLayoutBaseProps & {
    styles?: {
        layoutContainer?: StyleProp<ViewStyle>;
        contentContainer?: StyleProp<ViewStyle>;
        textContainer?: StyleProp<ViewStyle>;
        headerContainer?: StyleProp<ViewStyle>;
        mediaContainer?: StyleProp<ViewStyle>;
    };
} & Omit<CardRootProps, "children"> & {
    styles?: {
        /** Root element */
        root?: StyleProp<ViewStyle>;
    };
} & import("react").RefAttributes<View>>;
//# sourceMappingURL=index.d.ts.map