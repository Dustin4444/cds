import React from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
export type MediaCardLayoutBaseProps = {
  /** Text or React node to display as the card title. Use a Text component to override default color and font. */
  title?: React.ReactNode;
  /** Text or React node to display as the card subtitle. Use a Text component to override default color and font. */
  subtitle?: React.ReactNode;
  /** Text or React node to display as the card description. Use a Text component to override default color and font. */
  description?: React.ReactNode;
  /** React node to display as a thumbnail in the content area. */
  thumbnail: React.ReactNode;
  /** React node to display as the main media content. When provided, it will be rendered in an HStack container taking up 50% of the card width. */
  media?: React.ReactNode;
  /** The position of the media within the card.
   * @default 'end'
   */
  mediaPlacement?: 'start' | 'end';
};
export type MediaCardLayoutProps = MediaCardLayoutBaseProps & {
  styles?: {
    /** Layout container element */
    layoutContainer?: StyleProp<ViewStyle>;
    /** Content container element */
    contentContainer?: StyleProp<ViewStyle>;
    /** Text container element */
    textContainer?: StyleProp<ViewStyle>;
    /** Header container element */
    headerContainer?: StyleProp<ViewStyle>;
    /** Media container element */
    mediaContainer?: StyleProp<ViewStyle>;
  };
};
declare const MediaCardLayout: React.MemoExoticComponent<
  ({
    title,
    subtitle,
    description,
    thumbnail,
    media,
    mediaPlacement,
    styles,
  }: MediaCardLayoutProps) => import('react/jsx-runtime').JSX.Element
>;
export { MediaCardLayout };
//# sourceMappingURL=MediaCardLayout.d.ts.map
