import React from 'react';
import type { StyleProp, View, ViewStyle } from 'react-native';
import { type PressableProps } from '../system/Pressable';
export type CardRootBaseProps = {
    /** Content to render inside the card. */
    children: React.ReactNode;
    /**
     * If true, the CardRoot will be rendered as a Pressable component.
     * When false, renders as an HStack for layout purposes.
     * @default false
     */
    renderAsPressable?: boolean;
};
export type CardRootProps = CardRootBaseProps & Omit<PressableProps, 'style'> & {
    style?: StyleProp<ViewStyle>;
};
/**
 * CardRoot is the foundational wrapper component for card layouts.
 *
 * By default, it renders as an HStack for horizontal layout.
 * When `renderAsPressable` is true, it renders as a Pressable component.
 */
export declare const CardRoot: React.NamedExoticComponent<CardRootBaseProps & Omit<PressableProps, "style"> & {
    style?: StyleProp<ViewStyle>;
} & React.RefAttributes<View>>;
//# sourceMappingURL=CardRoot.d.ts.map