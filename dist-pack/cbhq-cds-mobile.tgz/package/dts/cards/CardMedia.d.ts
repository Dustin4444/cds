import type { CardMediaProps as CommonCardMediaProps } from '@cbhq/cds-common/types';
/**
 * @deprecated Use SpotSquare when `type` is "spotSquare", Pictogram when `type` is "pictogram", or RemoteImage when `type` is "image". This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardMediaProps = CommonCardMediaProps;
/**
 * @deprecated Use SpotSquare when `type` is "spotSquare", Pictogram when `type` is "pictogram", or RemoteImage when `type` is "image". This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const CardMedia: import('react').NamedExoticComponent<CommonCardMediaProps>;
//# sourceMappingURL=CardMedia.d.ts.map
