export {};
//# sourceMappingURL=MessagingCard.test.d.ts.map
