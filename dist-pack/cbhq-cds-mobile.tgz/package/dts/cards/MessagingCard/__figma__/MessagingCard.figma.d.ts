export {};
//# sourceMappingURL=MessagingCard.figma.d.ts.map
