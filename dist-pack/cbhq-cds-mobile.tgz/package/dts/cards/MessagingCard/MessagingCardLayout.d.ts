import React from 'react';
import type { GestureResponderEvent, StyleProp, ViewStyle } from 'react-native';
export type MessagingCardLayoutProps = {
  /** Type of messaging card. Determines background color and text color. */
  type: 'upsell' | 'nudge';
  /** Text or React node to display as the card title. Use a Text component to override default color and font. */
  title?: React.ReactNode;
  /** Text or React node to display as the card description. Use a Text component to override default color and font. */
  description?: React.ReactNode;
  /** Text or React node to display as a tag. When a string is provided, it will be rendered in a Tag component. */
  tag?: React.ReactNode;
  /**
   * Action element to display. Can be a string (renders as default button) or a custom ReactNode.
   * When a string is provided, use `onActionButtonPress` to handle presses.
   */
  action?: React.ReactNode;
  /** Callback fired when the action button is pressed. Only used when `action` is a string. */
  onActionButtonPress?: (event: GestureResponderEvent) => void;
  /** Accessibility label for the action button. Only used when `action` is a string.
   * @default action value (when action is a string)
   */
  actionButtonAccessibilityLabel?: string;
  /** React node to display as the dismiss button. When provided, this will be rendered instead of the default dismiss button. */
  dismissButton?: React.ReactNode;
  /** Callback fired when the dismiss button is pressed. When provided, a default dismiss button will be rendered in the top-right corner. */
  onDismissButtonPress?: (event: GestureResponderEvent) => void;
  /** Accessibility label for the dismiss button.
   * @default 'Dismiss {title}' when title is a string, otherwise 'Dismiss card'
   */
  dismissButtonAccessibilityLabel?: string;
  /** Placement of the media content relative to the text content.
   * @default 'end'
   */
  mediaPlacement: 'start' | 'end';
  /** React node to display as the main media content. When provided, it will be rendered in an HStack container. */
  media?: React.ReactNode;
  styles?: {
    /** Layout container element */
    layoutContainer?: StyleProp<ViewStyle>;
    /** Content container element */
    contentContainer?: StyleProp<ViewStyle>;
    /** Text container element */
    textContainer?: StyleProp<ViewStyle>;
    /** Media container element */
    mediaContainer?: StyleProp<ViewStyle>;
    /** Dismiss button container element */
    dismissButtonContainer?: StyleProp<ViewStyle>;
  };
};
export declare const MessagingCardLayout: React.MemoExoticComponent<
  ({
    type,
    title,
    description,
    tag,
    action,
    onActionButtonPress,
    actionButtonAccessibilityLabel,
    onDismissButtonPress,
    dismissButtonAccessibilityLabel,
    mediaPlacement,
    media,
    styles,
    dismissButton,
  }: MessagingCardLayoutProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=MessagingCardLayout.d.ts.map
