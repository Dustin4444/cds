import type { StyleProp, View, ViewStyle } from 'react-native';
import { type CardRootProps } from '../CardRoot';
import { type MessagingCardLayoutProps } from './MessagingCardLayout';
export type MessagingCardBaseProps = MessagingCardLayoutProps;
export type MessagingCardProps = MessagingCardBaseProps & Omit<CardRootProps, 'children'> & {
    styles?: {
        /** Root element */
        root?: StyleProp<ViewStyle>;
    };
};
export declare const MessagingCard: import("react").NamedExoticComponent<MessagingCardLayoutProps & Omit<CardRootProps, "children"> & {
    styles?: {
        /** Root element */
        root?: StyleProp<ViewStyle>;
    };
} & import("react").RefAttributes<View>>;
//# sourceMappingURL=index.d.ts.map