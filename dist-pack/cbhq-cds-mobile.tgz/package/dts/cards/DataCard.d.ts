import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type CardBaseProps } from './Card';
export type DataCardBaseProps = CardBaseProps &
  SharedProps & {
    onPress?: CardBaseProps['onPress'];
    /** Text to be displayed in TextHeadline under CardHeader section. */
    title: string;
    /** Text to be displayed in TextLabel2 under title. */
    description: string;
    startLabel?: string;
    endLabel?: string;
    progressVariant?: 'bar' | 'circle';
    progress?: number;
    progressColor?: ThemeVars.Color;
  };
export type DataCardProps = DataCardBaseProps;
export declare const DataCard: import('react').NamedExoticComponent<DataCardBaseProps>;
//# sourceMappingURL=DataCard.d.ts.map
