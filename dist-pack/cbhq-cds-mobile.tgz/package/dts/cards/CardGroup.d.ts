import React from 'react';
import type { View } from 'react-native';
import type { GroupProps, RenderGroupItem } from '../layout/Group';
/**
 * @deprecated Use `Box`, `HStack` or `VStack` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardGroupBaseProps = GroupProps;
/**
 * @deprecated Use `Box`, `HStack` or `VStack` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardGroupProps = CardGroupBaseProps;
export type CardGroupRenderItem = RenderGroupItem;
/**
 * @deprecated Use `Box`, `HStack` or `VStack` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const CardGroup: React.NamedExoticComponent<import("@cbhq/cds-common").SharedProps & import("../styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: import("react-native").Animated.WithAnimatedValue<import("react-native").StyleProp<import("react-native").ViewStyle>>;
    animated?: boolean;
    elevation?: import("@cbhq/cds-common").ElevationLevels;
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & Omit<import("react-native").ViewProps, "style"> & {
    accessibilityLabel?: string;
    children?: React.ReactNode;
    direction?: import("../layout").GroupDirection;
    divider?: React.ComponentType<React.PropsWithChildren<unknown>> | null;
    gap?: import("@cbhq/cds-common").ThemeVars.Space;
    renderItem?: ((info: {
        Wrapper: React.ComponentType<React.PropsWithChildren<import("../layout").BoxProps>>;
        item: React.ReactElement | string | number;
        index: number;
        isFirst: boolean;
        isLast: boolean;
    }) => React.ReactElement | string | number) | undefined;
} & React.RefAttributes<View>>;
//# sourceMappingURL=CardGroup.d.ts.map