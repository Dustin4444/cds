import React from 'react';
import { type CardBaseProps } from './Card';
import { type CardBodyBaseProps } from './CardBody';
export type FeatureEntryCardBaseProps = CardBaseProps & CardBodyBaseProps;
/**
 * @deprecated Use MessagingCard instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v6
 */
export type FeatureEntryCardProps = FeatureEntryCardBaseProps;
/**
 * @deprecated Use MessagingCard instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v6
 */
export declare const FeatureEntryCard: React.NamedExoticComponent<FeatureEntryCardBaseProps>;
//# sourceMappingURL=FeatureEntryCard.d.ts.map
