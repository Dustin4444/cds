import React from 'react';
import type { SharedAccessibilityProps } from '@cbhq/cds-common';
import type { BoxBaseProps, BoxProps } from '../layout/Box';
import { type PressableProps } from '../system/Pressable';
export type CardBaseProps = Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'> & Pick<PressableProps, 'noScaleOnPress' | 'onPress'> & BoxBaseProps & {
    /** Size of the card. Small and medium have fixed widths and large grows with its children. */
    size?: 'small' | 'medium' | 'large';
    /**
     * If onPress is present the Card will be wrapped with a Pressable component.
     * pressableProps allows customization of that Pressable wrapper.
     */
    pressableProps?: Omit<PressableProps, 'onPress'>;
};
/**
 * @deprecated Use `ContentCard`, `MediaCard`, `MessagingCard`, or `DataCard` based on your use case. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardProps = CardBaseProps & BoxProps;
/**
 * @deprecated Use ContentCard instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const Card: React.NamedExoticComponent<CardProps>;
//# sourceMappingURL=Card.d.ts.map