import React from 'react';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types';
import type { BoxBaseProps, BoxProps } from '../layout';
export type CardFooterBaseProps = Pick<
  SharedAccessibilityProps,
  'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'
> &
  Omit<BoxBaseProps, 'children'> & {
    /** CardFooter takes one or many actions as children */
    children: React.ReactNode;
  };
export type CardFooterProps = CardFooterBaseProps & Omit<BoxProps, 'children'>;
/**
 * @deprecated Use ContentCardFooter instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const CardFooter: React.NamedExoticComponent<CardFooterProps>;
//# sourceMappingURL=CardFooter.d.ts.map
