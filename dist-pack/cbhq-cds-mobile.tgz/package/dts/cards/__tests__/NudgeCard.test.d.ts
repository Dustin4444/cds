export {};
//# sourceMappingURL=NudgeCard.test.d.ts.map
