export {};
//# sourceMappingURL=FloatingAssetCard.test.d.ts.map
