export {};
//# sourceMappingURL=UpsellCard.test.d.ts.map
