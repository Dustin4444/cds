import React from 'react';
import type { PressableProps } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { DimensionStyles, SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common/types';
import { type HStackProps } from '../layout';
export type UpsellCardBaseProps = SharedProps & Pick<SharedAccessibilityProps, 'accessibilityLabel'> & Pick<DimensionStyles, 'width'> & Pick<HStackProps, 'style'> & {
    /** Callback fired when the action button is pressed */
    onActionPress?: PressableProps['onPress'];
    /** Callback fired when the dismiss button is pressed */
    onDismissPress?: PressableProps['onPress'];
    /** Callback fired when the card is pressed */
    onPress?: PressableProps['onPress'];
    /** Text or ReactNode to be displayed in TextHeadline */
    title: React.ReactNode;
    /** Content to be displayed below the title */
    description?: React.ReactNode;
    /** Node to display for the card action */
    action?: React.ReactNode;
    /**
     * Remote Image or other node with media content.
     */
    media?: React.ReactNode;
    /**
     * Background color for the card.
     * @default 'bgPrimaryWash'
     */
    background?: ThemeVars.Color;
    /**
     * @deprecated Use `style` or `background` to customize card background. This will be removed in a future major release.
     * @deprecationExpectedRemoval v10
     */
    dangerouslySetBackground?: string;
};
export type UpsellCardProps = UpsellCardBaseProps;
/**
 * @deprecated Use `MessagingCard` with `type="upsell"` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 *
 * Migration guide:
 * ```tsx
 * // Before
 * <UpsellCard
 *   title="Title"
 *   description="Description"
 *   media={<RemoteImage ... />}
 *   action="Get Started"
 *   onActionPress={handleAction}
 *   onDismissPress={handleDismiss}
 * />
 *
 * // After
 * <MessagingCard
 *   type="upsell"
 *   title="Title"
 *   description="Description"
 *   media={<RemoteImage ... />}
 *   actions={<Button compact variant="secondary">Get Started</Button>}
 *   onDismiss={handleDismiss}
 *   mediaPlacement="end"
 * />
 * ```
 */
export declare const UpsellCard: React.MemoExoticComponent<({ title, description, action, onActionPress, onDismissPress, media, background, dangerouslySetBackground, testID, accessibilityLabel, width, onPress, style, }: UpsellCardProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=UpsellCard.d.ts.map