import React from 'react';
import type { PressableProps } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { DimensionStyles, DimensionValue, IllustrationPictogramNames, SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common/types';
export type NudgeCardBaseProps = SharedProps & Omit<DimensionStyles, 'minHeight' | 'width'> & Pick<SharedAccessibilityProps, 'accessibilityLabel'> & {
    /** Text or ReactNode to be displayed above the description in a TextHeadline */
    title?: React.ReactNode;
    /** Text or ReactNode to be displayed below the title in a TextBody */
    description?: React.ReactNode;
    /** If you pass a Pictogram name it will render a Pictogram to the right of the text content */
    pictogram?: IllustrationPictogramNames;
    /** Pass any node to be rendered to the right of the text content */
    media?: React.ReactNode;
    /** Text or ReactNode to display as the call to action */
    action?: React.ReactNode;
    /**
     * Maximum number of lines shown for the title and description text. Text that exceeds will be truncated.
     * @default 3
     */
    numberOfLines?: number;
    /**
     * @default 327
     */
    width?: DimensionValue;
    /**
     * @default 160
     */
    minHeight?: DimensionValue;
    /**
     * Background color for the card.
     * @default bgAlternate
     */
    background?: ThemeVars.Color;
    /**
     * Set the media position for the pictogram or media.
     * @default right
     */
    mediaPosition?: 'left' | 'right';
    onDismissPress?: PressableProps['onPress'];
    onActionPress?: PressableProps['onPress'];
    onPress?: PressableProps['onPress'];
};
export type NudgeCardProps = NudgeCardBaseProps;
/**
 * @deprecated Use `MessagingCard` with `type="nudge"` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 *
 * Migration guide:
 * ```tsx
 * // Before
 * <NudgeCard
 *   title="Title"
 *   description="Description"
 *   pictogram="addToWatchlist"
 *   action="Learn more"
 *   onActionPress={handleAction}
 *   onDismissPress={handleDismiss}
 * />
 *
 * // After
 * <MessagingCard
 *   type="nudge"
 *   title="Title"
 *   description="Description"
 *   media={<Pictogram dimension="48x48" name="addToWatchlist" />}
 *   actions={<Button compact variant="secondary">Learn more</Button>}
 *   onDismiss={handleDismiss}
 *   mediaPlacement="end"
 * />
 * ```
 */
export declare const NudgeCard: React.MemoExoticComponent<({ title, description, pictogram, media, mediaPosition, action, onActionPress, numberOfLines, onDismissPress, width, testID, accessibilityLabel, background, onPress, maxWidth, maxHeight, minHeight, minWidth, height, aspectRatio, }: NudgeCardProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=NudgeCard.d.ts.map