import React from 'react';
import { type TextProps } from '../typography/Text';
export type CellDetailVariant = 'foregroundMuted' | 'negative' | 'positive' | 'warning';
export type CellDetailProps = {
  /**
   * Label and/or extra detail. This prop is only intended to accept a string or Text component;
   * other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `detailNode`.
   */
  detail?: React.ReactNode;
  /** React node to render label and/or extra detail. Takes precedence over `detail`. */
  detailNode?: React.ReactNode;
  /**
   * Subdetail providing more information. This prop is only intended to accept a string or Text component;
   * other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `subdetailNode`.
   */
  subdetail?: React.ReactNode;
  /** React node to render subdetail. Takes precedence over `subdetail`. */
  subdetailNode?: React.ReactNode;
  /** Variant color to apply to the subdetail text. */
  variant?: CellDetailVariant;
  /** Specifies whether font should be scaled down automatically to fit given style constraints. */
  adjustsFontSizeToFit?: boolean;
  /** Font to apply to the subdetail text. */
  subdetailFont?: TextProps['font'];
};
export declare const CellDetail: React.NamedExoticComponent<CellDetailProps>;
//# sourceMappingURL=CellDetail.d.ts.map
