import { type FallbackProps } from '../layout/Fallback';
import type { CellMediaType } from './CellMedia';
export type MediaFallbackProps = {
  type: CellMediaType;
} & Omit<FallbackProps, 'width' | 'height' | 'shape'>;
export declare const MediaFallback: import('react').NamedExoticComponent<MediaFallbackProps>;
//# sourceMappingURL=MediaFallback.d.ts.map
