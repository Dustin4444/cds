import React from 'react';
import type { ImageURISource } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { IconName, SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common/types';
import type { PictogramProps } from '../illustrations';
export type CellMediaType = 'asset' | 'avatar' | 'image' | 'icon' | 'pictogram';
export type CellMediaIconProps = {
  type: Extract<CellMediaType, 'icon'>;
  name: IconName;
  /** Whether the icon is active */
  active?: boolean;
  color?: ThemeVars.Color;
};
export type CellMediaPictogramProps = {
  type: Extract<CellMediaType, 'pictogram'>;
  illustration: React.ReactElement<PictogramProps>;
};
type CellMediaOtherProps = {
  type: Exclude<CellMediaType, 'icon' | 'pictogram'>;
  /**
   * @deprecated This will be removed in a future major release.
   * @deprecationExpectedRemoval v6
   * If required, use `accessibilityLabel` and `accessibilityHint` instead to set accessible labels.
   * Refer to https://cds.coinbase.com/components/cell-media/ for updated accessibility guidance.
   */
  title?: string;
  source: string | number;
};
type CellMediaVariantProps = CellMediaIconProps | CellMediaPictogramProps | CellMediaOtherProps;
export type CellMediaProps = SharedProps &
  CellMediaVariantProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityHint'> & {
    /**
     * Determines how the requests handles potentially cached responses. Not applicable to type="icon".
     * @link https://reactnative.dev/docs/0.67/images#cache-control-ios-only
     */
    cache?: ImageURISource['cache'];
  };
/**
 * @deprecated Pass media directly via the `media` prop. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 * For example: `<Avatar src={...} />`, `<Icon name={...} />`, `<RemoteImage source={...} />`, or a Pictogram.
 */
export declare const CellMedia: React.NamedExoticComponent<CellMediaProps>;
export {};
//# sourceMappingURL=CellMedia.d.ts.map
