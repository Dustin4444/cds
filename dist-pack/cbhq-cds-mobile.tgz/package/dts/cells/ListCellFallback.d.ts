import { type ReactNode } from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import type { FallbackRectWidthProps, SharedProps } from '@cbhq/cds-common/types';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types/SharedAccessibilityProps';
import { type CellAccessoryType } from './CellAccessory';
import type { CellMediaType } from './CellMedia';
import { type ListCellBaseProps } from './ListCell';
export type ListCellFallbackBaseProps = SharedProps &
  FallbackRectWidthProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabel'> &
  Pick<ListCellBaseProps, 'compact' | 'innerSpacing' | 'outerSpacing' | 'spacingVariant'> & {
    /** Accessory to display at the end of the cell. */
    accessory?: CellAccessoryType;
    /** Custom accessory rendered at the end of the cell. Takes precedence over `accessory`. */
    accessoryNode?: ReactNode;
    /** Display description shimmer. */
    description?: boolean;
    /** Display detail shimmer. */
    detail?: boolean;
    /** Display helper text shimmer. */
    helperText?: boolean;
    /** Display media shimmer with a shape according to type. */
    media?: CellMediaType;
    /** Display subdetail shimmer. */
    subdetail?: boolean;
    /** Display subtitle shimmer. */
    subtitle?: boolean;
    /** Display title shimmer. */
    title?: boolean;
  };
export type ListCellFallbackProps = ListCellFallbackBaseProps & {
  /** Styles to apply to the detail, bottomContent, and title. */
  styles?: {
    /** Style to apply to the bottom content (helper text shimmer). */
    helperText?: StyleProp<ViewStyle>;
    /** Style to apply to the detail shimmer. */
    detail?: StyleProp<ViewStyle>;
    /** Style to apply to the subdetail shimmer. */
    subdetail?: StyleProp<ViewStyle>;
    /** Style to apply to the title shimmer. */
    title?: StyleProp<ViewStyle>;
    /** Style to apply to the description shimmer. */
    description?: StyleProp<ViewStyle>;
    /** Style to apply to the subtitle shimmer. */
    subtitle?: StyleProp<ViewStyle>;
    /** Style to apply to the accessory container. */
    accessory?: StyleProp<ViewStyle>;
  };
};
export declare const ListCellFallback: import('react').NamedExoticComponent<ListCellFallbackProps>;
//# sourceMappingURL=ListCellFallback.d.ts.map
