export {};
//# sourceMappingURL=CellMedia.test.d.ts.map
