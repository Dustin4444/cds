import React from 'react';
import type { StyleProp, TextStyle, ViewStyle } from 'react-native';
import { type CellProps } from './Cell';
import { type CellAccessoryType } from './CellAccessory';
/**
 * @deprecated Use ListCell instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export type ContentCellBaseProps = {
  /** Accessory to display at the end of the cell. */
  accessory?: CellAccessoryType;
  /**
   * @deprecated Use `spacingVariant="compact"` instead. This will be removed in a future major release.
   * @deprecationExpectedRemoval v9
   */
  compact?: boolean;
  /**
   * Spacing variant configuration.
   * Deprecated value: 'compact'. Prefer 'condensed'.
   *
   * When `spacingVariant="normal"`:
   * 1. `min-height` is `80px`
   * 2. padding is `var(--space-2) var(--space-3)`
   * 3. `border-radius` is `var(--borderRadius-200)`
   *
   * When `spacingVariant="compact"`:
   * 1. same as `spacingVariant="normal"`, except `min-height` is `40px`
   *
   * When `spacingVariant="condensed"`:
   * 1. `min-height` is undefined
   * 2. padding is `var(--space-1) var(--space-2)`
   * 3. `border-radius` is `var(--borderRadius-0)`
   * 4. subtitle uses `label1`
   * 5. title wraps to 2 lines regardless of description content
   *
   * @default 'normal'
   */
  spacingVariant?: 'normal' | 'compact' | 'condensed';
  /** Description of content. Content will wrap accordingly. */
  description?: React.ReactNode;
  /**
   * React node to render description. Takes precedence over `description`.
   * When provided, `styles.description` is not applied.
   */
  descriptionNode?: React.ReactNode;
  /** Media (icon, asset, image, etc) to display at the start of the cell. */
  media?: React.ReactElement;
  /** Meta information to display at the end of the title. */
  meta?: React.ReactNode;
  /**
   * React node to render meta. Takes precedence over `meta`.
   * When provided, `styles.meta` and `styles.metaContainer` are not applied.
   */
  metaNode?: React.ReactNode;
  /** Subtitle of content. Max 1 line, otherwise will truncate. */
  subtitle?: React.ReactNode;
  /**
   * React node to render subtitle. Takes precedence over `subtitle`.
   * When provided, `styles.subtitle` is not applied.
   */
  subtitleNode?: React.ReactNode;
  /** Title of content. Up to 2 lines depending on spacing variant. */
  title?: React.ReactNode;
  /**
   * React node to render title. Takes precedence over `title`.
   * When provided, `styles.title` is not applied.
   */
  titleNode?: React.ReactNode;
  /** Styles for subcomponents, ignored when the corresponding `xxNode` prop is used */
  styles?: {
    /** Root element */
    root?: StyleProp<ViewStyle>;
    /** Media element */
    media?: StyleProp<ViewStyle>;
    /** Accessory element */
    accessory?: StyleProp<ViewStyle>;
    /** Content container element */
    contentContainer?: StyleProp<ViewStyle>;
    /** Pressable wrapper element */
    pressable?: StyleProp<ViewStyle>;
    /** Main content element */
    mainContent?: StyleProp<ViewStyle>;
    /** Title text element */
    title?: StyleProp<TextStyle>;
    /** Subtitle text element */
    subtitle?: StyleProp<TextStyle>;
    /** Meta container element */
    metaContainer?: StyleProp<ViewStyle>;
    /** Meta text element */
    meta?: StyleProp<TextStyle>;
    /** Description text element */
    description?: StyleProp<TextStyle>;
  };
};
export type ContentCellProps = Omit<CellProps, 'children' | 'accessory' | 'styles'> &
  ContentCellBaseProps;
/**
 * @deprecated Use ListCell instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const ContentCell: React.NamedExoticComponent<ContentCellProps>;
//# sourceMappingURL=ContentCell.d.ts.map
