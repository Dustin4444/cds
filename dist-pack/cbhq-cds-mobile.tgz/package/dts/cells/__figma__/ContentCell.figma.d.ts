export {};
//# sourceMappingURL=ContentCell.figma.d.ts.map
