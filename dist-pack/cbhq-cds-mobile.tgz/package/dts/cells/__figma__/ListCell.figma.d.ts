export {};
//# sourceMappingURL=ListCell.figma.d.ts.map
