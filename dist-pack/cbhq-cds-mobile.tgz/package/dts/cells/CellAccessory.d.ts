import React from 'react';
import type { PaddingProps } from '@cbhq/cds-common/types';
export type CellAccessoryType = 'arrow' | 'more' | 'selected' | 'unselected';
export type CellAccessoryProps = PaddingProps & {
  /** Type of accessory to display at the end. */
  type: CellAccessoryType;
  /**
   * @danger This is a migration escape hatch. It is not intended to be used normally.
   */
  className?: string;
};
export declare const CellAccessory: React.NamedExoticComponent<CellAccessoryProps>;
//# sourceMappingURL=CellAccessory.d.ts.map
