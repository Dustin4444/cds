import { cellHelperTextVariants } from '@cbhq/cds-common/tokens/cell';
import { type HStackProps } from '../layout/HStack';
export type CellHelperTextProps = HStackProps & {
  /** The variant determines the icon and color scheme */
  variant?: keyof typeof cellHelperTextVariants;
};
export declare const CellHelperText: import('react').MemoExoticComponent<
  ({ children, variant, ...props }: CellHelperTextProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=CellHelperText.d.ts.map
