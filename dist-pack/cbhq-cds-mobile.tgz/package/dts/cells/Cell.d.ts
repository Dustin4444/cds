import React from 'react';
import { type DimensionValue, type StyleProp, type ViewProps, type ViewStyle } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { CellPriority, SharedProps } from '@cbhq/cds-common/types';
import { type BoxBaseProps, type BoxProps } from '../layout/Box';
import type { LinkableProps, PressableProps } from '../system/Pressable';
import type { CellAccessoryProps } from './CellAccessory';
export type CellSpacing = Pick<BoxBaseProps, 'padding' | 'paddingX' | 'paddingY' | 'paddingTop' | 'paddingEnd' | 'paddingBottom' | 'paddingStart' | 'margin' | 'marginX' | 'marginY' | 'marginTop' | 'marginEnd' | 'marginBottom' | 'marginStart'>;
export type CellBaseProps = SharedProps & LinkableProps & Pick<PressableProps, 'blendStyles'> & {
    /** Accessory element rendered at the end of the cell (e.g., chevron). */
    accessory?: React.ReactElement<CellAccessoryProps>;
    /** Custom accessory node rendered at the end of the cell. Takes precedence over `accessory`. */
    accessoryNode?: React.ReactNode;
    /** Main content of the cell; typically title/description content. */
    children: React.ReactNode;
    /**
     * End-aligned content (e.g., value, status).
     * Replaces the deprecated `detail` prop.
     */
    end?: React.ReactNode;
    /**
     * @deprecated Use `end` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    detail?: React.ReactNode;
    /** Middle content between main content and detail. */
    intermediary?: React.ReactNode;
    /** Media rendered at the start of the cell (icon, avatar, image, etc). */
    media?: React.ReactElement;
    borderRadius?: ThemeVars.BorderRadius;
    /**
     * @deprecated Use `styles.end` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    detailWidth?: DimensionValue;
    /** Is the cell disabled? Will apply opacity and disable interaction. */
    disabled?: boolean;
    /** Which piece of content has the highest priority in regards to text truncation, growing, and shrinking. */
    priority?: CellPriority | CellPriority[];
    /** Is the cell selected? Will apply a background and selected accessory. */
    selected?: boolean;
    /** The spacing to use on the parent wrapper of Cell */
    outerSpacing?: CellSpacing;
    /** The spacing to use on the inner content of Cell */
    innerSpacing?: CellSpacing;
    /** The content to display below the main cell content. */
    bottomContent?: React.ReactNode;
    /** Measure the dimensions of the cell. */
    onLayout?: ViewProps['onLayout'];
    /** Custom styles for individual elements of the Cell component */
    styles?: {
        /** Root element */
        root?: StyleProp<ViewStyle>;
        /** Content container element */
        contentContainer?: StyleProp<ViewStyle>;
        /** Top content element */
        topContent?: StyleProp<ViewStyle>;
        /** Bottom content element */
        bottomContent?: StyleProp<ViewStyle>;
        /** Pressable wrapper element */
        pressable?: StyleProp<ViewStyle>;
        /** Media element */
        media?: StyleProp<ViewStyle>;
        /** Children container wrapper, controls flex behavior */
        childrenContainer?: StyleProp<ViewStyle>;
        /** Intermediary element */
        intermediary?: StyleProp<ViewStyle>;
        /** End element (detail or action container) */
        end?: StyleProp<ViewStyle>;
        /** Accessory element */
        accessory?: StyleProp<ViewStyle>;
    };
};
export type CellProps = BoxProps & CellBaseProps;
export declare const Cell: React.NamedExoticComponent<CellProps>;
//# sourceMappingURL=Cell.d.ts.map