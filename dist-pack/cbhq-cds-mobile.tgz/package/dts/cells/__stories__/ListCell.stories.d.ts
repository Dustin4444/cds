declare const ListCellScreen: () => import('react/jsx-runtime').JSX.Element;
export default ListCellScreen;
//# sourceMappingURL=ListCell.stories.d.ts.map
