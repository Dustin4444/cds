declare const ContentCellFallbackScreen: () => import('react/jsx-runtime').JSX.Element;
export default ContentCellFallbackScreen;
//# sourceMappingURL=ContentCellFallback.stories.d.ts.map
