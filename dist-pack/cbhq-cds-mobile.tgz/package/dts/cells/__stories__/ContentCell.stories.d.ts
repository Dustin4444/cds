declare const ContentCellScreen: () => import('react/jsx-runtime').JSX.Element;
export default ContentCellScreen;
//# sourceMappingURL=ContentCell.stories.d.ts.map
