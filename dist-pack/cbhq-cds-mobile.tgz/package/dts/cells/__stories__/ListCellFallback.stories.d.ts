declare const ListCellFallbackScreen: () => import('react/jsx-runtime').JSX.Element;
export default ListCellFallbackScreen;
//# sourceMappingURL=ListCellFallback.stories.d.ts.map
