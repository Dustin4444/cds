import React from 'react';
import type { StyleProp, TextStyle, ViewStyle } from 'react-native';
import { type CellBaseProps, type CellProps } from './Cell';
import { type CellAccessoryType } from './CellAccessory';
import { type CellDetailProps } from './CellDetail';
export declare const condensedInnerSpacing: {
  readonly paddingX: 3;
  readonly paddingY: 1;
  readonly marginX: 0;
};
export declare const condensedOuterSpacing: {
  readonly paddingX: 0;
  readonly paddingY: 0;
  readonly marginX: 0;
};
export type ListCellBaseProps = CellDetailProps &
  Omit<CellBaseProps, 'accessory' | 'children'> & {
    /** Accessory to display at the end of the cell. */
    accessory?: CellAccessoryType;
    /** Custom accessory node rendered at the end of the cell. Takes precedence over `accessory`. */
    accessoryNode?: React.ReactNode;
    /**
     * End-aligned content (e.g., CTA, form element, metric). Replacement for the deprecated action prop, and takes precedence over it.
     * If the content is a action (like button, link, etc), we recommand avoid using alongside `onPress`.
     * If used alongside `onClick`, the end action is triggered first and then the `onClick` handler.
     */
    end?: React.ReactNode;
    /**
     * @deprecated Use `end` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    action?: React.ReactNode;
    /**
     * @deprecated Use `spacingVariant="condensed"`. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    compact?: boolean;
    /**
     * Spacing variant configuration.
     * Deprecated values: 'normal' and 'compact'. Prefer 'condensed'.
     *
     * When `spacingVariant="normal"`:
     * 1. `min-height` is `80px`
     * 2. `padding` is `'var(--space-2) var(--space-3)'`
     * 3. `border-radius` is `'var(--borderRadius-200)'`
     * 4. when there is a description, title's `numberOfLines={1}` otherwise title's `numberOfLines={2}`
     * 5. description and subdetail have font `body`
     *
     * When `spacingVariant="compact"`:
     * 1. same as `spacingVariant="normal"`, except `min-height` is `40px`
     *
     * When `spacingVariant="condensed"`:
     * 1. `min-height` is undefined
     * 2. `padding` is `'var(--space-1) var(--space-2)'`
     * 3. `border-radius` is `--borderRadius-0`
     * 4. title's `numberOfLines={2}`
     * 5. description and subdetail have font `label2`
     *
     * @default 'normal'
     */
    spacingVariant?: /** @deprecated Use 'condensed' instead. */
      | 'normal'
      | /** @deprecated Use 'condensed' instead. */ 'compact'
      | 'condensed';
    /** Description of content. Max 1 line (with title) or 2 lines (without), otherwise will truncate. This prop is only intended to accept a string or Text component; other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `descriptionNode`. */
    description?: React.ReactNode;
    /**
     * React node to render description. Takes precedence over `description`.
     * When provided, `styles.description` is not applied.
     */
    descriptionNode?: React.ReactNode;
    /**
     * Disable the default accessory that is displayed when the cell is selected.
     * If `accessory` is provided, that will continue to be displayed, otherwise no accessory will be displayed when the cell is selected.
     */
    disableSelectionAccessory?: boolean;
    /**
     * @default false
     * When there is no description the title will take up two lines by default.
     * When this is set to true multiline title behavior is overwritten, and regardless of description text state
     * the title will take up a single line truncating with ellipses.
     */
    disableMultilineTitle?: boolean;
    /** Assistive message to display below the cell content. */
    helperText?: React.ReactNode;
    /** For internal use only. */
    intermediary?: React.ReactNode;
    media?: React.ReactElement;
    /** Allow the description to span multiple lines. This *will* break fixed height requirements, so should not be used in a `FlatList`. */
    multiline?: boolean;
    /** Title of content. Max 1 line (with description) or 2 lines (without), otherwise will truncate. This prop is only intended to accept a string or Text component; other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `titleNode`. */
    title?: React.ReactNode;
    /**
     * React node to render title. Takes precedence over `title`.
     * When provided, `styles.title` is not applied.
     */
    titleNode?: React.ReactNode;
    /** Subtitle to display below the title and above the description. This prop is only intended to accept a string or Text component; other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `subtitleNode`. */
    subtitle?: React.ReactNode;
    /**
     * React node to render subtitle. Takes precedence over `subtitle`.
     * When provided, `styles.subtitle` is not applied.
     */
    subtitleNode?: React.ReactNode;
    /** Styles for subcomponents, ignored when the corresponding `xxNode` prop is used */
    styles?: {
      /** Root element */
      root?: StyleProp<ViewStyle>;
      /** Media element */
      media?: StyleProp<ViewStyle>;
      /** Intermediary element */
      intermediary?: StyleProp<ViewStyle>;
      /** End element */
      end?: StyleProp<ViewStyle>;
      /** Accessory element */
      accessory?: StyleProp<ViewStyle>;
      /** Content container element */
      contentContainer?: StyleProp<ViewStyle>;
      /** Pressable wrapper element */
      pressable?: StyleProp<ViewStyle>;
      /** Main content element */
      mainContent?: StyleProp<ViewStyle>;
      /** Title stack element (title/subtitle/description VStack) */
      titleStack?: StyleProp<ViewStyle>;
      /** Title stack container wrapper, controls flex behavior */
      titleStackContainer?: StyleProp<ViewStyle>;
      /** Helper text element */
      helperText?: StyleProp<ViewStyle>;
      /** Title text element */
      title?: StyleProp<TextStyle>;
      /** Subtitle text element */
      subtitle?: StyleProp<TextStyle>;
      /** Description text element */
      description?: StyleProp<TextStyle>;
    };
  };
export type ListCellProps = ListCellBaseProps & Omit<CellProps, 'accessory' | 'children'>;
export declare const ListCell: React.NamedExoticComponent<ListCellProps>;
//# sourceMappingURL=ListCell.d.ts.map
