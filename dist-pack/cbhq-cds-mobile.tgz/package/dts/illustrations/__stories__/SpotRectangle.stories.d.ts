declare const SpotRectangleStory: () => import('react/jsx-runtime').JSX.Element;
export default SpotRectangleStory;
//# sourceMappingURL=SpotRectangle.stories.d.ts.map
