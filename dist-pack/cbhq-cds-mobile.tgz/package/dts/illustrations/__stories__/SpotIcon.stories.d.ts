declare const SpotIconStory: () => import('react/jsx-runtime').JSX.Element;
export default SpotIconStory;
//# sourceMappingURL=SpotIcon.stories.d.ts.map
