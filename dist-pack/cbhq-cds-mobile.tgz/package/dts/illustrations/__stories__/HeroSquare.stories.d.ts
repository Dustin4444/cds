declare const HeroSquareStory: () => import('react/jsx-runtime').JSX.Element;
export default HeroSquareStory;
//# sourceMappingURL=HeroSquare.stories.d.ts.map
