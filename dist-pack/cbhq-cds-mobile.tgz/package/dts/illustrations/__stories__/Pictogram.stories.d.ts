declare const PictogramStory: () => import('react/jsx-runtime').JSX.Element;
export default PictogramStory;
//# sourceMappingURL=Pictogram.stories.d.ts.map
