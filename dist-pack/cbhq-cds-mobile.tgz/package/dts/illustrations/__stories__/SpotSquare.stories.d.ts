declare const SpotSquareStory: () => import('react/jsx-runtime').JSX.Element;
export default SpotSquareStory;
//# sourceMappingURL=SpotSquare.stories.d.ts.map
