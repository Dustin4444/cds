import {
  type IllustrationA11yProps,
  type IllustrationBaseProps,
  type IllustrationDimensionsMap,
} from './createIllustration';
export declare const SpotIcon: import('react').NamedExoticComponent<
  import('./createIllustration').IllustrationBasePropsWithA11y<'spotIcon'>
>;
export type SpotIconBaseProps = IllustrationBaseProps<'spotIcon'> &
  IllustrationA11yProps & {
    /**
     * @default 32x32
     * */
    dimension?: IllustrationDimensionsMap['spotSquare'];
  };
export type SpotIconProps = SpotIconBaseProps;
export type { SpotIconName } from '@cbhq/cds-illustrations';
//# sourceMappingURL=SpotIcon.d.ts.map
