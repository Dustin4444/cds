export {};
//# sourceMappingURL=SpotRectangle.test.d.ts.map
