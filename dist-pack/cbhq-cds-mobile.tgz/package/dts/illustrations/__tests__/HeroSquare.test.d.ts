export {};
//# sourceMappingURL=HeroSquare.test.d.ts.map
