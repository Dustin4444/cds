export {};
//# sourceMappingURL=SpotSquare.test.d.ts.map
