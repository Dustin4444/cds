export {};
//# sourceMappingURL=Pictogram.test.d.ts.map
