import {
  type IllustrationA11yProps,
  type IllustrationBaseProps,
  type IllustrationDimensionsMap,
} from './createIllustration';
export type PictogramBaseProps = IllustrationBaseProps<'pictogram'> &
  IllustrationA11yProps & {
    /**
     * @default 48x48
     * */
    dimension?: IllustrationDimensionsMap['pictogram'];
  };
export type PictogramProps = PictogramBaseProps;
export declare const Pictogram: import('react').NamedExoticComponent<
  import('./createIllustration').IllustrationBasePropsWithA11y<'pictogram'>
>;
export type { PictogramName } from '@cbhq/cds-illustrations';
//# sourceMappingURL=Pictogram.d.ts.map
