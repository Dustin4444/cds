import {
  type IllustrationA11yProps,
  type IllustrationBaseProps,
  type IllustrationDimensionsMap,
} from './createIllustration';
export type SpotRectangleBaseProps = IllustrationBaseProps<'spotRectangle'> &
  IllustrationA11yProps & {
    /**
     * SpotRectangle dimensions
     * @default 240x120
     * */
    dimension?: IllustrationDimensionsMap['spotRectangle'];
  };
export type SpotRectangleProps = SpotRectangleBaseProps;
export declare const SpotRectangle: import('react').NamedExoticComponent<
  import('./createIllustration').IllustrationBasePropsWithA11y<'spotRectangle'>
>;
export type { SpotRectangleName } from '@cbhq/cds-illustrations';
//# sourceMappingURL=SpotRectangle.d.ts.map
