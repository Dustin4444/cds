export {};
//# sourceMappingURL=SpotIcon.figma.d.ts.map
