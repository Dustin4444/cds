export {};
//# sourceMappingURL=Pictogram.figma.d.ts.map
