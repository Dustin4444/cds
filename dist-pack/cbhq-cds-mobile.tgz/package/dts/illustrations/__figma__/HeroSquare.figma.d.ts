export {};
//# sourceMappingURL=HeroSquare.figma.d.ts.map
