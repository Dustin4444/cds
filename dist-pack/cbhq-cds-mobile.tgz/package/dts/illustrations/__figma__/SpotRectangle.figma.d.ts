export {};
//# sourceMappingURL=SpotRectangle.figma.d.ts.map
