export {};
//# sourceMappingURL=SpotSquare.figma.d.ts.map
