import {
  type IllustrationA11yProps,
  type IllustrationBaseProps,
  type IllustrationDimensionsMap,
} from './createIllustration';
export declare const SpotSquare: import('react').NamedExoticComponent<
  import('./createIllustration').IllustrationBasePropsWithA11y<'spotSquare'>
>;
export type SpotSquareBaseProps = IllustrationBaseProps<'spotSquare'> &
  IllustrationA11yProps & {
    /**
     * @default 96x96
     * */
    dimension?: IllustrationDimensionsMap['spotSquare'];
  };
export type SpotSquareProps = SpotSquareBaseProps;
export type { SpotSquareName } from '@cbhq/cds-illustrations';
//# sourceMappingURL=SpotSquare.d.ts.map
