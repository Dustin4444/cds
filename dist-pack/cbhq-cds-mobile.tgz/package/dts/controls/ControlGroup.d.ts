import React from 'react';
import type { View } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common';
import { type BoxBaseProps, type GroupBaseProps, type GroupProps } from '../layout';
export type ControlGroupOption<ControlComponentProps> = Omit<
  ControlComponentProps,
  'onChange' | 'checked' | 'value'
>;
export type ControlGroupBaseProps<
  ControlValue extends string = string,
  ControlComponentProps extends {
    value?: ControlValue;
  } = {
    value?: ControlValue;
  },
> = Omit<GroupBaseProps<BoxBaseProps>, 'children' | 'onChange'> &
  SharedProps & {
    /** The control component to render for each option. */
    ControlComponent: React.ComponentType<ControlComponentProps>;
    /** Control options for the group. */
    options: (ControlGroupOption<ControlComponentProps> & {
      value: ControlValue;
    })[];
    /** Set a label for the group. */
    label?: React.ReactNode;
    /** Current selected value(s). Use a string for single-select (e.g., RadioGroup) and an array of strings for multi-select (e.g., CheckboxGroup). */
    value: ControlValue | ControlValue[];
    /** Handle change events. */
    onChange?: (value: ControlValue | undefined, checked?: boolean) => void;
  };
export type ControlGroupProps<
  ControlValue extends string,
  ControlComponentProps extends {
    value?: ControlValue;
  },
> = ControlGroupBaseProps<ControlValue, ControlComponentProps> &
  Omit<GroupProps, 'children' | 'onChange'>;
declare const ControlGroupWithRef: <
  ControlValue extends string,
  ControlComponentProps extends {
    value?: ControlValue;
  },
>(
  props: ControlGroupProps<ControlValue, ControlComponentProps> & {
    ref?: React.Ref<View>;
  },
) => React.ReactElement;
export declare const ControlGroup: typeof ControlGroupWithRef &
  React.MemoExoticComponent<typeof ControlGroupWithRef>;
export {};
//# sourceMappingURL=ControlGroup.d.ts.map
