import React from 'react';
import type { View } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common';
import { type ControlBaseProps } from './Control';
export type CheckboxBaseProps<CheckboxValue extends string> = Omit<
  ControlBaseProps<CheckboxValue>,
  'controlColor' | 'controlSize' | 'dotSize'
> & {
  /**
   * Sets the checked/active color of the checkbox.
   * @default fgInverse
   */
  controlColor?: ThemeVars.Color;
  /**
   * Sets the border width of the checkbox.
   * @default 100
   */
  borderWidth?: ThemeVars.BorderWidth;
  /**
   * Sets the outer checkbox control size in pixels.
   * @default theme.controlSize.checkboxSize
   */
  controlSize?: number;
};
export type CheckboxProps<CheckboxValue extends string> = CheckboxBaseProps<CheckboxValue>;
declare const CheckboxWithRef: <CheckboxValue extends string>(
  props: CheckboxProps<CheckboxValue> & {
    ref?: React.Ref<View>;
  },
) => React.ReactElement;
export declare const Checkbox: typeof CheckboxWithRef &
  React.MemoExoticComponent<typeof CheckboxWithRef>;
export {};
//# sourceMappingURL=Checkbox.d.ts.map
