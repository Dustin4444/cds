import React from 'react';
import { type StyleProp, type TextStyle, type View, type ViewStyle } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import { type PressableProps } from '../system/Pressable';
import type { ControlBaseProps } from './Control';
export type RadioCellBaseProps<RadioValue extends string> = {
  title: React.ReactNode;
  description?: React.ReactNode;
  columnGap?: ThemeVars.Space;
  rowGap?: ThemeVars.Space;
  pressedBorderColor?: ThemeVars.Color;
  pressedBorderWidth?: ThemeVars.BorderWidth;
} & Omit<ControlBaseProps<RadioValue>, 'style' | 'children' | 'title' | 'controlSize' | 'dotSize'> &
  Omit<PressableProps, 'children' | 'noScaleOnPress'>;
export type RadioCellProps<RadioValue extends string> = RadioCellBaseProps<RadioValue> & {
  styles?: {
    /** Root element */
    root?: StyleProp<ViewStyle>;
    /** Radio input container element */
    radioContainer?: StyleProp<ViewStyle>;
    /** Content container element */
    contentContainer?: StyleProp<ViewStyle>;
    /** Title text element */
    title?: StyleProp<TextStyle>;
    /** Description text element */
    description?: StyleProp<TextStyle>;
  };
};
declare const RadioCellWithRef: <RadioValue extends string>(
  props: RadioCellProps<RadioValue> & {
    ref?: React.ForwardedRef<View>;
  },
) => React.ReactElement;
export declare const RadioCell: typeof RadioCellWithRef &
  React.MemoExoticComponent<typeof RadioCellWithRef>;
export {};
//# sourceMappingURL=RadioCell.d.ts.map
