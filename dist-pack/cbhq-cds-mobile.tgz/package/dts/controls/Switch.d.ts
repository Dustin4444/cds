import React from 'react';
import { type StyleProp, type View, type ViewStyle } from 'react-native';
import { type ControlBaseProps } from './Control';
export type SwitchBaseProps<SwitchValue extends string> = Omit<ControlBaseProps<SwitchValue>, 'controlSize' | 'dotSize'>;
export type SwitchProps<SwitchValue extends string> = SwitchBaseProps<SwitchValue> & {
    /**
     * Label content rendered next to the switch control.
     *
     * @example
     * ```tsx
     * <Switch onChange={handleChange}>Dark mode</Switch>
     * ```
     */
    children?: React.ReactNode;
    /** Slot-level styles for Switch. */
    styles?: {
        /** Persistent outer wrapper across all variants. */
        root?: StyleProp<ViewStyle>;
        /**
         * Control wrapper style.
         * Applied to the underlying `Control` element (same element that receives `style`).
         */
        control?: StyleProp<ViewStyle>;
    };
};
export declare const Switch: React.NamedExoticComponent<SwitchBaseProps<string> & {
    /**
     * Label content rendered next to the switch control.
     *
     * @example
     * ```tsx
     * <Switch onChange={handleChange}>Dark mode</Switch>
     * ```
     */
    children?: React.ReactNode;
    /** Slot-level styles for Switch. */
    styles?: {
        /** Persistent outer wrapper across all variants. */
        root?: StyleProp<ViewStyle>;
        /**
         * Control wrapper style.
         * Applied to the underlying `Control` element (same element that receives `style`).
         */
        control?: StyleProp<ViewStyle>;
    };
} & React.RefAttributes<View>>;
//# sourceMappingURL=Switch.d.ts.map