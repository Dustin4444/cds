import React from 'react';
import type { SharedAccessibilityProps } from '@cbhq/cds-common';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
import type { IconProps } from '../icons/Icon';
export type InputIconProps = {
  /**
   * If set to true, when parent input is focused, the icon will match the color of the focus state
   * @default false
   * */
  disableInheritFocusStyle?: boolean;
  compact?: boolean;
} & Omit<IconProps, 'size'> &
  SharedProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityHint'>;
export declare const InputIcon: React.NamedExoticComponent<InputIconProps>;
//# sourceMappingURL=InputIcon.d.ts.map
