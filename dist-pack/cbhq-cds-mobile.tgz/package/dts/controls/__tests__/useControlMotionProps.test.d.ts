export {};
//# sourceMappingURL=useControlMotionProps.test.d.ts.map
