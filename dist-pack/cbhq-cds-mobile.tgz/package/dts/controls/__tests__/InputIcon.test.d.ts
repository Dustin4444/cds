export {};
//# sourceMappingURL=InputIcon.test.d.ts.map
