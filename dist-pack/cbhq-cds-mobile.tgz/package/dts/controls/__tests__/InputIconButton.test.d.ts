export {};
//# sourceMappingURL=InputIconButton.test.d.ts.map
