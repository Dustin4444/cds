export {};
//# sourceMappingURL=InputStack.test.d.ts.map
