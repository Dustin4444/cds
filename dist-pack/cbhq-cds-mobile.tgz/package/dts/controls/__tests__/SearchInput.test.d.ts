export {};
//# sourceMappingURL=SearchInput.test.d.ts.map
