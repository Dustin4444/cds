import React from 'react';
import type { HelperTextProps } from './HelperText';
export declare const InputLabel: React.NamedExoticComponent<HelperTextProps>;
//# sourceMappingURL=InputLabel.d.ts.map
