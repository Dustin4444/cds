export {};
//# sourceMappingURL=CheckboxGroup.figma.d.ts.map
