export {};
//# sourceMappingURL=SelectOption.figma.d.ts.map
