export {};
//# sourceMappingURL=CheckboxCell.figma.d.ts.map
