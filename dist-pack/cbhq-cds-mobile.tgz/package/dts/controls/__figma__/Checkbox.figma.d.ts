export {};
//# sourceMappingURL=Checkbox.figma.d.ts.map
