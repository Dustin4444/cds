export {};
//# sourceMappingURL=RadioGroup.figma.d.ts.map
