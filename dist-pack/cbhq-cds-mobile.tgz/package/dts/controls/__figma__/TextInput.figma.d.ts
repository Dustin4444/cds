export {};
//# sourceMappingURL=TextInput.figma.d.ts.map
