export {};
//# sourceMappingURL=Switch.figma.d.ts.map
