export {};
//# sourceMappingURL=SearchInput.figma.d.ts.map
