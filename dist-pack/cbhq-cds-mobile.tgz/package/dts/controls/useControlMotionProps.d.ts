import { Animated } from 'react-native';
export type UseControlMotionParams = {
  checked?: boolean;
  disabled?: boolean;
  shouldUseSwitchTransition?: boolean;
};
/**
 * Checkbox and RadioGroup shares the same motion tokens while Switch uses different timing token.
 * Check the motion specs below:
 * @link Checkbox: https://coda.io/d/Motion-Foundations_d5KlLHcBPlL/CDS-Check-Box_suHNC#_lu30T
 * @link RadioGroup: https://coda.io/d/Motion-Foundations_d5KlLHcBPlL/CDS-Radio-Group_susTj#_lu0fa
 * @link Switch: https://coda.io/d/Motion-Foundations_d5KlLHcBPlL/CDS-Switch_su7H7#_luhBA
 */
export declare const useControlMotionProps: ({
  checked,
  disabled,
  shouldUseSwitchTransition,
}: UseControlMotionParams) => {
  animation: Animated.CompositeAnimation;
  animatedBoxValue: Animated.Value;
  animatedScaleValue: Animated.Value;
  animatedOpacityValue: Animated.Value;
};
//# sourceMappingURL=useControlMotionProps.d.ts.map
