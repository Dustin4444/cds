import React from 'react';
import { TouchableWithoutFeedback } from 'react-native';
import type { SharedAccessibilityProps, SharedInputProps, SharedProps } from '@cbhq/cds-common/types';
import { type InputStackBaseProps } from './InputStack';
export type SelectBaseProps = SharedProps & Omit<SharedInputProps, 'label'> & Pick<InputStackBaseProps, 'width' | 'disabled' | 'variant' | 'focused' | 'startNode' | 'labelVariant'> & Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'> & {
    children?: React.ReactNode;
    /** Pass a value that will prepopulate the select input. This will replace the placeholder text. */
    value?: string;
    /** Optional label for selected value when using a value/label object model */
    valueLabel?: string;
    /** Event handler for when the Select Input trigger is pressed */
    onPress?: () => void;
    /** Optional string placed above the input (or within if compact is enabled) to indicate purpose of the input */
    label?: string;
    /** Callback that is fired whenever a select option is selected */
    onChange?: ((newValue: string) => void) | React.Dispatch<React.SetStateAction<string>>;
};
export type SelectProps = SelectBaseProps;
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const Select: React.NamedExoticComponent<SharedProps & Omit<SharedInputProps, "label"> & Pick<InputStackBaseProps, "width" | "disabled" | "variant" | "startNode" | "focused" | "labelVariant"> & Pick<SharedAccessibilityProps, "accessibilityLabel" | "accessibilityHint" | "accessibilityLabelledBy"> & {
    children?: React.ReactNode;
    /** Pass a value that will prepopulate the select input. This will replace the placeholder text. */
    value?: string;
    /** Optional label for selected value when using a value/label object model */
    valueLabel?: string;
    /** Event handler for when the Select Input trigger is pressed */
    onPress?: () => void;
    /** Optional string placed above the input (or within if compact is enabled) to indicate purpose of the input */
    label?: string;
    /** Callback that is fired whenever a select option is selected */
    onChange?: ((newValue: string) => void) | React.Dispatch<React.SetStateAction<string>>;
} & React.RefAttributes<TouchableWithoutFeedback>>;
//# sourceMappingURL=Select.d.ts.map