import React from 'react';
import type { AccessibilityProps, View } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common';
import { type BoxBaseProps } from '../layout';
import type { GroupBaseProps } from '../layout/Group';
import { Radio, type RadioBaseProps, type RadioProps } from './Radio';
export { Radio, type RadioBaseProps, type RadioProps };
/**
 * @deprecated RadioGroup is deprecated. Use ControlGroup with accessibilityRole="radiogroup" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 *
 * @example
 * // Instead of:
 * <RadioGroup options={{ value1: 'Label 1' }} value={value} onChange={onChange} />
 *
 * // Use:
 * <ControlGroup
 *   accessibilityRole="radiogroup"
 *   ControlComponent={Radio}
 *   options={[{ value: 'value1', children: 'Label 1' }]}
 *   value={value}
 *   onChange={(value) => onChange(value)}
 * />
 */
export type RadioGroupBaseProps<RadioValue extends string> = Omit<
  AccessibilityProps,
  'accessibilityLabelledBy'
> &
  SharedProps &
  Pick<GroupBaseProps<BoxBaseProps>, 'direction' | 'gap'> & {
    /**
     * Multiple choice options for the radio group. The object key represents
     * the radio input value and the object value represents the radio option label.
     */
    options: Record<RadioValue, string | React.ReactNode>;
    /** Set a label summary for the group of radios. */
    label?: React.ReactNode;
    /** Currently selected value. */
    value?: RadioValue;
    /** Handle change event when pressing on a radio option. */
    onChange?: RadioProps<RadioValue>['onChange'];
    /** Sets the checked/active color of each control in the group.
     * @default bgPrimary
     */
    controlColor?: RadioProps<RadioValue>['controlColor'];
    /** A11Y label to indicate order of radio buttons when focused on one button */
    radioAccessibilityLabel?: string;
  };
/**
 * @deprecated RadioGroup is deprecated. Use ControlGroup with accessibilityRole="radiogroup" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export type RadioGroupProps<RadioValue extends string> = RadioGroupBaseProps<RadioValue>;
declare const RadioGroupWithRef: <RadioValue extends string>(
  props: RadioGroupProps<RadioValue> & {
    ref?: React.Ref<View>;
  },
) => React.ReactElement;
/**
 * @deprecated RadioGroup is deprecated. Use ControlGroup with accessibilityRole="radiogroup" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export declare const RadioGroup: typeof RadioGroupWithRef &
  React.MemoExoticComponent<typeof RadioGroupWithRef>;
//# sourceMappingURL=RadioGroup.d.ts.map
