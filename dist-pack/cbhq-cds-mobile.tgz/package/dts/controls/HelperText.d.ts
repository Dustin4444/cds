import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { TextProps } from '../typography/Text';
export type HelperTextProps = {
    /**
     * Determines the color of the text
     * @default fgMuted
     */
    color?: ThemeVars.Color;
    /** Accessibility label for the error icon */
    errorIconAccessibilityLabel?: string;
    /** Test ID for the error icon */
    errorIconTestID?: string;
    /** Custom styles for individual elements of the HelperText component */
    styles?: {
        /** Root text element */
        root?: TextProps['style'];
        /** Error icon element */
        icon?: TextProps['style'];
    };
} & TextProps;
export declare const HelperText: React.NamedExoticComponent<HelperTextProps>;
//# sourceMappingURL=HelperText.d.ts.map