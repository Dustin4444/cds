import React from 'react';
import { TextInput } from 'react-native';
import type { TextInputProps, ViewStyle } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types/SharedAccessibilityProps';
import type { TextBaseProps } from '../typography/Text';
import type { TextInputBaseProps } from './TextInput';
export type NativeInputProps = {
    /**
     * Text Align Input
     * @default start
     * */
    align?: TextBaseProps['align'];
    /** Custom container spacing if needed. This will add to the existing spacing */
    containerSpacing?: ViewStyle | undefined;
    /**
     * Disables input
     * @default false
     * */
    disabled?: boolean;
    /**
     * Native TextInput textAlign with the extra unset option to remove the textAlign style.
     * Use this to workaround the issue where long text does not ellipsis in TextInput
     * @warning Setting this to unset will break alignment for RTL languages.
     */
    textAlign?: TextInputProps['textAlign'] | 'unset';
    /**
     * Typography font token used for typed input text.
     * @default body
     */
    font?: ThemeVars.Font;
} & SharedProps & Pick<TextInputBaseProps, 'compact'> & Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'> & Omit<TextInputProps, 'textAlign'>;
export declare const NativeInput: React.NamedExoticComponent<{
    /**
     * Text Align Input
     * @default start
     * */
    align?: TextBaseProps["align"];
    /** Custom container spacing if needed. This will add to the existing spacing */
    containerSpacing?: ViewStyle | undefined;
    /**
     * Disables input
     * @default false
     * */
    disabled?: boolean;
    /**
     * Native TextInput textAlign with the extra unset option to remove the textAlign style.
     * Use this to workaround the issue where long text does not ellipsis in TextInput
     * @warning Setting this to unset will break alignment for RTL languages.
     */
    textAlign?: TextInputProps["textAlign"] | "unset";
    /**
     * Typography font token used for typed input text.
     * @default body
     */
    font?: ThemeVars.Font;
} & SharedProps & Pick<TextInputBaseProps, "compact"> & Pick<SharedAccessibilityProps, "accessibilityLabel" | "accessibilityHint" | "accessibilityLabelledBy"> & Omit<TextInputProps, "textAlign"> & React.RefAttributes<TextInput>>;
//# sourceMappingURL=NativeInput.d.ts.map