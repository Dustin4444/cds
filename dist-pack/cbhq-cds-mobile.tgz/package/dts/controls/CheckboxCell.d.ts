import React from 'react';
import { type StyleProp, type TextStyle, type View, type ViewStyle } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import { type PressableBaseProps } from '../system/Pressable';
import type { ControlBaseProps } from './Control';
export type CheckboxCellBaseProps<CheckboxValue extends string> = {
  title: React.ReactNode;
  description?: React.ReactNode;
  columnGap?: ThemeVars.Space;
  rowGap?: ThemeVars.Space;
  pressedBorderColor?: ThemeVars.Color;
  pressedBorderWidth?: ThemeVars.BorderWidth;
} & Omit<ControlBaseProps<CheckboxValue>, 'style' | 'children' | 'title' | 'dotSize'> &
  Omit<PressableBaseProps, 'children' | 'noScaleOnPress'>;
export type CheckboxCellProps<CheckboxValue extends string> =
  CheckboxCellBaseProps<CheckboxValue> & {
    styles?: {
      /** Root element */
      root?: StyleProp<ViewStyle>;
      /** Checkbox input container element */
      checkboxContainer?: StyleProp<ViewStyle>;
      /** Content container element */
      contentContainer?: StyleProp<ViewStyle>;
      /** Title text element */
      title?: StyleProp<TextStyle>;
      /** Description text element */
      description?: StyleProp<TextStyle>;
    };
  };
declare const CheckboxCellWithRef: <CheckboxValue extends string>(
  props: CheckboxCellProps<CheckboxValue> & {
    ref?: React.ForwardedRef<View>;
  },
) => React.ReactElement;
export declare const CheckboxCell: typeof CheckboxCellWithRef &
  React.MemoExoticComponent<typeof CheckboxCellWithRef>;
export {};
//# sourceMappingURL=CheckboxCell.d.ts.map
