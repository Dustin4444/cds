import React from 'react';
import type { View, ViewProps } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common';
/**
 * @deprecated CheckboxGroup is deprecated. Use ControlGroup with accessibilityRole="combobox" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 *
 * @example
 * // Instead of:
 * <CheckboxGroup selectedValues={new Set(['value1'])} onChange={onChange}>
 *   <Checkbox value="value1">Option 1</Checkbox>
 * </CheckboxGroup>
 *
 * // Use:
 * <ControlGroup
 *   accessibilityRole="combobox"
 *   ControlComponent={Checkbox}
 *   options={[{ value: 'value1', children: 'Option 1' }]}
 *   value={['value1']}
 *   onChange={(value) => onChange(value)}
 * />
 */
export type CheckboxGroupBaseProps<CheckboxValue extends string | number> = Omit<
  ViewProps,
  'children'
> &
  SharedProps & {
    /** Checkbox elements that are part of the checkbox group. */
    children: React.ReactElement[];
    /** Set a label summary for the group of checkboxes. */
    label?: React.ReactNode;
    /** Checkbox options that are checked. */
    selectedValues: Set<CheckboxValue>;
    /** Handle change events when user tap on the checkboxes */
    onChange?: (value?: CheckboxValue) => void;
  };
/**
 * @deprecated CheckboxGroup is deprecated. Use ControlGroup with accessibilityRole="combobox" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export type CheckboxGroupProps<CheckboxValue extends string> =
  CheckboxGroupBaseProps<CheckboxValue>;
declare const CheckboxGroupWithRef: <CheckboxValue extends string>(
  props: CheckboxGroupProps<CheckboxValue> & {
    ref?: React.Ref<View>;
  },
) => React.ReactElement;
/**
 * @deprecated CheckboxGroup is deprecated. Use ControlGroup with accessibilityRole="combobox" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export declare const CheckboxGroup: typeof CheckboxGroupWithRef &
  React.MemoExoticComponent<typeof CheckboxGroupWithRef>;
export {};
//# sourceMappingURL=CheckboxGroup.d.ts.map
