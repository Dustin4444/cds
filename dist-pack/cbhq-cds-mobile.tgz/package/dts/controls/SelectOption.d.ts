import type { GestureResponderEvent } from 'react-native';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types';
import { type CellBaseProps } from '../cells/Cell';
import type { ListCellBaseProps } from '../cells/ListCell';
export type SelectOptionBaseProps = Omit<CellBaseProps, 'children' | 'selected'> & Pick<ListCellBaseProps, 'title' | 'description' | 'multiline'> & Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityHint'> & {
    onPress?: (() => void) | ((event: GestureResponderEvent) => void);
    /** Unique identifier for each option */
    value: string;
};
export type SelectOptionProps = SelectOptionBaseProps;
/**
 * @deprecated Please use the new Select alpha component instead. If you are using this component outside of Select, we recommend replacing it with ListCell. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const SelectOption: import("react").MemoExoticComponent<(_props: SelectOptionProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SelectOption.d.ts.map