import React from 'react';
import type { GestureResponderEvent, TextInput as RNTextInput } from 'react-native';
import type { IconName } from '@cbhq/cds-common/types';
import { type TextInputBaseProps, type TextInputProps } from './TextInput';
export type SearchInputBaseProps = Pick<TextInputBaseProps, 'accessibilityHint' | 'accessibilityLabel' | 'accessibilityLabelledBy' | 'bordered' | 'borderRadius' | 'compact' | 'disabled' | 'enableColorSurge' | 'focusedBorderWidth' | 'helperTextErrorIconAccessibilityLabel' | 'font' | 'placeholder' | 'testID' | 'testIDMap' | 'width'> & {
    /**
     * Callback is fired when a user hits enter on the keyboard. Can obtain the query
     * through str parameter
     */
    onSearch?: (str: string) => void;
    /**
     * hide the start icon
     * @default false
     */
    hideStartIcon?: boolean;
    /**
     * Set the start icon. You can only
     * set it to search | backArrow icon. If
     * you set this, the icon would not toggle
     * between search and backArrow depending on
     * the focus state
     * @default search
     */
    startIcon?: Extract<IconName, 'search' | 'backArrow'>;
    /**
     * hide the end icon
     * @default undefined
     */
    hideEndIcon?: boolean;
    /**
     * Set the end node
     * @default undefined
     */
    end?: React.ReactNode;
    /**
     * Set the a11y label for the clear icon
     */
    clearIconAccessibilityLabel?: string | undefined;
    /**
     * Set the a11y label for the start icon
     */
    startIconAccessibilityLabel?: string | undefined;
};
export type SearchInputProps = SearchInputBaseProps & TextInputProps & {
    /** Callback is fired when the clear icon is pressed */
    onClear?: (event: GestureResponderEvent) => void;
    /**
     * Callback is fired when backArrow is pressed.
     * If disableBackArrow is true, this will do nothing
     */
    onBack?: (event: GestureResponderEvent) => void;
    /**
     * If this is set to true, the start icon won't toggle between backArrow and Search.
     * The start icon will always be a search icon
     */
    disableBackArrow?: boolean;
};
export declare const SearchInput: React.NamedExoticComponent<Pick<TextInputBaseProps, "borderRadius" | "width" | "testID" | "accessibilityLabel" | "accessibilityHint" | "accessibilityLabelledBy" | "font" | "bordered" | "disabled" | "compact" | "enableColorSurge" | "focusedBorderWidth" | "placeholder" | "testIDMap" | "helperTextErrorIconAccessibilityLabel"> & {
    /**
     * Callback is fired when a user hits enter on the keyboard. Can obtain the query
     * through str parameter
     */
    onSearch?: (str: string) => void;
    /**
     * hide the start icon
     * @default false
     */
    hideStartIcon?: boolean;
    /**
     * Set the start icon. You can only
     * set it to search | backArrow icon. If
     * you set this, the icon would not toggle
     * between search and backArrow depending on
     * the focus state
     * @default search
     */
    startIcon?: Extract<IconName, "search" | "backArrow">;
    /**
     * hide the end icon
     * @default undefined
     */
    hideEndIcon?: boolean;
    /**
     * Set the end node
     * @default undefined
     */
    end?: React.ReactNode;
    /**
     * Set the a11y label for the clear icon
     */
    clearIconAccessibilityLabel?: string | undefined;
    /**
     * Set the a11y label for the start icon
     */
    startIconAccessibilityLabel?: string | undefined;
} & import("@cbhq/cds-common").SharedProps & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityHint" | "accessibilityLabelledBy"> & import("@cbhq/cds-common").SharedInputProps & Pick<import("./InputStack").InputStackBaseProps, "borderRadius" | "width" | "height" | "disabled" | "variant" | "enableColorSurge" | "labelVariant" | "inputBackground" | "focusedBorderWidth"> & {
    align?: import("@cbhq/cds-common").TextAlignProps["align"];
    font?: import("@cbhq/cds-common").ThemeVars.Font;
    suffix?: string;
    start?: React.ReactNode;
    end?: React.ReactNode;
    testIDMap?: {
        start?: string;
        end?: string;
        label?: string;
        helperText?: string;
    };
    helperTextErrorIconAccessibilityLabel?: string;
    labelNode?: React.ReactNode;
    bordered?: boolean;
} & Omit<import("react-native").TextInputProps, "value" | "textAlign" | "onChange" | "onChangeText"> & {
    value?: import("react-native").TextInputProps["value"];
    onChange?: import("react-native").TextInputProps["onChange"];
    onChangeText?: import("react-native").TextInputProps["onChangeText"];
    minHeight?: import("react-native").DimensionValue;
    textAlign?: import("react-native").TextInputProps["textAlign"] | "unset";
} & {
    /** Callback is fired when the clear icon is pressed */
    onClear?: (event: GestureResponderEvent) => void;
    /**
     * Callback is fired when backArrow is pressed.
     * If disableBackArrow is true, this will do nothing
     */
    onBack?: (event: GestureResponderEvent) => void;
    /**
     * If this is set to true, the start icon won't toggle between backArrow and Search.
     * The start icon will always be a search icon
     */
    disableBackArrow?: boolean;
} & React.RefAttributes<RNTextInput>>;
//# sourceMappingURL=SearchInput.d.ts.map