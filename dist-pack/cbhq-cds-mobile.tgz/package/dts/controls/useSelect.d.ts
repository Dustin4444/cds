import type { SelectBaseProps } from './Select';
export declare const useSelect: ({
  value,
  onChange,
  handleClose,
}: {
  handleClose?: () => void;
} & Pick<SelectBaseProps, 'value' | 'onChange'>) => {
  value: string | undefined;
  onChange:
    | import('react').Dispatch<import('react').SetStateAction<string>>
    | ((newValue: string) => void)
    | undefined;
  handleClose: (() => void) | undefined;
};
export type SelectContextType = ReturnType<typeof useSelect>;
//# sourceMappingURL=useSelect.d.ts.map
