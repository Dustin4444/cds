import React from 'react';
import type { View } from 'react-native';
import type { IconButtonVariant, InputVariant } from '@cbhq/cds-common/types';
import { type IconButtonProps } from '../buttons/IconButton';
export declare const variantTransformMap: Record<InputVariant, IconButtonVariant>;
export type InputIconButtonProps = IconButtonProps & {
    /**
     * If set to true, when parent input is focused, the icon will match the color of the focus state
     * @default false
     * */
    disableInheritFocusStyle?: boolean;
};
export declare const InputIconButton: React.NamedExoticComponent<import("@cbhq/cds-common").SharedProps & Omit<import("../system").PressableBaseProps, "children"> & Pick<import("../buttons").ButtonBaseProps, "transparent" | "disabled" | "loading" | "progressCircleSize" | "compact" | "flush"> & {
    name: import("@cbhq/cds-common").IconName;
    iconSize?: import("@cbhq/cds-common").IconSize;
    active?: boolean;
    variant?: IconButtonVariant;
} & {
    /**
     * If set to true, when parent input is focused, the icon will match the color of the focus state
     * @default false
     * */
    disableInheritFocusStyle?: boolean;
} & React.RefAttributes<View>>;
//# sourceMappingURL=InputIconButton.d.ts.map