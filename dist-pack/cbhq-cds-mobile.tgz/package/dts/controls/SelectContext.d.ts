import React from 'react';
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const SelectContext: React.Context<{
    value: string | undefined;
    onChange: React.Dispatch<React.SetStateAction<string>> | ((newValue: string) => void) | undefined;
    handleClose: (() => void) | undefined;
}>;
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const SelectProvider: React.Provider<{
    value: string | undefined;
    onChange: React.Dispatch<React.SetStateAction<string>> | ((newValue: string) => void) | undefined;
    handleClose: (() => void) | undefined;
}>;
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const useSelectContext: () => {
    value: string | undefined;
    onChange: React.Dispatch<React.SetStateAction<string>> | ((newValue: string) => void) | undefined;
    handleClose: (() => void) | undefined;
};
//# sourceMappingURL=SelectContext.d.ts.map