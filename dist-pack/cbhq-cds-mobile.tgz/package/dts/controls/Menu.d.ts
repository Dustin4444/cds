import React from 'react';
import type { SelectBaseProps } from './Select';
export declare const Menu: ({
  onChange,
  value,
  children,
}: React.PropsWithChildren<
  Pick<SelectBaseProps, 'onChange' | 'value'>
>) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Menu.d.ts.map
