declare const CheckboxScreen: () => import('react/jsx-runtime').JSX.Element;
export default CheckboxScreen;
//# sourceMappingURL=Checkbox.stories.d.ts.map
