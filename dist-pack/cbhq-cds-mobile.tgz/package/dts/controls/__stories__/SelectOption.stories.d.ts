export default function SelectOptionScreen(): import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=SelectOption.stories.d.ts.map
