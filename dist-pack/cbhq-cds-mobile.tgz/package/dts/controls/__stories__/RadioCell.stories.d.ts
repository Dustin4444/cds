declare const RadioCellScreen: () => import('react/jsx-runtime').JSX.Element;
export default RadioCellScreen;
//# sourceMappingURL=RadioCell.stories.d.ts.map
