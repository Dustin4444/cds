declare const CheckboxCellScreen: () => import('react/jsx-runtime').JSX.Element;
export default CheckboxCellScreen;
//# sourceMappingURL=CheckboxCell.stories.d.ts.map
