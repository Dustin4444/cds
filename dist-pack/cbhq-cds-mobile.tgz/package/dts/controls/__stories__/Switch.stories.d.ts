declare const SwitchScreen: () => import('react/jsx-runtime').JSX.Element;
export default SwitchScreen;
//# sourceMappingURL=Switch.stories.d.ts.map
