declare const SearchInputScreen: () => import('react/jsx-runtime').JSX.Element;
export default SearchInputScreen;
//# sourceMappingURL=SearchInput.stories.d.ts.map
