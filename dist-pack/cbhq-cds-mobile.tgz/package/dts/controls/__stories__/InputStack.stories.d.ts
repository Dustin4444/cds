export default function InputStackScreen(): import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=InputStack.stories.d.ts.map
