declare const InputScreen: () => import('react/jsx-runtime').JSX.Element;
export default InputScreen;
//# sourceMappingURL=TextInput.stories.d.ts.map
