declare const InputIconScreen: () => import('react/jsx-runtime').JSX.Element;
export default InputIconScreen;
//# sourceMappingURL=InputIcon.stories.d.ts.map
