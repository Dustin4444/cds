declare const ControlGroupScreen: () => import('react/jsx-runtime').JSX.Element;
export default ControlGroupScreen;
//# sourceMappingURL=ControlGroup.stories.d.ts.map
