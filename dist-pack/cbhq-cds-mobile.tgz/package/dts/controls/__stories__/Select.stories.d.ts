declare const SelectScreen: () => import('react/jsx-runtime').JSX.Element;
export default SelectScreen;
//# sourceMappingURL=Select.stories.d.ts.map
