declare const RadioGroupScreen: () => import('react/jsx-runtime').JSX.Element;
export default RadioGroupScreen;
//# sourceMappingURL=RadioGroup.stories.d.ts.map
