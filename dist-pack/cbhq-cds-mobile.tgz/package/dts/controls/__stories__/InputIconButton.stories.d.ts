declare const InputIconButtonScreen: () => import('react/jsx-runtime').JSX.Element;
export default InputIconButtonScreen;
//# sourceMappingURL=InputIconButton.stories.d.ts.map
