export {};
//# sourceMappingURL=SelectChip.figma.d.ts.map
