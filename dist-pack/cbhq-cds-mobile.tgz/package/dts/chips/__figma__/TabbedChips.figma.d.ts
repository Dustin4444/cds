export {};
//# sourceMappingURL=TabbedChips.figma.d.ts.map
