export {};
//# sourceMappingURL=InputChip.figma.d.ts.map
