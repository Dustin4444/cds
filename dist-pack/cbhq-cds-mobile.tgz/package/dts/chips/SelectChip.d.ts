import React from 'react';
import type { View } from 'react-native';
import type { SelectBaseProps } from '../controls/Select';
import type { TrayBaseProps } from '../overlays/tray/Tray';
import type { ChipProps } from './ChipProps';
/**
 * @deprecated This component is deprecated. Please use the new SelectChip alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 * @see {@link @cbhq/cds-mobile/alpha/select-chip/SelectChip}
 */
export type SelectChipProps = Pick<SelectBaseProps, 'onChange' | 'valueLabel' | 'placeholder' | 'value'> & Omit<ChipProps, 'children' | 'onBlur'> & Omit<TrayBaseProps, 'onCloseComplete' | 'children'> & {
    children: React.ReactNode;
    /** Indicates that the control is being used to manipulate data elsewhere */
    active?: boolean;
};
/**
 * @deprecated This component is deprecated. Please use the new SelectChip alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 * @see {@link @cbhq/cds-mobile/alpha/select-chip/SelectChip}
 */
export declare const SelectChip: React.NamedExoticComponent<Pick<SelectBaseProps, "value" | "onChange" | "placeholder" | "valueLabel"> & Omit<import("./ChipProps").ChipBaseProps, "children" | "onBlur"> & Omit<TrayBaseProps, "children" | "onCloseComplete"> & {
    children: React.ReactNode;
    /** Indicates that the control is being used to manipulate data elsewhere */
    active?: boolean;
} & React.RefAttributes<View>>;
//# sourceMappingURL=SelectChip.d.ts.map