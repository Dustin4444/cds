export {};
//# sourceMappingURL=MediaChip.test.d.ts.map
