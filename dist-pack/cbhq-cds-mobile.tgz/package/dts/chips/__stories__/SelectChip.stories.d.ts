declare const SelectChipScreen: () => import('react/jsx-runtime').JSX.Element;
export default SelectChipScreen;
//# sourceMappingURL=SelectChip.stories.d.ts.map
