declare const ChipScreen: () => import('react/jsx-runtime').JSX.Element;
export default ChipScreen;
//# sourceMappingURL=Chip.stories.d.ts.map
