declare const TabbedChipsScreen: () => import('react/jsx-runtime').JSX.Element;
export default TabbedChipsScreen;
//# sourceMappingURL=TabbedChips.stories.d.ts.map
