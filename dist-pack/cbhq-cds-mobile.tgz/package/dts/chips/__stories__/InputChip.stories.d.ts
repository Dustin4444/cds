declare const InputChipScreen: () => import('react/jsx-runtime').JSX.Element;
export default InputChipScreen;
//# sourceMappingURL=InputChip.stories.d.ts.map
