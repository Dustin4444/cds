declare const MediaChipScreen: () => import('react/jsx-runtime').JSX.Element;
export default MediaChipScreen;
//# sourceMappingURL=MediaChip.stories.d.ts.map
