import React from 'react';
import type { View } from 'react-native';
import type { ChipProps } from './ChipProps';
export type { ChipProps };
/**
 * This is a basic Chip component used to create all Chip components.
 */
export declare const Chip: React.NamedExoticComponent<import("@cbhq/cds-common").SharedProps & Omit<import("../system").PressableProps, "children" | "maxWidth" | "style" | "onChange"> & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel"> & {
    children?: React.ReactNode;
    start?: React.ReactNode;
    end?: React.ReactNode;
    maxWidth?: import("react-native").DimensionValue;
    inverted?: boolean;
    invertColorScheme?: boolean;
    compact?: boolean;
    numberOfLines?: number;
    contentStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    style?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    styles?: {
        root?: import("react-native").StyleProp<import("react-native").ViewStyle>;
        content?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    };
} & React.RefAttributes<View>>;
//# sourceMappingURL=Chip.d.ts.map