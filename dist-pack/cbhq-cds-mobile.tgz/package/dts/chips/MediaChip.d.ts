import type { View } from 'react-native';
import type { ChipBaseProps, ChipProps } from './ChipProps';
export type MediaChipBaseProps = ChipBaseProps;
export type MediaChipProps = MediaChipBaseProps & ChipProps;
export declare const MediaChip: import("react").NamedExoticComponent<import("@cbhq/cds-common").SharedProps & Omit<import("../system").PressableProps, "children" | "maxWidth" | "style" | "onChange"> & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel"> & {
    children?: React.ReactNode;
    start?: React.ReactNode;
    end?: React.ReactNode;
    maxWidth?: import("react-native").DimensionValue;
    inverted?: boolean;
    invertColorScheme?: boolean;
    compact?: boolean;
    numberOfLines?: number;
    contentStyle?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    style?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    styles?: {
        root?: import("react-native").StyleProp<import("react-native").ViewStyle>;
        content?: import("react-native").StyleProp<import("react-native").ViewStyle>;
    };
} & import("react").RefAttributes<View>>;
//# sourceMappingURL=MediaChip.d.ts.map