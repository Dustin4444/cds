import React from 'react';
import type { View } from 'react-native';
import { type TabNavigationBaseProps } from '../tabs';
export type TabbedChipsBaseProps<TabId extends string = string> = Omit<
  TabNavigationBaseProps<TabId>,
  'variant'
>;
export type TabbedChipsProps<TabId extends string = string> = TabbedChipsBaseProps<TabId>;
type TabbedChipsFC = <TabId extends string = string>(
  props: TabbedChipsProps<TabId> & {
    ref?: React.ForwardedRef<View>;
  },
) => React.ReactElement;
/**
 * @deprecated Use `TabbedChips(Alpha)` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const TabbedChips: TabbedChipsFC;
export {};
//# sourceMappingURL=TabbedChips.d.ts.map
