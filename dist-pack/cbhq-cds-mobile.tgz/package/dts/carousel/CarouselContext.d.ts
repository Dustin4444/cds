import React from 'react';
import type { CarouselAutoplay } from '@cbhq/cds-common';
import type { Rect } from '@cbhq/cds-common/types';
export type CarouselContextValue = {
  registerItem: (id: string, state: Rect) => void;
  unregisterItem: (id: string) => void;
  /**
   * Set of item IDs that are currently visible in the carousel viewport.
   */
  visibleCarouselItems: Set<string>;
};
export declare const CarouselContext: React.Context<CarouselContextValue | undefined>;
export declare const useCarouselContext: () => CarouselContextValue;
export type CarouselAutoplayContextValue = Omit<
  CarouselAutoplay,
  'remainingTime' | 'addCompletionListener'
> & {
  /**
   * Whether autoplay is enabled via props.
   */
  isEnabled: boolean;
  /**
   * The autoplay interval duration in milliseconds.
   */
  interval: number;
};
export declare const CarouselAutoplayContext: React.Context<
  CarouselAutoplayContextValue | undefined
>;
export declare const useCarouselAutoplayContext: () => CarouselAutoplayContextValue;
//# sourceMappingURL=CarouselContext.d.ts.map
