export {};
//# sourceMappingURL=DefaultCarouselPagination.test.d.ts.map
