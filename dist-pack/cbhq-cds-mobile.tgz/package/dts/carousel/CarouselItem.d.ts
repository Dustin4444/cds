import React from 'react';
import type { CarouselItemProps } from './Carousel';
export declare const CarouselItem: React.MemoExoticComponent<
  ({ children, id, style, ...props }: CarouselItemProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=CarouselItem.d.ts.map
