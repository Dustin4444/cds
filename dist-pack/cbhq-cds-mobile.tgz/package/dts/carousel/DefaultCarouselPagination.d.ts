import React from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import type { CarouselPaginationComponentProps } from './Carousel';
export type DefaultCarouselPaginationProps = CarouselPaginationComponentProps & {
  /**
   * Custom styles for the component.
   */
  styles?: {
    /**
     * Custom styles for the root element.
     */
    root?: StyleProp<ViewStyle>;
    /**
     * Custom styles for the dot element.
     */
    dot?: StyleProp<ViewStyle>;
  };
};
export declare const DefaultCarouselPagination: React.NamedExoticComponent<DefaultCarouselPaginationProps>;
//# sourceMappingURL=DefaultCarouselPagination.d.ts.map
