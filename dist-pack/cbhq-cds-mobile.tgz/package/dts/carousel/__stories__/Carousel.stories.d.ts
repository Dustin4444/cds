export default function CarouselScreen(): import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Carousel.stories.d.ts.map
