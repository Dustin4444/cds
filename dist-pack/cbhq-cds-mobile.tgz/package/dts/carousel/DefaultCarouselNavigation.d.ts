import React from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import type { IconButtonVariant, IconName } from '@cbhq/cds-common';
import type { CarouselNavigationComponentProps } from './Carousel';
export type DefaultCarouselNavigationProps = CarouselNavigationComponentProps & {
  /**
   * Test ID map for the component.
   */
  testIDMap?: {
    /**
     * Test ID for the previous button.
     */
    previousButton?: string;
    /**
     * Test ID for the next button.
     */
    nextButton?: string;
    /**
     * Test ID for the autoplay button.
     */
    autoplayButton?: string;
  };
  /**
   * Icon to use for the previous button.
   */
  previousIcon?: IconName;
  /**
   * Icon to use for the next button.
   */
  nextIcon?: IconName;
  /**
   * Icon to use for the start autoplay button.
   */
  startIcon?: IconName;
  /**
   * Icon to use for the stop autoplay button.
   */
  stopIcon?: IconName;
  /**
   * Variant of the icon button.
   */
  variant?: IconButtonVariant;
  /**
   * Whether the icon button is compact.
   */
  compact?: boolean;
  /**
   * Custom styles for the component.
   */
  styles?: {
    /**
     * Custom styles for the root element.
     */
    root?: StyleProp<ViewStyle>;
    /**
     * Custom styles for the previous button.
     */
    previousButton?: StyleProp<ViewStyle>;
    /**
     * Custom styles for the next button.
     */
    nextButton?: StyleProp<ViewStyle>;
    /**
     * Custom styles for the autoplay button.
     */
    autoplayButton?: StyleProp<ViewStyle>;
  };
};
export declare const DefaultCarouselNavigation: React.NamedExoticComponent<DefaultCarouselNavigationProps>;
//# sourceMappingURL=DefaultCarouselNavigation.d.ts.map
