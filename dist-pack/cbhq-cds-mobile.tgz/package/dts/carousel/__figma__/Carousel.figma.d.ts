export {};
//# sourceMappingURL=Carousel.figma.d.ts.map
