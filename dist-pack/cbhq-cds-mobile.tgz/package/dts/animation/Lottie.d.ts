import React from 'react';
import { Animated } from 'react-native';
import LottieView from 'lottie-react-native';
export type LottieMobileRef = React.ForwardedRef<LottieView>;
export declare const Lottie: React.NamedExoticComponent<Omit<import("../layout").BoxBaseProps, "justifyContent" | "alignContent" | "flexDirection" | "flexWrap"> & {
    autoplay?: boolean;
    loop?: boolean;
    onAnimationFinish?: () => void;
    resizeMode?: "cover" | "contain" | "center";
    source: import("@cbhq/cds-common").LottieSource;
    progress?: number | Animated.Value | Animated.AnimatedInterpolation<number>;
    colorFilters?: {
        keypath: string;
        color: string;
    }[];
    animated?: boolean;
    style?: Animated.WithAnimatedValue<import("react-native").StyleProp<import("react-native").ViewStyle>>;
} & import("@cbhq/cds-common").SharedProps & import("../styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: Animated.WithAnimatedValue<import("react-native").StyleProp<import("react-native").ViewStyle>>;
    animated?: boolean;
    elevation?: import("@cbhq/cds-common").ElevationLevels;
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & Omit<import("react-native").ViewProps, "style"> & React.RefAttributes<LottieView>>;
//# sourceMappingURL=Lottie.d.ts.map