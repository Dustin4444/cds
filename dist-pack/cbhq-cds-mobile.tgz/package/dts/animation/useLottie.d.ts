import type { LottieSource } from '@cbhq/cds-common';
export declare function useLottie<T extends LottieSource>(
  source: T,
  startProgressValue?: number,
): import('./createLottie').LottiePlayerMobile<T>;
//# sourceMappingURL=useLottie.d.ts.map
