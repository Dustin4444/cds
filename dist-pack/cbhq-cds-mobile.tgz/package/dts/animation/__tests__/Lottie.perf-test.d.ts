export {};
//# sourceMappingURL=Lottie.perf-test.d.ts.map
