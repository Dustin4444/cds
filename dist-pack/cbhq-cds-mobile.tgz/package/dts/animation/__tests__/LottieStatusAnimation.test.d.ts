export {};
//# sourceMappingURL=LottieStatusAnimation.test.d.ts.map
