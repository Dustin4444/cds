export {};
//# sourceMappingURL=LottieStatusAnimation.perf-test.d.ts.map
