export {};
//# sourceMappingURL=createLottie.test.d.ts.map
