export {};
//# sourceMappingURL=convertMotionConfig.test.d.ts.map
