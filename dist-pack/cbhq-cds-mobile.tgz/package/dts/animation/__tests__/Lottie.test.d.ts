export {};
//# sourceMappingURL=Lottie.test.d.ts.map
