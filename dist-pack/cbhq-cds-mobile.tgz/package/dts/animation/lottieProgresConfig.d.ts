export declare const lottieProgressConfig: {
  toValue: number;
  easing: import('react-native').EasingFunction;
  useNativeDriver: boolean;
};
//# sourceMappingURL=lottieProgresConfig.d.ts.map
