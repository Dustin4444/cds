import type { Animated } from 'react-native';
import type { MotionBaseSpec } from '@cbhq/cds-common/types';
type MotionSpec = Omit<MotionBaseSpec, 'property'>;
export declare const mobileCurves: {
  global: import('react-native').EasingFunction;
  enterExpressive: import('react-native').EasingFunction;
  enterFunctional: import('react-native').EasingFunction;
  exitExpressive: import('react-native').EasingFunction;
  exitFunctional: import('react-native').EasingFunction;
  linear: import('react-native').EasingFunction;
};
export declare const convertMotionConfig: ({
  toValue,
  delay,
  easing,
  duration,
  useNativeDriver,
  oneOffDuration,
}: MotionSpec) => Animated.TimingAnimationConfig;
export {};
//# sourceMappingURL=convertMotionConfig.d.ts.map
