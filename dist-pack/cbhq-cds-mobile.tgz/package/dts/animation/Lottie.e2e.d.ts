export declare const Lottie: ({
  autoplay,
  colorFilters,
  loop,
  progress,
  resizeMode,
  source,
  onAnimationFinish,
  ...boxProps
}: import('./types').LottieProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Lottie.e2e.d.ts.map
