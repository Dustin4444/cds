import type { LottieSource } from '@cbhq/cds-common';
import type { LottieProps } from './types';
/**
 * Override colors of Lottie layers.
 * Theme dependent layers should use PaletteAlias as layer name in After Effects i.e 'foreground' or 'primary'
 */
export declare function useLottieColorFilters(
  source: LottieSource,
  customColorFilters?: LottieProps['colorFilters'],
): {
  keypath: string;
  color: string;
}[];
//# sourceMappingURL=useLottieColorFilters.d.ts.map
