import type { DimensionValue } from 'react-native';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types/SharedAccessibilityProps';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
import type { LottieStatus } from 'packages/common/dts/types/LottieStatus';
type LottieStatusAnimationBaseProps = {
    status?: LottieStatus;
    onFinish?: () => void;
};
type LottieStatusAnimationPropsWithWidth = {
    width: DimensionValue;
} & LottieStatusAnimationBaseProps;
type LottieStatusAnimationPropsWithHeight = {
    height: DimensionValue;
} & LottieStatusAnimationBaseProps;
export type LottieStatusAnimationProps = (LottieStatusAnimationPropsWithWidth | LottieStatusAnimationPropsWithHeight) & SharedProps & SharedAccessibilityProps;
export declare const LottieStatusAnimation: import("react").MemoExoticComponent<({ status, onFinish, testID, accessibilityLabel, ...otherProps }: LottieStatusAnimationProps) => import("react/jsx-runtime").JSX.Element>;
export {};
//# sourceMappingURL=LottieStatusAnimation.d.ts.map