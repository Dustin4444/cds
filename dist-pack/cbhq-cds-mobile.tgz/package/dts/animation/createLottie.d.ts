import React, { type JSX } from 'react';
import { Animated } from 'react-native';
import type { LottiePlayer, LottieSource } from '@cbhq/cds-common';
import type LottieView from 'lottie-react-native';
import type { LottieProps } from './types';
type ProgressListenerCallback = (frame: number) => void;
type ProgressTimingConfig = {
    startFrame?: number;
    endFrame?: number;
};
export type LottieProgress = {
    value: Animated.Value;
    timing: (config?: ProgressTimingConfig) => {
        start: (cb?: () => void) => void;
    };
    play: (cb?: () => void) => void;
    pause: () => void;
    reset: () => void;
    addListener: (callback: ProgressListenerCallback) => void;
    removeListener: () => void;
};
export type LottiePlayerMobile<Source extends LottieSource = LottieSource> = {
    lottieRef: React.Ref<LottieView>;
    progress: LottieProgress;
    Lottie: {
        (props: Omit<LottieProps, 'source'>): JSX.Element;
        displayName: 'Lottie';
    };
} & LottiePlayer<Source>;
export declare const createLottie: <Source extends LottieSource>(source: Source, progressOverride?: Animated.Value) => LottiePlayerMobile<Source>;
export {};
//# sourceMappingURL=createLottie.d.ts.map