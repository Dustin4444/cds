declare const LottieScreen: () => import('react/jsx-runtime').JSX.Element;
export default LottieScreen;
//# sourceMappingURL=Lottie.stories.d.ts.map
