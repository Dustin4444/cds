declare const LottieStatusAnimationScreen: () => import('react/jsx-runtime').JSX.Element;
export default LottieStatusAnimationScreen;
//# sourceMappingURL=LottieStatusAnimation.stories.d.ts.map
