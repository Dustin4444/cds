export declare const useLottie: () => {
  play: () => void;
  playMarkers: () => void;
  pause: () => void;
  resume: () => void;
  reset: () => void;
  progress: {
    value: import('react-native').Animated.Value;
    timing: () => {
      start: (cb?: () => void) => void | undefined;
    };
    play: () => void;
    pause: () => void;
    reset: () => void;
    addListener: () => void;
    removeListener: () => void;
  };
  lottieRef: {
    current: {
      play: () => void;
    };
  };
  Lottie: ({
    autoplay,
    colorFilters,
    loop,
    progress,
    resizeMode,
    source,
    onAnimationFinish,
    ...boxProps
  }: import('./types').LottieProps) => import('react/jsx-runtime').JSX.Element;
};
//# sourceMappingURL=useLottie.e2e.d.ts.map
