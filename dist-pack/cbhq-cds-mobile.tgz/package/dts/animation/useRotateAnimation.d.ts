import { Animated } from 'react-native';
import type { MotionBaseSpec } from '@cbhq/cds-common';
type SelectAnimation = {
  rotateAnimation: Animated.Value;
  animateRotateIn: Animated.CompositeAnimation;
  animateRotateOut: Animated.CompositeAnimation;
  rotateAnimationStyles: {
    transform: {
      rotate: Animated.AnimatedInterpolation<string>;
    }[];
  };
};
export declare const useRotateAnimation: (
  animateInConfig: MotionBaseSpec,
  animateOutConfig: MotionBaseSpec,
  degree: number,
) => SelectAnimation;
export {};
//# sourceMappingURL=useRotateAnimation.d.ts.map
