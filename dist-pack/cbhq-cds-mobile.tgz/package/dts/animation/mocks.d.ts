import { Animated } from 'react-native';
import type { LottieProps } from './types';
export declare const LottieMock: ({
  autoplay,
  colorFilters,
  loop,
  progress,
  resizeMode,
  source,
  onAnimationFinish,
  ...boxProps
}: LottieProps) => import('react/jsx-runtime').JSX.Element;
export declare const createLottieMock: {
  play: () => void;
  playMarkers: () => void;
  pause: () => void;
  resume: () => void;
  reset: () => void;
  progress: {
    value: Animated.Value;
    timing: () => {
      start: (cb?: () => void) => void | undefined;
    };
    play: () => void;
    pause: () => void;
    reset: () => void;
    addListener: () => void;
    removeListener: () => void;
  };
  lottieRef: {
    current: {
      play: () => void;
    };
  };
  Lottie: ({
    autoplay,
    colorFilters,
    loop,
    progress,
    resizeMode,
    source,
    onAnimationFinish,
    ...boxProps
  }: LottieProps) => import('react/jsx-runtime').JSX.Element;
};
//# sourceMappingURL=mocks.d.ts.map
