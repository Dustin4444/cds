import type { ComponentConfig } from '../core/componentConfig';
/**
 * Subscribes to the component config for a specific component via zustand selectors.
 * Only triggers re-renders when the config for THIS component changes - other
 * components' config changes are ignored.
 *
 * Raw config values are stored in the zustand store (not normalized to functions)
 * so that Object.is reference comparisons work correctly and unchanged entries
 * never cause re-renders.
 *
 * @param componentName - The component key in ComponentConfig (e.g., 'Button')
 * @param localProps - The props passed directly to the component instance
 * @returns Merged props with config defaults applied (local props take precedence)
 */
export declare const useComponentConfig: <
  K extends keyof ComponentConfig,
  P extends Record<string, any>,
>(
  componentName: K,
  localProps: P,
) => P;
//# sourceMappingURL=useComponentConfig.d.ts.map
