import type { OpenWebBrowserOptions } from '../utils/openWebBrowser';
export declare const useWebBrowserOpener: () => (
  url: string,
  options?: Partial<OpenWebBrowserOptions>,
) => Promise<void>;
//# sourceMappingURL=useWebBrowserOpener.d.ts.map
