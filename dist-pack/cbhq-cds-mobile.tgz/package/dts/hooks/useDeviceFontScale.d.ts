/** Update font scale on app change. RN does not offer a hook for tapping into this like useColorScheme so we have to manually handle based on app state. */
export declare const useDeviceFontScale: () => number;
//# sourceMappingURL=useDeviceFontScale.d.ts.map
