import { Animated } from 'react-native';
import type { GestureResponderEvent } from 'react-native';
export declare function usePressAnimation(
  factor?: number,
): [
  (event?: GestureResponderEvent) => void,
  (event?: GestureResponderEvent) => void,
  Animated.Value,
];
//# sourceMappingURL=usePressAnimation.d.ts.map
