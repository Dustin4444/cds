export declare const IOS_BOTTOM_NAV_BAR_HEIGHT = 50;
export declare function useDimensions(): {
    screenHeight: number;
    screenWidth: number;
    statusBarHeight: number;
};
//# sourceMappingURL=useDimensions.d.ts.map