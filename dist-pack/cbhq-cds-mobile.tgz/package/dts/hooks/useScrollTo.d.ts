import type { ScrollView } from 'react-native';
type CallbackRef<T> = (node: T) => void;
type AnyRef<T> =
  | React.Ref<T | null | undefined>
  | CallbackRef<T | null | undefined>
  | React.MutableRefObject<T | null | undefined>;
export type ScrollRef = CallbackRef<ScrollView> | null;
export type ScrollToParams = {
  x?: number;
  y?: number;
  animated?: boolean;
};
export type ScrollToFn = (params: ScrollToParams) => void;
export type ScrollToEndFn = (params?: { animated?: boolean }) => void;
export type ScrollToFns = {
  scrollTo: ScrollToFn;
  scrollToEnd: ScrollToEndFn;
};
export declare const useScrollTo: (ref?: AnyRef<ScrollView>) => [ScrollRef, ScrollToFns];
export {};
//# sourceMappingURL=useScrollTo.d.ts.map
