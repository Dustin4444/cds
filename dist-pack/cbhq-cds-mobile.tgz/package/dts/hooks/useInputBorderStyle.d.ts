import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { InputVariant } from '@cbhq/cds-common/types/InputBaseProps';
/**
 * Hook for managing input border styles with animation support.
 *
 * @param focused - Whether the input is currently focused
 * @param initialVariant - The variant when unfocused
 * @param focusedVariant - The variant when focused
 * @param bordered - Whether to show a border when unfocused
 * @param borderWidth - Width of the border (theme token). @default 100
 * @param focusedBorderWidth - Additional border width when focused (theme token). @default borderWidth
 */
export declare const useInputBorderStyle: (
  focused: boolean,
  initialVariant: InputVariant,
  focusedVariant: InputVariant,
  bordered?: boolean,
  borderWidth?: ThemeVars.BorderWidth,
  focusedBorderWidth?: ThemeVars.BorderWidth,
) => {
  borderUnfocusedStyle: {
    borderColor: string;
    borderWidth: number;
  };
  borderFocusedStyle: {
    opacity: import('react-native').Animated.Value;
    borderColor: string;
    borderWidth: number;
  };
};
//# sourceMappingURL=useInputBorderStyle.d.ts.map
