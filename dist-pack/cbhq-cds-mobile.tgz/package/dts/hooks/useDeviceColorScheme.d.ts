import type { ColorScheme } from '@cbhq/cds-common/core/theme';
/** Update device preference on app state change for Android. React Native's useColorScheme does not seem to fire on Android on App State change - this fixes that. */
export declare const useDeviceColorScheme: () => ColorScheme;
//# sourceMappingURL=useDeviceColorScheme.d.ts.map
