import { Animated } from 'react-native';
import type { MotionBaseSpec } from '@cbhq/cds-common/types';
/** Animate to a new value from it's previously tracked state */
export declare const useAnimatedTransition: (
  nextValue: number,
  motionSpec: Omit<MotionBaseSpec, 'toValue' | 'property'>,
) => Animated.Value;
//# sourceMappingURL=useAnimatedTransition.d.ts.map
