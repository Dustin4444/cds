import { Animated } from 'react-native';
import type { InputVariant } from '@cbhq/cds-common/types/InputBaseProps';
type InputBorderAnimationReturnType = {
  animateInputBorderIn: Animated.CompositeAnimation;
  animateInputBorderOut: Animated.CompositeAnimation;
  focusedBorderOpacity: Animated.Value;
  focusedBorderRgba: string;
  unFocusedBorderRgba: string;
};
export declare const useInputBorderAnimation: (
  fromVariant: InputVariant,
  toVariant: InputVariant,
) => InputBorderAnimationReturnType;
export {};
//# sourceMappingURL=useInputBorderAnimation.d.ts.map
