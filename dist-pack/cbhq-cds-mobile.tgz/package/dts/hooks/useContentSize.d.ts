export type OnContentSizeChange = (width: number, height: number) => void;
export type ContentSize = {
  width: number;
  height: number;
};
export declare const useContentSize: () => [ContentSize, OnContentSizeChange];
//# sourceMappingURL=useContentSize.d.ts.map
