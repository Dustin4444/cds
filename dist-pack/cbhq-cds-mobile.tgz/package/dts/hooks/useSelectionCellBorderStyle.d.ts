import { Animated } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common';
export declare const useSelectionCellBorderStyle: ({
  pressed,
  pressedBorderColor,
  borderColor,
  pressedBorderWidth,
  borderWidth,
}: {
  pressed: boolean;
  pressedBorderColor: ThemeVars.Color;
  borderColor: ThemeVars.Color;
  pressedBorderWidth: ThemeVars.BorderWidth;
  borderWidth: ThemeVars.BorderWidth;
}) => {
  focusRingStyle: {
    opacity: Animated.Value;
    borderColor: string;
    borderWidth: number;
  };
  pressedStyle: {
    borderColor: string;
    borderWidth: number;
  };
  unpressedStyle: {
    borderColor: string;
    borderWidth: number;
  };
};
//# sourceMappingURL=useSelectionCellBorderStyle.d.ts.map
