import type { LayoutChangeEvent, LayoutRectangle } from 'react-native';
export type OnLayout = (event: LayoutChangeEvent) => void;
export declare const useLayout: () => [LayoutRectangle, OnLayout];
//# sourceMappingURL=useLayout.d.ts.map
