/**
 * @deprecated This logic is seriously outdated. The last iPhone version to have a 20px status bar was iPhone 8. Most modern iOS devices no longer have a "notch". This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const useHasNotch: () => boolean;
//# sourceMappingURL=useHasNotch.d.ts.map