export declare const useAppState: () =>
  | 'background'
  | 'unknown'
  | 'active'
  | 'inactive'
  | 'extension';
//# sourceMappingURL=useAppState.d.ts.map
