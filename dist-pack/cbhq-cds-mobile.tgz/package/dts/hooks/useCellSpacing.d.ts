import type { CellSpacing } from '../cells/Cell';
export declare const innerDefaults: {
    readonly paddingX: 2;
    readonly paddingY: 1;
    readonly marginX: -2;
};
export declare const outerDefaults: {
    readonly paddingX: 3;
    readonly paddingY: 1;
    readonly marginX: 0;
};
export type UseCellSpacingParams = {
    innerSpacing?: CellSpacing;
    outerSpacing?: CellSpacing;
};
/**
 * Takes the inner and outerSpacing props from the Cell component and merges with their default values.
 */
export declare function useCellSpacing({ innerSpacing, outerSpacing, }?: UseCellSpacingParams | undefined): {
    readonly inner: {
        readonly padding?: import("@cbhq/cds-common").ThemeVars.Space;
        paddingX: import("@cbhq/cds-common").ThemeVars.Space;
        paddingY: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingTop?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingBottom?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingStart?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingEnd?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly margin?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        marginX: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginY?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginTop?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginBottom?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginStart?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginEnd?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
    };
    readonly outer: {
        readonly padding?: import("@cbhq/cds-common").ThemeVars.Space;
        paddingX: import("@cbhq/cds-common").ThemeVars.Space;
        paddingY: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingTop?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingBottom?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingStart?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly paddingEnd?: import("@cbhq/cds-common").ThemeVars.Space;
        readonly margin?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        marginX: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginY?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginTop?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginBottom?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginStart?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
        readonly marginEnd?: 0 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1 | -1.5 | -2 | -3 | -4 | -6 | -7 | -8 | -9;
    };
};
//# sourceMappingURL=useCellSpacing.d.ts.map