import type { Theme } from '../core/theme';
/** Returns the currently active Theme, determined by the ThemeProvider's `activeColorScheme`. */
export declare const useTheme: () => Theme;
//# sourceMappingURL=useTheme.d.ts.map
