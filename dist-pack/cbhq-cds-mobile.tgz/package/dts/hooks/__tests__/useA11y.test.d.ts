export {};
//# sourceMappingURL=useA11y.test.d.ts.map
