export {};
//# sourceMappingURL=useStatusBarHeight.test.d.ts.map