export {};
//# sourceMappingURL=useScrollOffset.test.d.ts.map
