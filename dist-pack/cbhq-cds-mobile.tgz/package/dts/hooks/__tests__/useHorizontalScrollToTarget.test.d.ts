export {};
//# sourceMappingURL=useHorizontalScrollToTarget.test.d.ts.map
