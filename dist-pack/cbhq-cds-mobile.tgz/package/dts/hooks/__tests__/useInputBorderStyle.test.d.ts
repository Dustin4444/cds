export {};
//# sourceMappingURL=useInputBorderStyle.test.d.ts.map
