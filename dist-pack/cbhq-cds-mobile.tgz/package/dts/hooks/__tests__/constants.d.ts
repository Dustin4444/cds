export declare const mockStatusBarHeight = 20;
//# sourceMappingURL=constants.d.ts.map