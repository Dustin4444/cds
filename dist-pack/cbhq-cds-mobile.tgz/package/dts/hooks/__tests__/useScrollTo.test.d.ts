export {};
//# sourceMappingURL=useScrollTo.test.d.ts.map
