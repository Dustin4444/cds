export {};
//# sourceMappingURL=useWebBrowserOpener.test.d.ts.map
