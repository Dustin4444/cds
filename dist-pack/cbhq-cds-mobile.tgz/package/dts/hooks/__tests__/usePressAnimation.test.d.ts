export {};
//# sourceMappingURL=usePressAnimation.test.d.ts.map
