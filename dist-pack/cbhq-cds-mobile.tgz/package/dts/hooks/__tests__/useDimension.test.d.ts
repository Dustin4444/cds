export {};
//# sourceMappingURL=useDimension.test.d.ts.map
