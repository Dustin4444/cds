export {};
//# sourceMappingURL=useScreenReaderStatus.test.d.ts.map
