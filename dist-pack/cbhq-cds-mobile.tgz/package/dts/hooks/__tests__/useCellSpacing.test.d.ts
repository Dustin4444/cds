export {};
//# sourceMappingURL=useCellSpacing.test.d.ts.map
