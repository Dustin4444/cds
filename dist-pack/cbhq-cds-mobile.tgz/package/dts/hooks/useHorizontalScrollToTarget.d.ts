import type { LayoutChangeEvent, NativeScrollEvent, NativeSyntheticEvent, ScrollView, View } from 'react-native';
export type UseHorizontalScrollToTargetOptions = {
    scrollThrottleWaitTime?: number;
    activeTarget?: View | null;
    autoScrollOffset?: number;
    overflowThreshold?: number;
};
/**
 * A hook for managing horizontal scrolling with overflow detection.
 * Useful for horizontally scrollable content that needs to show overflow indicators.
 * Optionally handles scrolling to an active target element.
 *
 * @param scrollThrottleWaitTime - Throttle time for scroll events (default: 200ms)
 * @param activeTarget - The active element to scroll to when it's offscreen
 * @param autoScrollOffset - X position offset when auto-scrolling to active target
 * @param overflowThreshold - Threshold for detecting if content is offscreen (default: 1)
 */
export declare const useHorizontalScrollToTarget: ({ scrollThrottleWaitTime, activeTarget, autoScrollOffset, overflowThreshold, }?: UseHorizontalScrollToTargetOptions) => {
    scrollRef: import("react").RefObject<ScrollView | null>;
    isScrollContentOverflowing: boolean;
    isScrollContentOffscreenRight: boolean;
    isScrollContentOffscreenLeft: boolean;
    handleScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void;
    handleScrollContainerLayout: (event: LayoutChangeEvent) => void;
    handleScrollContentSizeChange: (contentWidth: number) => void;
};
//# sourceMappingURL=useHorizontalScrollToTarget.d.ts.map