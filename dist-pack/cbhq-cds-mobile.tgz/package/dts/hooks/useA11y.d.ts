export declare const useA11y: () => {
    setA11yFocus: <T>(ref: React.RefObject<T | null>) => void;
    announceForA11y: (text: string) => void;
};
//# sourceMappingURL=useA11y.d.ts.map