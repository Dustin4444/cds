/**
 * Hook to track screen reader status and update when changed.
 *
 * @returns {boolean} isScreenReaderEnabled - Whether screen reader is enabled
 */
export declare const useScreenReaderStatus: () => boolean;
//# sourceMappingURL=useScreenReaderStatus.d.ts.map
