import { Animated } from 'react-native';
export declare function useScrollOffset(): {
  onScroll: (...args: any[]) => void;
  xOffset: Animated.Value;
  yOffset: Animated.Value;
  currentIndex: number;
};
//# sourceMappingURL=useScrollOffset.d.ts.map
