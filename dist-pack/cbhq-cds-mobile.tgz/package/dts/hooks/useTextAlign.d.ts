import type { TextAlignProps } from '@cbhq/cds-common';
export type TextAlign = TextAlignProps['align'];
export declare const useTextAlign: (align?: TextAlign) =>
  | {
      readonly textAlign: 'left' | 'right';
    }
  | {
      textAlign: 'center' | 'justify' | undefined;
    };
//# sourceMappingURL=useTextAlign.d.ts.map
