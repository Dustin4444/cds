import type { LayoutChangeEvent, LayoutRectangle, NativeScrollEvent, NativeSyntheticEvent, ScrollView } from 'react-native';
type Options = {
    scrollThrottleWaitTime?: number;
    setActivePressableLayout?: React.Dispatch<React.SetStateAction<LayoutRectangle>>;
};
export declare const useHorizontallyScrollingPressables: (selectedPressableId: string, { scrollThrottleWaitTime, setActivePressableLayout }?: Options) => {
    scrollRef: import("react").RefObject<ScrollView | null>;
    isScrollContentOverflowing: boolean;
    isScrollContentOffscreenRight: boolean;
    handleScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void;
    handleScrollContainerLayout: (event: LayoutChangeEvent) => void;
    handleScrollContentSizeChange: (contentWidth: number) => void;
    getPressableLayoutHandler: (id: string) => ({ nativeEvent: { layout } }: LayoutChangeEvent) => void;
};
export {};
//# sourceMappingURL=useHorizontallyScrollingPressables.d.ts.map