export declare const useSafeBottomPadding: () => number;
//# sourceMappingURL=useSafeBottomPadding.d.ts.map
