import React, { type JSX } from 'react';
import { ScrollView } from 'react-native';
import type { PaddingProps } from '@cbhq/cds-common/types';
import type { BoxProps } from '../layout/Box';
type ExampleRenderChildren = () => NonNullable<JSX.Element>;
export type ExampleProps = {
    children: ExampleRenderChildren | React.ReactNode[] | React.ReactNode;
    inline?: boolean;
    title?: string;
    hideDivider?: boolean;
    titlePadding?: PaddingProps;
} & Omit<BoxProps, 'children'>;
export declare const Example: ({ children, inline, title, titlePadding, hideDivider, ...props }: ExampleProps) => import("react/jsx-runtime").JSX.Element;
export declare const ExampleScreen: React.ForwardRefExoticComponent<import("@cbhq/cds-common").SharedProps & import("../styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: import("react-native").Animated.WithAnimatedValue<import("react-native").StyleProp<import("react-native").ViewStyle>>;
    animated?: boolean;
    elevation?: import("@cbhq/cds-common").ElevationLevels;
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & {
    children?: React.ReactNode | undefined;
} & React.RefAttributes<ScrollView>>;
export {};
//# sourceMappingURL=ExampleScreen.d.ts.map