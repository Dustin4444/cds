export {};
//# sourceMappingURL=AnimatedCaret.test.d.ts.map
