export {};
//# sourceMappingURL=Pulse.test.d.ts.map
