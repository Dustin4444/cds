export {};
//# sourceMappingURL=withMotionTiming.test.d.ts.map
