export {};
//# sourceMappingURL=Shake.test.d.ts.map
