declare const HintMotionScreen: () => import('react/jsx-runtime').JSX.Element;
export default HintMotionScreen;
//# sourceMappingURL=HintMotion.stories.d.ts.map
