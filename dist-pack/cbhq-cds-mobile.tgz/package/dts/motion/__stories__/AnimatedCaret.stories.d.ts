declare const AnimatedCaretScreen: () => import('react/jsx-runtime').JSX.Element;
export default AnimatedCaretScreen;
//# sourceMappingURL=AnimatedCaret.stories.d.ts.map
