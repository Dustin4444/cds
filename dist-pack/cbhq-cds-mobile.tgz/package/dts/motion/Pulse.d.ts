import React from 'react';
import type { MotionTransition, PulseVariant } from '@cbhq/cds-common/types';
import type { HintMotionBaseProps } from './types';
export type PulseBaseProps = HintMotionBaseProps & {
    /**
     * Variant controls opacity of the pulse
     * @default moderate
     */
    variant?: PulseVariant;
    children: React.ReactNode;
    /**
     * Specifies the number of times the pulse animation should loop.
     * Provide a positive integer to define an exact number of loops.
     * To enable infinite looping, omit this property or leave it undefined.
     * By default, the animation loops infinitely if this property is not specified.
     * @default Infinity
     */
    iterations?: number;
    /**
     * Custom motion transition to override default motion config
     */
    motionConfig?: Partial<MotionTransition>;
};
export type PulseRefBaseProps = {
    play: (variant?: PulseVariant) => Promise<void>;
    stop: () => void;
};
export type PulseProps = PulseBaseProps;
/**
 * Please consult with the motion team in #ask-motion before using this component.
 */
export declare const Pulse: React.NamedExoticComponent<HintMotionBaseProps & {
    /**
     * Variant controls opacity of the pulse
     * @default moderate
     */
    variant?: PulseVariant;
    children: React.ReactNode;
    /**
     * Specifies the number of times the pulse animation should loop.
     * Provide a positive integer to define an exact number of loops.
     * To enable infinite looping, omit this property or leave it undefined.
     * By default, the animation loops infinitely if this property is not specified.
     * @default Infinity
     */
    iterations?: number;
    /**
     * Custom motion transition to override default motion config
     */
    motionConfig?: Partial<MotionTransition>;
} & React.RefAttributes<PulseRefBaseProps>>;
//# sourceMappingURL=Pulse.d.ts.map