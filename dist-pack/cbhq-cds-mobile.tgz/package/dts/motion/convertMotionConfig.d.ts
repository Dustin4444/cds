import type { MotionBaseSpec } from '@cbhq/cds-common';
export declare const mobileCurves: {
    global: import("react-native-reanimated").EasingFunctionFactory;
    enterExpressive: import("react-native-reanimated").EasingFunctionFactory;
    enterFunctional: import("react-native-reanimated").EasingFunctionFactory;
    exitExpressive: import("react-native-reanimated").EasingFunctionFactory;
    exitFunctional: import("react-native-reanimated").EasingFunctionFactory;
    linear: import("react-native-reanimated").EasingFunctionFactory;
};
/** Reanimated version */
export declare const convertMotionConfig: ({ toValue, delay, easing, duration, oneOffDuration, ...rest }: Omit<MotionBaseSpec, "useNativeDriver">) => {
    property: string;
    fromValue?: import("@cbhq/cds-common").MotionValue | undefined;
    toValue: import("@cbhq/cds-common").MotionValue;
    delay: number | undefined;
    easing: import("react-native-reanimated").EasingFunctionFactory;
    duration: number | undefined;
};
/** Convert an array of motion configs */
export declare const convertMotionConfigs: (configs: MotionBaseSpec[]) => {
    property: string;
    fromValue?: import("@cbhq/cds-common").MotionValue | undefined;
    toValue: import("@cbhq/cds-common").MotionValue;
    delay: number | undefined;
    easing: import("react-native-reanimated").EasingFunctionFactory;
    duration: number | undefined;
}[];
//# sourceMappingURL=convertMotionConfig.d.ts.map