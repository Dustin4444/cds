import type { AnimationCallback } from 'react-native-reanimated';
import type { convertMotionConfig } from './convertMotionConfig';
/**
 * Util worklet to convert CDS motion config to Reanimated withTiming config
 * @param motionConfig CDS motion config
 * @param cb withTiming callback function
 * @returns Reanimated withTiming
 */
export declare const withMotionTiming: (
  motionConfig: ReturnType<typeof convertMotionConfig>,
  cb?: AnimationCallback,
) => import('@cbhq/cds-common').MotionValue;
//# sourceMappingURL=withMotionTiming.d.ts.map
