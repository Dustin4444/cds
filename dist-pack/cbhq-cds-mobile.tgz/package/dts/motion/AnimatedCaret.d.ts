import React from 'react';
import { Animated } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type IconProps } from '../icons';
export type AnimatedCaretBaseProps = SharedProps & {
  rotate: number;
};
export type AnimatedCaretProps = AnimatedCaretBaseProps & Partial<Omit<IconProps, 'name'>>;
export declare const useAnimatedCaretAnimation: () => {
  animatedStyles: {
    transform: {
      rotate: Animated.AnimatedInterpolation<string | number>;
    }[];
  };
  animate: (rotate: number) => void;
};
export declare const AnimatedCaret: React.NamedExoticComponent<AnimatedCaretProps>;
//# sourceMappingURL=AnimatedCaret.d.ts.map
