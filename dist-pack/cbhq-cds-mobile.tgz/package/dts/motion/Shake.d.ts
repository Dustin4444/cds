import React from 'react';
import type { HintMotionBaseProps } from './types';
export type ShakeRefBaseProps = {
    play: () => Promise<void>;
};
export type ShakeBaseProps = HintMotionBaseProps & {
    children: React.ReactNode;
};
export type ShakeProps = ShakeBaseProps;
/**
 * Please consult with the motion team in #ask-motion before using this component.
 */
export declare const Shake: React.NamedExoticComponent<HintMotionBaseProps & {
    children: React.ReactNode;
} & React.RefAttributes<ShakeRefBaseProps>>;
//# sourceMappingURL=Shake.d.ts.map