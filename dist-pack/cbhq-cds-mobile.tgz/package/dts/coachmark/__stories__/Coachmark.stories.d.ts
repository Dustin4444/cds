declare const CoachmarkScreen: () => import('react/jsx-runtime').JSX.Element;
export default CoachmarkScreen;
//# sourceMappingURL=Coachmark.stories.d.ts.map
