export {};
//# sourceMappingURL=Coachmark.figma.d.ts.map
