import React from 'react';
import type { DimensionValue, View } from 'react-native';
import { type SharedProps } from '@cbhq/cds-common';
import { type BoxBaseProps, type BoxProps } from '../layout';
export type CoachmarkBaseProps = SharedProps & BoxBaseProps & {
    /**
     * Title of the Coachmark. Text or ReactNode
     */
    title: React.ReactNode;
    /**
     * Content of the Coachmark. Text or ReactNode to be rendered below the title
     */
    content: React.ReactNode;
    /**
     * Checkbox component to be rendered below the content
     */
    checkbox?: React.ReactNode;
    /**
     * Media of the Coachmark
     */
    media?: React.ReactNode;
    /**
     * Callback function fired when close button is pressed
     */
    onClose?: () => void;
    /**
     * Action button for next step or ending the tour
     */
    action: React.ReactNode;
    /**
     * Desired width of the Coachmark with respect to max width of windowWidth - spacing2 * 2
     */
    width?: DimensionValue;
    /**
     * a11y label of the close button
     */
    closeButtonAccessibilityLabel?: string;
};
export type CoachmarkProps = CoachmarkBaseProps & BoxProps;
export declare const Coachmark: React.NamedExoticComponent<SharedProps & import("../styles/styleProps").StyleProps & {
    children?: React.ReactNode;
    style?: import("react-native").Animated.WithAnimatedValue<import("react-native").StyleProp<import("react-native").ViewStyle>>;
    animated?: boolean;
    elevation?: import("@cbhq/cds-common").ElevationLevels;
    font?: import("@cbhq/cds-common").ThemeVars.FontFamily | "inherit";
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & {
    /**
     * Title of the Coachmark. Text or ReactNode
     */
    title: React.ReactNode;
    /**
     * Content of the Coachmark. Text or ReactNode to be rendered below the title
     */
    content: React.ReactNode;
    /**
     * Checkbox component to be rendered below the content
     */
    checkbox?: React.ReactNode;
    /**
     * Media of the Coachmark
     */
    media?: React.ReactNode;
    /**
     * Callback function fired when close button is pressed
     */
    onClose?: () => void;
    /**
     * Action button for next step or ending the tour
     */
    action: React.ReactNode;
    /**
     * Desired width of the Coachmark with respect to max width of windowWidth - spacing2 * 2
     */
    width?: DimensionValue;
    /**
     * a11y label of the close button
     */
    closeButtonAccessibilityLabel?: string;
} & Omit<import("react-native").ViewProps, "style"> & React.RefAttributes<View>>;
//# sourceMappingURL=Coachmark.d.ts.map