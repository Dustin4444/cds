export {};
//# sourceMappingURL=DotStatusColor.figma.d.ts.map
