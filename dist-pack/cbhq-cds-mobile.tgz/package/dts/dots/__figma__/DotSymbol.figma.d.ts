export {};
//# sourceMappingURL=DotSymbol.figma.d.ts.map
