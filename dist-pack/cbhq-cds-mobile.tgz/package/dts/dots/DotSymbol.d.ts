import React from 'react';
import {
  type ImageSourcePropType,
  type ImageStyle,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import type {
  DotOverlap,
  DotSize,
  IconName,
  PinPlacement,
  SharedAccessibilityProps,
  SharedProps,
} from '@cbhq/cds-common/types';
import { type IconProps } from '../icons/Icon';
import { type BoxBaseProps } from '../layout/Box';
export type DotSymbolBaseProps = SharedProps &
  Pick<
    SharedAccessibilityProps,
    'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'
  > & {
    /** Icon name to add to the dot. */
    iconName?: IconName;
    /** Size of the dot */
    size?: DotSize;
    /** Whether the icon is active */
    active?: boolean;
    /** The color of the icon */
    color?: IconProps['color'];
    background?: BoxBaseProps['background'];
    borderColor?: BoxBaseProps['borderColor'];
    /** Position of the dot */
    pin?: PinPlacement;
    /** The element that the dot will anchor to */
    children?: React.ReactNode;
    /** Indicates what shape dot is overlapping */
    overlap?: DotOverlap;
    /** Add an arbitrary ReactNode to the dot instead of an icon. */
    symbol?: React.ReactNode;
    /** Image source path */
    source?: ImageSourcePropType | string;
    style?: StyleProp<ViewStyle>;
    iconStyle?: StyleProp<ViewStyle>;
    imageStyle?: StyleProp<ImageStyle>;
  };
export type DotSymbolProps = DotSymbolBaseProps;
export declare const DotSymbol: React.MemoExoticComponent<
  (_props: DotSymbolProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=DotSymbol.d.ts.map
