declare const DotScreen: () => import('react/jsx-runtime').JSX.Element;
export default DotScreen;
//# sourceMappingURL=Dot.stories.d.ts.map
