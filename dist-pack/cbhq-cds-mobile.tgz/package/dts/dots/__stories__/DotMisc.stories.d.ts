declare const DotMiscScreen: () => import('react/jsx-runtime').JSX.Element;
export default DotMiscScreen;
//# sourceMappingURL=DotMisc.stories.d.ts.map
