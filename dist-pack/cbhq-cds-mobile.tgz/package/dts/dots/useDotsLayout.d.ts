import type { LayoutRectangle } from 'react-native';
import type { OnLayout } from '../hooks/useLayout';
export declare const useDotsLayout: () => [LayoutRectangle | null, OnLayout];
//# sourceMappingURL=useDotsLayout.d.ts.map
