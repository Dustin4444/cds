export declare const getTransform: (
  translateX: number,
  translateY: number,
) => {
  position: string;
  transform: (
    | {
        translateX: number;
        translateY?: undefined;
      }
    | {
        translateY: number;
        translateX?: undefined;
      }
  )[];
};
//# sourceMappingURL=dotStyles.d.ts.map
