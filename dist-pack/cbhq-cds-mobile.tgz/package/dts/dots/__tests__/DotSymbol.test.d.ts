export {};
//# sourceMappingURL=DotSymbol.test.d.ts.map
