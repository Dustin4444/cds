export {};
//# sourceMappingURL=getTransformers.test.d.ts.map
