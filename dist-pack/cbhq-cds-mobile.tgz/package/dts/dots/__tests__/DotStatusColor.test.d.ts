export {};
//# sourceMappingURL=DotStatusColor.test.d.ts.map
