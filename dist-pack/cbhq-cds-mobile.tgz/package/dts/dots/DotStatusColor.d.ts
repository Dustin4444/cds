import React from 'react';
import type {
  DotOverlap,
  DotSize,
  DotVariant,
  PinPlacement,
  SharedAccessibilityProps,
  SharedProps,
} from '@cbhq/cds-common/types';
export type DotStatusColorBaseProps = SharedProps &
  Pick<
    SharedAccessibilityProps,
    'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'
  > & {
    /** Position of dot relative to its parent */
    pin?: PinPlacement;
    /** Background color of dot */
    variant: DotVariant;
    /** Children of where the dot will anchor to */
    children?: React.ReactNode;
    /** Size of dot */
    size?: DotSize;
    /** Indicates what shape Dot is overlapping */
    overlap?: DotOverlap;
  };
export type DotStatusColorProps = DotStatusColorBaseProps;
export declare const DotStatusColor: React.MemoExoticComponent<
  (_props: DotStatusColorProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=DotStatusColor.d.ts.map
