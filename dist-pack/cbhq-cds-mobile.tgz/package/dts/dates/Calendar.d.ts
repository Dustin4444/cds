import { type StyleProp, type TextStyle, type ViewStyle } from 'react-native';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type BoxBaseProps } from '../layout/Box';
import { type VStackProps } from '../layout/VStack';
import { type PressableBaseProps } from '../system/Pressable';
export type CalendarPressableBaseProps = PressableBaseProps & {
    borderRadius?: number;
    width?: number;
    height?: number;
    background?: 'transparent' | 'bg' | 'bgPrimary';
};
export type CalendarDayProps = {
    /** Date of this CalendarDay. */
    date: Date;
    /** Callback function fired when pressing this CalendarDay. */
    onPress?: (date: Date) => void;
    /** Toggle active styles. */
    active?: boolean;
    /** Disables user interaction. */
    disabled?: boolean;
    /** Toggle highlighted styles. */
    highlighted?: boolean;
    /** Toggle today's date styles. */
    isToday?: boolean;
    /** Toggle current month styles. */
    isCurrentMonth?: boolean;
    /** Tooltip content shown when hovering or focusing a disabled Calendar Day. */
    disabledError?: string;
    /** Accessibility hint for the current day when it is not disabled. */
    todayAccessibilityHint?: string;
    /** Accessibility hint announced for highlighted dates. */
    highlightedDateAccessibilityHint?: string;
    /** Custom style for the date cell pressable wrapper */
    style?: StyleProp<ViewStyle>;
};
export type CalendarRefHandle = {
    /** Sets accessibility focus on the selected date, seed date, or today. */
    focusInitialDate: () => void;
};
export type CalendarBaseProps = SharedProps & Omit<BoxBaseProps, 'children'> & {
    /** Currently selected Calendar date. Date used to generate the Calendar month. Will be rendered with active styles. */
    selectedDate?: Date | null;
    /** Date used to generate the Calendar month when there is no value for the `selectedDate` prop, defaults to today. */
    seedDate?: Date;
    /** Callback function fired when pressing a Calendar date. */
    onPressDate?: (date: Date) => void;
    /** Disables user interaction. */
    disabled?: boolean;
    /** Hides the Calendar next and previous month arrows. This probably only makes sense to be used when `minDate` and `maxDate` are set to the first and last days of the same month. */
    hideControls?: boolean;
    /** Array of disabled dates, and date tuples for date ranges. Make sure to set `disabledDateError` as well. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    disabledDates?: (Date | [Date, Date])[];
    /** Array of highlighted dates, and date tuples for date ranges. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    highlightedDates?: (Date | [Date, Date])[];
    /** Minimum date allowed to be selected, inclusive. Dates before the `minDate` are disabled. All navigation to months before the `minDate` is disabled. */
    minDate?: Date;
    /** Maximum date allowed to be selected, inclusive. Dates after the `maxDate` are disabled. All navigation to months after the `maxDate` is disabled. */
    maxDate?: Date;
    /**
     * Tooltip content shown when hovering or focusing a disabled date, including dates before the `minDate` or after the `maxDate`.
     * @default 'Date unavailable'
     */
    disabledDateError?: string;
    /**
     * Accessibility label describing the Calendar next month arrow.
     * @default 'Go to next month'
     */
    nextArrowAccessibilityLabel?: string;
    /**
     * Accessibility label describing the Calendar previous month arrow.
     * @default 'Go to previous month'
     */
    previousArrowAccessibilityLabel?: string;
    /**
     * Accessibility hint for the current day when it is not disabled. Omit or leave default for non-localized usage.
     * @default 'Today'
     */
    todayAccessibilityHint?: string;
    /**
     * Accessibility hint announced for highlighted dates. Applied to all highlighted dates.
     * @default 'Highlighted'
     */
    highlightedDateAccessibilityHint?: string;
};
export type CalendarProps = CalendarBaseProps & Omit<VStackProps, 'children' | 'ref'> & {
    /** Custom styles for individual elements of the Calendar component. */
    styles?: {
        /** Root container element */
        root?: StyleProp<ViewStyle>;
        /** Header row containing month label and navigation arrows */
        header?: StyleProp<ViewStyle>;
        /** Month and year title text element */
        title?: StyleProp<TextStyle>;
        /** Navigation controls element */
        navigation?: StyleProp<ViewStyle>;
        /** Container for the days-of-week header and the date grid */
        content?: StyleProp<ViewStyle>;
        /** Individual date cell element, basic ViewStyle applied to the pressable wrapper */
        day?: StyleProp<ViewStyle>;
    };
};
export declare const Calendar: import("react").NamedExoticComponent<SharedProps & Omit<BoxBaseProps, "children"> & {
    /** Currently selected Calendar date. Date used to generate the Calendar month. Will be rendered with active styles. */
    selectedDate?: Date | null;
    /** Date used to generate the Calendar month when there is no value for the `selectedDate` prop, defaults to today. */
    seedDate?: Date;
    /** Callback function fired when pressing a Calendar date. */
    onPressDate?: (date: Date) => void;
    /** Disables user interaction. */
    disabled?: boolean;
    /** Hides the Calendar next and previous month arrows. This probably only makes sense to be used when `minDate` and `maxDate` are set to the first and last days of the same month. */
    hideControls?: boolean;
    /** Array of disabled dates, and date tuples for date ranges. Make sure to set `disabledDateError` as well. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    disabledDates?: (Date | [Date, Date])[];
    /** Array of highlighted dates, and date tuples for date ranges. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    highlightedDates?: (Date | [Date, Date])[];
    /** Minimum date allowed to be selected, inclusive. Dates before the `minDate` are disabled. All navigation to months before the `minDate` is disabled. */
    minDate?: Date;
    /** Maximum date allowed to be selected, inclusive. Dates after the `maxDate` are disabled. All navigation to months after the `maxDate` is disabled. */
    maxDate?: Date;
    /**
     * Tooltip content shown when hovering or focusing a disabled date, including dates before the `minDate` or after the `maxDate`.
     * @default 'Date unavailable'
     */
    disabledDateError?: string;
    /**
     * Accessibility label describing the Calendar next month arrow.
     * @default 'Go to next month'
     */
    nextArrowAccessibilityLabel?: string;
    /**
     * Accessibility label describing the Calendar previous month arrow.
     * @default 'Go to previous month'
     */
    previousArrowAccessibilityLabel?: string;
    /**
     * Accessibility hint for the current day when it is not disabled. Omit or leave default for non-localized usage.
     * @default 'Today'
     */
    todayAccessibilityHint?: string;
    /**
     * Accessibility hint announced for highlighted dates. Applied to all highlighted dates.
     * @default 'Highlighted'
     */
    highlightedDateAccessibilityHint?: string;
} & Omit<import("../layout").BoxProps, "children" | "ref"> & {
    /** Custom styles for individual elements of the Calendar component. */
    styles?: {
        /** Root container element */
        root?: StyleProp<ViewStyle>;
        /** Header row containing month label and navigation arrows */
        header?: StyleProp<ViewStyle>;
        /** Month and year title text element */
        title?: StyleProp<TextStyle>;
        /** Navigation controls element */
        navigation?: StyleProp<ViewStyle>;
        /** Container for the days-of-week header and the date grid */
        content?: StyleProp<ViewStyle>;
        /** Individual date cell element, basic ViewStyle applied to the pressable wrapper */
        day?: StyleProp<ViewStyle>;
    };
} & import("react").RefAttributes<CalendarRefHandle>>;
//# sourceMappingURL=Calendar.d.ts.map