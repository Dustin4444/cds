export {};
//# sourceMappingURL=DatePicker.figma.d.ts.map
