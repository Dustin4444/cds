import React from 'react';
import { type StyleProp, type TextInput as NativeTextInput, type ViewStyle } from 'react-native';
import { type DateInputOptions } from '@cbhq/cds-common/dates/useDateInput';
import { type TextInputBaseProps, type TextInputProps } from '../controls/TextInput';
export type DateInputBaseProps = Omit<DateInputOptions, 'intlDateFormat'> & Omit<TextInputBaseProps, 'inputNode' | 'value' | 'defaultValue'> & {
    /** Date format separator character, e.g. the / in "MM/DD/YYYY". Defaults to forward slash (/). */
    separator?: string;
};
export type DateInputProps = DateInputBaseProps & Omit<TextInputProps, 'inputNode' | 'value' | 'defaultValue' | 'style'> & {
    style?: StyleProp<ViewStyle>;
};
export declare const DateInput: React.NamedExoticComponent<Omit<DateInputOptions, "intlDateFormat"> & Omit<TextInputBaseProps, "value" | "inputNode" | "defaultValue"> & {
    /** Date format separator character, e.g. the / in "MM/DD/YYYY". Defaults to forward slash (/). */
    separator?: string;
} & Omit<TextInputProps, "value" | "style" | "inputNode" | "defaultValue"> & {
    style?: StyleProp<ViewStyle>;
} & React.RefAttributes<NativeTextInput>>;
//# sourceMappingURL=DateInput.d.ts.map