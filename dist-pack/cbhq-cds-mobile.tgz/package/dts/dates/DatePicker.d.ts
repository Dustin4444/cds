import { type NativeSyntheticEvent, type StyleProp, type TextInputChangeEventData, type TextStyle, type View, type ViewStyle } from 'react-native';
import type { DateInputValidationError } from '@cbhq/cds-common/dates/DateInputValidationError';
import { type CalendarBaseProps } from './Calendar';
import { type DateInputProps } from './DateInput';
export type DatePickerBaseProps = Pick<CalendarBaseProps, 'disabled' | 'disabledDates' | 'disabledDateError' | 'highlightedDateAccessibilityHint' | 'highlightedDates' | 'maxDate' | 'minDate' | 'nextArrowAccessibilityLabel' | 'previousArrowAccessibilityLabel' | 'seedDate'> & {
    /** Control the date value of the DatePicker. */
    date: Date | null;
    /** Callback function fired when the date changes, e.g. when a valid date is selected or unselected. */
    onChangeDate: (selectedDate: Date | null) => void;
    /** Control the error value of the DatePicker. */
    error: DateInputValidationError | null;
    /** Callback function fired when validation finds an error, e.g. required input fields and impossible or disabled dates. Will always be called after `onChangeDate`. */
    onErrorDate: (error: DateInputValidationError | null) => void;
    /** Callback function fired when the picker is opened. */
    onOpen?: () => void;
    /** Callback function fired when the picker is closed. Will always be called after `onCancel`, `onConfirm`, and `onChangeDate`. */
    onClose?: () => void;
    /** Callback function fired when the user selects a date using the picker. Interacting with the DateInput does not fire this callback. Will always be called before `onClose`. */
    onConfirm?: () => void;
    /** Callback function fired when the user closes the picker without selecting a date. Interacting with the DateInput does not fire this callback. Will always be called before `onClose`. */
    onCancel?: () => void;
    /**
     * Accessibility label describing the calendar IconButton, which opens the calendar when pressed.
     * @deprecated Use openCalendarAccessibilityLabel/closeCalendarAccessibilityLabel instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    calendarIconButtonAccessibilityLabel?: string;
    /**
     * Accessibility label for the calendar IconButton, which opens the calendar when pressed.
     * @default 'Open calendar'
     */
    openCalendarAccessibilityLabel?: string;
    /**
     * Accessibility label for the handle bar that closes the picker.
     * @default 'Close calendar without selecting a date'
     */
    closeCalendarAccessibilityLabel?: string;
};
export type DatePickerProps = DatePickerBaseProps & Omit<DateInputProps, 'date' | 'separator' | 'onChangeDate' | 'disabledDates' | 'minDate' | 'maxDate' | 'disabledDateError' | 'style'> & {
    /** Callback function fired when the DateInput text value changes. Prefer to use `onChangeDate` instead. Will always be called before `onChangeDate`. This prop should only be used for edge cases, such as custom error handling.  */
    onChange?: (event: NativeSyntheticEvent<TextInputChangeEventData>) => void;
    /**
     * Custom style to apply to the DateInput.
     * @deprecated Use `styles.dateInput` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    dateInputStyle?: StyleProp<ViewStyle>;
    /**
     * Text to display on the confirm button.
     * @default 'Confirm'
     */
    confirmText?: string;
    /**
     * Accessibility hint for the confirm button.
     */
    confirmButtonAccessibilityHint?: string;
    /** Custom styles for the DateInput and Calendar subcomponents. */
    styles?: {
        dateInput?: DateInputProps['style'];
        calendar?: StyleProp<ViewStyle>;
        calendarHeader?: StyleProp<ViewStyle>;
        calendarTitle?: StyleProp<TextStyle>;
        calendarNavigation?: StyleProp<ViewStyle>;
        calendarContent?: StyleProp<ViewStyle>;
        calendarDay?: StyleProp<ViewStyle>;
    };
};
export declare const DatePicker: import("react").NamedExoticComponent<Pick<CalendarBaseProps, "disabled" | "previousArrowAccessibilityLabel" | "nextArrowAccessibilityLabel" | "seedDate" | "disabledDates" | "highlightedDates" | "minDate" | "maxDate" | "disabledDateError" | "highlightedDateAccessibilityHint"> & {
    /** Control the date value of the DatePicker. */
    date: Date | null;
    /** Callback function fired when the date changes, e.g. when a valid date is selected or unselected. */
    onChangeDate: (selectedDate: Date | null) => void;
    /** Control the error value of the DatePicker. */
    error: DateInputValidationError | null;
    /** Callback function fired when validation finds an error, e.g. required input fields and impossible or disabled dates. Will always be called after `onChangeDate`. */
    onErrorDate: (error: DateInputValidationError | null) => void;
    /** Callback function fired when the picker is opened. */
    onOpen?: () => void;
    /** Callback function fired when the picker is closed. Will always be called after `onCancel`, `onConfirm`, and `onChangeDate`. */
    onClose?: () => void;
    /** Callback function fired when the user selects a date using the picker. Interacting with the DateInput does not fire this callback. Will always be called before `onClose`. */
    onConfirm?: () => void;
    /** Callback function fired when the user closes the picker without selecting a date. Interacting with the DateInput does not fire this callback. Will always be called before `onClose`. */
    onCancel?: () => void;
    /**
     * Accessibility label describing the calendar IconButton, which opens the calendar when pressed.
     * @deprecated Use openCalendarAccessibilityLabel/closeCalendarAccessibilityLabel instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    calendarIconButtonAccessibilityLabel?: string;
    /**
     * Accessibility label for the calendar IconButton, which opens the calendar when pressed.
     * @default 'Open calendar'
     */
    openCalendarAccessibilityLabel?: string;
    /**
     * Accessibility label for the handle bar that closes the picker.
     * @default 'Close calendar without selecting a date'
     */
    closeCalendarAccessibilityLabel?: string;
} & Omit<DateInputProps, "style" | "separator" | "disabledDates" | "minDate" | "maxDate" | "disabledDateError" | "date" | "onChangeDate"> & {
    /** Callback function fired when the DateInput text value changes. Prefer to use `onChangeDate` instead. Will always be called before `onChangeDate`. This prop should only be used for edge cases, such as custom error handling.  */
    onChange?: (event: NativeSyntheticEvent<TextInputChangeEventData>) => void;
    /**
     * Custom style to apply to the DateInput.
     * @deprecated Use `styles.dateInput` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    dateInputStyle?: StyleProp<ViewStyle>;
    /**
     * Text to display on the confirm button.
     * @default 'Confirm'
     */
    confirmText?: string;
    /**
     * Accessibility hint for the confirm button.
     */
    confirmButtonAccessibilityHint?: string;
    /** Custom styles for the DateInput and Calendar subcomponents. */
    styles?: {
        dateInput?: DateInputProps["style"];
        calendar?: StyleProp<ViewStyle>;
        calendarHeader?: StyleProp<ViewStyle>;
        calendarTitle?: StyleProp<TextStyle>;
        calendarNavigation?: StyleProp<ViewStyle>;
        calendarContent?: StyleProp<ViewStyle>;
        calendarDay?: StyleProp<ViewStyle>;
    };
} & import("react").RefAttributes<View>>;
//# sourceMappingURL=DatePicker.d.ts.map