declare const CalendarScreen: () => import('react/jsx-runtime').JSX.Element;
export default CalendarScreen;
//# sourceMappingURL=Calendar.stories.d.ts.map
