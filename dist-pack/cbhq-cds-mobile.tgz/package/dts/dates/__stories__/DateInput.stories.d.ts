export declare const Examples: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomLabel: () => import('react/jsx-runtime').JSX.Element;
export default Examples;
//# sourceMappingURL=DateInput.stories.d.ts.map
