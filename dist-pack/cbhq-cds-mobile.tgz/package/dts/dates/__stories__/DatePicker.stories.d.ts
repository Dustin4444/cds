export declare const FullExample: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomLabel: () => import('react/jsx-runtime').JSX.Element;
export default FullExample;
//# sourceMappingURL=DatePicker.stories.d.ts.map
