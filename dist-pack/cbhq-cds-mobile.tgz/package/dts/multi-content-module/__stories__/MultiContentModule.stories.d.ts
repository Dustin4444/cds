export declare const WithButtonGroup: () => import('react/jsx-runtime').JSX.Element;
export declare const WithEnd: () => import('react/jsx-runtime').JSX.Element;
export declare const WithLongContent: () => import('react/jsx-runtime').JSX.Element;
declare const MultiContentModuleScreen: () => import('react/jsx-runtime').JSX.Element;
export default MultiContentModuleScreen;
//# sourceMappingURL=MultiContentModule.stories.d.ts.map
