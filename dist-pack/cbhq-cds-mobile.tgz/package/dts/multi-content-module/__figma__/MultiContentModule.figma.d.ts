export {};
//# sourceMappingURL=MultiContentModule.figma.d.ts.map
