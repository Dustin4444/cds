export * from './MultiContentModule';
//# sourceMappingURL=index.d.ts.map
