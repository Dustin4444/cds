export {};
//# sourceMappingURL=MultiContentModule.test.d.ts.map
