import React from 'react';
import { Animated, type StyleProp, type TextStyle, type ViewStyle } from 'react-native';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { IconName, IconSize, IconSourcePixelSize, PaddingProps, SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common/types';
export type IconBaseProps = SharedProps & PaddingProps & Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityHint'> & {
    /**
     * Size for a given icon.
     * @default m
     */
    size?: IconSize;
    /** Name of the icon, as defined in Figma. */
    name: IconName;
    /**
     * Fallback element to render if unable to find an icon with matching name
     * @default null
     * */
    fallback?: null | React.ReactNode;
    /**
     * Toggles the active and inactive state of the navigation icon
     * @default false
     */
    active?: boolean;
    /** Color of the icon when used as a foreground.
     * @default primary
     */
    color?: ThemeVars.Color;
    /**
     * @deprecated Use `style`, `styles.icon`, or the `color` prop to customize icon color. This will be removed in a future major release.
     * @deprecationExpectedRemoval v10
     */
    dangerouslySetColor?: string | Animated.AnimatedInterpolation<string>;
    animated?: boolean;
    style?: Animated.WithAnimatedValue<StyleProp<TextStyle>>;
};
export type IconProps = IconBaseProps & {
    /** Custom styles for individual elements of the Icon component */
    styles?: {
        /** Outer Box wrapper element */
        root?: StyleProp<ViewStyle>;
        /** Inner icon glyph Text element */
        icon?: StyleProp<TextStyle>;
    };
};
declare const getIconSourceSize: (iconSize: number) => IconSourcePixelSize;
export declare const Icon: React.MemoExoticComponent<(_props: IconProps) => string | number | bigint | boolean | import("react/jsx-runtime").JSX.Element | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | null>;
export { getIconSourceSize };
//# sourceMappingURL=Icon.d.ts.map