import React from 'react';
import type { LogoMarkParams } from '@cbhq/cds-common/hooks/useLogo';
export declare const LogoMark: React.MemoExoticComponent<
  ({
    size,
    foreground,
  }: Omit<LogoMarkParams, 'colorScheme'>) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=LogoMark.d.ts.map
