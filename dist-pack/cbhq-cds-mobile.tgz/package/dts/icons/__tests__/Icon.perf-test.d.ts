export {};
//# sourceMappingURL=Icon.perf-test.d.ts.map
