export {};
//# sourceMappingURL=LogoWordmark.figma.d.ts.map
