export {};
//# sourceMappingURL=SubBrandLogoMark.figma.d.ts.map
