export {};
//# sourceMappingURL=SubBrandLogoWordmark.figma.d.ts.map
