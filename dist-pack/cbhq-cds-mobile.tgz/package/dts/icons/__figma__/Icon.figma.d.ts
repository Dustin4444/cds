export {};
//# sourceMappingURL=Icon.figma.d.ts.map
