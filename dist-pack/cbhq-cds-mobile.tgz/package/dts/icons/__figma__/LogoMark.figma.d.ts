export {};
//# sourceMappingURL=LogoMark.figma.d.ts.map
