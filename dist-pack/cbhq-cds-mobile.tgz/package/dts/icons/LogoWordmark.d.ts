import React from 'react';
import type { LogoWordmarkParams } from '@cbhq/cds-common/hooks/useLogo';
export declare const LogoWordmark: React.MemoExoticComponent<
  ({
    foreground,
  }: Omit<LogoWordmarkParams, 'colorScheme'>) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=LogoWordmark.d.ts.map
