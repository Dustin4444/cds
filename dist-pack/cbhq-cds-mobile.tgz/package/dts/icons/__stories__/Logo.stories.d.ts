declare const LogoScreen: () => import('react/jsx-runtime').JSX.Element;
export default LogoScreen;
//# sourceMappingURL=Logo.stories.d.ts.map
