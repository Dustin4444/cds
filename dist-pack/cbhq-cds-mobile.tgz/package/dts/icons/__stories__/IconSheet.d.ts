import React from 'react';
import type { IconName, IconSize } from '@cbhq/cds-common/types';
type IconSheetProps = {
  renderIcon?: (name: IconName, size: IconSize) => React.ReactNode;
};
export declare function IconSheet({
  renderIcon,
}: IconSheetProps): import('react/jsx-runtime').JSX.Element;
export {};
//# sourceMappingURL=IconSheet.d.ts.map
