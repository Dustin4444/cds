import React from 'react';
import { Animated } from 'react-native';
import type { StyleProp, TextStyle } from 'react-native';
import type { IconName } from '@cbhq/cds-common';
import type { IconProps } from './Icon';
export type TextIconProps = Pick<IconProps, 'color' | 'size' | 'testID'> & {
  name: IconName;
  active?: boolean;
} & (
    | {
        animated: true;
        style: Animated.WithAnimatedValue<StyleProp<TextStyle>>;
      }
    | {
        animated?: false | undefined;
        style?: StyleProp<TextStyle>;
      }
  );
/**
 *
 * This is a simplified, text-only version of the Icon component.
 * Nested text components need to all be RN Text and the Icon component has a box wrapper to handle border and badges.
 * Adheres to all the requirements for Nested Text on react native. https://reactnative.dev/docs/text#nested-text
 */
export declare const TextIcon: React.NamedExoticComponent<TextIconProps>;
//# sourceMappingURL=TextIcon.d.ts.map
