import React from 'react';
import type { SubBrandLogoWordmarkParams } from '@cbhq/cds-common/hooks/useSubBrandLogo';
export type SubBrandLogoWordmarkProps = SubBrandLogoWordmarkParams;
export declare const SubBrandLogoWordmark: React.MemoExoticComponent<
  (props: Omit<SubBrandLogoWordmarkProps, 'colorScheme'>) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=SubBrandLogoWordmark.d.ts.map
