import React from 'react';
import type { SubBrandLogoMarkParams } from '@cbhq/cds-common/hooks/useSubBrandLogo';
export type SubBrandLogoMarkProps = SubBrandLogoMarkParams;
export declare const SubBrandLogoMark: React.MemoExoticComponent<
  (props: Omit<SubBrandLogoMarkProps, 'colorScheme'>) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=SubBrandLogoMark.d.ts.map
