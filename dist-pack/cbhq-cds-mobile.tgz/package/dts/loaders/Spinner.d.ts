import React from 'react';
import type { ActivityIndicatorProps } from 'react-native';
/**
 * @deprecated Use indeterminate ProgressCircle or ActivityIndicator component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const Spinner: React.NamedExoticComponent<ActivityIndicatorProps>;
//# sourceMappingURL=Spinner.d.ts.map
