declare const SpinnerScreen: () => import('react/jsx-runtime').JSX.Element;
export default SpinnerScreen;
//# sourceMappingURL=Spinner.stories.d.ts.map
