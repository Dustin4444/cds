import type { CamelCase, KebabCase, PascalCase, SnakeCase, Split } from 'type-fest';
export declare const camelCase: <T extends string>(str: T) => CamelCase<T>;
export declare const pascalCase: <T extends string>(str: T) => PascalCase<typeof str>;
export declare const wordCase: <T extends string>(str: T) => string;
export declare const kebabCase: <T extends string>(str: T) => KebabCase<typeof str>;
export declare const snakeCase: <T extends string>(str: T) => SnakeCase<typeof str>;
export declare const toCssVar: <T extends string>(str: T) => `--${import("type-fest").DelimiterCase<T, "-">}`;
export declare const split: <T extends string, K extends string>(str: T, separator: K) => Split<T, K>;
export declare const toCssVarFn: <T extends string>(str: T) => `var(--${import("type-fest").DelimiterCase<T, "-">})`;
export declare const capitalize: <T extends string>(str: T) => Capitalize<T>;
export declare const generateRandomId: <T extends string>(prefix?: T) => string;
//# sourceMappingURL=string.d.ts.map