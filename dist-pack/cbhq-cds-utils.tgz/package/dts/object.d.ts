import type { AnyObject, StringKey } from './types';
/**
 * @deprecated Do not use. This will be removed in a future major release.
 * @deprecationExpectedRemoval v2
 */
export declare const emptyObject: {};
export declare function entries<T extends Record<string, unknown>>(item: T): [keyof T, T[keyof T]][];
export declare function mapKeys<T extends AnyObject, K extends (value: T[keyof T], key: keyof T, obj: T) => StringKey<unknown>>(obj: T, callbackFn: K): { [key in ReturnType<K>]: T[keyof T]; };
export declare function mapValues<T extends AnyObject, K extends (value: T[keyof T], key: keyof T, i: number) => unknown>(obj: T, callbackFn: K): { [key in keyof T]: ReturnType<K>; };
export declare const renameKeys: <T>(obj: Record<string, T>, newKeys: Record<string, string>) => Record<string, T>;
/**
 *
 * @param baseObj The base object you want to merge onto or return if condition is not met
 * @param objToMerge The object you want to merge
 * @returns newly merged object
 */
export declare function merge<BaseObj extends AnyObject | Readonly<AnyObject>, ConditionalObj extends AnyObject | Readonly<AnyObject>>(baseObj: BaseObj, objToMerge: ConditionalObj | undefined | false): BaseObj & {};
//# sourceMappingURL=object.d.ts.map