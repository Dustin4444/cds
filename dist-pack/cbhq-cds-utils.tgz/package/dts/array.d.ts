export declare const emptyArray: never[];
export declare const arrayToObject: <T extends string | number>(arr: T[] | readonly T[]) => { [key in T]: key; };
export declare const arrayIncludes: <T>(arr: T[], arg: T) => boolean;
//# sourceMappingURL=array.d.ts.map