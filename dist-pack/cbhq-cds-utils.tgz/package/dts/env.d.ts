export declare const isDevelopment: () => boolean;
export declare const isProduction: () => boolean;
export declare const isTest: () => boolean;
export declare const isStorybook: () => boolean;
export declare const getFigmaAccessToken: () => string;
//# sourceMappingURL=env.d.ts.map