/**
 * CDS MCP collects anonymous usage data to help us understand how the server is used
 * and to improve the product.
 */
type CdsEventType = 'cdsCli' | 'cdsMcp' | 'cdsDocs';
type CdsEventData = {
  version: string;
  command: string;
  arguments?: string;
  context?: string;
};
export declare function postMetric(
  eventType: CdsEventType,
  data: Omit<CdsEventData, 'version'>,
): void;
export {};
//# sourceMappingURL=analytics.d.ts.map
