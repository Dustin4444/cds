import React from 'react';
export declare const CoachmarkExamples: () => import("react/jsx-runtime").JSX.Element;
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("..").CoachmarkProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
export default _default;
//# sourceMappingURL=Coachmark.stories.d.ts.map