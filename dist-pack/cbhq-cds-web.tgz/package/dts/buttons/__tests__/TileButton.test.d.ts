export {};
//# sourceMappingURL=TileButton.test.d.ts.map
