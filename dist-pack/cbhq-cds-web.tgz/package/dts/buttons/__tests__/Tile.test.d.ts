export {};
//# sourceMappingURL=Tile.test.d.ts.map
