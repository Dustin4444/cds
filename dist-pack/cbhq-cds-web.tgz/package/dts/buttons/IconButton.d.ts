import React from 'react';
import type { IconButtonVariant, IconName, IconSize } from '@cbhq/cds-common/types';
import type { Polymorphic } from '../core/polymorphism';
import { type PressableBaseProps } from '../system/Pressable';
import { type ButtonBaseProps } from './Button';
export declare const iconButtonDefaultElement = 'button';
export type IconButtonDefaultElement = typeof iconButtonDefaultElement;
export type IconButtonBaseProps = Polymorphic.ExtendableProps<
  Omit<PressableBaseProps, 'children'>,
  Pick<ButtonBaseProps, 'disabled' | 'transparent' | 'compact' | 'flush'> & {
    /** Name of the icon, as defined in Figma. */
    name: IconName;
    /**
     * Size for the icon rendered inside the button.
     * @default compact ? 's' : 'm'
     */
    iconSize?: IconSize;
    /** Whether the icon is active */
    active?: boolean;
    /**
     * Toggle design and visual variants.
     * @default primary
     */
    variant?: IconButtonVariant;
  }
>;
export type IconButtonProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  IconButtonBaseProps
>;
type IconButtonComponent = (<AsComponent extends React.ElementType = IconButtonDefaultElement>(
  props: IconButtonProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const IconButton: IconButtonComponent;
export {};
//# sourceMappingURL=IconButton.d.ts.map
