import React, { type JSX } from 'react';
export type TileBaseProps = {
    title: string;
    /** Surfaces a DotCount around the content */
    count?: number;
    /** Reveals truncated title text */
    showOverflow?: boolean;
    children?: JSX.Element;
};
export type TileProps = TileBaseProps;
/**
 * @danger this component is for internal use only
 */
export declare const Tile: React.MemoExoticComponent<(_props: TileProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=Tile.d.ts.map