export {};
//# sourceMappingURL=TileButton.figma.d.ts.map
