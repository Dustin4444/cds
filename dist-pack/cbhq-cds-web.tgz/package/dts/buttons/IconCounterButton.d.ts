import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { IconSize } from '@cbhq/cds-common/types';
import type { IconName } from '@cbhq/cds-icons';
import { type PressableDefaultElement, type PressableProps } from '../system/Pressable';
export type IconCounterButtonBaseProps = {
    /** Name of the icon or a ReactNode */
    icon: Exclude<React.ReactNode, 'string'> | IconName;
    /**
     * @deprecated Use `size` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v8
     */
    iconSize?: IconSize;
    /** Size for given icon. */
    size?: IconSize;
    /** Whether the icon is active */
    active?: boolean;
    /** Number to display */
    count?: number;
    /** Color of the icon */
    color?: ThemeVars.Color;
    /**
     * @deprecated Use `styles.icon`, `classNames.icon`, or `color` to customize icon color. This will be removed in a future major release.
     * @deprecationExpectedRemoval v10
     */
    dangerouslySetColor?: string;
    /** Background color of the overlay (element being interacted with). */
    background?: ThemeVars.Color;
};
export type IconCounterButtonProps = IconCounterButtonBaseProps & Omit<PressableProps<PressableDefaultElement>, 'background'> & {
    /** Custom inline styles for individual elements of the IconCounterButton component */
    styles?: {
        /** Root Pressable element */
        root?: React.CSSProperties;
        /** Icon element rendered when `icon` is an icon name */
        icon?: React.CSSProperties;
    };
    /** Custom class names for individual elements of the IconCounterButton component */
    classNames?: {
        /** Root Pressable element */
        root?: string;
        /** Icon element rendered when `icon` is an icon name */
        icon?: string;
    };
};
export declare const IconCounterButton: React.NamedExoticComponent<Omit<IconCounterButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=IconCounterButton.d.ts.map