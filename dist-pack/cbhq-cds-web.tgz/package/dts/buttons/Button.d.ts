import React from 'react';
import type {
  ButtonVariant,
  IconName,
  SharedAccessibilityProps,
  SharedProps,
} from '@cbhq/cds-common/types';
import type { Polymorphic } from '../core/polymorphism';
import { type PressableBaseProps } from '../system/Pressable';
/** @deprecated Use progressCircleSize instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const spinnerHeight = 2.5;
export declare const buttonDefaultElement = 'button';
export type ButtonDefaultElement = typeof buttonDefaultElement;
export type ButtonBaseProps = Polymorphic.ExtendableProps<
  PressableBaseProps,
  SharedProps &
    Pick<SharedAccessibilityProps, 'accessibilityLabel'> & {
      /**
       * Toggle design and visual variants.
       * @default primary
       */
      variant?: ButtonVariant;
      /** Mark the button as disabled. */
      disabled?: boolean;
      /** Mark the button as loading and display a spinner. */
      loading?: boolean;
      /** Size of the loading progress circle in px.
       * @default 24
       */
      progressCircleSize?: number;
      /** Mark the background and border as transparent until interacted with. */
      transparent?: boolean;
      /** Change to block and expand to 100% of parent width. */
      block?: boolean;
      /** Reduce the inner padding within the button itself. */
      compact?: boolean;
      /** Children to render within the button. */
      children: React.ReactNode;
      /** Set the start node */
      start?: React.ReactNode;
      /** Icon to render at the start of the button. */
      startIcon?: IconName;
      /** Whether the start icon is active */
      startIconActive?: boolean;
      /** Set the end node */
      end?: React.ReactNode;
      /** Icon to render at the end of the button. */
      endIcon?: IconName;
      /** Whether the end icon is active */
      endIconActive?: boolean;
      /** Ensure the button aligns flush on the left or right.
       * This prop will translate the entire button left/right,
       * so take care to ensure it is not overflowing awkwardly
       */
      flush?: 'start' | 'end';
      /** Uniquely identify the button within a form. */
      name?: string;
      /** Don't scale element on press. */
      noScaleOnPress?: boolean;
      /**
       * Truncates text after wrapping to a defined number of lines.
       * @default 1
       */
      numberOfLines?: number;
    }
>;
export type ButtonProps<AsComponent extends React.ElementType = ButtonDefaultElement> =
  Polymorphic.Props<AsComponent, ButtonBaseProps>;
type ButtonComponent = (<AsComponent extends React.ElementType = ButtonDefaultElement>(
  props: ButtonProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const Button: ButtonComponent;
export {};
//# sourceMappingURL=Button.d.ts.map
