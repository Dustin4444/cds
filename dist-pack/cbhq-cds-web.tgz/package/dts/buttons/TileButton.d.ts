import React from 'react';
import type { IllustrationPictogramNames } from '@cbhq/cds-common/types';
import type { Polymorphic } from '../core/polymorphism';
import { type PressableBaseProps } from '../system/Pressable';
import { type TileBaseProps } from './Tile';
export declare const tileButtonDefaultElement = 'button';
export type TileButtonDefaultElement = typeof tileButtonDefaultElement;
export type TileButtonBaseProps = Polymorphic.ExtendableProps<
  Omit<PressableBaseProps, 'noScaleOnPress' | 'loading' | 'children'>,
  TileBaseProps & {
    /** Name of illustration as defined in Figma */
    pictogram?: IllustrationPictogramNames;
  }
>;
export type TileButtonProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  TileButtonBaseProps
>;
type TileButtonComponent = (<AsComponent extends React.ElementType = TileButtonDefaultElement>(
  props: TileButtonProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const TileButton: TileButtonComponent;
export {};
//# sourceMappingURL=TileButton.d.ts.map
