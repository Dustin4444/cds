import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("..").IconCounterButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
};
export default _default;
export declare const IconCounterButtonExample: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=IconCounterButton.stories.d.ts.map