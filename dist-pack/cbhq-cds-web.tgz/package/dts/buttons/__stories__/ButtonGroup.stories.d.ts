import React from 'react';
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
export declare const Block: () => import('react/jsx-runtime').JSX.Element;
export declare const Vertical: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: React.NamedExoticComponent<import('..').ButtonGroupBaseProps>;
};
export default _default;
//# sourceMappingURL=ButtonGroup.stories.d.ts.map
