import React from 'react';
import { type AvatarButtonProps } from '../AvatarButton';
declare const _default: {
  component: (<AsComponent extends React.ElementType = 'button'>(
    props: AvatarButtonProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
  title: string;
};
export default _default;
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=AvatarButton.stories.d.ts.map
