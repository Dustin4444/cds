import React from 'react';
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
export declare const Sheet1: () => import('react/jsx-runtime').JSX.Element;
export declare const Sheet2: () => import('react/jsx-runtime').JSX.Element;
export declare const Sheet3: () => import('react/jsx-runtime').JSX.Element;
export declare const Sheet4: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: (<AsComponent extends React.ElementType = 'button'>(
    props: import('..').IconButtonProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
};
export default _default;
//# sourceMappingURL=IconButton.stories.d.ts.map
