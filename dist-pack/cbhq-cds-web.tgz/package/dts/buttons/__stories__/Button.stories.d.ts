import React from 'react';
declare const _default: {
  component: (<AsComponent extends React.ElementType = 'button'>(
    props: import('..').ButtonProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
  title: string;
};
export default _default;
export declare const CreateButtonStories: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomEndIconButton: () => import('react/jsx-runtime').JSX.Element;
export declare const FlushProps: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Button.stories.d.ts.map
