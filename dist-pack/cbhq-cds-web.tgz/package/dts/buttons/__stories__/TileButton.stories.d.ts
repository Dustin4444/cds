import React from 'react';
declare const _default: {
  title: string;
  component: (<AsComponent extends React.ElementType = 'button'>(
    props: import('..').TileButtonProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
};
export default _default;
export declare const TileButtonPictogram: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
//# sourceMappingURL=TileButton.stories.d.ts.map
