export declare const ToggleLoading: ({
  compact,
}: {
  compact?: boolean;
}) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=ToggleLoading.d.ts.map
