import './styles/global';
//# sourceMappingURL=globalStyles.d.ts.map
