import type { ResponsiveProp } from '../styles/styleProps';
/**
 * Resolves a ResponsiveProp to a single value based on the current viewport.
 *
 * Use this when you need the resolved value in JavaScript (e.g., passing to a child
 * component or using in conditional logic). For applying responsive styles via CSS,
 * use getStyles from styleProps instead—it handles responsive objects via
 * media-query CSS variables.
 *
 * Reads getSnapshot from MediaQueryContext when within MediaQueryProvider.
 * Without it, returns the first defined value (base ?? phone ?? tablet ?? desktop).
 *
 * @param value - A scalar value or responsive object with base/phone/tablet/desktop keys
 * @returns The resolved value for the current breakpoint
 */
export declare const useResolveResponsiveProp: <T>(value: ResponsiveProp<T> | undefined) => T | undefined;
//# sourceMappingURL=useResolveResponsiveProp.d.ts.map