import { useLayoutEffect } from 'react';
export declare const useIsoEffect: typeof useLayoutEffect;
//# sourceMappingURL=useIsoEffect.d.ts.map
