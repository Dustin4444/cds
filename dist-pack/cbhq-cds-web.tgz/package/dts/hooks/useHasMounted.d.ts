export declare const useHasMounted: () => boolean;
//# sourceMappingURL=useHasMounted.d.ts.map
