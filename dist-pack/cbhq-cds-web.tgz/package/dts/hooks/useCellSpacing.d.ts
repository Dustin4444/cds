import type { CellSpacing } from '../cells/Cell';
export declare const innerDefaults: {
    readonly paddingX: 2;
    readonly paddingY: 1;
    readonly marginX: -2;
};
export declare const outerDefaults: {
    readonly paddingX: 3;
    readonly paddingY: 1;
    readonly marginX: 0;
};
export type UseCellSpacingParams = {
    innerSpacing?: CellSpacing;
    outerSpacing?: CellSpacing;
};
/**
 * Takes the inner and outerSpacing props from the Cell component and merges with their default values.
 */
export declare function useCellSpacing({ innerSpacing, outerSpacing, }?: UseCellSpacingParams | undefined): {
    readonly inner: {
        readonly padding?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        paddingX: import("@cbhq/cds-common").ThemeVars.Space | import("../styles/styleProps").ResponsiveValue<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        paddingY: import("@cbhq/cds-common").ThemeVars.Space | import("../styles/styleProps").ResponsiveValue<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingTop?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingBottom?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingStart?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingEnd?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly margin?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        marginX: 0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | import("../styles/styleProps").ResponsiveValue<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginY?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginTop?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginBottom?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginEnd?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginStart?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
    };
    readonly outer: {
        readonly padding?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        paddingX: import("@cbhq/cds-common").ThemeVars.Space | import("../styles/styleProps").ResponsiveValue<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        paddingY: import("@cbhq/cds-common").ThemeVars.Space | import("../styles/styleProps").ResponsiveValue<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingTop?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingBottom?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingStart?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly paddingEnd?: import("../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space | undefined>;
        readonly margin?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        marginX: 0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | import("../styles/styleProps").ResponsiveValue<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginY?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginTop?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginBottom?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginEnd?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
        readonly marginStart?: import("../styles/styleProps").ResponsiveProp<0 | -1 | -2 | -5 | -10 | -0.25 | -0.5 | -0.75 | -1.5 | -3 | -4 | -6 | -7 | -8 | -9 | undefined>;
    };
};
//# sourceMappingURL=useCellSpacing.d.ts.map