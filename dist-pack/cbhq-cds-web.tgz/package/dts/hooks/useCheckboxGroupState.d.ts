import type { GroupToggleState } from '@cbhq/cds-common/hooks/useGroupToggler';
export type CheckboxGroupStateProps<CheckboxValue extends string> = {
  select: React.ChangeEventHandler<HTMLInputElement>;
  unselect: React.ChangeEventHandler<HTMLInputElement>;
  toggle: React.ChangeEventHandler<HTMLInputElement>;
  isAllSelected: GroupToggleState<CheckboxValue>['isAllSelected'];
};
/**
 *
 * @param values - An array of all possible options. Make sure the array doesn't change if it's the same values so that the handlers will also stay the same.
 * @param initialState - Initial checked option values.
 * @deprecated Do not use this. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 * @returns [
 *  state,
    {
      select,
      unselect,
      toggle,
      isAllSelected,
    }
  ]
 */
export declare const useCheckboxGroupState: <CheckboxValue extends string>(
  values: CheckboxValue[],
  initialState?: CheckboxValue[],
) => [Set<CheckboxValue>, CheckboxGroupStateProps<CheckboxValue>];
//# sourceMappingURL=useCheckboxGroupState.d.ts.map
