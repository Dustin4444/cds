export declare const useScrollBlocker: () => (shouldBlock: boolean) => void;
//# sourceMappingURL=useScrollBlocker.d.ts.map
