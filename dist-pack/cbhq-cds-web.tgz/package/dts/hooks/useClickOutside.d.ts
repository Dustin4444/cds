/**
 * Options for configuring the useClickOutside hook
 */
export type ClickOutsideOptions = {
    /** Reference to the element to detect clicks outside of */
    ref?: React.MutableRefObject<HTMLElement | null>;
    /** Array of refs that should be excluded from triggering the outside click handler */
    excludeRefs?: React.MutableRefObject<HTMLElement | null>[];
};
/**
 * Hook that detects clicks outside of a specified element and triggers a callback
 * @param callback - Function to call when a click outside is detected
 * @param options - Configuration options for the hook
 * @returns A ref to attach to the element you want to detect clicks outside of
 */
export declare const useClickOutside: (callback: () => void, { ref, excludeRefs }?: ClickOutsideOptions) => import("react").MutableRefObject<HTMLElement | null>;
//# sourceMappingURL=useClickOutside.d.ts.map