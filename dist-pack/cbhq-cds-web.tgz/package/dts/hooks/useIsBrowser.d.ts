/** Checks to see that there is a window and the DOM has mounted */
export declare const useIsBrowser: () => boolean;
//# sourceMappingURL=useIsBrowser.d.ts.map
