export type DeviceBreakpointValues =
  | 'isPhone'
  | 'isPhonePortrait'
  | 'isPhoneLandscape'
  | 'isTablet'
  | 'isTabletPortrait'
  | 'isTabletLandscape'
  | 'isDesktop'
  | 'isDesktopSmall'
  | 'isDesktopLarge'
  | 'isExtraWide';
type BreakpointRecord = Record<DeviceBreakpointValues, boolean>;
/**
 * Only use this hook to conditionally render large component trees or logic
 * @returns isPhone, isPhoneLandscape, isTablet, isTabletLandscape, isDesktop, isDesktopLarge, isExtraWide
 */
export declare const useBreakpoints: () => BreakpointRecord;
export {};
//# sourceMappingURL=useBreakpoints.d.ts.map
