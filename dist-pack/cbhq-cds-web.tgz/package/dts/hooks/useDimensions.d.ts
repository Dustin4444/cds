import type { RefObject } from 'react';
export declare const observerErr = "\uD83D\uDCA1 react-cool-dimensions: the browser doesn't support Resize Observer, please use polyfill: https://github.com/wellyshen/react-cool-dimensions#resizeobserver-polyfill";
export declare const borderBoxWarn = "\uD83D\uDCA1 react-cool-dimensions: the browser doesn't support border-box size, fallback to content-box size. Please see: https://github.com/wellyshen/react-cool-dimensions#border-box-size-measurement";
type State = {
    currentBreakpoint: string;
    width: number;
    height: number;
    x: number;
    y: number;
    entry?: ResizeObserverEntry;
};
export type Event<T> = {
    entry: ResizeObserverEntry;
    observe: (element: T | null) => void;
    unobserve: () => void;
} & State;
type OnResize<T> = {
    (event: Event<T>): void;
};
type ShouldUpdate = {
    (state: State): boolean;
};
type Breakpoints = Record<string, number>;
export type Options<T> = {
    ref?: RefObject<T | null> | null;
    useBorderBoxSize?: boolean;
    breakpoints?: Breakpoints;
    updateOnBreakpointChange?: boolean;
    shouldUpdate?: ShouldUpdate;
    onResize?: OnResize<T>;
    polyfill?: any;
};
type Return<T> = {
    ref: RefObject<T | null>;
    entry?: ResizeObserverEntry;
} & Omit<Event<T>, 'entry'>;
/**
 *
 * Ported from react-cool-dimensions
 * @link https://github.com/wellyshen/react-cool-dimensions
 * Copyright (c) 2020 Welly Shen

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
 */
export declare const useDimensions: <T extends HTMLElement>({ ref: refOpt, useBorderBoxSize, breakpoints, updateOnBreakpointChange, shouldUpdate, onResize, polyfill, }?: Options<T>) => Return<T>;
export {};
//# sourceMappingURL=useDimensions.d.ts.map