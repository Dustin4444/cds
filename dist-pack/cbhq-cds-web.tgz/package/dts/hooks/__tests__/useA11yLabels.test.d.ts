export {};
//# sourceMappingURL=useA11yLabels.test.d.ts.map
