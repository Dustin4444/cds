export {};
//# sourceMappingURL=useIsBrowser.test.d.ts.map
