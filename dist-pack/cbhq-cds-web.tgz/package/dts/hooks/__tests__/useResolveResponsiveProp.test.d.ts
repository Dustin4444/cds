export {};
//# sourceMappingURL=useResolveResponsiveProp.test.d.ts.map