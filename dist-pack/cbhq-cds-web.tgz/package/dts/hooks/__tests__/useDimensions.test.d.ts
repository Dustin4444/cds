export {};
//# sourceMappingURL=useDimensions.test.d.ts.map
