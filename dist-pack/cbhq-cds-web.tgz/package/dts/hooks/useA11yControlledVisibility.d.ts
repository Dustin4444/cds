export type AriaHasPopupType = 'false' | 'true' | 'menu' | 'listbox' | 'tree' | 'grid' | 'dialog';
export type Options = {
  accessibilityLabel?: string;
  hasPopupType?: AriaHasPopupType;
};
export type AccessibleControlledReturnType = {
  triggerAccessibilityProps: {
    'aria-expanded': boolean;
    'aria-controls': string;
    'aria-haspopup': AriaHasPopupType;
  };
  controlledElementAccessibilityProps: {
    id: string;
    accessibilityLabel?: string;
  };
};
/** hook that generates unique aria labels and attributes for trigger element that controls the visibility of another controlled element */
export declare const useA11yControlledVisibility: (
  isVisible: boolean,
  { accessibilityLabel, hasPopupType }?: Options | undefined,
) => AccessibleControlledReturnType;
//# sourceMappingURL=useA11yControlledVisibility.d.ts.map
