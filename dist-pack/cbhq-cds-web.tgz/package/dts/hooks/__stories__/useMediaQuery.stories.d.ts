export declare const DefaultToDevice: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    percy: {
      enableJavaScript: boolean;
    };
  };
};
declare const _default: {
  title: string;
  component: () => import('react/jsx-runtime').JSX.Element;
};
export default _default;
//# sourceMappingURL=useMediaQuery.stories.d.ts.map
