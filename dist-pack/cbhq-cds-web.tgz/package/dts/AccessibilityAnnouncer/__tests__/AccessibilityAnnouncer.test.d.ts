export {};
//# sourceMappingURL=AccessibilityAnnouncer.test.d.ts.map
