import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
export type AccessibilityAnnouncerProps = Omit<{
    /** The aria-live attribute
     * @default polite
     */
    politeness?: React.AriaAttributes['aria-live'];
    /** The message to announce */
    message?: string | null;
}, 'children'> & SharedProps;
export declare const AccessibilityAnnouncer: React.NamedExoticComponent<Omit<{
    /** The aria-live attribute
     * @default polite
     */
    politeness?: React.AriaAttributes["aria-live"];
    /** The message to announce */
    message?: string | null;
}, "children"> & SharedProps & React.RefAttributes<HTMLParagraphElement>>;
//# sourceMappingURL=AccessibilityAnnouncer.d.ts.map