import type { StoryObj } from '@storybook/react';
import type { AccessibilityAnnouncerProps } from '../AccessibilityAnnouncer';
declare const meta: {
    title: string;
    component: ({ message, ...rest }: AccessibilityAnnouncerProps) => import("react/jsx-runtime").JSX.Element;
    args: {
        message: string;
    };
};
export default meta;
type Story = StoryObj<typeof meta>;
export declare const Default: Story;
export declare const Assertive: Story;
//# sourceMappingURL=AccessibilityAnnouncer.stories.d.ts.map