export * from './AccessibilityAnnouncer';
//# sourceMappingURL=index.d.ts.map
