import './styles/defaultFont';
//# sourceMappingURL=defaultFontStyles.d.ts.map
