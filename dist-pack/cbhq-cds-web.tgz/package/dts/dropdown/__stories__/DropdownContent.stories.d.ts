import type { DropdownContentProps } from '../DropdownContent';
export declare const DropdownContentExamples: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: (
    props: Pick<DropdownContentProps, 'placement'>,
  ) => import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      test: string;
    };
  };
};
export default _default;
//# sourceMappingURL=DropdownContent.stories.d.ts.map
