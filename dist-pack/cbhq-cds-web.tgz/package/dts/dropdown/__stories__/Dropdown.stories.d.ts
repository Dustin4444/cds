import React from 'react';
import type { DropdownProps, DropdownRef } from '../DropdownProps';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<import("@cbhq/cds-common").SharedProps & Pick<import("../../overlays").PopoverBaseProps, "content" | "block" | "children" | "disableTypeFocus" | "respectNegativeTabIndex" | "controlledElementAccessibilityProps" | "showOverlay" | "contentPosition"> & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityLabelledBy" | "accessibilityHint"> & {
        enableMobileModal?: boolean;
        disableCloseOnOptionChange?: boolean;
        value?: string;
        onOpenMenu?: () => void;
        onCloseMenu?: () => void;
        onBlur?: () => void;
        disablePortal?: boolean;
        onChange?: ((newValue: string) => void) | React.Dispatch<React.SetStateAction<string>>;
        disabled?: boolean;
        restoreFocusOnUnmount?: boolean;
    } & {
        width?: React.CSSProperties["width"];
        minWidth?: React.CSSProperties["minWidth"];
        maxWidth?: React.CSSProperties["maxWidth"];
        maxHeight?: React.CSSProperties["maxHeight"];
    } & React.RefAttributes<DropdownRef>>;
    parameters: {
        a11y: {
            test: string;
        };
    };
};
export default _default;
type MockDropdownProps = {
    subjectTestID?: string;
    options?: string[];
    containerHeight?: number | string;
    customAriaControlsID?: string;
} & Pick<DropdownProps, 'enableMobileModal' | 'showOverlay' | 'testID' | 'onBlur' | 'onCloseMenu' | 'disablePortal' | 'disabled' | 'value' | 'maxHeight' | 'enableMobileModal'>;
export declare const Default: ({ options, containerHeight, disabled, subjectTestID, customAriaControlsID, enableMobileModal, ...props }: MockDropdownProps) => import("react/jsx-runtime").JSX.Element;
export declare const Wrapped: () => import("react/jsx-runtime").JSX.Element;
export declare const WrappedMobileModal: () => import("react/jsx-runtime").JSX.Element;
export declare const SubMenu: () => import("react/jsx-runtime").JSX.Element;
export declare const ShowOverlay: () => import("react/jsx-runtime").JSX.Element;
export declare const MobileModal: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomOptions: () => import("react/jsx-runtime").JSX.Element;
export declare const Disabled: () => import("react/jsx-runtime").JSX.Element;
export declare const LongText: () => import("react/jsx-runtime").JSX.Element;
export declare const WithMobileModal: () => import("react/jsx-runtime").JSX.Element;
export declare const WithMaxHeightHigherThanContent: () => import("react/jsx-runtime").JSX.Element;
export declare const WithPercentMaxHeight: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Dropdown.stories.d.ts.map