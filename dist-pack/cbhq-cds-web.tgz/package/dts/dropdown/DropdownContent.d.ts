import React from 'react';
import type { Placement } from '../overlays/popover/PopoverProps';
import type { DropdownProps } from './DropdownProps';
export type DropdownContentProps = {
    height?: React.CSSProperties['height'];
    placement?: Placement;
} & Pick<DropdownProps, 'width' | 'maxHeight' | 'maxWidth' | 'minWidth' | 'children'>;
export declare const DropdownContent: React.NamedExoticComponent<{
    height?: React.CSSProperties["height"];
    placement?: Placement;
} & Pick<DropdownProps, "width" | "minWidth" | "maxWidth" | "maxHeight" | "children"> & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=DropdownContent.d.ts.map