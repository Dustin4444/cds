import type React from 'react';
import type { RectReadOnly } from 'react-use-measure';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import { type PopoverContentPositionConfig } from '../overlays/popover/PopoverProps';
type UseResponsiveHeightParams = {
    gap?: ThemeVars.Space;
    dropdownBounds: RectReadOnly;
    maxHeight?: React.CSSProperties['maxHeight'];
    visible: boolean;
    placement: PopoverContentPositionConfig['placement'];
};
export declare function useResponsiveHeight({ gap, dropdownBounds, maxHeight, visible, placement, }: UseResponsiveHeightParams): {
    dropdownHeight: import("csstype").Property.MaxHeight<string | number> | undefined;
};
export {};
//# sourceMappingURL=useResponsiveHeight.d.ts.map