import React from 'react';
import type { SelectOptionProps } from '../controls/SelectOption';
import type { Polymorphic } from '../core/polymorphism';
import { type PressableBaseProps } from '../system/Pressable';
export declare const menuitemDefaultElement = 'button';
export type MenuitemDefaultElement = typeof menuitemDefaultElement;
export type MenuitemBaseProps = Polymorphic.ExtendableProps<
  PressableBaseProps,
  {
    children: NonNullable<React.ReactNode>;
  } & Pick<SelectOptionProps, 'disableCloseOnOptionChange' | 'value' | 'tabIndex'>
>;
export type MenuitemProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  MenuitemBaseProps
>;
type MenuitemComponent = (<AsComponent extends React.ElementType = MenuitemDefaultElement>(
  props: MenuitemProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const MenuItem: MenuitemComponent;
export {};
//# sourceMappingURL=MenuItem.d.ts.map
