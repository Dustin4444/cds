import React from 'react';
import type { DropdownRef } from './DropdownProps';
export declare const DROPDOWN_MAX_HEIGHT = 300;
export type { DropdownBaseProps } from './DropdownProps';
export declare const Dropdown: React.NamedExoticComponent<import("@cbhq/cds-common").SharedProps & Pick<import("../overlays").PopoverBaseProps, "content" | "block" | "children" | "disableTypeFocus" | "respectNegativeTabIndex" | "controlledElementAccessibilityProps" | "showOverlay" | "contentPosition"> & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityLabelledBy" | "accessibilityHint"> & {
    enableMobileModal?: boolean;
    disableCloseOnOptionChange?: boolean;
    value?: string;
    onOpenMenu?: () => void;
    onCloseMenu?: () => void;
    onBlur?: () => void;
    disablePortal?: boolean;
    onChange?: ((newValue: string) => void) | React.Dispatch<React.SetStateAction<string>>;
    disabled?: boolean;
    restoreFocusOnUnmount?: boolean;
} & {
    width?: React.CSSProperties["width"];
    minWidth?: React.CSSProperties["minWidth"];
    maxWidth?: React.CSSProperties["maxWidth"];
    maxHeight?: React.CSSProperties["maxHeight"];
} & React.RefAttributes<DropdownRef>>;
//# sourceMappingURL=Dropdown.d.ts.map