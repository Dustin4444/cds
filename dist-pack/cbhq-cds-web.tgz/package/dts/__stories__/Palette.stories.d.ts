export declare const Default: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: () => import('react/jsx-runtime').JSX.Element;
};
export default _default;
//# sourceMappingURL=Palette.stories.d.ts.map
