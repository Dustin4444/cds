import type { ComponentConfig } from '../../core/componentConfig';
export declare const customComponentConfig: ComponentConfig;
//# sourceMappingURL=customComponentConfig.d.ts.map
