import { type BoxDefaultElement, type BoxProps } from '@cbhq/cds-web/layout/Box';
type ContainerProps = Omit<BoxProps<BoxDefaultElement>, 'title'> & {
  title?: string;
};
export declare const Container: import('react').MemoExoticComponent<
  ({
    background,
    alignSelf,
    alignItems,
    flexDirection,
    justifyContent,
    flexWrap,
    flexGrow,
    flexShrink,
    width,
    borderRadius,
    position,
    padding,
    gap,
    children,
    title,
    ...props
  }: ContainerProps) => import('react/jsx-runtime').JSX.Element
>;
export {};
//# sourceMappingURL=Container.d.ts.map
