export declare const TextInputExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=TextInput.d.ts.map
