export declare const ToastExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=ToastExample.d.ts.map
