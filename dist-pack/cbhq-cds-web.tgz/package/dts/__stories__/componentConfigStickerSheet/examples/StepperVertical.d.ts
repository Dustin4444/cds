export declare const StepperVerticalCustomExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=StepperVertical.d.ts.map
