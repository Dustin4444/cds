export declare const SelectExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=Select.d.ts.map
