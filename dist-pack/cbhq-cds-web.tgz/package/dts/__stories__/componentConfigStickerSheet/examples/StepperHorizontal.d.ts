export declare const StepperHorizontalBasicExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=StepperHorizontal.d.ts.map
