export declare const SegmentedTabsExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=SegmentedTabs.d.ts.map
