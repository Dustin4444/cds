export declare const DatePickerExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=DatePicker.d.ts.map
