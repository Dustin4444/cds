export declare const RollingNumberExample: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=RollingNumber.d.ts.map
