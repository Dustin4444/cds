import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { BannerVariant, ButtonVariant, TagColorScheme } from '@cbhq/cds-common/types';
export declare const space: ThemeVars.Space[];
export declare const iconSizes: ThemeVars.IconSize[];
export declare const avatarSizes: ThemeVars.AvatarSize[];
export declare const borderRadii: ThemeVars.BorderRadius[];
export declare const borderWidths: ThemeVars.BorderWidth[];
export declare const buttonVariants: ButtonVariant[];
export declare const tagColorSchemes: TagColorScheme[];
export declare const bannerVariants: BannerVariant[];
export declare const spectrumHues: ThemeVars.SpectrumHue[];
export declare const spectrumHueSteps: ThemeVars.SpectrumHueStep[];
//# sourceMappingURL=themeVars.d.ts.map
