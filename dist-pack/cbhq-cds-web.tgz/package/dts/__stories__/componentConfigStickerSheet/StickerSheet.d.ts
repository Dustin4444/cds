export declare const StickerSheet: import('react').MemoExoticComponent<
  () => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=StickerSheet.d.ts.map
