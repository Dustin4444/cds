import { type TextDefaultElement, type TextProps } from '@cbhq/cds-web/typography/Text';
export declare const BodyText: import('react').MemoExoticComponent<
  ({ style, ...props }: TextProps<TextDefaultElement>) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=BodyText.d.ts.map
