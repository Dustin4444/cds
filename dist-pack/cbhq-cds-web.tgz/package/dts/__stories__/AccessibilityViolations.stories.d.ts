export declare const Default: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  component: () => import('react/jsx-runtime').JSX.Element;
  title: string;
  parameters: {
    a11y: {
      test: string;
    };
  };
};
export default _default;
//# sourceMappingURL=AccessibilityViolations.stories.d.ts.map
