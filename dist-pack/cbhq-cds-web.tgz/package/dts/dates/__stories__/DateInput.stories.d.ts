import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("..").DateInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
};
export default _default;
export declare const Examples: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
export declare const Props: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
export declare const CustomLabel: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
//# sourceMappingURL=DateInput.stories.d.ts.map