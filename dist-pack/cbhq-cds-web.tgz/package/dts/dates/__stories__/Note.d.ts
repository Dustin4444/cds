import React from 'react';
export declare const Note: ({
  children,
}: {
  children: React.ReactNode;
}) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Note.d.ts.map
