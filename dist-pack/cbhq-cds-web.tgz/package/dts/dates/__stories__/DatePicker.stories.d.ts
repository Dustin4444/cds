declare const _default: {
    title: string;
    component: import("react").NamedExoticComponent<Omit<import("..").DatePickerProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
};
export default _default;
export declare const Examples: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
export declare const AccessibilityLabels: () => import("react/jsx-runtime").JSX.Element;
export declare const MultiplePickers: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
export declare const CustomErrors: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
export declare const CustomLabel: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
//# sourceMappingURL=DatePicker.stories.d.ts.map