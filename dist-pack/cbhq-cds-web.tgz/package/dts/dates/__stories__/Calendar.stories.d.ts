import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("../../layout").BoxBaseProps, "children"> & {
        selectedDate?: Date | null;
        seedDate?: Date;
        onPressDate?: (date: Date) => void;
        disabled?: boolean;
        hideControls?: boolean;
        disabledDates?: (Date | [Date, Date])[];
        highlightedDates?: (Date | [Date, Date])[];
        minDate?: Date;
        maxDate?: Date;
        disabledDateError?: string;
        nextArrowAccessibilityLabel?: string;
        previousArrowAccessibilityLabel?: string;
        highlightedDateAccessibilityHint?: string;
    } & import("../../types").StylesAndClassNames<{
        readonly root: "cds-Calendar";
        readonly header: "cds-Calendar-header";
        readonly title: "cds-Calendar-title";
        readonly navigation: "cds-Calendar-navigation";
        readonly content: "cds-Calendar-content";
        readonly day: "cds-Calendar-day";
    }> & Omit<import("../../layout").VStackProps<"div">, "ref" | "children"> & {
        className?: string;
        style?: React.CSSProperties;
    } & React.RefAttributes<HTMLElement>>;
};
export default _default;
export declare const Examples: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
export declare const Props: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
export declare const SlotStyling: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            disable: boolean;
        };
    };
};
//# sourceMappingURL=Calendar.stories.d.ts.map