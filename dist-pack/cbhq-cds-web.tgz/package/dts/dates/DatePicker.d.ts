import type { DateInputValidationError } from '@cbhq/cds-common/dates/DateInputValidationError';
import { type PopoverProps } from '../overlays/popover/PopoverProps';
import { type CalendarBaseProps } from './Calendar';
import { type DateInputProps } from './DateInput';
export type DatePickerBaseProps = Pick<CalendarBaseProps, 'disabled' | 'disabledDates' | 'disabledDateError' | 'highlightedDateAccessibilityHint' | 'highlightedDates' | 'maxDate' | 'minDate' | 'nextArrowAccessibilityLabel' | 'previousArrowAccessibilityLabel' | 'seedDate'> & {
    /** Control the date value of the DatePicker. */
    date: Date | null;
    /** Callback function fired when the date changes, e.g. when a valid date is selected or unselected. */
    onChangeDate: (selectedDate: Date | null) => void;
    /** Control the error value of the DatePicker. */
    error: DateInputValidationError | null;
    /** Callback function fired when validation finds an error, e.g. required input fields and impossible or disabled dates. Will always be called after `onChangeDate`. */
    onErrorDate: (error: DateInputValidationError | null) => void;
    /** Callback function fired when the picker is opened. */
    onOpen?: () => void;
    /** Callback function fired when the picker is closed. Will always be called after `onCancel`, `onConfirm`, and `onChangeDate`. */
    onClose?: () => void;
    /** Callback function fired when the user selects a date using the picker. Interacting with the DateInput does not fire this callback. Will always be called before `onClose`. */
    onConfirm?: () => void;
    /** Callback function fired when the user closes the picker without selecting a date. Interacting with the DateInput does not fire this callback. Will always be called before `onClose`. */
    onCancel?: () => void;
    /**
     * Accessibility label describing the calendar IconButton, which opens the calendar when pressed.
     * @deprecated Use openCalendarAccessibilityLabel/closeCalendarAccessibilityLabel instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    calendarIconButtonAccessibilityLabel?: string;
    /**
     * Accessibility label for the calendar IconButton when the popover is closed (opens the calendar when pressed).
     * @default 'Open calendar'
     */
    openCalendarAccessibilityLabel?: string;
    /**
     * Accessibility label for the calendar IconButton when the popover is open (closes the calendar when pressed).
     * @default 'Close calendar'
     */
    closeCalendarAccessibilityLabel?: string;
};
export type DatePickerProps = DatePickerBaseProps & Pick<PopoverProps, 'showOverlay'> & Omit<DateInputProps, 'date' | 'separator' | 'onChangeDate' | 'disabledDates' | 'minDate' | 'maxDate' | 'disabledDateError' | 'className' | 'style'> & {
    /** Control the default open state of the Calendar popover. */
    defaultOpen?: boolean;
    /** Callback function fired when the DateInput text value changes. Prefer to use `onChangeDate` instead. Will always be called before `onChangeDate`. This prop should only be used for edge cases, such as custom error handling.  */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    /**
     * If `true`, the focus trap will restore focus to the previously focused element when it unmounts.
     *
     * WARNING: If you disable this, you need to ensure that focus is restored properly so it doesn't end up on the body
     * @default true
     */
    restoreFocusOnUnmount?: boolean;
    /**
     * Custom style to apply to the Calendar container.
     * @deprecated Use `styles.calendar` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    calendarStyle?: React.CSSProperties;
    /**
     * Custom class name to apply to the Calendar container.
     * @deprecated Use `classNames.calendar` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    calendarClassName?: string;
    /**
     * Custom style to apply to the DateInput.
     * @deprecated Use `styles.dateInput` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    dateInputStyle?: React.CSSProperties;
    /**
     * Custom class name to apply to the DateInput.
     * @deprecated Use `classNames.dateInput` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    dateInputClassName?: string;
    /** Custom class names for the DateInput and Calendar subcomponents. */
    classNames?: {
        dateInput?: string;
        calendar?: string;
        calendarHeader?: string;
        calendarTitle?: string;
        calendarNavigation?: string;
        calendarContent?: string;
        calendarDay?: string;
    };
    /** Custom styles for the DateInput and Calendar subcomponents. */
    styles?: {
        dateInput?: React.CSSProperties;
        calendar?: React.CSSProperties;
        calendarHeader?: React.CSSProperties;
        calendarTitle?: React.CSSProperties;
        calendarNavigation?: React.CSSProperties;
        calendarContent?: React.CSSProperties;
        calendarDay?: React.CSSProperties;
    };
};
export declare const DatePicker: import("react").NamedExoticComponent<Omit<DatePickerProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=DatePicker.d.ts.map