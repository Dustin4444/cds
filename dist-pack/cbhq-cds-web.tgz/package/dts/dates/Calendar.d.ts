import React from 'react';
import type { Polymorphic } from '../core/polymorphism';
import { type VStackBaseProps, type VStackDefaultElement, type VStackProps } from '../layout/VStack';
import { type PressableBaseProps } from '../system/Pressable';
import type { StylesAndClassNames } from '../types';
export declare const calendarPressableDefaultElement = "button";
export type CalendarPressableDefaultElement = typeof calendarPressableDefaultElement;
export type CalendarPressableBaseProps = PressableBaseProps;
export type CalendarPressableProps<AsComponent extends React.ElementType> = Polymorphic.Props<AsComponent, CalendarPressableBaseProps>;
export type CalendarDayProps = {
    /** Date of this CalendarDay. */
    date: Date;
    /** Callback function fired when pressing this CalendarDay. */
    onClick?: (date: Date) => void;
    /** Toggle active styles. */
    active?: boolean;
    /** Disables user interaction. */
    disabled?: boolean;
    /** Toggle highlighted styles. */
    highlighted?: boolean;
    /** Toggle today's date styles. */
    isToday?: boolean;
    /** Toggle current month styles. */
    isCurrentMonth?: boolean;
    /** Tooltip content shown when hovering or focusing a disabled Calendar Day. */
    disabledError?: string;
    /** Accessibility hint announced for highlighted dates. */
    highlightedDateAccessibilityHint?: string;
    /** Custom class name for the date cell (CalendarPressable). */
    className?: string;
    /** Custom style for the date cell (CalendarPressable). */
    style?: React.CSSProperties;
};
export type CalendarBaseProps = Omit<VStackBaseProps, 'children'> & {
    /** Currently selected Calendar date. Date used to generate the Calendar month. Will be rendered with active styles. */
    selectedDate?: Date | null;
    /** Date used to generate the Calendar month when there is no value for the `selectedDate` prop, defaults to today. */
    seedDate?: Date;
    /** Callback function fired when pressing a Calendar date. */
    onPressDate?: (date: Date) => void;
    /** Disables user interaction. */
    disabled?: boolean;
    /** Hides the Calendar next and previous month arrows, but does not prevent navigating to the next or previous months via keyboard. This probably only makes sense to be used when `minDate` and `maxDate` are set to the first and last days of the same month. */
    hideControls?: boolean;
    /** Array of disabled dates, and date tuples for date ranges. Make sure to set `disabledDateError` as well. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    disabledDates?: (Date | [Date, Date])[];
    /** Array of highlighted dates, and date tuples for date ranges. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    highlightedDates?: (Date | [Date, Date])[];
    /** Minimum date allowed to be selected, inclusive. Dates before the `minDate` are disabled. All navigation to months before the `minDate` is disabled. */
    minDate?: Date;
    /** Maximum date allowed to be selected, inclusive. Dates after the `maxDate` are disabled. All navigation to months after the `maxDate` is disabled. */
    maxDate?: Date;
    /**
     * Tooltip content shown when hovering or focusing a disabled date, including dates before the `minDate` or after the `maxDate`.
     * @default 'Date unavailable'
     */
    disabledDateError?: string;
    /**
     * Accessibility label describing the Calendar next month arrow.
     * @default 'Go to next month'
     */
    nextArrowAccessibilityLabel?: string;
    /**
     * Accessibility label describing the Calendar previous month arrow.
     * @default 'Go to previous month'
     */
    previousArrowAccessibilityLabel?: string;
    /**
     * Accessibility hint announced for highlighted dates. Applied to all highlighted dates.
     * @default 'Highlighted'
     */
    highlightedDateAccessibilityHint?: string;
};
/**
 * Static class names for Calendar component parts.
 * Use these selectors to target specific elements with CSS.
 */
export declare const calendarClassNames: {
    /** Root element */
    readonly root: "cds-Calendar";
    /** Header section */
    readonly header: "cds-Calendar-header";
    /** Month and year title text element */
    readonly title: "cds-Calendar-title";
    /** Navigation controls element */
    readonly navigation: "cds-Calendar-navigation";
    /** Main content area */
    readonly content: "cds-Calendar-content";
    /** Individual date cell in a calendar grid */
    readonly day: "cds-Calendar-day";
};
export type CalendarProps = CalendarBaseProps & StylesAndClassNames<typeof calendarClassNames> & Omit<VStackProps<VStackDefaultElement>, 'children' | 'ref'> & {
    className?: string;
    style?: React.CSSProperties;
};
export declare const Calendar: React.NamedExoticComponent<Omit<import("../layout").BoxBaseProps, "children"> & {
    /** Currently selected Calendar date. Date used to generate the Calendar month. Will be rendered with active styles. */
    selectedDate?: Date | null;
    /** Date used to generate the Calendar month when there is no value for the `selectedDate` prop, defaults to today. */
    seedDate?: Date;
    /** Callback function fired when pressing a Calendar date. */
    onPressDate?: (date: Date) => void;
    /** Disables user interaction. */
    disabled?: boolean;
    /** Hides the Calendar next and previous month arrows, but does not prevent navigating to the next or previous months via keyboard. This probably only makes sense to be used when `minDate` and `maxDate` are set to the first and last days of the same month. */
    hideControls?: boolean;
    /** Array of disabled dates, and date tuples for date ranges. Make sure to set `disabledDateError` as well. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    disabledDates?: (Date | [Date, Date])[];
    /** Array of highlighted dates, and date tuples for date ranges. A number is created for every individual date within a tuple range, so do not abuse this with massive ranges. */
    highlightedDates?: (Date | [Date, Date])[];
    /** Minimum date allowed to be selected, inclusive. Dates before the `minDate` are disabled. All navigation to months before the `minDate` is disabled. */
    minDate?: Date;
    /** Maximum date allowed to be selected, inclusive. Dates after the `maxDate` are disabled. All navigation to months after the `maxDate` is disabled. */
    maxDate?: Date;
    /**
     * Tooltip content shown when hovering or focusing a disabled date, including dates before the `minDate` or after the `maxDate`.
     * @default 'Date unavailable'
     */
    disabledDateError?: string;
    /**
     * Accessibility label describing the Calendar next month arrow.
     * @default 'Go to next month'
     */
    nextArrowAccessibilityLabel?: string;
    /**
     * Accessibility label describing the Calendar previous month arrow.
     * @default 'Go to previous month'
     */
    previousArrowAccessibilityLabel?: string;
    /**
     * Accessibility hint announced for highlighted dates. Applied to all highlighted dates.
     * @default 'Highlighted'
     */
    highlightedDateAccessibilityHint?: string;
} & StylesAndClassNames<{
    /** Root element */
    readonly root: "cds-Calendar";
    /** Header section */
    readonly header: "cds-Calendar-header";
    /** Month and year title text element */
    readonly title: "cds-Calendar-title";
    /** Navigation controls element */
    readonly navigation: "cds-Calendar-navigation";
    /** Main content area */
    readonly content: "cds-Calendar-content";
    /** Individual date cell in a calendar grid */
    readonly day: "cds-Calendar-day";
}> & Omit<VStackProps<"div">, "ref" | "children"> & {
    className?: string;
    style?: React.CSSProperties;
} & React.RefAttributes<HTMLElement>>;
//# sourceMappingURL=Calendar.d.ts.map