import React from 'react';
import { type DateInputOptions } from '@cbhq/cds-common/dates/useDateInput';
import { type TextInputBaseProps, type TextInputProps } from '../controls/TextInput';
export type DateInputBaseProps = Omit<DateInputOptions, 'intlDateFormat'> & Omit<TextInputBaseProps, 'inputNode' | 'value' | 'defaultValue' | 'style'> & {
    /** Date format separator character, e.g. the / in "MM/DD/YYYY". Defaults to forward slash (/). */
    separator?: string;
};
export type DateInputProps = DateInputBaseProps & Omit<TextInputProps, 'inputNode' | 'value' | 'defaultValue' | 'style'> & {
    className?: string;
    style?: React.CSSProperties;
};
export declare const DateInput: React.NamedExoticComponent<Omit<DateInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=DateInput.d.ts.map