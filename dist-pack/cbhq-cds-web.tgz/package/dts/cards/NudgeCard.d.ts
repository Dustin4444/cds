import React from 'react';
import type { IllustrationPictogramNames } from '@cbhq/cds-common/types/IllustrationNames';
import { type BoxDefaultElement, type BoxProps } from '../layout/Box';
import { type StyleProps } from '../styles/styleProps';
export type NudgeCardBaseProps = {
  /** Text or React.ReactNode to be displayed above the description in a TextHeadline */
  title?: React.ReactNode;
  /** Text or React.ReactNode to be displayed below the title in a TextBody */
  description?: React.ReactNode;
  /** If you pass a Pictogram name it will render a Pictogram to the right of the text content */
  pictogram?: IllustrationPictogramNames;
  /** Pass any node to be rendered to the right of the text content */
  media?: React.ReactNode;
  /** Text or React.ReactNode to display as the call to action */
  action?: React.ReactNode;
  /**
   * Maximum number of lines shown for the title and description text. Text that exceeds will be truncated.
   * @default 3
   */
  numberOfLines?: number;
  /**
   * @default 327
   */
  width?: StyleProps['width'];
  /**
   * @default 160
   */
  minHeight?: StyleProps['minHeight'];
  /**
   * Background color for the card.
   * @default bgAlternate
   */
  background?: StyleProps['background'];
  /**
   * Set the media position for the pictogram or media.
   * @default right
   */
  mediaPosition?: 'left' | 'right';
  /**
   * Callback fired when the action button is pressed
   * Cannot be used when `action` is a React Element, only when `action` is a string
   */
  onActionPress?: React.MouseEventHandler;
  /** Callback fired when the dismiss button is pressed */
  onDismissPress?: React.MouseEventHandler;
};
export type NudgeCardProps = NudgeCardBaseProps & Omit<BoxProps<BoxDefaultElement>, 'title'>;
/**
 * @deprecated Use `MessagingCard` with `type="nudge"` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 *
 * Migration guide:
 * ```tsx
 * // Before
 * <NudgeCard
 *   title="Title"
 *   description="Description"
 *   pictogram="addToWatchlist"
 *   action="Learn more"
 *   onActionPress={handleAction}
 *   onDismissPress={handleDismiss}
 * />
 *
 * // After
 * <MessagingCard
 *   type="nudge"
 *   title="Title"
 *   description="Description"
 *   media={<Pictogram dimension="48x48" name="addToWatchlist" />}
 *   actions={<Button compact variant="secondary">Learn more</Button>}
 *   onDismiss={handleDismiss}
 *   mediaPlacement="end"
 * />
 * ```
 */
export declare const NudgeCard: ({
  title,
  description,
  pictogram,
  media,
  mediaPosition,
  action,
  className,
  onActionPress,
  numberOfLines,
  onDismissPress,
  width,
  minWidth,
  testID,
  accessibilityLabel,
  maxHeight,
  maxWidth,
  background,
  minHeight,
  height,
  aspectRatio,
  onClick,
  ...props
}: NudgeCardProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=NudgeCard.d.ts.map
