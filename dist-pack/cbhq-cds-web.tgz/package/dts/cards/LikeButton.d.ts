import type { SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common/types';
import { type PressableDefaultElement, type PressableProps } from '../system/Pressable';
export type LikeButtonBaseProps = Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityHint'> & SharedProps & {
    liked?: boolean;
    count?: number;
    /** Use the compact variant. */
    compact?: boolean;
    /** Ensure the button aligns flush on the left or right.
     * This prop will translate the entire button left/right,
     * so take care to ensure it is not overflowing awkwardly
     */
    flush?: 'start' | 'end';
};
export type LikeButtonProps = LikeButtonBaseProps & PressableProps<PressableDefaultElement>;
export declare const LikeButton: import("react").NamedExoticComponent<LikeButtonProps>;
//# sourceMappingURL=LikeButton.d.ts.map