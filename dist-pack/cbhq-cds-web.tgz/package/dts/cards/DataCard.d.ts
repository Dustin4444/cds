/**
 * @deprecated This component is deprecated. Please use the alpha `DataCard` from `@cbhq/cds-web/alpha/data-card` instead.
 *
 * ### Migration Guide
 *
 * The new `DataCard` provides more flexibility with custom layouts and visualization components.
 *
 * **Before:**
 * ```jsx
 * <DataCard
 *   title="Progress"
 *   description="45% complete"
 *   progress={0.45}
 *   progressVariant="bar"
 *   startLabel="0"
 *   endLabel="45"
 * />
 * ```
 *
 * **After:**
 * ```jsx
 * import { DataCard } from '@cbhq/cds-web/alpha/data-card';
 *
 * <DataCard
 *   title="Progress"
 *   subtitle="45% complete"
 *   layout="vertical"
 *   thumbnail={<RemoteImage src={assetUrl} shape="circle" size="l" />}
 * >
 *   <ProgressBarWithFixedLabels startLabel={0} endLabel={45} labelPlacement="below">
 *     <ProgressBar accessibilityLabel="45% complete" progress={0.45} weight="semiheavy" />
 *   </ProgressBarWithFixedLabels>
 * </DataCard>
 * ```
 */
import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type CardBaseProps } from './Card';
export type DataCardBaseProps = CardBaseProps &
  SharedProps & {
    onClick?: CardBaseProps['onClick'];
    /** Text to be displayed in TextHeadline under CardHeader section. */
    title: string;
    /** Text to be displayed in TextLabel2 under title. */
    description: string;
    startLabel?: string;
    endLabel?: string;
    progressVariant?: 'bar' | 'circle';
    progress?: number;
    progressColor?: ThemeVars.Color;
  };
export type DataCardProps = DataCardBaseProps;
export declare const DataCard: React.NamedExoticComponent<DataCardBaseProps>;
//# sourceMappingURL=DataCard.d.ts.map
