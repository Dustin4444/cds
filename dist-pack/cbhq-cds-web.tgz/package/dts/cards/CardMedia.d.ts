import React from 'react';
import type { CardMediaProps } from '@cbhq/cds-common/types';
/**
 * @deprecated Use SpotSquare when `type` is "spotSquare", Pictogram when `type` is "pictogram", or RemoteImage when `type` is "image". This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const CardMedia: React.NamedExoticComponent<CardMediaProps>;
//# sourceMappingURL=CardMedia.d.ts.map
