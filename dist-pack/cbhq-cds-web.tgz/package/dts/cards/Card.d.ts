import React, { type HTMLAttributes, type MouseEventHandler } from 'react';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types';
import type { BoxBaseProps, BoxDefaultElement, BoxProps } from '../layout/Box';
import { type PressableProps } from '../system/Pressable';
export type CardBaseProps = Pick<SharedAccessibilityProps, 'id'> & Pick<PressableProps<'a'>, 'href' | 'target' | 'background' | 'noScaleOnPress'> & Omit<BoxBaseProps, 'background'> & {
    /** Size of the card. Small and medium have fixed widths and large grows with its children. */
    size?: 'small' | 'medium' | 'large';
    children?: React.ReactNode;
    onKeyDown?: HTMLAttributes<HTMLElement>['onKeyDown'];
    onKeyUp?: HTMLAttributes<HTMLElement>['onKeyUp'];
    onClick?: MouseEventHandler;
};
/**
 * @deprecated Use `ContentCard`, `MediaCard`, `MessagingCard`, or `DataCard` based on your use case. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardProps = CardBaseProps & Omit<BoxProps<BoxDefaultElement>, 'onClick' | 'onKeyDown' | 'onKeyUp' | 'background'>;
/**
 * @deprecated Use ContentCard instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const Card: React.NamedExoticComponent<CardProps>;
//# sourceMappingURL=Card.d.ts.map