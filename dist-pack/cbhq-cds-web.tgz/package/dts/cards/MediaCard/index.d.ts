import React from 'react';
import type { Polymorphic } from '../../core/polymorphism';
import { type CardRootBaseProps } from '../CardRoot';
import { type MediaCardLayoutProps } from './MediaCardLayout';
export type MediaCardBaseProps = Polymorphic.ExtendableProps<
  Omit<CardRootBaseProps, 'children'>,
  MediaCardLayoutProps & {
    classNames?: {
      /** Root element */
      root?: string;
    };
    styles?: {
      /** Root element */
      root?: React.CSSProperties;
    };
  }
>;
export type MediaCardProps<AsComponent extends React.ElementType = 'article'> = Polymorphic.Props<
  AsComponent,
  MediaCardBaseProps
>;
type MediaCardComponent = (<AsComponent extends React.ElementType = 'article'>(
  props: MediaCardProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const MediaCard: MediaCardComponent;
export {};
//# sourceMappingURL=index.d.ts.map
