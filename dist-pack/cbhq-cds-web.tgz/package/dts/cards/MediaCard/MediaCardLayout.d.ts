import React from 'react';
export type MediaCardLayoutBaseProps = {
  /** Text or React node to display as the card title. Use a Text component to override default color and font. */
  title?: React.ReactNode;
  /** Text or React node to display as the card subtitle. Use a Text component to override default color and font. */
  subtitle?: React.ReactNode;
  /** Text or React node to display as the card description. Use a Text component to override default color and font. */
  description?: React.ReactNode;
  /** React node to display as a thumbnail in the content area. */
  thumbnail: React.ReactNode;
  /** React node to display as the main media content. When provided, it will be rendered in a Box container taking up 50% of the card width. */
  media?: React.ReactNode;
  /** The position of the media within the card.
   * @default 'end'
   */
  mediaPlacement?: 'start' | 'end';
};
export type MediaCardLayoutProps = MediaCardLayoutBaseProps & {
  classNames?: {
    /** Layout container element */
    layoutContainer?: string;
    /** Content container element */
    contentContainer?: string;
    /** Text container element */
    textContainer?: string;
    /** Header container element */
    headerContainer?: string;
    /** Media container element */
    mediaContainer?: string;
  };
  styles?: {
    /** Layout container element */
    layoutContainer?: React.CSSProperties;
    /** Content container element */
    contentContainer?: React.CSSProperties;
    /** Text container element */
    textContainer?: React.CSSProperties;
    /** Header container element */
    headerContainer?: React.CSSProperties;
    /** Media container element */
    mediaContainer?: React.CSSProperties;
  };
};
export declare const MediaCardLayout: React.MemoExoticComponent<
  ({
    title,
    subtitle,
    description,
    thumbnail,
    media,
    mediaPlacement,
    classNames,
    styles,
  }: MediaCardLayoutProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=MediaCardLayout.d.ts.map
