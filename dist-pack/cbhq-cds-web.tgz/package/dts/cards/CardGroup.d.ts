import React from 'react';
import type { GroupProps, RenderGroupItem } from '../layout/Group';
/**
 * @deprecated Use `Box`, `HStack` or `VStack` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardGroupBaseProps = Omit<GroupProps, 'horizontal'>;
/**
 * @deprecated Use `Box`, `HStack` or `VStack` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type CardGroupProps = CardGroupBaseProps;
export type CardGroupRenderItem = RenderGroupItem;
/**
 * @deprecated Use `Box`, `HStack` or `VStack` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const CardGroup: React.NamedExoticComponent<Omit<CardGroupBaseProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=CardGroup.d.ts.map