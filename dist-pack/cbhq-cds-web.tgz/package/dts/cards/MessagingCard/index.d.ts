import type { Polymorphic } from '../../core/polymorphism';
import { type CardRootBaseProps } from '../CardRoot';
import { type MessagingCardLayoutProps } from './MessagingCardLayout';
export type MessagingCardBaseProps = Polymorphic.ExtendableProps<
  Omit<CardRootBaseProps, 'children'>,
  MessagingCardLayoutProps & {
    classNames?: {
      /** Root element */
      root?: string;
    };
    styles?: {
      /** Root element */
      root?: React.CSSProperties;
    };
  }
>;
export type MessagingCardProps<AsComponent extends React.ElementType = 'article'> =
  Polymorphic.Props<AsComponent, MessagingCardBaseProps>;
type MessagingCardComponent = (<AsComponent extends React.ElementType = 'article'>(
  props: MessagingCardProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const MessagingCard: MessagingCardComponent;
export {};
//# sourceMappingURL=index.d.ts.map
