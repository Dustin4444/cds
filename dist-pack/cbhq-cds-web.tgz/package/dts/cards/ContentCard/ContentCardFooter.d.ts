import React from 'react';
import type { Polymorphic } from '../../core/polymorphism';
import { type BoxBaseProps } from '../../layout';
export declare const contentCardFooterDefaultElement = 'footer';
export type ContentCardFooterDefaultElement = typeof contentCardFooterDefaultElement;
export type ContentCardFooterBaseProps = BoxBaseProps;
export type ContentCardFooterProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  ContentCardFooterBaseProps
>;
type ContentCardFooterComponent = (<
  AsComponent extends React.ElementType = ContentCardFooterDefaultElement,
>(
  props: ContentCardFooterProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const ContentCardFooter: ContentCardFooterComponent;
export {};
//# sourceMappingURL=ContentCardFooter.d.ts.map
