import React, { type JSX } from 'react';
export declare const Basic: () => JSX.Element;
export declare const MediaPlacement: () => JSX.Element;
export declare const WithBackground: () => JSX.Element;
/**
 * Pressable Cards
 *
 * To make a ContentCard interactive, wrap it in a Pressable component.
 * For proper accessibility, use `as="div"` on the Pressable to render it as a
 * non-interactive container, then include an internal button for keyboard and
 * screen reader users.
 *
 * This allows:
 * - Mouse/touch users: Click anywhere on the card
 * - Screen reader users: Navigate through card content and focus on the action button
 * - Keyboard users: Tab to the action button
 */
export declare const PressableCards: () => JSX.Element;
export declare const CustomContent: () => JSX.Element;
export declare const ProductCarousel: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
            options: {
                rules: {
                    'target-size': {
                        enabled: boolean;
                    };
                };
            };
        };
    };
};
declare const _default: {
    title: string;
    component: (<AsComponent extends React.ElementType = "article">(props: import("..").ContentCardProps<AsComponent>) => import("../../..").Polymorphic.ReactReturn) & import("../../..").Polymorphic.ReactNamed;
};
export default _default;
//# sourceMappingURL=ContentCard.stories.d.ts.map