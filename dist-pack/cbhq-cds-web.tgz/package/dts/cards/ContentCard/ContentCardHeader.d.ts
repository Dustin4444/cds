import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { Polymorphic } from '../../core/polymorphism';
import { type BoxBaseProps } from '../../layout';
export declare const contentCardHeaderDefaultElement = 'header';
export type ContentCardHeaderDefaultElement = typeof contentCardHeaderDefaultElement;
export type ContentCardHeaderBaseProps = Polymorphic.ExtendableProps<
  BoxBaseProps,
  SharedProps & {
    /**
     * @deprecated Use `thumbnail` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    avatar?: React.ReactNode;
    /** A media object like an image, avatar, illustration, or cryptocurrency asset. */
    thumbnail?: React.ReactNode;
    /** Text or React node to display as the header title. Use a Text component to override default color and font. */
    title: React.ReactNode;
    /**
     * @deprecated Use `subtitle` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    meta?: React.ReactNode;
    /** Text or React node to display as the header subtitle. Use a Text component to override default color and font. */
    subtitle?: React.ReactNode;
    /**
     * @deprecated Use `actions` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    end?: React.ReactNode;
    /** Slot for action buttons. */
    actions?: React.ReactNode;
    styles?: {
      /** Root container element */
      root?: React.CSSProperties;
      /** Text content container (title + subtitle) */
      textContainer?: React.CSSProperties;
      /** Content container (thumbnail + text content) */
      contentContainer?: React.CSSProperties;
    };
    classNames?: {
      /** Root container element */
      root?: string;
      /** Text content container (title + subtitle) */
      textContainer?: string;
      /** Content container (thumbnail + text content) */
      contentContainer?: string;
    };
  }
>;
export type ContentCardHeaderProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  ContentCardHeaderBaseProps
>;
type ContentCardHeaderComponent = (<
  AsComponent extends React.ElementType = ContentCardHeaderDefaultElement,
>(
  props: ContentCardHeaderProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const ContentCardHeader: ContentCardHeaderComponent;
export {};
//# sourceMappingURL=ContentCardHeader.d.ts.map
