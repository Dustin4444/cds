import React from 'react';
import type { Polymorphic } from '../../core/polymorphism';
import { type VStackBaseProps } from '../../layout';
export declare const contentCardDefaultElement = 'article';
export type ContentCardDefaultElement = typeof contentCardDefaultElement;
export type ContentCardBaseProps = Polymorphic.ExtendableProps<VStackBaseProps, object>;
export type ContentCardProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  ContentCardBaseProps
>;
type ContentCardComponent = (<AsComponent extends React.ElementType = ContentCardDefaultElement>(
  props: ContentCardProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const ContentCard: ContentCardComponent;
export {};
//# sourceMappingURL=ContentCard.d.ts.map
