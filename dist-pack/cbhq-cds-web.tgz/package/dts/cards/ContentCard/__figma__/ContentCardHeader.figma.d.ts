export {};
//# sourceMappingURL=ContentCardHeader.figma.d.ts.map
