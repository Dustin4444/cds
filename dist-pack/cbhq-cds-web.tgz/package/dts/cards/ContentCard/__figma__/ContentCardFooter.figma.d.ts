export {};
//# sourceMappingURL=ContentCardFooter.figma.d.ts.map
