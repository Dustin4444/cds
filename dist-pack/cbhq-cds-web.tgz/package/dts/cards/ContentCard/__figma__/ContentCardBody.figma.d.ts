export {};
//# sourceMappingURL=ContentCardBody.figma.d.ts.map
