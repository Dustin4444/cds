import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { Polymorphic } from '../../core/polymorphism';
import { type BoxBaseProps } from '../../layout';
export declare const contentCardBodyDefaultElement = 'div';
export type ContentCardBodyDefaultElement = typeof contentCardBodyDefaultElement;
export type ContentCardBodyBaseProps = Polymorphic.ExtendableProps<
  BoxBaseProps,
  SharedProps & {
    /** Text or React node to display as the card title. Use a Text component to override default color and font. */
    title?: React.ReactNode;
    /**
     * @deprecated Use description instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * Main body copy
     */
    body?: React.ReactNode;
    /** Text or React node to display as the card description. Use a Text component to override default color and font. */
    description?: React.ReactNode;
    /**
     * @deprecated Use a ReactNode as `description` instead if you need to display content below the description. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * Use for supplemental data.
     */
    label?: React.ReactNode;
    /** React node to display as media content (e.g., Image or RemoteImage). */
    media?: React.ReactNode;
    /**
     * @deprecated Use mediaPlacement instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     * The position of the media within the card.
     * Can be one of: 'top', 'bottom', 'right' or 'left'.
     */
    mediaPosition?: 'top' | 'bottom' | 'right' | 'left';
    /** Placement of the media content relative to the text content.
     * @default 'top'
     */
    mediaPlacement?: 'top' | 'bottom' | 'start' | 'end';
    /**
     * Custom content to display below the main content box (title/description/media).
     * Use this when you need to render custom content that doesn't fit the standard media/title/description layout.
     */
    children?: React.ReactNode;
    styles?: {
      /** Root container element (content container + children) */
      root?: React.CSSProperties;
      /** Content container (media + text content) */
      contentContainer?: React.CSSProperties;
      /** Text content container (title + description + label) */
      textContainer?: React.CSSProperties;
      /** Media container element */
      mediaContainer?: React.CSSProperties;
    };
    classNames?: {
      /** Root container element */
      root?: string;
      /** Content container (media + text content) */
      contentContainer?: string;
      /** Text content container (title + description + label) */
      textContainer?: string;
      /** Media container element */
      mediaContainer?: string;
    };
  }
>;
export type ContentCardBodyProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  ContentCardBodyBaseProps
>;
type ContentCardBodyComponent = (<
  AsComponent extends React.ElementType = ContentCardBodyDefaultElement,
>(
  props: ContentCardBodyProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const ContentCardBody: ContentCardBodyComponent;
export {};
//# sourceMappingURL=ContentCardBody.d.ts.map
