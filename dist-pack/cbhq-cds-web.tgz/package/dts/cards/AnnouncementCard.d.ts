import React from 'react';
import { type CardBaseProps } from './Card';
import { type CardBodyBaseProps } from './CardBody';
export type AnnouncementCardBaseProps = CardBaseProps & CardBodyBaseProps;
export type AnnouncementCardProps = AnnouncementCardBaseProps;
/**
 * @deprecated Use MessagingCard instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v6
 */
export declare const AnnouncementCard: React.NamedExoticComponent<AnnouncementCardBaseProps>;
//# sourceMappingURL=AnnouncementCard.d.ts.map
