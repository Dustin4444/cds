import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type BoxDefaultElement, type BoxProps } from '../layout/Box';
export declare const floatingAssetCardLargeWidth = 359;
export declare const floatingAssetCardSmallDimension = 156;
export type FloatingAssetCardBaseProps = SharedProps & {
  /** Text or ReactNode to be displayed above Title */
  subtitle?: React.ReactNode;
  /** Text or ReactNode to be displayed in TextHeadline */
  title: React.ReactNode;
  /** Content to be displayed below the title */
  description?: React.ReactNode;
  /**
   * Remote Image or other node with media content.
   */
  media: React.ReactNode;
  /**
   * Variant for card size. Can be small or large.
   * @default 's'
   */
  size?: 's' | 'l';
};
export type FloatingAssetCardProps = FloatingAssetCardBaseProps &
  Omit<BoxProps<BoxDefaultElement>, 'title'>;
/**
 * @deprecated Use `MediaCard` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 *
 * Migration guide:
 * ```tsx
 * // Before
 * <FloatingAssetCard
 *   title="Asset Title"
 *   subtitle="Subtitle"
 *   description="Description"
 *   media={<RemoteImage ... />}
 * />
 *
 * // After
 * <MediaCard
 *   title="Asset Title"
 *   subtitle="Subtitle"
 *   description="Description"
 *   thumbnail={<RemoteImage ... />}
 * />
 * ```
 *
 * Note: The floating variation (media outside the card container) is no longer supported.
 * MediaCard provides a contained layout with media placement options (start/end).
 */
export declare const FloatingAssetCard: ({
  className,
  title,
  description,
  subtitle,
  media,
  size,
  width,
  testID,
  onClick,
  ...props
}: FloatingAssetCardProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=FloatingAssetCard.d.ts.map
