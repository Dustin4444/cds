import React from 'react';
import type { CardHeaderProps } from '@cbhq/cds-common/types';
/**
 * @deprecated Use ContentCardHeader instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const CardHeader: React.NamedExoticComponent<CardHeaderProps>;
//# sourceMappingURL=CardHeader.d.ts.map
