import React, { type JSX } from 'react';
export declare const BasicTypes: () => JSX.Element;
export declare const Features: () => JSX.Element;
export declare const PolymorphicAndInteractive: () => JSX.Element;
export declare const CustomBackgroundColor: () => JSX.Element;
export declare const TextContent: () => JSX.Element;
export declare const DismissibleCards: () => JSX.Element;
export declare const MultipleCards: () => JSX.Element;
declare const _default: {
    title: string;
    component: (<AsComponent extends React.ElementType = "article">(props: import("..").MessagingCardProps<AsComponent>) => import("../..").Polymorphic.ReactReturn) & import("../..").Polymorphic.ReactNamed;
};
export default _default;
//# sourceMappingURL=MessagingCard.stories.d.ts.map