import { type JSX } from 'react';
export declare const Default: () => JSX.Element;
export declare const Vertical: () => JSX.Element;
export declare const Horizontal: () => JSX.Element;
export declare const LongText: () => JSX.Element;
export declare const Custom: () => JSX.Element;
export declare const Carousel: () => JSX.Element;
declare const _default: {
    title: string;
    component: ({ className, title, description, subtitle, media, size, width, testID, onClick, ...props }: import("..").FloatingAssetCardProps) => import("react/jsx-runtime").JSX.Element;
};
export default _default;
//# sourceMappingURL=FloatingAssetCard.stories.d.ts.map