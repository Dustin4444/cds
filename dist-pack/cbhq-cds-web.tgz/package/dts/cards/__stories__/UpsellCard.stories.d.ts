import React, { type JSX } from 'react';
import { type UpsellCardProps } from '../UpsellCard';
export declare const Default: () => JSX.Element;
export declare const Compact: () => JSX.Element;
export declare const Vertical: () => JSX.Element;
export declare const Horizontal: () => JSX.Element;
export declare const LongText: () => JSX.Element;
export declare const CustomTextNodes: () => JSX.Element;
export declare const CustomBackground: () => JSX.Element;
export declare const CustomWidth: () => JSX.Element;
export declare const Carousel: () => JSX.Element;
declare const _default: {
    title: string;
    component: React.MemoExoticComponent<({ title, description, action, onActionPress, onDismissPress, media, background, dangerouslySetBackground, testID, accessibilityLabel, width, onClick, className, style, }: UpsellCardProps) => import("react/jsx-runtime").JSX.Element>;
};
export default _default;
//# sourceMappingURL=UpsellCard.stories.d.ts.map