import { type JSX } from 'react';
import type { ContainedAssetCardProps } from '../ContainedAssetCard';
export declare const Default: () => JSX.Element;
export declare const LongText: () => JSX.Element;
export declare const Vertical: () => JSX.Element;
export declare const Horizontal: () => JSX.Element;
export declare const Custom: {
    (): JSX.Element;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            options: {
                rules: {
                    'color-contrast': {
                        enabled: boolean;
                    };
                };
            };
        };
    };
};
export declare const Carousel: () => JSX.Element;
export declare const HeaderWithDotColorStatus: () => JSX.Element;
export declare const CustomWidth: () => JSX.Element;
declare const _default: {
    title: string;
    component: ({ header, title, subtitle, description, size, children, className, flexDirection, background, borderRadius, height, width, minWidth, overflow, onClick, testID, ...props }: ContainedAssetCardProps) => import("react/jsx-runtime").JSX.Element;
};
export default _default;
//# sourceMappingURL=ContainedAssetCard.stories.d.ts.map