import React, { type JSX } from 'react';
export declare const Basic: () => JSX.Element;
export declare const MediaPlacement: () => JSX.Element;
export declare const PolymorphicAndInteractive: () => JSX.Element;
export declare const TextContent: () => JSX.Element;
export declare const Styling: () => JSX.Element;
export declare const MultipleCards: () => JSX.Element;
declare const _default: {
    title: string;
    component: (<AsComponent extends React.ElementType = "article">(props: import("..").MediaCardProps<AsComponent>) => import("../..").Polymorphic.ReactReturn) & import("../..").Polymorphic.ReactNamed;
};
export default _default;
//# sourceMappingURL=MediaCard.stories.d.ts.map