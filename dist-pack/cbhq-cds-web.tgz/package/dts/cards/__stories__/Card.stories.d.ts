import React from 'react';
import { baseConfig } from '@cbhq/cds-common/internal/utils/storyBuilder';
import type { Meta, StoryObj } from '@storybook/react';
import type { FeedCardProps } from '../FeedCard';
export declare const AnnouncementCard: import("@cbhq/cds-common/internal/utils/storyBuilder").Story<Omit<Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "id"> & Pick<import("../../system").PressableProps<"a">, "background" | "noScaleOnPress" | "target" | "href"> & Omit<import("../../layout").BoxBaseProps, "background"> & {
    size?: "small" | "medium" | "large";
    children?: React.ReactNode;
    onKeyDown?: React.HTMLAttributes<HTMLElement>["onKeyDown"];
    onKeyUp?: React.HTMLAttributes<HTMLElement>["onKeyUp"];
    onClick?: React.MouseEventHandler;
} & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").StaticStyleProps> & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").DynamicStyleProps> & import("@cbhq/cds-common").SharedProps & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityLabelledBy" | "accessibilityHint"> & {
    style?: React.CSSProperties;
    font?: import("../../styles/styleProps").ResponsiveProp<keyof typeof import("../../styles/responsive/base").fontFamily>;
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & {
    onActionPress?: React.MouseEventHandler;
    title?: React.ReactNode;
    description?: React.ReactNode;
    numberOfLines?: number;
    compact?: boolean;
    children?: React.ReactNode;
    mediaPlacement?: import("..").CardMediaPlacement;
    spotSquare?: import("@cbhq/cds-illustrations").SpotSquareName;
    pictogram?: import("@cbhq/cds-illustrations").PictogramName;
    image?: string;
    media?: React.ReactNode;
    actionLabel?: string;
    action?: React.ReactNode;
}, "children">, {
    readonly background: "bg";
    readonly borderedBottom: true;
}, React.ReactElement<unknown, string | React.JSXElementConstructor<any>>>;
export declare const AnnouncementCards: import("@cbhq/cds-common/internal/utils/storyBuilder").Story<Omit<Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "id"> & Pick<import("../../system").PressableProps<"a">, "background" | "noScaleOnPress" | "target" | "href"> & Omit<import("../../layout").BoxBaseProps, "background"> & {
    size?: "small" | "medium" | "large";
    children?: React.ReactNode;
    onKeyDown?: React.HTMLAttributes<HTMLElement>["onKeyDown"];
    onKeyUp?: React.HTMLAttributes<HTMLElement>["onKeyUp"];
    onClick?: React.MouseEventHandler;
} & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").StaticStyleProps> & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").DynamicStyleProps> & import("@cbhq/cds-common").SharedProps & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityLabelledBy" | "accessibilityHint"> & {
    style?: React.CSSProperties;
    font?: import("../../styles/styleProps").ResponsiveProp<keyof typeof import("../../styles/responsive/base").fontFamily>;
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & {
    onActionPress?: React.MouseEventHandler;
    title?: React.ReactNode;
    description?: React.ReactNode;
    numberOfLines?: number;
    compact?: boolean;
    children?: React.ReactNode;
    mediaPlacement?: import("..").CardMediaPlacement;
    spotSquare?: import("@cbhq/cds-illustrations").SpotSquareName;
    pictogram?: import("@cbhq/cds-illustrations").PictogramName;
    image?: string;
    media?: React.ReactNode;
    actionLabel?: string;
    action?: React.ReactNode;
}, "children">, {
    readonly background: "bg";
    readonly borderedBottom: true;
}, React.ReactElement<unknown, string | React.JSXElementConstructor<any>>>;
export declare const FeatureEntryCard: import("@cbhq/cds-common/internal/utils/storyBuilder").Story<Omit<Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "id"> & Pick<import("../../system").PressableProps<"a">, "background" | "noScaleOnPress" | "target" | "href"> & Omit<import("../../layout").BoxBaseProps, "background"> & {
    size?: "small" | "medium" | "large";
    children?: React.ReactNode;
    onKeyDown?: React.HTMLAttributes<HTMLElement>["onKeyDown"];
    onKeyUp?: React.HTMLAttributes<HTMLElement>["onKeyUp"];
    onClick?: React.MouseEventHandler;
} & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").StaticStyleProps> & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").DynamicStyleProps> & import("@cbhq/cds-common").SharedProps & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityLabelledBy" | "accessibilityHint"> & {
    style?: React.CSSProperties;
    font?: import("../../styles/styleProps").ResponsiveProp<keyof typeof import("../../styles/responsive/base").fontFamily>;
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & {
    onActionPress?: React.MouseEventHandler;
    title?: React.ReactNode;
    description?: React.ReactNode;
    numberOfLines?: number;
    compact?: boolean;
    children?: React.ReactNode;
    mediaPlacement?: import("..").CardMediaPlacement;
    spotSquare?: import("@cbhq/cds-illustrations").SpotSquareName;
    pictogram?: import("@cbhq/cds-illustrations").PictogramName;
    image?: string;
    media?: React.ReactNode;
    actionLabel?: string;
    action?: React.ReactNode;
}, "children">, {
    readonly background: "bg";
    readonly borderedBottom: true;
}, React.ReactElement<unknown, string | React.JSXElementConstructor<any>>>;
export declare const FeatureEntryCards: import("@cbhq/cds-common/internal/utils/storyBuilder").Story<Omit<Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "id"> & Pick<import("../../system").PressableProps<"a">, "background" | "noScaleOnPress" | "target" | "href"> & Omit<import("../../layout").BoxBaseProps, "background"> & {
    size?: "small" | "medium" | "large";
    children?: React.ReactNode;
    onKeyDown?: React.HTMLAttributes<HTMLElement>["onKeyDown"];
    onKeyUp?: React.HTMLAttributes<HTMLElement>["onKeyUp"];
    onClick?: React.MouseEventHandler;
} & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").StaticStyleProps> & import("../../styles/styleProps").ResponsiveProps<import("../../styles/styleProps").DynamicStyleProps> & import("@cbhq/cds-common").SharedProps & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabel" | "accessibilityLabelledBy" | "accessibilityHint"> & {
    style?: React.CSSProperties;
    font?: import("../../styles/styleProps").ResponsiveProp<keyof typeof import("../../styles/responsive/base").fontFamily>;
    pin?: import("@cbhq/cds-common").PinningDirection;
    bordered?: boolean;
    borderedTop?: boolean;
    borderedBottom?: boolean;
    borderedStart?: boolean;
    borderedEnd?: boolean;
    borderedHorizontal?: boolean;
    borderedVertical?: boolean;
    dangerouslySetBackground?: string;
} & {
    onActionPress?: React.MouseEventHandler;
    title?: React.ReactNode;
    description?: React.ReactNode;
    numberOfLines?: number;
    compact?: boolean;
    children?: React.ReactNode;
    mediaPlacement?: import("..").CardMediaPlacement;
    spotSquare?: import("@cbhq/cds-illustrations").SpotSquareName;
    pictogram?: import("@cbhq/cds-illustrations").PictogramName;
    image?: string;
    media?: React.ReactNode;
    actionLabel?: string;
    action?: React.ReactNode;
}, "children">, {
    readonly background: "bg";
    readonly borderedBottom: true;
}, React.ReactElement<unknown, string | React.JSXElementConstructor<any>>>;
type Story = StoryObj<FeedCardProps & typeof baseConfig.args>;
export declare const FeedCard: Story;
export declare const FeedCards: Story;
declare const PressableCards: () => import("react/jsx-runtime").JSX.Element;
declare const PressableColoredCards: () => import("react/jsx-runtime").JSX.Element;
declare const NonClickableCards: () => import("react/jsx-runtime").JSX.Element;
declare const NonClickableColoredCards: () => import("react/jsx-runtime").JSX.Element;
declare const PinnedTopCard: () => import("react/jsx-runtime").JSX.Element;
declare const PinnedRightCard: () => import("react/jsx-runtime").JSX.Element;
declare const PinnedBottomCard: () => import("react/jsx-runtime").JSX.Element;
declare const PinnedLeftCard: () => import("react/jsx-runtime").JSX.Element;
export { NonClickableCards, NonClickableColoredCards, PinnedBottomCard, PinnedLeftCard, PinnedRightCard, PinnedTopCard, PressableCards, PressableColoredCards, };
declare const meta: Meta;
export default meta;
//# sourceMappingURL=Card.stories.d.ts.map