export declare const Default: () => import('react/jsx-runtime').JSX.Element;
export declare const Compact: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const LongText: () => import('react/jsx-runtime').JSX.Element;
export declare const VerticallyStacked: () => import('react/jsx-runtime').JSX.Element;
export declare const Carousel: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomDimensions: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomTextNodes: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: () => import('react/jsx-runtime').JSX.Element;
};
export default _default;
//# sourceMappingURL=NudgeCard.stories.d.ts.map
