import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type BoxDefaultElement, type BoxProps } from '../layout/Box';
export type ContainedAssetCardBaseProps = SharedProps & {
  header: React.ReactNode;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  description?: React.ReactNode;
  size?: 's' | 'l';
  children?: React.ReactNode;
};
export type ContainedAssetCardProps = ContainedAssetCardBaseProps &
  Omit<BoxProps<BoxDefaultElement>, 'title'>;
export declare const containedAssetCardHeight = 156;
export declare const containedAssetCardSmallWidth = 156;
export declare const containedAssetCardSmallMinWidth = 156;
export declare const containedAssetCardLargeWidth = 359;
export declare const containedAssetCardLargeMinWidth = 327;
/**
 * @deprecated Use `MediaCard` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 *
 * Migration guide:
 * ```tsx
 * // Before
 * <ContainedAssetCard
 *   header={<Avatar ... />}
 *   title="Asset Title"
 *   subtitle="Subtitle"
 *   description="Description"
 *   size="l"
 * >
 *   <RemoteImage ... />
 * </ContainedAssetCard>
 *
 * // After
 * <MediaCard
 *   thumbnail={<Avatar ... />}
 *   title="Asset Title"
 *   subtitle="Subtitle"
 *   description="Description"
 *   media={<RemoteImage ... />}
 *   mediaPlacement="end"
 * />
 * ```
 */
export declare const ContainedAssetCard: ({
  header,
  title,
  subtitle,
  description,
  size,
  children,
  className,
  flexDirection,
  background,
  borderRadius,
  height,
  width,
  minWidth,
  overflow,
  onClick,
  testID,
  ...props
}: ContainedAssetCardProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=ContainedAssetCard.d.ts.map
