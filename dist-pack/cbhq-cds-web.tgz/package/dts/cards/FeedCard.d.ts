import React from 'react';
import type { CardMediaPlacement } from '@cbhq/cds-common/types/CardMediaProps';
import type { ButtonBaseProps } from '../buttons/Button';
import type { IconButtonBaseProps } from '../buttons/IconButton';
import { type CardBaseProps } from './Card';
import { type CardBodyBaseProps } from './CardBody';
import { type LikeButtonBaseProps } from './LikeButton';
export type FeedCardBaseProps = Pick<CardBodyBaseProps, 'image' | 'pictogram' | 'spotSquare'> &
  CardBaseProps & {
    /** Image url for Avatar */
    avatar?: string;
    /** Source of the card info. Typically this text is associated with the avatar. */
    author?: string;
    /** Metadata to be displayed under author text. */
    metadata?: string;
    /** Above places media above text content, start & end places media to the side of text content
     * @default above for mobile, start for web. Web will need to handle responsiveness changes manually.
     */
    mediaPlacement?: Exclude<CardMediaPlacement, 'end'>;
    /** Text to be displayed in TextHeadline under CardHeader section. */
    title: string;
    /** Text to be displayed in TextLabel2 under title. */
    description: string;
    /** IconButton to show in top-right of FeedCard. Takes props for IconButton */
    headerAction?: IconButtonBaseProps & {
      onClick?: CardBaseProps['onClick'];
    };
    like?: LikeButtonBaseProps;
    comment?: Omit<IconButtonBaseProps, 'name'>;
    share?: Omit<IconButtonBaseProps, 'name'>;
    cta?: ButtonBaseProps;
  };
/**
 * @deprecated Use the ContentCard component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export type FeedCardProps = FeedCardBaseProps;
/**
 * @deprecated Use the ContentCard component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export declare const FeedCard: React.NamedExoticComponent<FeedCardBaseProps>;
//# sourceMappingURL=FeedCard.d.ts.map
