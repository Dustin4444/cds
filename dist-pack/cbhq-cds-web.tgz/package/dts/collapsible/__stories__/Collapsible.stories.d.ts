import React from 'react';
declare const _default: {
    component: React.NamedExoticComponent<import("@cbhq/cds-common").SharedProps & import("@cbhq/cds-common").PaddingProps & Pick<import("../../layout").BoxProps<"div">, "id" | "accessibilityLabelledBy" | "role"> & {
        collapsed: boolean;
        children: React.ReactNode;
        direction?: import("@cbhq/cds-common").CollapsibleDirection;
        dangerouslyDisableOverflowHidden?: boolean;
        maxHeight?: import("../../layout").BoxProps<import("../../layout").BoxDefaultElement>["maxHeight"];
        maxWidth?: import("../../layout").BoxProps<import("../../layout").BoxDefaultElement>["maxWidth"];
    } & React.RefAttributes<HTMLDivElement>>;
    title: string;
};
export default _default;
export declare const BasicCollapsible: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultExpanded: () => import("react/jsx-runtime").JSX.Element;
export declare const Horizontal: () => import("react/jsx-runtime").JSX.Element;
export declare const RevealTop: () => import("react/jsx-runtime").JSX.Element;
export declare const Scroll: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Collapsible.stories.d.ts.map