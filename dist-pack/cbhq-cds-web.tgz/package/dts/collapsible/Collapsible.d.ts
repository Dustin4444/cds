import React from 'react';
import type { CollapsibleDirection, PaddingProps, SharedProps } from '@cbhq/cds-common/types';
import { type BoxDefaultElement, type BoxProps } from '../layout/Box';
export type CollapsibleBaseProps = SharedProps & PaddingProps & Pick<BoxProps<BoxDefaultElement>, 'role' | 'id' | 'accessibilityLabelledBy'> & {
    /**
     * Expand/collapse state of the content.
     * @default true
     */
    collapsed: boolean;
    /**
     * Collapsible content
     */
    children: React.ReactNode;
    /**
     * Direction the content should expand/collapse to
     * @default vertical
     */
    direction?: CollapsibleDirection;
    /**
     * This option may break animation. Only use this if your container has fixed height or width.
     * @danger This is a migration escape hatch. It is not intended to be used normally.
     */
    dangerouslyDisableOverflowHidden?: boolean;
    /**
     * Max height of the content. Overflow content will be scrollable.
     */
    maxHeight?: BoxProps<BoxDefaultElement>['maxHeight'];
    /**
     * Max width of the content. Overflow content will be scrollable.
     */
    maxWidth?: BoxProps<BoxDefaultElement>['maxWidth'];
};
export type CollapsibleProps = CollapsibleBaseProps;
export declare const Collapsible: React.NamedExoticComponent<SharedProps & PaddingProps & Pick<BoxProps<"div">, "id" | "accessibilityLabelledBy" | "role"> & {
    /**
     * Expand/collapse state of the content.
     * @default true
     */
    collapsed: boolean;
    /**
     * Collapsible content
     */
    children: React.ReactNode;
    /**
     * Direction the content should expand/collapse to
     * @default vertical
     */
    direction?: CollapsibleDirection;
    /**
     * This option may break animation. Only use this if your container has fixed height or width.
     * @danger This is a migration escape hatch. It is not intended to be used normally.
     */
    dangerouslyDisableOverflowHidden?: boolean;
    /**
     * Max height of the content. Overflow content will be scrollable.
     */
    maxHeight?: BoxProps<BoxDefaultElement>["maxHeight"];
    /**
     * Max width of the content. Overflow content will be scrollable.
     */
    maxWidth?: BoxProps<BoxDefaultElement>["maxWidth"];
} & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=Collapsible.d.ts.map