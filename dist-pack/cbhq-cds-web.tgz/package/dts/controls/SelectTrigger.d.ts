import React from 'react';
import type { SelectBaseProps } from './Select';
export type SelectTriggerProps = Omit<SelectBaseProps, 'children' | 'focused' | 'width' | 'onChange' | 'onPress'> & {
    triggerHasFocus: boolean;
    /** Select Dropdown menu is opened */
    visible?: boolean;
    /** Event handler for when the Select Input trigger is pressed */
    onClick?: () => void;
};
export declare const SelectTrigger: React.NamedExoticComponent<Omit<SelectBaseProps, "width" | "children" | "onChange" | "focused" | "onPress"> & {
    triggerHasFocus: boolean;
    /** Select Dropdown menu is opened */
    visible?: boolean;
    /** Event handler for when the Select Input trigger is pressed */
    onClick?: () => void;
} & React.RefAttributes<HTMLElement>>;
//# sourceMappingURL=SelectTrigger.d.ts.map