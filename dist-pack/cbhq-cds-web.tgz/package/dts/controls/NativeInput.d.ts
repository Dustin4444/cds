import React from 'react';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types/SharedAccessibilityProps';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
import type { TextAlignProps } from '@cbhq/cds-common/types/TextBaseProps';
import { type BoxBaseProps, type BoxProps } from '../layout';
export type NativeInputBaseProps = BoxBaseProps & {
    /**
     * Decreases the padding within the input element
     * @default false
     */
    compact?: boolean;
    /** Custom container spacing if needed. This will add to the existing spacing */
    containerSpacing?: string;
    /**
     * Text Align Input
     * @default start
     * */
    align?: TextAlignProps['align'];
};
export type NativeInputProps = NativeInputBaseProps & BoxProps<'input'> & SharedProps & Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'> & {
    /**
     * Callback fired when pressed/clicked
     */
    onClick?: React.MouseEventHandler;
};
export declare const NativeInput: React.NamedExoticComponent<Omit<NativeInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=NativeInput.d.ts.map