import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
import { type InteractableBaseProps } from '../system/Interactable';
import type { FilteredHTMLAttributes, StylesAndClassNames } from '../types';
/**
 * Static class names for Control component parts.
 * Use these selectors to target specific elements with CSS.
 */
export declare const controlClassNames: {
    /** Persistent outer wrapper across labeled and unlabeled variants. */
    readonly root: "cds-Control";
    /** Native `<label>` wrapper element. */
    readonly label: "cds-Control-label";
    /** Interactable icon wrapper element. */
    readonly icon: "cds-Control-icon";
    /** Native input element. */
    readonly input: "cds-Control-input";
};
export type ControlBaseProps<ControlValue extends string> = FilteredHTMLAttributes<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'color'> & SharedProps & Partial<Pick<InteractableBaseProps, 'background' | 'borderColor' | 'borderRadius' | 'borderWidth' | 'color' | 'elevation' | 'className' | 'style'>> & {
    /** Label for the control option. */
    children?: React.ReactNode;
    /** Set the control to selected/on. */
    checked?: boolean;
    /** Disable user interaction. */
    disabled?: boolean;
    /** Set the control to ready-only. Similar effect as disabled. */
    readOnly?: boolean;
    /** Value of the option. Useful for multiple choice. */
    value?: ControlValue;
    /** Accessibility label describing the element. */
    accessibilityLabel?: string;
    /** Enable indeterminate state. Useful when you want to indicate that sub-items of a control are partially filled. */
    indeterminate?: boolean;
    /** Style for the icon element */
    iconStyle?: React.CSSProperties;
    /** Style for the label element */
    labelStyle?: React.CSSProperties;
};
export type ControlProps<ControlValue extends string> = ControlBaseProps<ControlValue> & StylesAndClassNames<typeof controlClassNames> & {
    label?: React.ReactNode;
    children: React.ReactNode;
};
declare const ControlWithRef: <ControlValue extends string>(props: ControlProps<ControlValue> & {
    ref?: React.Ref<HTMLInputElement>;
}) => React.ReactElement;
export declare const Control: typeof ControlWithRef & React.MemoExoticComponent<typeof ControlWithRef>;
export {};
//# sourceMappingURL=Control.d.ts.map