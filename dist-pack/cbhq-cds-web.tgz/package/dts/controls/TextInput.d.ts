import React from 'react';
import type { SharedInputProps } from '@cbhq/cds-common/types/InputBaseProps';
import type { InputStackBaseProps } from './InputStack';
import { type NativeInputBaseProps, type NativeInputProps } from './NativeInput';
export type TextInputBaseProps = NativeInputBaseProps & SharedInputProps & Pick<InputStackBaseProps, 'height' | 'variant' | 'width' | 'disabled' | 'borderRadius' | 'enableColorSurge' | 'labelVariant' | 'inputBackground'> & {
    /**
     * Customize the element which the input area will be rendered as.
     * Adds ability to render the input area as a `<textarea />`, `<input />` etc...
     * By default, TextInput renders an `<input />`.
     * @danger Use this at your own risk, and don't use unless ABSOLUTELY NECESSARY. You may see weird UI when focusing etc..
     * Our default input handles all of the UI/Accessibility needs for your out of the box, but inputNode will not include
     * those.
     *
     * If you need a ref to the underlying input element, prefer using `ref` on the `TextInput` component.
     * Supplying a `ref` on the `inputNode` element is redundant; if present, it will be merged with the component's ref.
     * */
    inputNode?: React.ReactElement;
    /**
     * Adds border to input.
     * When set to `false`, focus border styling is disabled by default.
     * @default true
     */
    bordered?: boolean;
    /**
     * Additional border width when focused.
     * Set this when `bordered={false}` to opt into a focus border style.
     */
    focusedBorderWidth?: InputStackBaseProps['focusedBorderWidth'];
    /**
     * Adds suffix text to the end of input
     */
    suffix?: string;
    /** Adds content to the start of the inner input. Refer to diagram for location of startNode in InputStack component */
    start?: React.ReactNode;
    /** Adds content to the end of the inner input. Refer to diagram for location of endNode in InputStack component */
    end?: React.ReactNode;
    /**
     * Add ability to test individual parts of the input
     */
    testIDMap?: {
        start?: string;
        end?: string;
        label?: string;
        helperText?: string;
    };
    /**
     * Accessibility label for helper text error icon when variant='negative'
     * @default 'error'
     */
    helperTextErrorIconAccessibilityLabel?: string;
    /**
     * React node to render label. Takes precedence over `label`.
     * @note if both labelNode and label are provided, label will still be used as accessibility label for the input if no accessibilityLabel is provided.
     */
    labelNode?: React.ReactNode;
};
export type TextInputProps = TextInputBaseProps & NativeInputProps;
export declare const TextInput: React.NamedExoticComponent<Omit<TextInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=TextInput.d.ts.map