import { type CSSProperties } from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { ResponsiveProp } from '../styles/styleProps';
import { type PressableProps } from '../system';
import type { ControlBaseProps } from './Control';
export type RadioCellBaseProps<RadioValue extends string> = Omit<
  PressableProps<'label'>,
  'title' | 'onChange'
> &
  Omit<
    ControlBaseProps<RadioValue>,
    'onChange' | 'title' | 'children' | 'iconStyle' | 'labelStyle' | 'checked'
  > & {
    checked?: boolean;
    title: React.ReactNode;
    onChange?: (inputChangeEvent: React.ChangeEvent<HTMLInputElement>) => void;
    description?: React.ReactNode;
    columnGap?: ResponsiveProp<ThemeVars.Space>;
    rowGap?: ResponsiveProp<ThemeVars.Space>;
    /** Custom ID for the title element. If not provided, a unique ID will be generated. */
    titleId?: string;
    /** Custom ID for the description element. If not provided, a unique ID will be generated. */
    descriptionId?: string;
  };
export type RadioCellProps<RadioValue extends string> = RadioCellBaseProps<RadioValue> & {
  classNames?: {
    /** Root element */
    root?: string;
    /** Radio input container element */
    radioContainer?: string;
    /** Title text element */
    title?: string;
    /** Description text element */
    description?: string;
    /** Content container element */
    contentContainer?: string;
  };
  styles?: {
    /** Root element */
    root?: CSSProperties;
    /** Radio input container element */
    radioContainer?: CSSProperties;
    /** Title text element */
    title?: CSSProperties;
    /** Description text element */
    description?: CSSProperties;
    /** Content container element */
    contentContainer?: CSSProperties;
  };
};
declare const RadioCellWithRef: <RadioValue extends string>(
  props: RadioCellProps<RadioValue> & {
    ref?: React.Ref<HTMLLabelElement>;
  },
) => React.ReactElement;
export declare const RadioCell: typeof RadioCellWithRef &
  React.MemoExoticComponent<typeof RadioCellWithRef>;
export {};
//# sourceMappingURL=RadioCell.d.ts.map
