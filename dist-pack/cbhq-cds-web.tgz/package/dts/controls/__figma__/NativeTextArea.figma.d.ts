export {};
//# sourceMappingURL=NativeTextArea.figma.d.ts.map
