export {};
//# sourceMappingURL=NativeInput.test.d.ts.map
