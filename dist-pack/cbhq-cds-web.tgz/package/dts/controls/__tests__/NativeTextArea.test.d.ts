export {};
//# sourceMappingURL=NativeTextArea.test.d.ts.map
