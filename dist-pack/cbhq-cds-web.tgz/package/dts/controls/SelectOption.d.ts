import React from 'react';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types';
import { type CellBaseProps } from '../cells/Cell';
import type { ListCellBaseProps } from '../cells/ListCell';
import { type PressableProps } from '../system/Pressable';
export declare const selectOptionStaticClassName = "cds-select-option";
export type SelectOptionBaseProps = Omit<CellBaseProps, 'children' | 'selected'> & Pick<PressableProps<'a'>, 'href'> & Pick<ListCellBaseProps, 'title' | 'description' | 'multiline' | 'compact'> & Pick<SharedAccessibilityProps, 'accessibilityLabel'> & {
    onClick?: React.MouseEventHandler;
    /** Prevent menu from closing when an option is selected */
    disableCloseOnOptionChange?: boolean;
    /**
     * Necessary to control roving tabindex for accessibility
     * https://www.w3.org/TR/wai-aria-practices/#kbd_roving_tabindex
     * */
    tabIndex?: number;
    /** Unique identifier for each option */
    value: string;
};
export type SelectOptionProps = SelectOptionBaseProps;
/**
 * @deprecated This component is deprecated along with old Select component. Please use the new Select alpha component instead. If you are using this component outside of Select, we recommend replacing it with ListCell. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const SelectOption: React.MemoExoticComponent<(_props: SelectOptionProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=SelectOption.d.ts.map