import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("..").InputIconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
};
export default _default;
export declare const AddCustomColor: () => import("react/jsx-runtime").JSX.Element;
export declare const AddCustomColorEnd: () => import("react/jsx-runtime").JSX.Element;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const BasicEnd: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultsToPrimary: () => import("react/jsx-runtime").JSX.Element;
export declare const InvalidPlacement: () => import("react/jsx-runtime").JSX.Element;
export declare const SetColorAndInheritFocusStyle: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InputIconButton.stories.d.ts.map