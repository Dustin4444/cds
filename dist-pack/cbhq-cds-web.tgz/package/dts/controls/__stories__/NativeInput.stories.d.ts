import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("../NativeInput").NativeInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
};
export default _default;
export declare const NativeInputBasic: () => import("react/jsx-runtime").JSX.Element;
export declare const NativeInputCustomContainerSpacing: () => import("react/jsx-runtime").JSX.Element;
export declare const NativeInputTextAlign: () => import("react/jsx-runtime").JSX.Element;
export declare const NativeInputActions: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=NativeInput.stories.d.ts.map