import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("..").SearchInputProps, "ref"> & React.RefAttributes<HTMLInputElement>>;
};
export default _default;
export declare const Default: () => import("react/jsx-runtime").JSX.Element;
/**
 * This tests how the SearchInput will work when
 * onChange and onChangeText are used together
 */
export declare const OnChangeExample: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SearchInput.stories.d.ts.map