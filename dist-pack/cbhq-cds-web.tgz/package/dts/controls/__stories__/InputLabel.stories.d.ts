import React from 'react';
declare const _default: {
  title: string;
  component: React.NamedExoticComponent<import('../InputLabel').InputLabelProps>;
};
export default _default;
export declare const InputLabelBasic: () => import('react/jsx-runtime').JSX.Element;
export declare const InputLabelTextAlignments: () => import('react/jsx-runtime').JSX.Element;
export declare const LabelColor: () => import('react/jsx-runtime').JSX.Element;
export declare const InputLabelDangerouslySetClassName: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=InputLabel.stories.d.ts.map
