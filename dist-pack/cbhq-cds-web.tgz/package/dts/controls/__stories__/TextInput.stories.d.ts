import type { Meta, StoryObj } from '@storybook/react';
declare const meta: Meta;
export default meta;
type Story = StoryObj;
/**
 * DEFAULT TEXT INPUT VARIATIONS
 */
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const InsideLabel: () => import("react/jsx-runtime").JSX.Element;
export declare const Placeholder: () => import("react/jsx-runtime").JSX.Element;
export declare const HelperText: () => import("react/jsx-runtime").JSX.Element;
export declare const Align: () => import("react/jsx-runtime").JSX.Element;
export declare const Variants: () => import("react/jsx-runtime").JSX.Element;
export declare const ColorSurge: () => import("react/jsx-runtime").JSX.Element;
export declare const NumberInput: () => import("react/jsx-runtime").JSX.Element;
export declare const Width: () => import("react/jsx-runtime").JSX.Element;
export declare const Height: () => import("react/jsx-runtime").JSX.Element;
export declare const BorderRadius: () => import("react/jsx-runtime").JSX.Element[];
export declare const Borderless: () => import("react/jsx-runtime").JSX.Element;
export declare const Disabled: Story;
export declare const NoLabel: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomLabel: () => import("react/jsx-runtime").JSX.Element;
export declare const StartContent: () => import("react/jsx-runtime").JSX.Element;
export declare const EndContent: () => import("react/jsx-runtime").JSX.Element;
export declare const Suffix: () => import("react/jsx-runtime").JSX.Element;
export declare const SuffixAndEndContent: () => import("react/jsx-runtime").JSX.Element;
/**
 * COMPACT TEXT INPUT VARIATIONS
 */
export declare const CompactInput: () => import("react/jsx-runtime").JSX.Element;
export declare const CompactInputStart: () => import("react/jsx-runtime").JSX.Element;
export declare const CompactInputEnd: () => import("react/jsx-runtime").JSX.Element;
export declare const CompactInputSuffix: () => import("react/jsx-runtime").JSX.Element;
export declare const CompactHelperText: () => import("react/jsx-runtime").JSX.Element;
export declare const InputOnChange: () => import("react/jsx-runtime").JSX.Element;
export declare const RenderInputDefault: () => import("react/jsx-runtime").JSX.Element;
export declare const RenderInputDisabled: Story;
export declare const RenderInputCompact: () => import("react/jsx-runtime").JSX.Element;
export declare const RenderNativeTextArea: () => import("react/jsx-runtime").JSX.Element;
export declare const RenderNativeTextAreaCustomSpacing: () => import("react/jsx-runtime").JSX.Element;
export declare const CopyTextInput: () => import("react/jsx-runtime").JSX.Element;
export declare const ReadOnly: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TextInput.stories.d.ts.map