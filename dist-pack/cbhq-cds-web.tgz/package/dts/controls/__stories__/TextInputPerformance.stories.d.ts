declare const _default: {
    title: string;
    component: import("react").NamedExoticComponent<Omit<import("..").TextInputProps, "ref"> & import("react").RefAttributes<HTMLInputElement>>;
    decorators: ((...args: any) => any)[];
    excludeStories: string[];
};
export default _default;
export declare const CDSTextInput: () => import("react/jsx-runtime").JSX.Element;
export declare const HTMLInput: () => import("react/jsx-runtime").JSX.Element;
declare const HundredCDSComponents: () => import("react/jsx-runtime").JSX.Element[];
declare const HundredHTMLComponent: () => import("react/jsx-runtime").JSX.Element[];
declare const ThousandCDSComponents: () => import("react/jsx-runtime").JSX.Element[];
declare const ThousandHTMLComponent: () => import("react/jsx-runtime").JSX.Element[];
export { HundredCDSComponents, HundredHTMLComponent, ThousandCDSComponents, ThousandHTMLComponent };
//# sourceMappingURL=TextInputPerformance.stories.d.ts.map