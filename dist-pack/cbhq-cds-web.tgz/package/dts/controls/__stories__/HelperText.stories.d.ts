import React from 'react';
declare const _default: {
  title: string;
  component: React.NamedExoticComponent<import('../HelperText').HelperTextProps>;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export default _default;
export declare const MessageAreaBasic: () => import('react/jsx-runtime').JSX.Element;
export declare const MessageAreaColor: () => import('react/jsx-runtime').JSX.Element;
export declare const TextAlign: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomColor: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=HelperText.stories.d.ts.map
