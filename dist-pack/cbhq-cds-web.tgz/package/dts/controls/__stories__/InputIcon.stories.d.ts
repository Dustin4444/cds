import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("..").InputIconProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
};
export default _default;
export declare const AddCustomColor: () => import("react/jsx-runtime").JSX.Element;
export declare const AddCustomColorEnd: () => import("react/jsx-runtime").JSX.Element;
export declare const Basic: () => import("react/jsx-runtime").JSX.Element;
export declare const BasicEnd: () => import("react/jsx-runtime").JSX.Element;
export declare const DefaultsToForeground: () => import("react/jsx-runtime").JSX.Element;
export declare const InvalidPlacement: () => import("react/jsx-runtime").JSX.Element;
export declare const SetColorAndInheritFocusStyle: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InputIcon.stories.d.ts.map