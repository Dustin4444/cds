export declare const AddressForm: ({
  ...props
}: {
  [x: string]: any;
}) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=AddressForm.d.ts.map
