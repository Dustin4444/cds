import React from 'react';
declare const _default: {
  title: string;
  component: React.MemoExoticComponent<
    (_props: import('..').SelectOptionProps) => import('react/jsx-runtime').JSX.Element
  >;
  parameters: {
    a11y: {
      test: string;
    };
  };
};
export default _default;
export declare const Stories: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=SelectOption.stories.d.ts.map
