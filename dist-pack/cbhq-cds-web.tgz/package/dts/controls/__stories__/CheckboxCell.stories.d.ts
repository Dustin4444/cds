declare const _default: {
    title: string;
    component: (<CheckboxValue extends string>(props: import("@cbhq/cds-web/controls").CheckboxCellProps<CheckboxValue> & {
        ref?: React.Ref<HTMLLabelElement>;
    }) => React.ReactElement) & import("react").NamedExoticComponent<Omit<import("../../system").PressableProps<"label">, "title" | "onChange"> & Omit<import("../Control").ControlBaseProps<string>, "title" | "children" | "checked" | "onChange" | "iconStyle" | "labelStyle"> & {
        checked?: boolean;
        controlSize?: number;
        title: React.ReactNode;
        description?: React.ReactNode;
        onChange?: (inputChangeEvent: React.ChangeEvent<HTMLInputElement>) => void;
        columnGap?: import("../../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space>;
        rowGap?: import("../../styles/styleProps").ResponsiveProp<import("@cbhq/cds-common").ThemeVars.Space>;
        titleId?: string;
        descriptionId?: string;
    } & {
        classNames?: {
            root?: string;
            checkboxContainer?: string;
            title?: string;
            description?: string;
            contentContainer?: string;
        };
        styles?: {
            root?: import("react").CSSProperties;
            checkboxContainer?: import("react").CSSProperties;
            title?: import("react").CSSProperties;
            description?: import("react").CSSProperties;
            contentContainer?: import("react").CSSProperties;
        };
    } & {
        ref?: React.Ref<HTMLLabelElement>;
    }> & {
        readonly type: <CheckboxValue extends string>(props: import("@cbhq/cds-web/controls").CheckboxCellProps<CheckboxValue> & {
            ref?: React.Ref<HTMLLabelElement>;
        }) => React.ReactElement;
    };
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CheckboxCell.stories.d.ts.map