import React from 'react';
declare const _default: {
    title: string;
    component: (<CheckboxValue extends string>(props: import("..").CheckboxProps<CheckboxValue> & {
        ref?: React.Ref<HTMLInputElement>;
    }) => React.ReactElement) & React.NamedExoticComponent<import("../../types").FilteredHTMLAttributes<React.InputHTMLAttributes<HTMLInputElement>, "color" | "value"> & import("@cbhq/cds-common").SharedProps & Partial<Pick<import("../../system").InteractableBaseProps, "borderWidth" | "borderRadius" | "color" | "style" | "background" | "borderColor" | "elevation" | "className">> & {
        children?: React.ReactNode;
        checked?: boolean;
        disabled?: boolean;
        readOnly?: boolean;
        value?: string | undefined;
        accessibilityLabel?: string;
        indeterminate?: boolean;
        iconStyle?: React.CSSProperties;
        labelStyle?: React.CSSProperties;
    } & {
        controlColor?: import("@cbhq/cds-common").ThemeVars.Color;
        borderWidth?: import("@cbhq/cds-common").ThemeVars.BorderWidth;
        controlSize?: number;
    } & {
        ref?: React.Ref<HTMLInputElement>;
    }> & {
        readonly type: <CheckboxValue extends string>(props: import("..").CheckboxProps<CheckboxValue> & {
            ref?: React.Ref<HTMLInputElement>;
        }) => React.ReactElement;
    };
};
export default _default;
export declare const NoLabel: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
            test: string;
        };
    };
};
export declare const ReadOnly: {
    (): import("react/jsx-runtime").JSX.Element;
    parameters: {
        /**
         * Color contrast ratio doesn't need to meet 4.5:1, as the element is disabled
         * @link https://dequeuniversity.com/rules/axe/4.3/color-contrast
         */
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
        };
    };
};
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Checkbox.stories.d.ts.map