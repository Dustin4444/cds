import type { Meta, StoryObj } from '@storybook/react';
import { ControlGroup } from '../ControlGroup';
declare const meta: Meta<typeof ControlGroup>;
export default meta;
type Story = StoryObj<typeof ControlGroup>;
export declare const RadioGroupStory: Story;
export declare const CheckboxGroupStory: Story;
export declare const RadioCellGroupStory: Story;
export declare const CheckboxCellGroupStory: Story;
export declare const SwitchGroupStory: Story;
//# sourceMappingURL=ControlGroup.stories.d.ts.map
