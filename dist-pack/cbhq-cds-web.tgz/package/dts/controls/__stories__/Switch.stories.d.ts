import React from 'react';
export declare const Normal: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomColors: () => import("react/jsx-runtime").JSX.Element;
export declare const DarkNormal: () => import("react/jsx-runtime").JSX.Element;
export declare const On: () => import("react/jsx-runtime").JSX.Element;
export declare const DisabledOff: () => import("react/jsx-runtime").JSX.Element;
export declare const DisabledOn: () => import("react/jsx-runtime").JSX.Element;
export declare const DarkNormalOn: () => import("react/jsx-runtime").JSX.Element;
export declare const DarkNormalDisabledOff: () => import("react/jsx-runtime").JSX.Element;
export declare const DarkNormalDisabledOn: () => import("react/jsx-runtime").JSX.Element;
export declare const MultiLineLabel: () => import("react/jsx-runtime").JSX.Element;
export declare const Elevation: () => import("react/jsx-runtime").JSX.Element;
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<import("../../types").FilteredHTMLAttributes<React.InputHTMLAttributes<HTMLInputElement>, "color" | "value"> & import("@cbhq/cds-common").SharedProps & Partial<Pick<import("../../system").InteractableBaseProps, "borderWidth" | "borderRadius" | "color" | "style" | "background" | "borderColor" | "elevation" | "className">> & {
        children?: React.ReactNode;
        checked?: boolean;
        disabled?: boolean;
        readOnly?: boolean;
        value?: string | undefined;
        accessibilityLabel?: string;
        indeterminate?: boolean;
        iconStyle?: React.CSSProperties;
        labelStyle?: React.CSSProperties;
    } & {
        controlColor?: import("@cbhq/cds-common").ThemeVars.Color;
    } & import("../../types").StylesAndClassNames<{
        readonly root: "cds-Switch";
        readonly control: "cds-Switch-control";
        readonly track: "cds-Switch-track";
        readonly thumb: "cds-Switch-thumb";
    }> & {
        children?: React.ReactNode;
    } & React.RefAttributes<HTMLInputElement>>;
};
export default _default;
//# sourceMappingURL=Switch.stories.d.ts.map