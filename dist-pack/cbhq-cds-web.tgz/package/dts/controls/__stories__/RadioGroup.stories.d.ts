import React from 'react';
declare const _default: {
    title: string;
    component: (<RadioValue extends string>(props: import("..").RadioGroupProps<RadioValue> & {
        ref?: React.Ref<HTMLInputElement>;
    }) => React.ReactElement) & React.NamedExoticComponent<import("../../types").FilteredHTMLAttributes<React.HTMLAttributes<HTMLDivElement>, "color" | "onChange"> & import("@cbhq/cds-common").SharedProps & Pick<import("@cbhq/cds-common").SharedAccessibilityProps, "accessibilityLabelledBy"> & Pick<import("../../layout").GroupBaseProps<import("../../layout").BoxBaseProps>, "gap" | "direction"> & {
        options: Record<string, React.ReactNode>;
        label?: React.ReactNode;
        value?: string | undefined;
        name: string;
        onChange?: ((value: string) => void) | undefined;
        controlColor?: import("@cbhq/cds-common").ThemeVars.Color;
    } & {
        ref?: React.Ref<HTMLInputElement>;
    }> & {
        readonly type: <RadioValue extends string>(props: import("..").RadioGroupProps<RadioValue> & {
            ref?: React.Ref<HTMLInputElement>;
        }) => React.ReactElement;
    };
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=RadioGroup.stories.d.ts.map