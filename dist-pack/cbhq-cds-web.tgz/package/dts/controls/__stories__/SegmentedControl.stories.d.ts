import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<import("..").SegmentedControlProps & React.RefAttributes<HTMLInputElement>>;
};
export default _default;
export declare const Normal: () => import("react/jsx-runtime").JSX.Element;
export declare const Icons: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SegmentedControl.stories.d.ts.map