import type { Meta, StoryObj } from '@storybook/react';
import { type SelectProps } from '../Select';
declare const meta: Meta;
export default meta;
type Story = StoryObj;
declare const Default: ({ variant, label, helperText, labelVariant, startNode, compact, placeholder, }: Pick<SelectProps, "variant" | "label" | "helperText" | "labelVariant" | "startNode" | "compact" | "placeholder">) => import("react/jsx-runtime").JSX.Element;
declare const LongTextSelect: ({ variant, label, helperText, }: Pick<SelectProps, "variant" | "label" | "helperText">) => import("react/jsx-runtime").JSX.Element;
declare const AssetSelect: (props: SelectProps) => import("react/jsx-runtime").JSX.Element;
declare const InputStackOptions: () => import("react/jsx-runtime").JSX.Element;
declare const Disabled: Story;
declare const Compact: () => import("react/jsx-runtime").JSX.Element;
declare const Variants: () => import("react/jsx-runtime").JSX.Element;
declare const LongText: () => import("react/jsx-runtime").JSX.Element;
declare const LabelVariants: () => import("react/jsx-runtime").JSX.Element;
export { AssetSelect, Compact, Default, Disabled, InputStackOptions, LabelVariants, LongText, LongTextSelect, Variants, };
//# sourceMappingURL=Select.stories.d.ts.map