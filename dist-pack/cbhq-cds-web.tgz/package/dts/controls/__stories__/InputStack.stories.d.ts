import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("../InputStack").InputStackProps, "ref"> & React.RefAttributes<HTMLElement>>;
};
export default _default;
export declare const InputStackExamples: () => import("react/jsx-runtime").JSX.Element;
export declare const Append: () => import("react/jsx-runtime").JSX.Element;
export declare const Prepend: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InputStack.stories.d.ts.map