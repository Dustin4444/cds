import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { InputVariant } from '@cbhq/cds-common/types/InputBaseProps';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
import type { IconProps } from '../icons/Icon';
export type InputIconProps = {
    /**
     * If set to true, when parent input is focused, the icon will match the color of the focus state
     * @default false
     * */
    disableInheritFocusStyle?: boolean;
} & Omit<IconProps, 'size'> & SharedProps;
export declare const variantColorMap: Record<InputVariant, ThemeVars.Color>;
export declare const InputIcon: React.NamedExoticComponent<Omit<InputIconProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=InputIcon.d.ts.map