import React from 'react';
import type { IconButtonVariant, InputVariant } from '@cbhq/cds-common/types';
import { type IconButtonDefaultElement, type IconButtonProps } from '../buttons/IconButton';
export declare const variantTransformMap: Record<InputVariant, IconButtonVariant>;
export type InputIconButtonProps = IconButtonProps<IconButtonDefaultElement> & {
    /**
     * If set to true, when parent input is focused, the icon will match the color of the focus state
     * @default false
     * */
    disableInheritFocusStyle?: boolean;
};
export declare const InputIconButton: React.NamedExoticComponent<Omit<InputIconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=InputIconButton.d.ts.map