import { type CSSProperties } from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { ResponsiveProp } from '../styles/styleProps';
import { type PressableProps } from '../system/Pressable';
import type { ControlBaseProps } from './Control';
export type CheckboxCellBaseProps<CheckboxValue extends string> = Omit<
  PressableProps<'label'>,
  'title' | 'onChange'
> &
  Omit<
    ControlBaseProps<CheckboxValue>,
    'onChange' | 'title' | 'children' | 'iconStyle' | 'labelStyle' | 'checked'
  > & {
    checked?: boolean;
    /**
     * Sets the outer checkbox control size in pixels.
     * @default theme.controlSize.checkboxSize
     */
    controlSize?: number;
    title: React.ReactNode;
    description?: React.ReactNode;
    onChange?: (inputChangeEvent: React.ChangeEvent<HTMLInputElement>) => void;
    columnGap?: ResponsiveProp<ThemeVars.Space>;
    rowGap?: ResponsiveProp<ThemeVars.Space>;
    /** Custom ID for the title element. If not provided, a unique ID will be generated. */
    titleId?: string;
    /** Custom ID for the description element. If not provided, a unique ID will be generated. */
    descriptionId?: string;
  };
export type CheckboxCellProps<CheckboxValue extends string> =
  CheckboxCellBaseProps<CheckboxValue> & {
    classNames?: {
      /** Root element */
      root?: string;
      /** Checkbox input container element */
      checkboxContainer?: string;
      /** Title text element */
      title?: string;
      /** Description text element */
      description?: string;
      /** Content container element */
      contentContainer?: string;
    };
    styles?: {
      /** Root element */
      root?: CSSProperties;
      /** Checkbox input container element */
      checkboxContainer?: CSSProperties;
      /** Title text element */
      title?: CSSProperties;
      /** Description text element */
      description?: CSSProperties;
      /** Content container element */
      contentContainer?: CSSProperties;
    };
  };
declare const CheckboxCellWithRef: <CheckboxValue extends string>(
  props: CheckboxCellProps<CheckboxValue> & {
    ref?: React.Ref<HTMLLabelElement>;
  },
) => React.ReactElement;
export declare const CheckboxCell: typeof CheckboxCellWithRef &
  React.MemoExoticComponent<typeof CheckboxCellWithRef>;
export {};
//# sourceMappingURL=CheckboxCell.d.ts.map
