/**
 * Returns the height of the selection cell control based on the theme's headline line height and font size
 * @returns The height of the selection cell control
 */
export declare const useSelectionCellControlHeight: () =>
  | number
  | '-moz-initial'
  | 'inherit'
  | 'initial'
  | 'revert'
  | 'revert-layer'
  | 'unset'
  | (string & {})
  | 'normal';
//# sourceMappingURL=useSelectionCellControlHeight.d.ts.map
