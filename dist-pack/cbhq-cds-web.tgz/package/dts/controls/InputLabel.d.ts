import React from 'react';
import { type TextProps } from '../typography/Text';
export type InputLabelProps = TextProps<'label'>;
export declare const InputLabel: React.NamedExoticComponent<InputLabelProps>;
//# sourceMappingURL=InputLabel.d.ts.map
