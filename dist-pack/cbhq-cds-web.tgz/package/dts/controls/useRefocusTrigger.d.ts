/** Refocuses a pressable that opens a menu after the menu has been opened and then closed */
export declare const useRefocusTrigger: (shouldRefocus: boolean) => import("react").RefObject<HTMLButtonElement | null>;
//# sourceMappingURL=useRefocusTrigger.d.ts.map