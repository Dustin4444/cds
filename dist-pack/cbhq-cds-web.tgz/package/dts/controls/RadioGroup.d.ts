import React from 'react';
import type { SharedAccessibilityProps, SharedProps, ThemeVars } from '@cbhq/cds-common';
import type { BoxBaseProps } from '../layout';
import type { GroupBaseProps } from '../layout/Group';
import type { FilteredHTMLAttributes } from '../types';
import { Radio, type RadioProps } from './Radio';
import { useHandleRadioSelect } from './useHandleRadioSelect';
export { Radio, type RadioProps, useHandleRadioSelect };
/**
 * @deprecated RadioGroup is deprecated. Use ControlGroup with role="radiogroup" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v6
 *
 * @example
 * // Instead of:
 * <RadioGroup options={{ value1: 'Label 1' }} value={value} onChange={onChange} name="radio" />
 *
 * // Use:
 * <ControlGroup
 *   role="radiogroup"
 *   ControlComponent={Radio}
 *   options={[{ value: 'value1', children: 'Label 1' }]}
 *   value={value}
 *   onChange={(e) => onChange(e.target.value)}
 *   name="radio"
 * />
 */
export type RadioGroupBaseProps<RadioValue extends string> = FilteredHTMLAttributes<
  React.HTMLAttributes<HTMLDivElement>,
  'onChange' | 'color'
> &
  SharedProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabelledBy'> &
  Pick<GroupBaseProps<BoxBaseProps>, 'direction' | 'gap'> & {
    /**
     * Multiple choice options for the radio group. The object key represents
     * the radio input value and the object value represents the radio option label.
     */
    options: Record<RadioValue, string | React.ReactNode>;
    /** Set a label summary for the group of radios. */
    label?: React.ReactNode;
    /** Currently selected value. */
    value?: RadioValue;
    /** Field name of the multiple choice radio group. */
    name: string;
    /** Handle change event when pressing on a radio option. */
    onChange?: (value: RadioValue) => void;
    /** Sets the checked/active color of each control in the group.
     * @default bgPrimary
     */
    controlColor?: ThemeVars.Color;
  };
/**
 * @deprecated RadioGroup is deprecated. Use ControlGroup with role="radiogroup" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export type RadioGroupProps<RadioValue extends string> = RadioGroupBaseProps<RadioValue>;
declare const RadioGroupWithRef: <RadioValue extends string>(
  props: RadioGroupProps<RadioValue> & {
    ref?: React.Ref<HTMLInputElement>;
  },
) => React.ReactElement;
/**
 * @deprecated RadioGroup is deprecated. Use ControlGroup with role="radiogroup" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v6
 */
export declare const RadioGroup: typeof RadioGroupWithRef &
  React.MemoExoticComponent<typeof RadioGroupWithRef>;
//# sourceMappingURL=RadioGroup.d.ts.map
