import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
import type { BoxProps } from '../layout/Box';
import type { TextInputBaseProps } from './TextInput';
export type NativeTextAreaBaseProp = {
    /** Custom container spacing if needed. This will add to the existing spacing */
    containerSpacing?: string;
    /**
     * Callback fired when pressed/clicked
     */
    onClick?: React.MouseEventHandler;
} & SharedProps & Pick<TextInputBaseProps, 'compact'>;
export type NativeTextAreaProp = NativeTextAreaBaseProp & BoxProps<'textarea'>;
export declare const NativeTextArea: React.NamedExoticComponent<Omit<NativeTextAreaProp, "ref"> & React.RefAttributes<HTMLTextAreaElement>>;
//# sourceMappingURL=NativeTextArea.d.ts.map