import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import { type TextDefaultElement, type TextProps } from '../typography/Text';
export type HelperTextProps = {
    /** Color of helper text. negative color will render an icon */
    color?: ThemeVars.Color;
    /** Used to associate the helper text with an input */
    id?: string;
    /** Accessibility label for the error icon */
    errorIconAccessibilityLabel?: string;
    /** Test ID for the error icon */
    errorIconTestID?: string;
    /** Custom inline styles for individual elements of the HelperText component */
    styles?: {
        /** Root text element */
        root?: React.CSSProperties;
        /** Error icon element */
        icon?: React.CSSProperties;
    };
    /** Custom class names for individual elements of the HelperText component */
    classNames?: {
        /** Root text element */
        root?: string;
        /** Error icon element */
        icon?: string;
    };
} & TextProps<TextDefaultElement>;
export declare const HelperText: React.NamedExoticComponent<HelperTextProps>;
//# sourceMappingURL=HelperText.d.ts.map