import React from 'react';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types';
import type { SelectBaseProps } from './Select';
export type SelectStackProps = {
    children: React.ReactElement;
    helperTextErrorIconAccessibilityLabel?: string;
} & Pick<SelectBaseProps, 'compact' | 'label' | 'disabled' | 'helperText' | 'variant' | 'focused' | 'labelVariant'> & Pick<SharedAccessibilityProps, 'accessibilityLabelId' | 'accessibilityDescriptionId'>;
export declare const SelectStack: React.NamedExoticComponent<{
    children: React.ReactElement;
    helperTextErrorIconAccessibilityLabel?: string;
} & Pick<SelectBaseProps, "label" | "compact" | "disabled" | "variant" | "focused" | "labelVariant" | "helperText"> & Pick<SharedAccessibilityProps, "accessibilityLabelId" | "accessibilityDescriptionId"> & React.RefAttributes<HTMLElement>>;
//# sourceMappingURL=SelectStack.d.ts.map