import React, { type FieldsetHTMLAttributes } from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { FilteredHTMLAttributes } from '../types';
/**
 * @deprecated CheckboxGroup is deprecated. Use ControlGroup with role="group" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 *
 * @example
 * // Instead of:
 * <CheckboxGroup selectedValues={new Set(['value1'])} onChange={onChange}>
 *   <Checkbox value="value1">Option 1</Checkbox>
 * </CheckboxGroup>
 *
 * // Use:
 * <ControlGroup
 *   role="group"
 *   ControlComponent={Checkbox}
 *   options={[{ value: 'value1', children: 'Option 1' }]}
 *   value={['value1']}
 *   onChange={onChange}xw
 * />
 */
export type CheckboxGroupBaseProps<CheckboxValue extends string | number> = FilteredHTMLAttributes<
  FieldsetHTMLAttributes<HTMLFieldSetElement>,
  'onChange'
> &
  SharedProps & {
    /** Checkbox elements that are part of the checkbox group. */
    children: React.ReactElement[];
    /** Set a label summary for the group of checkboxes. */
    label?: React.ReactNode;
    /** Checkbox options that are checked. */
    selectedValues: Set<CheckboxValue>;
    className?: string;
    /** Handle change event when pressing on a checkbox option. */
    onChange?: React.ChangeEventHandler<HTMLInputElement>;
    style?: React.CSSProperties;
  };
/**
 * @deprecated CheckboxGroup is deprecated. Use ControlGroup with role="group" instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v8
 */
export type CheckboxGroupProps<CheckboxValue extends string> =
  CheckboxGroupBaseProps<CheckboxValue>;
declare const CheckboxGroupWithRef: <CheckboxValue extends string>(
  props: CheckboxGroupProps<CheckboxValue> & {
    ref?: React.Ref<HTMLFieldSetElement>;
  },
) => React.ReactElement;
export declare const CheckboxGroup: typeof CheckboxGroupWithRef &
  React.MemoExoticComponent<typeof CheckboxGroupWithRef>;
export {};
//# sourceMappingURL=CheckboxGroup.d.ts.map
