import React from 'react';
import type { IconName, IconSize, SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common/types';
export type SegmentedControlProps = {
    /** The selected value */
    value?: string;
    /** Expand to 100% of parent width */
    block?: boolean;
    /** Callback fired when an option is selected */
    onChange?: (value: string) => void;
    disabled?: boolean;
} & (TextOptionProps | IconOptionProps) & SharedProps;
export type TextOptions = readonly TextOption[];
export type IconOptions = readonly IconOption[];
type BaseOption = {
    /** The option value */
    value: string;
} & Pick<SharedAccessibilityProps, 'accessibilityLabel'>;
type TextOption = {
    /** The option label to display in the control */
    label: string;
} & BaseOption;
type TextOptionProps = {
    type?: 'text';
    /** The options to render as an array of values and labels */
    options: TextOptions;
};
type IconOption = {
    /** The option icon to display in the control */
    label: IconName;
    /** Whether the icon is active */
    active?: boolean;
} & BaseOption;
type IconOptionProps = {
    type: 'icon';
    iconSize: IconSize;
    /** The options to render as an array of values and IconNames  */
    options: IconOptions;
};
/**
 * @deprecated SegmentedControl is deprecated and will be removed in a future version. Please use Tabs or SegmentedTabs instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const SegmentedControl: React.NamedExoticComponent<SegmentedControlProps & React.RefAttributes<HTMLInputElement>>;
export {};
//# sourceMappingURL=SegmentedControl.d.ts.map