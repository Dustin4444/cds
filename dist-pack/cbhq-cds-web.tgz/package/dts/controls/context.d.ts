import type { InputVariant } from '@cbhq/cds-common/types/InputBaseProps';
export declare const TextInputFocusVariantContext: import('react').Context<
  InputVariant | undefined
>;
export declare const useTextInputFocusVariantContent: () => InputVariant | undefined;
//# sourceMappingURL=context.d.ts.map
