import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { StylesAndClassNames } from '../types';
import { type ControlBaseProps } from './Control';
/**
 * Static class names for Switch component parts.
 * Use these selectors to target specific elements with CSS.
 */
export declare const switchClassNames: {
    /** Persistent outer wrapper across all variants. */
    readonly root: "cds-Switch";
    /** Underlying `Control` wrapper element. */
    readonly control: "cds-Switch-control";
    /** Track wrapper element. */
    readonly track: "cds-Switch-track";
    /** Thumb wrapper element. */
    readonly thumb: "cds-Switch-thumb";
};
export type SwitchBaseProps = ControlBaseProps<string> & {
    /** Sets the checked/active color of the control.
     * @default bgPrimary
     */
    controlColor?: ThemeVars.Color;
};
export type SwitchProps = SwitchBaseProps & StylesAndClassNames<typeof switchClassNames> & {
    /**
     * Label content rendered next to the switch control.
     *
     * @example
     * ```tsx
     * <Switch onChange={handleChange}>Dark mode</Switch>
     * ```
     */
    children?: React.ReactNode;
};
export declare const Switch: React.NamedExoticComponent<import("../types").FilteredHTMLAttributes<React.InputHTMLAttributes<HTMLInputElement>, "color" | "value"> & import("@cbhq/cds-common").SharedProps & Partial<Pick<import("../system").InteractableBaseProps, "borderWidth" | "borderRadius" | "color" | "style" | "background" | "borderColor" | "elevation" | "className">> & {
    children?: React.ReactNode;
    checked?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    value?: string | undefined;
    accessibilityLabel?: string;
    indeterminate?: boolean;
    iconStyle?: React.CSSProperties;
    labelStyle?: React.CSSProperties;
} & {
    /** Sets the checked/active color of the control.
     * @default bgPrimary
     */
    controlColor?: ThemeVars.Color;
} & StylesAndClassNames<{
    /** Persistent outer wrapper across all variants. */
    readonly root: "cds-Switch";
    /** Underlying `Control` wrapper element. */
    readonly control: "cds-Switch-control";
    /** Track wrapper element. */
    readonly track: "cds-Switch-track";
    /** Thumb wrapper element. */
    readonly thumb: "cds-Switch-thumb";
}> & {
    /**
     * Label content rendered next to the switch control.
     *
     * @example
     * ```tsx
     * <Switch onChange={handleChange}>Dark mode</Switch>
     * ```
     */
    children?: React.ReactNode;
} & React.RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=Switch.d.ts.map