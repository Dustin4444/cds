import React from 'react';
import type { SharedAccessibilityProps, SharedInputProps, SharedProps } from '@cbhq/cds-common/types';
import type { DropdownProps } from '../dropdown/DropdownProps';
import type { InputStackBaseProps } from './InputStack';
export type SelectBaseProps = SharedProps & Omit<SharedInputProps, 'label'> & Pick<InputStackBaseProps, 'disabled' | 'focused' | 'startNode' | 'variant' | 'labelVariant'> & Pick<SharedAccessibilityProps, 'accessibilityLabel' | 'accessibilityLabelledBy' | 'accessibilityHint'> & Pick<DropdownProps, 'disablePortal' | 'width'> & {
    children?: React.ReactNode;
    /** Event handler for when the Select Input trigger is pressed */
    onClick?: () => void;
    /** Pass a value that will prepopulate the select input. This will replace the placeholder text. */
    value?: string;
    /** Optional label for selected value when using a value/label object model */
    valueLabel?: string;
    /** Optional string placed above the input (or within if compact is enabled) to indicate purpose of the input */
    label?: string;
    /** Callback that is fired whenever a select option is selected */
    onChange?: ((newValue: string) => void) | React.Dispatch<React.SetStateAction<string>>;
};
export type SelectProps = SelectBaseProps;
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const Select: React.NamedExoticComponent<SharedProps & Omit<SharedInputProps, "label"> & Pick<InputStackBaseProps, "disabled" | "variant" | "startNode" | "focused" | "labelVariant"> & Pick<SharedAccessibilityProps, "accessibilityLabel" | "accessibilityLabelledBy" | "accessibilityHint"> & Pick<DropdownProps, "width" | "disablePortal"> & {
    children?: React.ReactNode;
    /** Event handler for when the Select Input trigger is pressed */
    onClick?: () => void;
    /** Pass a value that will prepopulate the select input. This will replace the placeholder text. */
    value?: string;
    /** Optional label for selected value when using a value/label object model */
    valueLabel?: string;
    /** Optional string placed above the input (or within if compact is enabled) to indicate purpose of the input */
    label?: string;
    /** Callback that is fired whenever a select option is selected */
    onChange?: ((newValue: string) => void) | React.Dispatch<React.SetStateAction<string>>;
} & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=Select.d.ts.map