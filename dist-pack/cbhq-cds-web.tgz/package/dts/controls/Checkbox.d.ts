import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import { type ControlBaseProps } from './Control';
export type CheckboxBaseProps<CheckboxValue extends string> = ControlBaseProps<CheckboxValue> & {
  /**
   * Sets the checked/active color of the checkbox.
   * @default fgInverse
   */
  controlColor?: ThemeVars.Color;
  /**
   * Sets the border width of the checkbox.
   * @default 100
   */
  borderWidth?: ThemeVars.BorderWidth;
  /**
   * Sets the outer checkbox control size in pixels.
   * @default theme.controlSize.checkboxSize
   */
  controlSize?: number;
};
export type CheckboxProps<CheckboxValue extends string> = CheckboxBaseProps<CheckboxValue>;
declare const CheckboxWithRef: <CheckboxValue extends string>(
  props: CheckboxProps<CheckboxValue> & {
    ref?: React.Ref<HTMLInputElement>;
  },
) => React.ReactElement;
export declare const Checkbox: typeof CheckboxWithRef &
  React.MemoExoticComponent<typeof CheckboxWithRef>;
export {};
//# sourceMappingURL=Checkbox.d.ts.map
