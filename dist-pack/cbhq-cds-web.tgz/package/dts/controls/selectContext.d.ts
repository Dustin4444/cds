import type { SelectBaseProps } from './Select';
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export type SelectContextType = {
    handleCloseMenu?: () => void;
} & Pick<SelectBaseProps, 'onChange' | 'value'>;
export declare const defaultContext: {
    onChange: () => void;
    value: undefined;
    handleCloseMenu: undefined;
};
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const SelectContext: import("react").Context<SelectContextType>;
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const SelectProvider: import("react").Provider<SelectContextType>;
/**
 * @deprecated Please use the new Select alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const useSelectContext: () => SelectContextType;
//# sourceMappingURL=selectContext.d.ts.map