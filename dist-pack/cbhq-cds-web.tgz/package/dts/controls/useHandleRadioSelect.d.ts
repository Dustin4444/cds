export declare function useHandleRadioSelect<RadioValue extends string>(
  onChange?: (value: RadioValue) => void,
): import('react').ChangeEventHandler<HTMLInputElement>;
//# sourceMappingURL=useHandleRadioSelect.d.ts.map
