import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import { type ControlBaseProps } from './Control';
export type RadioBaseProps<RadioValue extends string> = ControlBaseProps<RadioValue> & {
  /**
   * Sets the checked/active color of the radio.
   * @default bgPrimary
   */
  controlColor?: ThemeVars.Color;
  /**
   * Sets the border width of the radio.
   * @default 100
   */
  borderWidth?: ThemeVars.BorderWidth;
  /**
   * Sets the outer radio control size in pixels.
   * @default theme.controlSize.radioSize
   */
  controlSize?: number;
  /**
   * Sets the inner dot size in pixels.
   * @default 2/3 of controlSize
   */
  dotSize?: number;
};
export type RadioProps<RadioValue extends string> = RadioBaseProps<RadioValue>;
declare const RadioWithRef: <RadioValue extends string>(
  props: RadioProps<RadioValue> & {
    ref?: React.Ref<HTMLInputElement>;
  },
) => React.ReactElement;
export declare const Radio: typeof RadioWithRef & React.MemoExoticComponent<typeof RadioWithRef>;
export {};
//# sourceMappingURL=Radio.d.ts.map
