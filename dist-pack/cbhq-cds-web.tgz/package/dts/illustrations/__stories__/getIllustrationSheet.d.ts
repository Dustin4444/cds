import type { IllustrationVariant } from '@cbhq/cds-common';
type IllustrationSheetProps<Type> = {
  type: Type;
  startIndex?: number;
  endIndex?: number;
};
export declare function getIllustrationSheet<Type extends IllustrationVariant>({
  type,
  startIndex,
  endIndex,
}: IllustrationSheetProps<Type>): () => import('react/jsx-runtime').JSX.Element;
export {};
//# sourceMappingURL=getIllustrationSheet.d.ts.map
