/**
 * DO NOT MODIFY
 * Generated from yarn nx run illustrations:generate-stories
 */
declare const _default: {
  title: string;
  component: import('react').NamedExoticComponent<
    import('../createIllustration').IllustrationBasePropsWithA11y<'pictogram'>
  >;
};
export default _default;
export declare const pictogram: () => import('react/jsx-runtime').JSX.Element;
export declare const pictogramSheet1: () => import('react/jsx-runtime').JSX.Element;
export declare const pictogramSheet2: () => import('react/jsx-runtime').JSX.Element;
export declare const pictogramSheet3: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Pictogram.stories.d.ts.map
