/**
 * DO NOT MODIFY
 * Generated from yarn nx run illustrations:generate-stories
 */
declare const _default: {
  title: string;
  component: import('react').NamedExoticComponent<
    import('../createIllustration').IllustrationBasePropsWithA11y<'spotRectangle'>
  >;
};
export default _default;
export declare const spotRectangle: () => import('react/jsx-runtime').JSX.Element;
export declare const spotRectangleSheet1: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=SpotRectangle.stories.d.ts.map
