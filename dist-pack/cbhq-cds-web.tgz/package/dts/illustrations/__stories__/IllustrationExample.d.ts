import React from 'react';
export declare const IllustrationExample: React.NamedExoticComponent<{
  children?: React.ReactNode | undefined;
}>;
//# sourceMappingURL=IllustrationExample.d.ts.map
