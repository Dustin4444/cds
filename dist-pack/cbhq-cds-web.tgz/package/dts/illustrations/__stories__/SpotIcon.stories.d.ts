/**
 * DO NOT MODIFY
 * Generated from yarn nx run illustrations:generate-stories
 */
declare const _default: {
  title: string;
  component: import('react').NamedExoticComponent<
    import('../createIllustration').IllustrationBasePropsWithA11y<'spotIcon'>
  >;
};
export default _default;
export declare const spotIcon: () => import('react/jsx-runtime').JSX.Element;
export declare const spotIconSheet1: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=SpotIcon.stories.d.ts.map
