/**
 * DO NOT MODIFY
 * Generated from yarn nx run illustrations:generate-stories
 */
declare const _default: {
  title: string;
  component: import('react').NamedExoticComponent<
    import('../createIllustration').IllustrationBasePropsWithA11y<'spotSquare'>
  >;
};
export default _default;
export declare const spotSquare: () => import('react/jsx-runtime').JSX.Element;
export declare const spotSquareSheet1: () => import('react/jsx-runtime').JSX.Element;
export declare const spotSquareSheet2: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=SpotSquare.stories.d.ts.map
