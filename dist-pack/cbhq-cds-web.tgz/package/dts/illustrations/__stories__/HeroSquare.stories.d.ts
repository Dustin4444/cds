/**
 * DO NOT MODIFY
 * Generated from yarn nx run illustrations:generate-stories
 */
declare const _default: {
  title: string;
  component: import('react').NamedExoticComponent<
    import('../createIllustration').IllustrationBasePropsWithA11y<'heroSquare'>
  >;
};
export default _default;
export declare const heroSquare: () => import('react/jsx-runtime').JSX.Element;
export declare const heroSquareSheet1: () => import('react/jsx-runtime').JSX.Element;
export declare const heroSquareSheet2: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=HeroSquare.stories.d.ts.map
