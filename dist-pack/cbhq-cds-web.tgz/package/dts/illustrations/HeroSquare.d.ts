import {
  type IllustrationA11yProps,
  type IllustrationBaseProps,
  type IllustrationDimensionsMap,
} from './createIllustration';
export type HeroSquareBaseProps = IllustrationBaseProps<'heroSquare'> &
  IllustrationA11yProps & {
    /**
     * HeroSquare dimensions.
     * @default  240x240
     * */
    dimension?: IllustrationDimensionsMap['heroSquare'];
  };
export type HeroSquareProps = HeroSquareBaseProps;
export declare const HeroSquare: import('react').NamedExoticComponent<
  import('./createIllustration').IllustrationBasePropsWithA11y<'heroSquare'>
>;
export type { HeroSquareName } from '@cbhq/cds-illustrations/__generated__/heroSquare/types/HeroSquareName';
//# sourceMappingURL=HeroSquare.d.ts.map
