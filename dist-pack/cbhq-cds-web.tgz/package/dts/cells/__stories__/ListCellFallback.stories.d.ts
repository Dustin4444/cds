import React from 'react';
declare const _default: {
  title: string;
  component: React.NamedExoticComponent<import('..').ListCellFallbackProps>;
};
export default _default;
export declare const Fallbacks: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=ListCellFallback.stories.d.ts.map
