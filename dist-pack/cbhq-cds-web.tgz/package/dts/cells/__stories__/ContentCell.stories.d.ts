import React from 'react';
declare const _default: {
  title: string;
  component: (<AsComponent extends React.ElementType = 'div'>(
    props: import('..').ContentCellProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
};
export default _default;
export declare const Content: () => import('react/jsx-runtime').JSX.Element;
export declare const LongContent: () => import('react/jsx-runtime').JSX.Element;
export declare const PressableContent: () => import('react/jsx-runtime').JSX.Element;
export declare const WithAccessory: () => import('react/jsx-runtime').JSX.Element;
export declare const WithMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const SpacingVariant: () => import('react/jsx-runtime').JSX.Element;
export declare const CondensedContentCell: () => import('react/jsx-runtime').JSX.Element;
export declare const Fallback: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=ContentCell.stories.d.ts.map
