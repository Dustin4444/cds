import React from 'react';
declare const _default: {
  title: string;
  component: React.NamedExoticComponent<import('..').ContentCellFallbackProps>;
};
export default _default;
export declare const Fallbacks: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=ContentCellFallback.stories.d.ts.map
