import React from 'react';
declare const _default: {
    title: string;
    component: (<AsComponent extends React.ElementType = "div">(props: import("..").ListCellProps<AsComponent>) => import("../..").Polymorphic.ReactReturn) & import("../..").Polymorphic.ReactNamed;
    parameters: {
        percy: {
            enableJavaScript: boolean;
        };
        a11y: {
            config: {
                rules: {
                    id: string;
                    enabled: boolean;
                }[];
            };
            context: {
                include: string[];
                exclude: string[];
            };
        };
    };
};
export default _default;
export declare const withA11yVStack: () => import("react/jsx-runtime").JSX.Element;
declare const Content: () => import("react/jsx-runtime").JSX.Element;
declare const CustomNodes: () => import("react/jsx-runtime").JSX.Element;
declare const CompactContentDeprecated: () => import("react/jsx-runtime").JSX.Element;
declare const PressableContent: () => import("react/jsx-runtime").JSX.Element;
declare const CompactPressableContentDeprecated: () => import("react/jsx-runtime").JSX.Element;
declare const LongContent: () => import("react/jsx-runtime").JSX.Element;
declare const PriorityContent: () => import("react/jsx-runtime").JSX.Element;
declare const WithAccessory: () => import("react/jsx-runtime").JSX.Element;
declare const WithMedia: () => import("react/jsx-runtime").JSX.Element;
declare const WithActions: () => import("react/jsx-runtime").JSX.Element;
declare const Fallback: () => import("react/jsx-runtime").JSX.Element;
declare const WithIntermediary: () => import("react/jsx-runtime").JSX.Element;
declare const WithHelperText: () => import("react/jsx-runtime").JSX.Element;
declare const BorderCustomization: () => import("react/jsx-runtime").JSX.Element;
declare const CondensedListCell: () => import("react/jsx-runtime").JSX.Element;
declare const UseCaseShowcase: () => import("react/jsx-runtime").JSX.Element;
/**
 * This story shows all 3 spacing variants side by side for easy comparison.
 * Each column represents a different variant, and each row shows the same content configuration.
 *
 * This is useful for:
 * - Comparing visual differences between variants
 * - Understanding the impact of removing fixed min-height values
 * - Testing before/after changes to spacing or height behavior
 *
 * Current min-height values:
 * - normal: 80px
 * - compact (deprecated): 40px
 * - condensed: undefined (no min-height)
 */
declare const SpacingVariantsComparison: () => import("react/jsx-runtime").JSX.Element;
export { BorderCustomization, CompactContentDeprecated, CompactPressableContentDeprecated, CondensedListCell, Content, CustomNodes, Fallback, LongContent, PressableContent, PriorityContent, SpacingVariantsComparison, UseCaseShowcase, WithAccessory, WithActions, WithHelperText, WithIntermediary, WithMedia, };
//# sourceMappingURL=ListCell.stories.d.ts.map