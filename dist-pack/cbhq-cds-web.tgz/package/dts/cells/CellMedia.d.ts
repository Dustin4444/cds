import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { IconName, SharedAccessibilityProps, SharedProps } from '@cbhq/cds-common/types';
import type { PictogramProps } from '../illustrations/Pictogram';
export type CellMediaType = 'asset' | 'avatar' | 'image' | 'icon' | 'pictogram';
export type CellMediaIconProps = {
  type: Extract<CellMediaType, 'icon'>;
  name: IconName;
  /** Whether the icon is active */
  active?: boolean;
  color?: ThemeVars.Color;
};
export type CellMediaPictogramProps = {
  type: Extract<CellMediaType, 'pictogram'>;
  illustration: React.ReactElement<PictogramProps>;
};
type CellMediaOtherProps = {
  type: Exclude<CellMediaType, 'icon' | 'pictogram'>;
  /**
   * @deprecated This will be removed in a future major release.
   * @deprecationExpectedRemoval v6
   * If required, use `accessibilityLabel` and `accessibilityHint` instead to set accessible labels.
   * Refer to https://cds.coinbase.com/components/cell-media/ for updated accessibility guidance.
   */
  title?: string;
  source: string | number;
};
type CellMediaVariantProps = CellMediaIconProps | CellMediaPictogramProps | CellMediaOtherProps;
export type CellMediaBaseProps = SharedProps &
  CellMediaVariantProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabel'>;
export type CellMediaProps = CellMediaBaseProps;
/**
 * @deprecated Pass media directly via the `media` prop. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 * For example: `<Avatar src={...} />`, `<Icon name={...} />`, `<RemoteImage source={...} />`, or a Pictogram.
 */
export declare const CellMedia: React.NamedExoticComponent<CellMediaBaseProps>;
export {};
//# sourceMappingURL=CellMedia.d.ts.map
