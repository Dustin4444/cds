import type { CSSProperties, ReactNode } from 'react';
import type { FallbackRectWidthProps, SharedProps } from '@cbhq/cds-common/types';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types/SharedAccessibilityProps';
import { type CellAccessoryType } from './CellAccessory';
import type { CellMediaType } from './CellMedia';
import { type ListCellBaseProps } from './ListCell';
export type ListCellFallbackBaseProps = SharedProps &
  FallbackRectWidthProps &
  Pick<SharedAccessibilityProps, 'accessibilityLabel'> &
  Pick<ListCellBaseProps, 'innerSpacing' | 'outerSpacing' | 'spacingVariant'> & {
    /** Accessory to display at the end of the cell. */
    accessory?: CellAccessoryType;
    /** Custom accessory rendered at the end of the cell. Takes precedence over `accessory`. */
    accessoryNode?: ReactNode;
    /** Display description shimmer. */
    description?: boolean;
    /** Display detail shimmer. */
    detail?: boolean;
    /** Display helper text shimmer. */
    helperText?: boolean;
    /** Display media shimmer with a shape according to type. */
    media?: CellMediaType;
    /** Display subdetail shimmer. */
    subdetail?: boolean;
    /** Display subtitle shimmer. */
    subtitle?: boolean;
    /** Display title shimmer. */
    title?: boolean;
  };
export type ListCellFallbackProps = ListCellFallbackBaseProps & {
  /** Class names to apply to parts of the fallback cell. */
  classNames?: {
    /** Class name for the bottom content (helper text). */
    helperText?: string;
    /** Class name for the detail shimmer. */
    detail?: string;
    /** Class name for the subdetail shimmer. */
    subdetail?: string;
    /** Class name for the accessory container. */
    accessory?: string;
    /** Class name for the subtitle shimmer. */
    subtitle?: string;
    /** Class name for the title shimmer. */
    title?: string;
    /** Class name for the description shimmer. */
    description?: string;
  };
  /** Styles to apply to parts of the fallback cell. */
  styles?: {
    /** Style to apply to the bottom content (helper text shimmer). */
    helperText?: CSSProperties;
    /** Style to apply to the detail shimmer. */
    detail?: CSSProperties;
    /** Style to apply to the subdetail shimmer. */
    subdetail?: CSSProperties;
    /** Style to apply to the accessory container. */
    accessory?: CSSProperties;
    /** Style to apply to the subtitle shimmer. */
    subtitle?: CSSProperties;
    /** Style to apply to the title shimmer. */
    title?: CSSProperties;
    /** Style to apply to the description shimmer. */
    description?: CSSProperties;
  };
};
export declare const ListCellFallback: import('react').NamedExoticComponent<ListCellFallbackProps>;
//# sourceMappingURL=ListCellFallback.d.ts.map
