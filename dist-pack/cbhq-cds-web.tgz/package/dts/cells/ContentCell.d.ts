import React from 'react';
import type { Polymorphic } from '../core/polymorphism';
import { type CellBaseProps } from './Cell';
import { type CellAccessoryType } from './CellAccessory';
export declare const contentCellDefaultElement = 'div';
export type ContentCellDefaultElement = typeof contentCellDefaultElement;
/**
 * @deprecated Use ListCell instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export type ContentCellBaseProps = Polymorphic.ExtendableProps<
  Omit<CellBaseProps, 'children'>,
  {
    /** Accessory to display at the end of the cell. */
    accessory?: CellAccessoryType;
    /**
     * @deprecated Use `spacingVariant="compact"` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    compact?: boolean;
    /**
     * Spacing variant configuration.
     * Deprecated value: 'compact'. Prefer 'condensed'.
     *
     * When `spacingVariant="normal"`:
     * 1. `min-height` is `80px`
     * 2. `padding` is `'var(--space-2) var(--space-3)'`
     * 3. `border-radius` is `'var(--borderRadius-200)'`
     *
     * When `spacingVariant="compact"`:
     * 1. same as `spacingVariant="normal"`, except `min-height` is `40px`
     *
     * When `spacingVariant="condensed"`:
     * 1. `min-height` is undefined
     * 2. `padding` is `'var(--space-1) var(--space-2)'`
     * 3. `border-radius` is `'var(--borderRadius-0)'`
     * 4. subtitle uses `label1`
     * 5. title wraps to 2 lines regardless of description content
     * 6. meta is placed alongside the accessory
     *
     * @default 'normal'
     */
    spacingVariant?: 'normal' | 'compact' | 'condensed';
    /**
     * React node to render description. Takes precedence over `description`.
     * When provided, `classNames.description` and `styles.description` are not applied.
     */
    descriptionNode?: React.ReactNode;
    /** Description of content. Content will wrap accordingly. */
    description?: React.ReactNode;
    /**
     * React node to render meta. Takes precedence over `meta`.
     * When provided, `classNames.meta` and `styles.meta` are not applied.
     */
    metaNode?: React.ReactNode;
    /** Media (icon, asset, image, etc) to display at the start of the cell. */
    media?: React.ReactElement;
    /** Meta information to display at the end of the title. */
    meta?: React.ReactNode;
    /**
     * React node to render subtitle. Takes precedence over `subtitle`.
     * When provided, `classNames.subtitle` and `styles.subtitle` are not applied.
     */
    subtitleNode?: React.ReactNode;
    /** Subtitle of content. Max 1 line, otherwise will truncate. */
    subtitle?: React.ReactNode;
    /**
     * React node to render title. Takes precedence over `title`.
     * When provided, `classNames.title` and `styles.title` are not applied.
     */
    titleNode?: React.ReactNode;
    /** Title of content. Up to 2 lines depending on spacing variant. */
    title?: React.ReactNode;
    /** Class names for subcomponents, ignored when the corresponding `xxNode` prop is used */
    classNames?: {
      /** Root element */
      root?: string;
      /** Media element */
      media?: string;
      /** Accessory element */
      accessory?: string;
      /** Content container element */
      contentContainer?: string;
      /** Pressable wrapper element */
      pressable?: string;
      /** Main content element */
      mainContent?: string;
      /** Title text element */
      title?: string;
      /** Subtitle text element */
      subtitle?: string;
      /** End element */
      end?: string;
      /** Meta container element */
      metaContainer?: string;
      /** Meta text element */
      meta?: string;
      /** Description text element */
      description?: string;
    };
    /** Styles for subcomponents, ignored when the corresponding `xxNode` prop is used */
    styles?: {
      /** Root element */
      root?: React.CSSProperties;
      /** Media element */
      media?: React.CSSProperties;
      /** Accessory element */
      accessory?: React.CSSProperties;
      /** Content container element */
      contentContainer?: React.CSSProperties;
      /** Pressable wrapper element */
      pressable?: React.CSSProperties;
      /** Main content element */
      mainContent?: React.CSSProperties;
      /** Title text element */
      title?: React.CSSProperties;
      /** Subtitle text element */
      subtitle?: React.CSSProperties;
      /** End element */
      end?: React.CSSProperties;
      /** Meta container element */
      metaContainer?: React.CSSProperties;
      /** Meta text element */
      meta?: React.CSSProperties;
      /** Description text element */
      description?: React.CSSProperties;
    };
  }
>;
export type ContentCellProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  ContentCellBaseProps
>;
type ContentCellComponent = (<AsComponent extends React.ElementType = ContentCellDefaultElement>(
  props: ContentCellProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
/**
 * @deprecated Use ListCell instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const ContentCell: ContentCellComponent;
export {};
//# sourceMappingURL=ContentCell.d.ts.map
