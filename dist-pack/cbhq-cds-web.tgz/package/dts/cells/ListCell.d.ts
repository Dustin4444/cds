import React from 'react';
import type { Polymorphic } from '../core/polymorphism';
import { type CellBaseProps } from './Cell';
import { type CellAccessoryType } from './CellAccessory';
import { type CellDetailProps } from './CellDetail';
export declare const listCellDefaultElement = 'div';
export type ListCellDefaultElement = typeof listCellDefaultElement;
export declare const condensedInnerSpacing: {
  readonly paddingX: 3;
  readonly paddingY: 1;
  readonly marginX: 0;
};
export declare const condensedOuterSpacing: {
  readonly paddingX: 0;
  readonly paddingY: 0;
  readonly marginX: 0;
};
export type ListCellBaseProps = Polymorphic.ExtendableProps<
  Omit<CellBaseProps, 'children'>,
  CellDetailProps & {
    /** Accessory to display at the end of the cell. */
    accessory?: CellAccessoryType;
    /**
     * End-aligned content (e.g., CTA, form element, metric). Replacement for the deprecated action prop, and takes precedence over it.
     * If the content is an action (like button, link, etc), we recommend avoiding use alongside `onClick`.
     * If used alongside `onClick`, the end action is triggered first and then the `onClick` handler.
     */
    end?: React.ReactNode;
    /**
     * @deprecated Use `end` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    action?: React.ReactNode;
    /**
     * @deprecated Use `spacingVariant="condensed"` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    compact?: boolean;
    /**
     * Spacing variant configuration.
     * Deprecated values: 'normal' and 'compact'. Prefer 'condensed'.
     *
     * When `spacingVariant="normal"`:
     * 1. `min-height` is `80px`
     * 2. `padding` is `'var(--space-2) var(--space-3)'`
     * 3. `border-radius` is `'var(--borderRadius-200)'`
     * 4. when there is a description, title's `numberOfLines={1}` otherwise title's `numberOfLines={2}`
     * 5. description and subdetail have font `body`
     *
     * When `spacingVariant="compact"`:
     * 1. same as `spacingVariant="normal"`, except `min-height` is `40px`
     *
     * When `spacingVariant="condensed"`:
     * 1. `min-height` is undefined
     * 2. `padding` is `'var(--space-1) var(--space-2)'`
     * 3. `border-radius` is `--borderRadius-0`
     * 4. title's `numberOfLines={2}`
     * 5. description and subdetail have font `label2`
     *
     * @default 'normal'
     */
    spacingVariant?: /** @deprecated Use 'condensed' instead. */
      | 'normal'
      | /** @deprecated Use 'condensed' instead. */ 'compact'
      | 'condensed';
    /** Description of content. Max 1 line (with title) or 2 lines (without), otherwise will truncate. This prop is only intended to accept a string or Text component; other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `descriptionNode`. */
    description?: React.ReactNode;
    /**
     * React node to render description. Takes precedence over `description`.
     * When provided, `classNames.description` and `styles.description` are not applied.
     */
    descriptionNode?: React.ReactNode;
    /**
     * When there is no description the title will take up two lines by default.
     * When this is set to true multiline title behavior is overwritten, and regardless of description text state
     * the title will take up a single line truncating with ellipses.
     */
    disableMultilineTitle?: boolean;
    /**
     * Disable the default accessory that is displayed when the cell is selected.
     * If `accessory` is provided, that will continue to be displayed, otherwise no accessory will be displayed when the cell is selected.
     */
    disableSelectionAccessory?: boolean;
    /** Assitive message to display below the cell content */
    helperText?: React.ReactNode;
    /** For internal use only. */
    intermediary?: React.ReactNode;
    media?: React.ReactElement;
    /** Allow the description to span multiple lines. This *will* break fixed height requirements, so should not be used in a `FlatList`. */
    multiline?: boolean;
    /** Title of content. Max 1 line (with description) or 2 lines (without), otherwise will truncate. This prop is only intended to accept a string or Text component; other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `titleNode`. */
    title?: React.ReactNode;
    /**
     * React node to render title. Takes precedence over `title`.
     * When provided, `classNames.title` and `styles.title` are not applied.
     */
    titleNode?: React.ReactNode;
    /** Subtitle to display below the title and above the description. This prop is only intended to accept a string or Text component; other use cases, while allowed, are not supported and may result in unexpected behavior. For arbitrary content, use `subtitleNode`. */
    subtitle?: React.ReactNode;
    /**
     * React node to render subtitle. Takes precedence over `subtitle`.
     * When provided, `classNames.subtitle` and `styles.subtitle` are not applied.
     */
    subtitleNode?: React.ReactNode;
    /** Class names for subcomponents, ignored when the corresponding `xxNode` prop is used */
    classNames?: {
      /** Root element */
      root?: string;
      /** Media element */
      media?: string;
      /** Intermediary element */
      intermediary?: string;
      /** End element */
      end?: string;
      /** Accessory element */
      accessory?: string;
      /** Content container element */
      contentContainer?: string;
      /** Pressable wrapper element */
      pressable?: string;
      /** Title stack element (title/subtitle/description VStack) */
      titleStack?: string;
      /** Title stack container wrapper, controls flex behavior */
      titleStackContainer?: string;
      /** Main content element */
      mainContent?: string;
      /** Helper text element */
      helperText?: string;
      /** Title text element */
      title?: string;
      /** Subtitle text element */
      subtitle?: string;
      /** Description text element */
      description?: string;
    };
    /** Styles for subcomponents, ignored when the corresponding `xxNode` prop is used */
    styles?: {
      /** Root element */
      root?: React.CSSProperties;
      /** Media element */
      media?: React.CSSProperties;
      /** Intermediary element */
      intermediary?: React.CSSProperties;
      /** End element */
      end?: React.CSSProperties;
      /** Accessory element */
      accessory?: React.CSSProperties;
      /** Content container element */
      contentContainer?: React.CSSProperties;
      /** Pressable wrapper element */
      pressable?: React.CSSProperties;
      /** Title stack element (title/subtitle/description VStack) */
      titleStack?: React.CSSProperties;
      /** Title stack container wrapper, controls flex behavior */
      titleStackContainer?: React.CSSProperties;
      /** Main content element */
      mainContent?: React.CSSProperties;
      /** Helper text element */
      helperText?: React.CSSProperties;
      /** Title text element */
      title?: React.CSSProperties;
      /** Subtitle text element */
      subtitle?: React.CSSProperties;
      /** Description text element */
      description?: React.CSSProperties;
    };
  }
>;
export type ListCellProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  ListCellBaseProps
>;
type ListCellComponent = (<AsComponent extends React.ElementType = ListCellDefaultElement>(
  props: ListCellProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const ListCell: ListCellComponent;
export {};
//# sourceMappingURL=ListCell.d.ts.map
