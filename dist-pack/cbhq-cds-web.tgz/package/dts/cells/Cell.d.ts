import React from 'react';
import type { CellPriority } from '@cbhq/cds-common/types';
import type { Polymorphic } from '../core/polymorphism';
import { type BoxBaseProps } from '../layout/Box';
import { type PressableProps } from '../system/Pressable';
import type { CellAccessoryProps } from './CellAccessory';
export declare const cellDefaultElement = 'div';
export type CellDefaultElement = typeof cellDefaultElement;
export type CellSpacing = Pick<
  BoxBaseProps,
  | 'padding'
  | 'paddingX'
  | 'paddingY'
  | 'paddingTop'
  | 'paddingEnd'
  | 'paddingBottom'
  | 'paddingStart'
  | 'margin'
  | 'marginX'
  | 'marginY'
  | 'marginTop'
  | 'marginEnd'
  | 'marginBottom'
  | 'marginStart'
>;
export type CellBaseProps = Polymorphic.ExtendableProps<
  BoxBaseProps,
  Pick<PressableProps<'a'>, 'href' | 'target'> & {
    /**
     * @deprecated Use `classNames.contentContainer` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    contentClassName?: string;
    /** Key down handler for keyboard interaction. */
    onKeyDown?: React.KeyboardEventHandler;
    /** Key up handler for keyboard interaction. */
    onKeyUp?: React.KeyboardEventHandler;
    /** Click handler. */
    onClick?: React.MouseEventHandler;
    /** Accessory element rendered at the end of the cell (e.g., chevron). */
    accessory?: React.ReactElement<CellAccessoryProps>;
    /** Custom accessory node rendered at the end of the cell. Takes precedence over `accessory`. */
    accessoryNode?: React.ReactNode;
    /** Main content of the cell; typically title/description content. */
    children: React.ReactNode;
    /**
     * End-aligned content (e.g., value, status).
     * Replaces the deprecated `detail` prop.
     */
    end?: React.ReactNode;
    /**
     * @deprecated Use `end` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    detail?: React.ReactNode;
    /** Middle content between main content and detail. */
    intermediary?: React.ReactNode;
    /** Media rendered at the start of the cell (icon, avatar, image, etc). */
    media?: React.ReactElement;
    /**
     * @deprecated Use `shouldTruncate` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    shouldOverflow?: boolean;
    /**
     * Controls whether the main content should truncate with an ellipsis.
     * Defaults to true (truncates) when not provided.
     * @default true
     */
    shouldTruncate?: boolean;
    /**
     * @deprecated Use `styles.end` instead. This will be removed in a future major release.
     * @deprecationExpectedRemoval v9
     */
    detailWidth?: number | string;
    /** Is the cell disabled? Will apply opacity and disable interaction. */
    disabled?: boolean;
    /** Which piece of content has the highest priority in regards to text truncation, growing, and shrinking. */
    priority?: CellPriority | CellPriority[];
    /** Is the cell selected? Will apply a background and selected accessory. */
    selected?: boolean;
    /** The spacing to use on the parent wrapper of Cell */
    outerSpacing?: CellSpacing;
    /** The spacing to use on the inner content of Cell */
    innerSpacing?: CellSpacing;
    /** The content to display below the main cell content */
    bottomContent?: React.ReactNode;
    /** Custom styles for individual elements of the Cell component */
    styles?: {
      /** Root element */
      root?: React.CSSProperties;
      /** Content container element */
      contentContainer?: React.CSSProperties;
      /** Top content element */
      topContent?: React.CSSProperties;
      /** Bottom content element */
      bottomContent?: React.CSSProperties;
      /** Pressable wrapper element */
      pressable?: React.CSSProperties;
      /** Media element */
      media?: React.CSSProperties;
      /** Children container wrapper, controls flex behavior */
      childrenContainer?: React.CSSProperties;
      /** Intermediary element */
      intermediary?: React.CSSProperties;
      /** End element (detail or action container) */
      end?: React.CSSProperties;
      /** Accessory element */
      accessory?: React.CSSProperties;
    };
    /** Custom class names for individual elements of the Cell component */
    classNames?: {
      /** Root element */
      root?: string;
      /** Content container element */
      contentContainer?: string;
      /** Top content element */
      topContent?: string;
      /** Bottom content element */
      bottomContent?: string;
      /** Pressable wrapper element */
      pressable?: string;
      /** Media element */
      media?: string;
      /** Children container wrapper, controls flex behavior */
      childrenContainer?: string;
      /** Intermediary element */
      intermediary?: string;
      /** End element (detail or action container) */
      end?: string;
      /** Accessory element */
      accessory?: string;
    };
  }
>;
export type CellProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  CellBaseProps
>;
type CellComponent = (<AsComponent extends React.ElementType = CellDefaultElement>(
  props: CellProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const Cell: CellComponent;
export {};
//# sourceMappingURL=Cell.d.ts.map
