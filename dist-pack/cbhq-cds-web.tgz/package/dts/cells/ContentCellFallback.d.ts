import React from 'react';
import type { FallbackRectWidthProps } from '@cbhq/cds-common/types';
import type { SharedAccessibilityProps } from '@cbhq/cds-common/types/SharedAccessibilityProps';
import { type CellAccessoryType } from './CellAccessory';
import type { CellMediaType } from './CellMedia';
import type { ContentCellBaseProps } from './ContentCell';
type ContentCellFallbackSpacingProps = Pick<ContentCellBaseProps, 'innerSpacing' | 'outerSpacing' | 'spacingVariant'>;
export type ContentCellFallbackProps = FallbackRectWidthProps & ContentCellFallbackSpacingProps & Pick<SharedAccessibilityProps, 'accessibilityLabel'> & {
    /** Accessory to display at the end of the cell. */
    accessory?: CellAccessoryType;
    /** Custom accessory rendered at the end of the cell. Takes precedence over `accessory`. */
    accessoryNode?: React.ReactNode;
    /** Display description shimmer. */
    description?: boolean;
    /** Display media shimmer with a shape according to type. */
    media?: CellMediaType;
    /** Display meta shimmer. */
    meta?: boolean;
    /** Display subtitle shimmer. */
    subtitle?: boolean;
    /** Display title shimmer. */
    title?: boolean;
};
/**
 * @deprecated Use `ListCellFallback` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const ContentCellFallback: React.NamedExoticComponent<ContentCellFallbackProps>;
export {};
//# sourceMappingURL=ContentCellFallback.d.ts.map