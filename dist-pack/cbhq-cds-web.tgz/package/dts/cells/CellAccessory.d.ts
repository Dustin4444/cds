import React from 'react';
import type { PaddingProps } from '@cbhq/cds-common/types';
import { type BoxDefaultElement, type BoxProps } from '../layout/Box';
export declare const cellAccessoryTestId = "accessory";
export type CellAccessoryType = 'arrow' | 'more' | 'selected' | 'unselected';
export type CellAccessoryBaseProps = PaddingProps & {
    /** Type of accessory to display at the end. */
    type: CellAccessoryType;
    /**
     * @danger This is a migration escape hatch. It is not intended to be used normally.
     */
    className?: string;
};
export type CellAccessoryProps = CellAccessoryBaseProps & BoxProps<BoxDefaultElement>;
export declare const CellAccessory: React.NamedExoticComponent<Omit<CellAccessoryProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=CellAccessory.d.ts.map