export {};
//# sourceMappingURL=CellAccessory.test.d.ts.map
