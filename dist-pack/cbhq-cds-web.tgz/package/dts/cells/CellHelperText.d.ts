import { cellHelperTextVariants } from '@cbhq/cds-common/tokens/cell';
import { type TextProps } from '../typography/Text';
export type CellHelperTextVariant = 'information' | 'warning' | 'error';
export type CellHelperTextProps = TextProps<'span'> & {
    /** The variant determines the icon and color scheme */
    variant?: keyof typeof cellHelperTextVariants;
};
export declare const CellHelperText: import("react").NamedExoticComponent<Omit<CellHelperTextProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=CellHelperText.d.ts.map