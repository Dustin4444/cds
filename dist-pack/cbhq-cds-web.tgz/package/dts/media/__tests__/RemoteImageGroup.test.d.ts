import '@testing-library/jest-dom';
//# sourceMappingURL=RemoteImageGroup.test.d.ts.map
