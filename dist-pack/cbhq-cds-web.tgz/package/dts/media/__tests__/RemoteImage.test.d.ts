import '@testing-library/jest-dom';
//# sourceMappingURL=RemoteImage.test.d.ts.map
