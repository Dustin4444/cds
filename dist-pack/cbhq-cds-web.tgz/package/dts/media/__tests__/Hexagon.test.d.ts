import '@testing-library/jest-dom';
//# sourceMappingURL=Hexagon.test.d.ts.map
