import React from 'react';
import type {
  AvatarSize,
  Shape,
  SharedAccessibilityProps,
  SharedProps,
} from '@cbhq/cds-common/types';
import { type BoxDefaultElement, type BoxProps } from '../layout/Box';
export type RemoteImageGroupBaseProps = SharedProps &
  SharedAccessibilityProps &
  Pick<BoxProps<BoxDefaultElement>, 'borderWidth' | 'borderColor'> & {
    /**
     * Indicates the number of remote image before it collapses
     * @default 4
     */
    max?: number;
    /**
     * Size of all RemoteImage children in the group.
     * @default m
     */
    size?: AvatarSize | number;
    /**
     * Shape of all RemoteImage children in the group
     * @default circle
     */
    shape?: Shape;
    /** Children content */
    children?: React.ReactNode;
  };
export type RemoteImageGroupProps = RemoteImageGroupBaseProps;
export declare const RemoteImageGroup: (
  _props: RemoteImageGroupProps,
) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=RemoteImageGroup.d.ts.map
