import React from 'react';
import type { AvatarSize } from '@cbhq/cds-common/types/AvatarSize';
import type { AspectRatio, Shape } from '@cbhq/cds-common/types/Shape';
import { type BoxProps } from '../layout/Box';
declare const resizeCss: {
  cover: import('@linaria/core').LinariaClassName;
  contain: import('@linaria/core').LinariaClassName;
};
export type RemoteImageBaseProps = Omit<BoxProps<'img'>, 'aspectRatio'> & {
  /** Absolute url to the image that should be shown in the RemoteImage. If no source is provided then a generic fallback image is used. */
  source?: string;
  resizeMode?: keyof typeof resizeCss;
  /**
   * Shape of RemoteImage
   * @default square
   * */
  shape?: Shape;
  /**
   * Size for a given RemoteImage. If width or height is not defined,
   * it will set size = m as default
   *
   * @default m
   * */
  size?: AvatarSize;
  aspectRatio?: AspectRatio;
};
export type RemoteImageProps = RemoteImageBaseProps;
export declare const RemoteImage: React.MemoExoticComponent<
  (_props: RemoteImageProps) => import('react/jsx-runtime').JSX.Element
>;
export {};
//# sourceMappingURL=RemoteImage.d.ts.map
