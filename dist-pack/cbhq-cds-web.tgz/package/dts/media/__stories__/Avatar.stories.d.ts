import React from 'react';
import { type AvatarProps } from '../Avatar';
declare const _default: {
  component: React.MemoExoticComponent<
    (_props: AvatarProps) => import('react/jsx-runtime').JSX.Element
  >;
  title: string;
};
export default _default;
export declare const Normal: () => import('react/jsx-runtime').JSX.Element;
export declare const FallbackImage: () => import('react/jsx-runtime').JSX.Element;
export declare const ColorSchemes: () => import('react/jsx-runtime').JSX.Element;
export declare const FallbackColored: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Avatar.stories.d.ts.map
