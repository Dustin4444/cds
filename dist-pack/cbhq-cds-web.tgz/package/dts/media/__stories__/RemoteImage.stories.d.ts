import React from 'react';
declare const _default: {
  component: React.MemoExoticComponent<
    (_props: import('..').RemoteImageProps) => import('react/jsx-runtime').JSX.Element
  >;
  title: string;
};
export default _default;
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=RemoteImage.stories.d.ts.map
