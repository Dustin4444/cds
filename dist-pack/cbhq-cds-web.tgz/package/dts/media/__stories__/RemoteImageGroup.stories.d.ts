declare const _default: {
  component: (
    _props: import('..').RemoteImageGroupProps,
  ) => import('react/jsx-runtime').JSX.Element;
  title: string;
};
export default _default;
export declare const All: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=RemoteImageGroup.stories.d.ts.map
