import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type CollapsibleBaseProps } from '../collapsible';
export type AccordionPanelBaseProps = SharedProps & Pick<CollapsibleBaseProps, 'collapsed' | 'children'> & {
    /**
     * Key of the accordion item.
     * This should be unique inside the same Accordion
     * unless you want multiple items to be controlled at the same time.
     */
    itemKey: string;
    maxHeight?: CollapsibleBaseProps['maxHeight'];
};
export type AccordionPanelProps = AccordionPanelBaseProps;
/**
 * Renders a collapsible element to use as the primary content container for an AccordionItem.
 * Accepts a unique `itemKey` prop to uniquely identify one panel from another.
 */
export declare const AccordionPanel: React.NamedExoticComponent<SharedProps & Pick<CollapsibleBaseProps, "children" | "collapsed"> & {
    /**
     * Key of the accordion item.
     * This should be unique inside the same Accordion
     * unless you want multiple items to be controlled at the same time.
     */
    itemKey: string;
    maxHeight?: CollapsibleBaseProps["maxHeight"];
} & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=AccordionPanel.d.ts.map