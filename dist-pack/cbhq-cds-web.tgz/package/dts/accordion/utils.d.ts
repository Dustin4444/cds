export declare const getAccordionHeaderId: (itemKey: string) => string;
export declare const getAccordionPanelId: (itemKey: string) => string;
//# sourceMappingURL=utils.d.ts.map
