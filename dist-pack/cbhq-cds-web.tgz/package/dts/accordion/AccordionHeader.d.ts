import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { CollapsibleBaseProps } from '../collapsible';
export type AccordionMediaBaseProps = {
    media?: React.ReactNode;
};
export type AccordionTitleBaseProps = {
    /**
     * Title of the accordion item
     */
    title: string;
    /**
     * Subtitle of the accordion item
     */
    subtitle?: string;
};
export type AccordionIconBaseProps = Pick<CollapsibleBaseProps, 'collapsed'>;
export type AccordionHeaderBaseProps = SharedProps & AccordionMediaBaseProps & AccordionTitleBaseProps & AccordionIconBaseProps & {
    /**
     * Callback function fired when the accordion item is clicked
     */
    onClick?: (key: string) => void;
    /**
     * Key of the accordion item.
     * This should be unique inside the same Accordion
     * unless you want multiple items to be controlled at the same time.
     */
    itemKey: string;
};
type AccordionMediaProps = AccordionMediaBaseProps;
export declare const AccordionMedia: React.MemoExoticComponent<({ media }: AccordionMediaProps) => import("react/jsx-runtime").JSX.Element>;
type AccordionTitleProps = AccordionTitleBaseProps;
export declare const AccordionTitle: React.MemoExoticComponent<({ title, subtitle }: AccordionTitleProps) => import("react/jsx-runtime").JSX.Element>;
type AccordionIconProps = AccordionIconBaseProps;
export declare const AccordionIcon: React.MemoExoticComponent<({ collapsed }: AccordionIconProps) => import("react/jsx-runtime").JSX.Element>;
/**
 * Renders a Pressable element to use as the header to an AccordionItem.
 * Composes an Accordion Media, Title, and Icon.
 */
export declare const AccordionHeader: React.NamedExoticComponent<SharedProps & AccordionMediaBaseProps & AccordionTitleBaseProps & AccordionIconBaseProps & {
    /**
     * Callback function fired when the accordion item is clicked
     */
    onClick?: (key: string) => void;
    /**
     * Key of the accordion item.
     * This should be unique inside the same Accordion
     * unless you want multiple items to be controlled at the same time.
     */
    itemKey: string;
} & React.RefAttributes<HTMLButtonElement>>;
export {};
//# sourceMappingURL=AccordionHeader.d.ts.map