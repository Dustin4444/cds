import React from 'react';
import { type AccordionHeaderBaseProps } from './AccordionHeader';
import { type AccordionPanelBaseProps } from './AccordionPanel';
export type AccordionItemBaseProps = Omit<AccordionHeaderBaseProps, 'collapsed'> & Pick<AccordionPanelBaseProps, 'maxHeight' | 'children'> & {
    headerRef?: React.RefObject<HTMLButtonElement | null>;
    panelRef?: React.RefObject<HTMLDivElement | null>;
    style?: React.CSSProperties;
};
export type AccordionItemProps = AccordionItemBaseProps;
/**
 * A component that represents a single item within an Accordion.
 * It composes together an AccordionHeader and a collapsible AccordionPanel.
 * Accepts a unique `itemKey` prop to uniquely identify one item from another within the same Accordion.
 */
export declare const AccordionItem: React.MemoExoticComponent<({ itemKey, title, subtitle, children, onClick, media, testID, headerRef, panelRef, maxHeight, style, }: AccordionItemProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=AccordionItem.d.ts.map