declare const _default: {
  component: (_props: import('..').AccordionProps) => import('react/jsx-runtime').JSX.Element;
  title: string;
};
export default _default;
declare const BasicAccordion: () => import('react/jsx-runtime').JSX.Element;
declare const NoMedia: () => import('react/jsx-runtime').JSX.Element;
declare const NoSubtitle: () => import('react/jsx-runtime').JSX.Element;
declare const TitleOnly: () => import('react/jsx-runtime').JSX.Element;
declare const LongContent: () => import('react/jsx-runtime').JSX.Element;
declare const CustomStyle: () => import('react/jsx-runtime').JSX.Element;
export declare const NestedButtons: () => import('react/jsx-runtime').JSX.Element;
export { BasicAccordion, CustomStyle, LongContent, NoMedia, NoSubtitle, TitleOnly };
//# sourceMappingURL=Accordion.stories.d.ts.map
