import React from 'react';
import { type AccordionProviderProps } from '@cbhq/cds-common/accordion/AccordionProvider';
import type { SharedProps } from '@cbhq/cds-common/types';
export type AccordionBaseProps = SharedProps & AccordionProviderProps;
export type AccordionProps = AccordionBaseProps & {
  style?: React.CSSProperties;
};
export declare const Accordion: (_props: AccordionProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Accordion.d.ts.map
