import React from 'react';
import type { IconButtonVariant } from '@cbhq/cds-common/types/IconButtonBaseProps';
import type { IconName } from '@cbhq/cds-common/types/IconName';
import type { CarouselNavigationComponentProps } from './Carousel';
export type DefaultCarouselNavigationProps = CarouselNavigationComponentProps & {
  /**
   * Test ID map for the component.
   */
  testIDMap?: {
    /**
     * Test ID for the previous button.
     */
    previousButton?: string;
    /**
     * Test ID for the next button.
     */
    nextButton?: string;
    /**
     * Test ID for the autoplay button.
     */
    autoplayButton?: string;
  };
  /**
   * Icon to use for the previous button.
   */
  previousIcon?: IconName;
  /**
   * Icon to use for the next button.
   */
  nextIcon?: IconName;
  /**
   * Icon to use for the start autoplay button.
   */
  startIcon?: IconName;
  /**
   * Icon to use for the stop autoplay button.
   */
  stopIcon?: IconName;
  /**
   * Variant of the icon button.
   */
  variant?: IconButtonVariant;
  /**
   * Whether the icon button is compact.
   */
  compact?: boolean;
  /**
   * Whether the navigation buttons should be hidden unless focused.
   */
  hideUnlessFocused?: boolean;
  /**
   * Custom class names for the component.
   */
  classNames?: {
    /**
     * Custom class name for the root element.
     */
    root?: string;
    /**
     * Custom class name for the previous button.
     */
    previousButton?: string;
    /**
     * Custom class name for the next button.
     */
    nextButton?: string;
    /**
     * Custom class name for the autoplay button.
     */
    autoplayButton?: string;
  };
  /**
   * Custom styles for the component.
   */
  styles?: {
    /**
     * Custom styles for the root element.
     */
    root?: React.CSSProperties;
    /**
     * Custom styles for the previous button.
     */
    previousButton?: React.CSSProperties;
    /**
     * Custom styles for the next button.
     */
    nextButton?: React.CSSProperties;
    /**
     * Custom styles for the autoplay button.
     */
    autoplayButton?: React.CSSProperties;
  };
};
export declare const DefaultCarouselNavigation: React.NamedExoticComponent<DefaultCarouselNavigationProps>;
//# sourceMappingURL=DefaultCarouselNavigation.d.ts.map
