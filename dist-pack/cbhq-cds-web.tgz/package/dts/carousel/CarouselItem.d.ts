import React from 'react';
import type { CarouselItemProps } from './Carousel';
/**
 * Individual carousel item component that registers itself with the carousel via RefMapContext.
 */
export declare const CarouselItem: React.MemoExoticComponent<
  ({
    id,
    children,
    testID,
    style,
    className,
    isClone,
    ...props
  }: CarouselItemProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=CarouselItem.d.ts.map
