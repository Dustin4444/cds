import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import type { CarouselPaginationComponentProps } from './Carousel';
export type DefaultCarouselPaginationProps = CarouselPaginationComponentProps &
  SharedProps & {
    /**
     * Custom class names for the component.
     */
    classNames?: {
      /**
       * Custom class name for the root element.
       */
      root?: string;
      /**
       * Custom class name for the dot element.
       */
      dot?: string;
    };
    /**
     * Custom styles for the component.
     */
    styles?: {
      /**
       * Custom styles for the root element.
       */
      root?: React.CSSProperties;
      /**
       * Custom styles for the dot element.
       */
      dot?: React.CSSProperties;
    };
  };
export declare const DefaultCarouselPagination: React.NamedExoticComponent<DefaultCarouselPaginationProps>;
//# sourceMappingURL=DefaultCarouselPagination.d.ts.map
