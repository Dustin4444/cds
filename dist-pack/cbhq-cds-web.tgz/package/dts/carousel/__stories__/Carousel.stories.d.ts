import React from 'react';
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<import("..").CarouselProps, "ref"> & React.RefAttributes<import("..").CarouselImperativeHandle>>;
    parameters: {
        a11y: {
            options: {
                rules: {
                    'target-size': {
                        enabled: boolean;
                    };
                    'color-contrast': {
                        enabled: boolean;
                    };
                };
            };
        };
    };
};
export default _default;
export declare const All: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Carousel.stories.d.ts.map