import { type Theme } from './theme';
/** Takes a theme object and formats its keys as CSS variables to be used in inline styles. */
export declare const createThemeCssVars: (theme: Partial<Theme>) => Record<string, unknown>;
//# sourceMappingURL=createThemeCssVars.d.ts.map
