/**
 * Prior art:
 * https://www.benmvp.com/blog/polymorphic-react-components-typescript/
 * https://github.com/DefinitelyTyped/DefinitelyTyped/pull/70361
 */
export declare namespace Polymorphic {
  type ExtendableProps<BaseProps, OverrideProps> = OverrideProps &
    Omit<BaseProps, keyof OverrideProps>;
  type InheritableElementProps<
    Component extends React.ElementType,
    Props,
  > = Polymorphic.ExtendableProps<React.ComponentPropsWithoutRef<Component>, Props>;
  type Ref<AsComponent extends React.ElementType> = React.ComponentPropsWithRef<AsComponent>['ref'];
  type Props<AsComponent extends React.ElementType, Props> = Polymorphic.InheritableElementProps<
    AsComponent,
    Props & {
      /**
       * The underlying element or component the polymorphic component will render.
       *
       * Changing `as` also changes the inherited native props (e.g. `href` for `as="a"`) and the
       * expected `ref` type.
       */
      as?: AsComponent;
    } & {
      ref?: Polymorphic.Ref<AsComponent>;
    }
  >;
  type ReactReturn = ReturnType<React.ExoticComponent>;
  type ReactNamed = {
    [k in keyof React.NamedExoticComponent]: React.NamedExoticComponent[k];
  };
}
//# sourceMappingURL=polymorphism.d.ts.map
