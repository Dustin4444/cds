import type { ChipBaseProps } from '../ChipProps';
declare const _default: {
    title: string;
    component: import("react").NamedExoticComponent<Omit<ChipBaseProps, "ref"> & import("react").RefAttributes<HTMLButtonElement | HTMLDivElement>>;
};
export default _default;
export declare const Default: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Chip.stories.d.ts.map