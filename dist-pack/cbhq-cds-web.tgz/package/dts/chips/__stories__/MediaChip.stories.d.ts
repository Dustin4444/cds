declare const _default: {
    title: string;
    component: import("react").NamedExoticComponent<Omit<import("..").MediaChipProps, "ref"> & import("react").RefAttributes<HTMLButtonElement | HTMLDivElement>>;
};
export default _default;
export declare const Default: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MediaChip.stories.d.ts.map