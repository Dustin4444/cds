declare const _default: {
    title: string;
    component: import("react").NamedExoticComponent<Omit<import("..").InputChipProps, "ref"> & import("react").RefAttributes<HTMLButtonElement>>;
};
export default _default;
export declare const Default: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=InputChip.stories.d.ts.map