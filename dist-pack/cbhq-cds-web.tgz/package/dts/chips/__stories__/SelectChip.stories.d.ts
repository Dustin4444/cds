import React from 'react';
import type { SelectChipProps } from '../SelectChip';
export declare const Default: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomEndNode: () => import("react/jsx-runtime").JSX.Element;
export declare const ObjectValueModel: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomStyle: () => import("react/jsx-runtime").JSX.Element;
declare const _default: {
    title: string;
    component: React.NamedExoticComponent<Omit<SelectChipProps, "ref"> & React.RefAttributes<unknown>>;
};
export default _default;
//# sourceMappingURL=SelectChip.stories.d.ts.map