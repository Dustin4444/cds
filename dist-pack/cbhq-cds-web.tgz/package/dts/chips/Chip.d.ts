import type { ChipProps } from './ChipProps';
export type { ChipProps };
/**
 * This is a basic Chip component used to create all Chip components.
 * When onClick is provided, the ref will be typed as HTMLButtonElement.
 * When onClick is not provided, the ref will be typed as HTMLDivElement.
 */
export declare const Chip: import("react").NamedExoticComponent<Omit<import("./ChipProps").ChipBaseProps, "ref"> & import("react").RefAttributes<HTMLButtonElement | HTMLDivElement>>;
//# sourceMappingURL=Chip.d.ts.map