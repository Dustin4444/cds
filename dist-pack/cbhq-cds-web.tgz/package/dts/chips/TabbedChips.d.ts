import React from 'react';
import { type BoxBaseProps } from '../layout';
import { type TabNavigationBaseProps } from '../tabs';
export type TabbedChipsBaseProps<TabId extends string = string> = BoxBaseProps &
  Omit<TabNavigationBaseProps<TabId>, 'variant'>;
export type TabbedChipsProps<TabId extends string = string> = TabbedChipsBaseProps<TabId>;
type TabbedChipsFC = <TabId extends string = string>(
  props: TabbedChipsProps<TabId> & {
    ref?: React.ForwardedRef<HTMLElement>;
  },
) => React.ReactElement;
/**
 * @deprecated Use `TabbedChips(Alpha)` instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 */
export declare const TabbedChips: TabbedChipsFC;
export {};
//# sourceMappingURL=TabbedChips.d.ts.map
