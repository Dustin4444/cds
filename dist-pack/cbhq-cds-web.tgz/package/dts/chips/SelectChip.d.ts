import React from 'react';
import type { SelectBaseProps } from '../controls/Select';
import type { DropdownProps } from '../dropdown';
import type { ChipProps } from './ChipProps';
export declare const SELECT_CHIP_DEFAULT_TEST_ID = "select-chip";
/**
 * @deprecated This component is deprecated. Please use the new SelectChip alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 * @see {@link @cbhq/cds-web/alpha/select-chip/SelectChip}
 */
export type SelectChipProps = {
    /** Indicates that the control is being used to manipulate data elsewhere */
    active?: boolean;
    /**
     * @deprecated This will be removed in a future major release.
     * @deprecationExpectedRemoval v7
     */
    children?: React.ReactNode;
} & Omit<ChipProps, 'inverted' | 'children' | 'onBlur' | 'noScaleOnPress' | 'content'> & Pick<SelectBaseProps, 'onChange' | 'valueLabel' | 'placeholder' | 'value'> & Omit<DropdownProps, 'onChange' | 'children'>;
/**
 * @deprecated This component is deprecated. Please use the new SelectChip alpha component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v9
 * @see {@link @cbhq/cds-web/alpha/select-chip/SelectChip}
 */
export declare const SelectChip: React.NamedExoticComponent<Omit<SelectChipProps, "ref"> & React.RefAttributes<unknown>>;
//# sourceMappingURL=SelectChip.d.ts.map