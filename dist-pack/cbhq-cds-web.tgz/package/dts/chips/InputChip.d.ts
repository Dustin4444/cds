import React from 'react';
import type { InputChipProps } from './ChipProps';
export declare const InputChip: React.NamedExoticComponent<Omit<InputChipProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=InputChip.d.ts.map