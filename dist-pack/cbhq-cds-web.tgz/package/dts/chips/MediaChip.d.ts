import type { ChipBaseProps, ChipProps } from './ChipProps';
export type MediaChipBaseProps = ChipBaseProps;
export type MediaChipProps = MediaChipBaseProps & ChipProps;
export declare const MediaChip: import("react").NamedExoticComponent<Omit<MediaChipProps, "ref"> & import("react").RefAttributes<HTMLButtonElement | HTMLDivElement>>;
//# sourceMappingURL=MediaChip.d.ts.map