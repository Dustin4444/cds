export {};
//# sourceMappingURL=getTransform.test.d.ts.map
