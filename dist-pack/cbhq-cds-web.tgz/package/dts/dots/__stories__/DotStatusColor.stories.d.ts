import React from 'react';
declare const _default: {
  title: string;
  component: React.MemoExoticComponent<
    (_props: import('..').DotStatusColorProps) => import('react/jsx-runtime').JSX.Element
  >;
};
export default _default;
export declare const AllDotStatusColor: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=DotStatusColor.stories.d.ts.map
