declare const _default: {
  title: string;
  component: import('react').MemoExoticComponent<
    (_props: import('..').DotSymbolProps) => import('react/jsx-runtime').JSX.Element
  >;
};
export default _default;
export declare const AllDotSymbol: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomSymbol: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=DotSymbol.stories.d.ts.map
