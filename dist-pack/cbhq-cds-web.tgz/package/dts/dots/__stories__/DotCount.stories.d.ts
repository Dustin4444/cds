import React from 'react';
declare const _default: {
  title: string;
  component: React.MemoExoticComponent<
    (_props: import('..').DotCountProps) => import('react/jsx-runtime').JSX.Element
  >;
};
export default _default;
export declare const AllDotCount: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export declare const DotCountPressable: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=DotCount.stories.d.ts.map
