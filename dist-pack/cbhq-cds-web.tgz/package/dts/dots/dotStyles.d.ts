import type { DotOverlap } from '@cbhq/cds-common/types/DotBaseProps';
import type { PinPlacement } from '@cbhq/cds-common/types/Placement';
export declare const getTransform: (
  pin?: PinPlacement,
  overlap?: DotOverlap,
) =>
  | {
      readonly position?: undefined;
      readonly transform?: undefined;
      readonly translateX?: undefined;
      readonly translateY?: undefined;
    }
  | {
      readonly [x: string]: 0 | 'absolute' | `translate(${number}%, ${number}%)` | `${number}%`;
      readonly position: 'absolute';
      readonly transform: `translate(${number}%, ${number}%)`;
      readonly translateX: `${number}%`;
      readonly translateY: `${number}%`;
    };
//# sourceMappingURL=dotStyles.d.ts.map
