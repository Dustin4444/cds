import React from 'react';
import {
  useFallbackShape,
  type UseFallbackShapeOptions,
} from '@cbhq/cds-common/hooks/useFallbackShape';
import type { Shape } from '@cbhq/cds-common/types';
import type { Polymorphic } from '../core/polymorphism';
import { type BoxBaseProps } from './Box';
export declare const fallbackDefaultElement = 'div';
export type FallbackDefaultElement = typeof fallbackDefaultElement;
export type FallbackBaseProps = Polymorphic.ExtendableProps<
  BoxBaseProps,
  {
    width: string | number;
    height: string | number;
    /**
     * @default rectangle
     */
    shape?: Shape;
    /** Disables randomization of rectangle shape width. */
    disableRandomRectWidth?: boolean;
    /**
     * When shape is a rectangle, creates a variant with deterministic width.
     * Variants map to a predetermined set of width values, which are cycled through repeatedly when the set is exhausted.
     */
    rectWidthVariant?: number;
    /** Convert width to a percentage. */
    percentage?: boolean;
  }
>;
export type FallbackProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  FallbackBaseProps
>;
type FallbackComponent = (<AsComponent extends React.ElementType = FallbackDefaultElement>(
  props: FallbackProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const Fallback: FallbackComponent;
export { useFallbackShape, type UseFallbackShapeOptions };
//# sourceMappingURL=Fallback.d.ts.map
