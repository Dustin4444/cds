import React from 'react';
import type { Polymorphic } from '../core/polymorphism';
import { type BoxBaseProps } from './Box';
export declare const hStackDefaultElement = 'div';
export type HStackDefaultElement = typeof hStackDefaultElement;
export type HStackBaseProps = BoxBaseProps;
export type HStackProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  HStackBaseProps
>;
type HStackComponent = (<AsComponent extends React.ElementType = HStackDefaultElement>(
  props: HStackProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const HStack: HStackComponent;
export {};
//# sourceMappingURL=HStack.d.ts.map
