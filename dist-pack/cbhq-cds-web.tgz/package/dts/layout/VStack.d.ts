import React from 'react';
import type { Polymorphic } from '../core/polymorphism';
import { type BoxBaseProps } from './Box';
export declare const vStackDefaultElement = 'div';
export type VStackDefaultElement = typeof vStackDefaultElement;
export type VStackBaseProps = BoxBaseProps;
export type VStackProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  VStackBaseProps
>;
type VStackComponent = (<AsComponent extends React.ElementType = VStackDefaultElement>(
  props: VStackProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const VStack: VStackComponent;
export {};
//# sourceMappingURL=VStack.d.ts.map
