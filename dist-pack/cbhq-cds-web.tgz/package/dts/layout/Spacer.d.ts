import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { Polymorphic } from '../core/polymorphism';
import { type BoxBaseProps } from './Box';
export declare const spacerDefaultElement = 'span';
export type SpacerDefaultElement = typeof spacerDefaultElement;
export type SpacerBaseProps = Polymorphic.ExtendableProps<
  BoxBaseProps,
  {
    /** Space in the horizontal direction */
    horizontal?: ThemeVars.Space;
    /** Space in the vertical direction */
    vertical?: ThemeVars.Space;
    /** Max space in the horizontal direction */
    maxHorizontal?: ThemeVars.Space;
    /** Max space in the vertical direction */
    maxVertical?: ThemeVars.Space;
    /** Min space in the horizontal direction */
    minHorizontal?: ThemeVars.Space;
    /** Min space in the vertical direction */
    minVertical?: ThemeVars.Space;
  }
>;
export type SpacerProps<AsComponent extends React.ElementType> = Polymorphic.Props<
  AsComponent,
  SpacerBaseProps
>;
type SpacerComponent = (<AsComponent extends React.ElementType = SpacerDefaultElement>(
  props: SpacerProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const Spacer: SpacerComponent;
export {};
//# sourceMappingURL=Spacer.d.ts.map
