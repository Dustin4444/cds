export declare const GridExamples: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: () => import('react/jsx-runtime').JSX.Element;
};
export default _default;
//# sourceMappingURL=Grid.stories.d.ts.map
