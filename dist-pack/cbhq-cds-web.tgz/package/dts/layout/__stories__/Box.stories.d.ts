import React from 'react';
declare const _default: {
  title: string;
  component: (<AsComponent extends React.ElementType = 'div'>(
    props: import('..').BoxProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
};
export default _default;
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
export declare const Elevation: () => import('react/jsx-runtime').JSX.Element;
export declare const Elevation1: () => import('react/jsx-runtime').JSX.Element;
export declare const Elevation2: () => import('react/jsx-runtime').JSX.Element;
export declare const Opacity: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export declare const FlexControls: () => import('react/jsx-runtime').JSX.Element;
export declare const AlternateBackground: () => import('react/jsx-runtime').JSX.Element;
export declare const OverlayBackground: () => import('react/jsx-runtime').JSX.Element;
export declare const PrimaryBackground: () => import('react/jsx-runtime').JSX.Element;
export declare const SecondaryBackground: () => import('react/jsx-runtime').JSX.Element;
export declare const PositiveBackground: () => import('react/jsx-runtime').JSX.Element;
export declare const NegativeBackground: () => import('react/jsx-runtime').JSX.Element;
export declare const Bordered: () => import('react/jsx-runtime').JSX.Element;
export declare const BorderedAndRounded: () => import('react/jsx-runtime').JSX.Element;
export declare const RoundedVariations: () => import('react/jsx-runtime').JSX.Element;
export declare const Spacing: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomSpacing: () => import('react/jsx-runtime').JSX.Element;
export declare const VerticalSpacing: () => import('react/jsx-runtime').JSX.Element;
export declare const HorizontalSpacing: () => import('react/jsx-runtime').JSX.Element;
export declare const Offset: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomOffset: () => import('react/jsx-runtime').JSX.Element;
export declare const VerticalOffset: () => import('react/jsx-runtime').JSX.Element;
export declare const HorizontalOffset: () => import('react/jsx-runtime').JSX.Element;
export declare const Positioned: () => import('react/jsx-runtime').JSX.Element;
export declare const TopPin: () => import('react/jsx-runtime').JSX.Element;
export declare const RightPin: () => import('react/jsx-runtime').JSX.Element;
export declare const BottomPin: () => import('react/jsx-runtime').JSX.Element;
export declare const LeftPin: () => import('react/jsx-runtime').JSX.Element;
export declare const AllPin: () => import('react/jsx-runtime').JSX.Element;
export declare const BooleanStyleProps: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
//# sourceMappingURL=Box.stories.d.ts.map
