export declare const Examples: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: () => import('react/jsx-runtime').JSX.Element;
};
export default _default;
//# sourceMappingURL=Layouts.stories.d.ts.map
