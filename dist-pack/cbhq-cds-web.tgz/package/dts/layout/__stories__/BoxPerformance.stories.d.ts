import React from 'react';
declare const _default: {
  component: (<AsComponent extends React.ElementType = 'div'>(
    props: import('..').BoxProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
  title: string;
  decorators: ((...args: any) => any)[];
  excludeStories: string[];
};
export default _default;
export declare const CDSBox: () => import('react/jsx-runtime').JSX.Element;
export declare const SingleDiv: () => import('react/jsx-runtime').JSX.Element;
export declare const HundredCDSComponents: () => import('react/jsx-runtime').JSX.Element[];
export declare const HundredHTMLComponent: () => import('react/jsx-runtime').JSX.Element[];
export declare const ThousandCDSComponents: () => import('react/jsx-runtime').JSX.Element[];
export declare const ThousandHTMLComponent: () => import('react/jsx-runtime').JSX.Element[];
//# sourceMappingURL=BoxPerformance.stories.d.ts.map
