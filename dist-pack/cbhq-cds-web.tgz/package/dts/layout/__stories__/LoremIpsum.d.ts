import { type TextBaseProps } from '../../typography/Text';
export type LoremIpsumProps = {
  title?: string;
  color?: TextBaseProps['color'];
  concise?: boolean;
  repeat?: number;
};
export declare const LoremIpsum: ({
  color,
  concise,
  title,
  repeat,
}: LoremIpsumProps) => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=LoremIpsum.d.ts.map
