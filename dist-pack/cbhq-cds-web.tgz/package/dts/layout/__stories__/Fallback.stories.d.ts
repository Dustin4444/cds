declare const _default: {
  title: string;
  component: (<AsComponent extends React.ElementType = 'div'>(
    props: import('..').FallbackProps<AsComponent>,
  ) => import('../..').Polymorphic.ReactReturn) &
    import('../..').Polymorphic.ReactNamed;
};
export default _default;
export declare const Basic: () => import('react/jsx-runtime').JSX.Element;
export declare const HeightAsCSSVar: () => import('react/jsx-runtime').JSX.Element;
export declare const RectangleWidthVariants: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Fallback.stories.d.ts.map
