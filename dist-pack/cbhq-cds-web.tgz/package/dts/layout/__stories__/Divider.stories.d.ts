import type { StoryObj } from '@storybook/react';
import type { DividerProps } from '../Divider';
declare const meta: {
    title: string;
    component: import("react").MemoExoticComponent<(_props: DividerProps) => import("react/jsx-runtime").JSX.Element>;
    argTypes: {
        direction: {
            options: string[];
            control: {
                type: "radio";
            };
        };
    };
    render: ({ direction, ...rest }: DividerProps) => import("react/jsx-runtime").JSX.Element;
};
export default meta;
type Story = StoryObj<typeof meta>;
export declare const HorizontalDirection: Story;
export declare const VerticalDirection: Story;
export declare const LightColor: Story;
export declare const HeavyColor: Story;
//# sourceMappingURL=Divider.stories.d.ts.map