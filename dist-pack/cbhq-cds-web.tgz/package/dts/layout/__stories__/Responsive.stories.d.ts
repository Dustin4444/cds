export declare const ResponsiveBox: () => import('react/jsx-runtime').JSX.Element;
export declare const ResponsiveBoxHoistedPerformance: () => import('react/jsx-runtime').JSX.Element;
export declare const HideOnMobile: () => import('react/jsx-runtime').JSX.Element;
export declare const ResponsiveStacks: () => import('react/jsx-runtime').JSX.Element;
export declare const ResponsiveCard: () => import('react/jsx-runtime').JSX.Element;
export declare const ResponsiveCells: () => import('react/jsx-runtime').JSX.Element;
export declare const ResponsiveTable: () => import('react/jsx-runtime').JSX.Element;
export declare const ResponsiveTypography: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  title: string;
  component: () => import('react/jsx-runtime').JSX.Element;
  excludeStories: RegExp;
};
export default _default;
//# sourceMappingURL=Responsive.stories.d.ts.map
