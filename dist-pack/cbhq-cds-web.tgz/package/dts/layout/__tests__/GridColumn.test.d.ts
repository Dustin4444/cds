export {};
//# sourceMappingURL=GridColumn.test.d.ts.map
