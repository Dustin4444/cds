import React from 'react';
import { type BoxProps } from './Box';
export type DividerBaseProps = {
  /**
   * The direction to render the divider line.
   * @default horizontal
   */
  direction?: 'horizontal' | 'vertical';
};
export type DividerProps = DividerBaseProps & Omit<BoxProps<'hr'>, 'as' | 'role'>;
export declare const Divider: React.MemoExoticComponent<
  (_props: DividerProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=Divider.d.ts.map
