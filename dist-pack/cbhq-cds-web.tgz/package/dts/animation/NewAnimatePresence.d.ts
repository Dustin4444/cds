import { type AnimatePresenceProps } from 'framer-motion';
type NewAnimatePresenceProps = {
  children: React.ReactNode;
} & Omit<AnimatePresenceProps, 'children'>;
export declare const NewAnimatePresence: React.FC<NewAnimatePresenceProps>;
export {};
//# sourceMappingURL=NewAnimatePresence.d.ts.map
