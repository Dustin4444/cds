import type { LottieAnimationRef, LottieListener } from './types';
export declare const useLottieListeners: (
  animationRef: LottieAnimationRef,
  listeners?: LottieListener[],
) => void;
//# sourceMappingURL=useLottieListeners.d.ts.map
