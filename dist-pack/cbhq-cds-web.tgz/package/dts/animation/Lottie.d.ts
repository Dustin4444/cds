import React from 'react';
import type { LottiePlayer } from '@cbhq/cds-common/types/LottiePlayer';
import type { LottieSource } from '@cbhq/cds-common/types/LottieSource';
import type { LottieProps } from './types';
export declare const Lottie: React.NamedExoticComponent<Omit<LottieProps<string, LottieSource<string>>, "ref"> & React.RefAttributes<LottiePlayer<LottieSource<any>>>>;
//# sourceMappingURL=Lottie.d.ts.map