export {};
//# sourceMappingURL=useLottieHandlers.test.d.ts.map
