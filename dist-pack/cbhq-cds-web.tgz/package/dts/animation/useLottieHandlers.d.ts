import type { LottieEventHandlersMap, LottieListener } from './types';
export declare const useLottieHandlers: (handlers?: LottieEventHandlersMap) => LottieListener[];
//# sourceMappingURL=useLottieHandlers.d.ts.map
