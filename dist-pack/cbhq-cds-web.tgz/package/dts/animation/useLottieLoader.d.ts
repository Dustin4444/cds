import type { LottieSource } from '@cbhq/cds-common';
import type { AnyObject } from '@cbhq/cds-utils';
import type { LottieAnimationRef, LottieProps } from './types';
export declare const useLottieLoader: <Marker extends string, Source extends LottieSource<Marker>>({ source, loop, autoplay, resizeMode, filterSize, }: LottieProps<Marker, Source>) => {
    containerRef: import("react").RefObject<HTMLDivElement | null>;
    animationRef: LottieAnimationRef;
    loadAnimation: (forcedConfigs?: AnyObject) => void;
};
//# sourceMappingURL=useLottieLoader.d.ts.map