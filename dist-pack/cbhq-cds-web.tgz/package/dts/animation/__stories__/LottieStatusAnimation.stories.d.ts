import React from 'react';
declare const _default: {
  component: React.MemoExoticComponent<
    ({
      status,
      onFinish,
      testID,
      accessibilityLabel,
      ...otherProps
    }: import('..').LottieStatusAnimationProps) => import('react/jsx-runtime').JSX.Element
  >;
  title: string;
};
export default _default;
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=LottieStatusAnimation.stories.d.ts.map
