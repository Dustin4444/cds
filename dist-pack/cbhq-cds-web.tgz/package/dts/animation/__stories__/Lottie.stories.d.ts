import React from 'react';
import type { LottiePlayer } from '@cbhq/cds-common/types/LottiePlayer';
declare const _default: {
    component: React.NamedExoticComponent<Omit<import("../types").LottieProps<string, import("@cbhq/cds-common").LottieSource<string>>, "ref"> & React.RefAttributes<LottiePlayer<import("@cbhq/cds-common").LottieSource<any>>>>;
    title: string;
};
export default _default;
export declare const Default: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Lottie.stories.d.ts.map