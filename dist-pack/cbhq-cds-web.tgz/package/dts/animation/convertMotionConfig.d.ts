import type {
  MotionBaseSpec as DefaultMotionSpec,
  MotionCurve,
} from '@cbhq/cds-common/types/Motion';
export declare const webCurves: {
  global: string;
  enterExpressive: string;
  enterFunctional: string;
  exitExpressive: string;
  exitFunctional: string;
  linear: string;
};
export type MotionBaseSpec = {
  toValue: number | string;
  fromValue?: number | string;
} & Omit<DefaultMotionSpec, 'toValue' | 'fromValue' | 'property'> &
  Pick<EffectTiming, 'fill'>;
export type MotionConfigOutput = {
  easing: string;
  duration?: number;
} & EffectTiming &
  Pick<MotionBaseSpec, 'toValue' | 'fromValue' | 'fill'>;
export declare function cubicBezier(easing: MotionCurve): string;
export declare const convertMotionConfig: ({
  toValue,
  fromValue,
  delay,
  easing,
  duration,
  oneOffDuration,
  fill,
}: MotionBaseSpec) => MotionConfigOutput;
//# sourceMappingURL=convertMotionConfig.d.ts.map
