import type { ComboboxProps } from '../Combobox';
import { type ComboboxRef } from '../';
declare const _default: {
  title: string;
  component: <
    Type extends import('../..').SelectType = 'single',
    SelectOptionValue extends string = string,
  >(
    props: ComboboxProps<Type, SelectOptionValue> & {
      ref?: React.Ref<ComboboxRef>;
    },
  ) => React.ReactElement;
  parameters: {
    a11y: {
      test: string;
    };
  };
};
export default _default;
export declare const BasicUsage: () => import('react/jsx-runtime').JSX.Element;
export declare const SingleSelect: () => import('react/jsx-runtime').JSX.Element;
export declare const MultipleComboboxes: () => import('react/jsx-runtime').JSX.Element;
export declare const EmptySelectedValues: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsWithLongLabels: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsWithLongLabelsSingleSelect: () => import('react/jsx-runtime').JSX.Element;
export declare const LongPlaceholder: () => import('react/jsx-runtime').JSX.Element;
export declare const Alignments: () => import('react/jsx-runtime').JSX.Element;
export declare const ControlledSearch: () => import('react/jsx-runtime').JSX.Element;
export declare const UncontrolledSearch: () => import('react/jsx-runtime').JSX.Element;
export declare const ControlledOpen: () => import('react/jsx-runtime').JSX.Element;
export declare const DefaultOpen: () => import('react/jsx-runtime').JSX.Element;
export declare const WithDescriptions: () => import('react/jsx-runtime').JSX.Element;
export declare const HideSearchInput: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomFilter: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomOnSearch: () => import('react/jsx-runtime').JSX.Element;
export declare const Disabled: () => import('react/jsx-runtime').JSX.Element;
export declare const Compact: () => import('react/jsx-runtime').JSX.Element;
export declare const CompactSingleSelect: () => import('react/jsx-runtime').JSX.Element;
export declare const HelperText: () => import('react/jsx-runtime').JSX.Element;
export declare const Variants: () => import('react/jsx-runtime').JSX.Element;
export declare const StartNode: () => import('react/jsx-runtime').JSX.Element;
export declare const EndNode: () => import('react/jsx-runtime').JSX.Element;
export declare const MaxSelectedDisplay: () => import('react/jsx-runtime').JSX.Element;
export declare const HiddenOptionsLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const RemoveOptionLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const AccessibilityLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const SelectAll: () => import('react/jsx-runtime').JSX.Element;
export declare const HideSelectAll: () => import('react/jsx-runtime').JSX.Element;
export declare const ClearAll: () => import('react/jsx-runtime').JSX.Element;
export declare const EmptyOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const PersistentDropdown: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomStyles: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomClasses: () => import('react/jsx-runtime').JSX.Element;
export declare const TestIdentifier: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsWithMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsWithAccessory: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsWithEnd: () => import('react/jsx-runtime').JSX.Element;
export declare const DisabledOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const LongList: () => import('react/jsx-runtime').JSX.Element;
export declare const NoResults: () => import('react/jsx-runtime').JSX.Element;
export declare const ValueMonitoring: () => import('react/jsx-runtime').JSX.Element;
export declare const ChangeHandler: () => import('react/jsx-runtime').JSX.Element;
export declare const RefImperativeHandle: () => import('react/jsx-runtime').JSX.Element;
export declare const MultipleInstances: () => import('react/jsx-runtime').JSX.Element;
export declare const DynamicOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const CountrySelectionExample: () => import('react/jsx-runtime').JSX.Element;
export declare const FreeSoloComboboxExample: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomControlComponent: () => import('react/jsx-runtime').JSX.Element;
export declare const StressTest: () => import('react/jsx-runtime').JSX.Element;
export declare const Borderless: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Combobox.stories.d.ts.map
