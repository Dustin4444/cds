import type { ComboboxControlComponent } from './Combobox';
export declare const DefaultComboboxControl: ComboboxControlComponent;
//# sourceMappingURL=DefaultComboboxControl.d.ts.map
