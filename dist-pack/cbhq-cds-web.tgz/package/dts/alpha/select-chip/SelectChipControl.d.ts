import React from 'react';
import { type ChipBaseProps } from '../../chips';
import { type SelectControlProps, type SelectType } from '../select/types';
export declare const SelectChipControl: <
  Type extends SelectType,
  SelectOptionValue extends string = string,
>(
  props: SelectControlProps<Type, SelectOptionValue> &
    Pick<ChipBaseProps, 'invertColorScheme' | 'numberOfLines'> & {
      ref?: React.Ref<HTMLElement>;
      displayValue?: React.ReactNode;
    },
) => React.ReactElement;
//# sourceMappingURL=SelectChipControl.d.ts.map
