import React from 'react';
import { type TabbedChipsProps } from '../TabbedChips';
declare const _default: {
  title: string;
  component: <TabId extends string = string>(
    props: TabbedChipsProps<TabId> & {
      ref?: React.ForwardedRef<HTMLElement>;
    },
  ) => React.ReactElement;
};
export default _default;
export declare const Default: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    percy: {
      enableJavaScript: boolean;
    };
    a11y: {
      config: {
        rules: {
          id: string;
          enabled: boolean;
        }[];
      };
    };
  };
};
//# sourceMappingURL=TabbedChips.stories.d.ts.map
