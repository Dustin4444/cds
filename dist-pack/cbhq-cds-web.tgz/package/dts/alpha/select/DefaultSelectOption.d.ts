import type { SelectOptionProps, SelectType } from './Select';
type DefaultSelectOptionBase = <Type extends SelectType, SelectOptionValue extends string = string>(
  props: SelectOptionProps<Type, SelectOptionValue> & {
    ref?: React.Ref<HTMLButtonElement>;
  },
) => React.ReactElement;
export declare const DefaultSelectOption: DefaultSelectOptionBase;
export {};
//# sourceMappingURL=DefaultSelectOption.d.ts.map
