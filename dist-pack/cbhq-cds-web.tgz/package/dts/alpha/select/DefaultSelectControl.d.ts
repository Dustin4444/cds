import React from 'react';
import { type SelectControlProps, type SelectType } from './Select';
type DefaultSelectControlBase = <
  Type extends SelectType,
  SelectOptionValue extends string = string,
>(
  props: SelectControlProps<Type, SelectOptionValue> & {
    ref?: React.Ref<HTMLElement>;
  },
) => React.ReactElement;
export declare const DefaultSelectControl: DefaultSelectControlBase;
export {};
//# sourceMappingURL=DefaultSelectControl.d.ts.map
