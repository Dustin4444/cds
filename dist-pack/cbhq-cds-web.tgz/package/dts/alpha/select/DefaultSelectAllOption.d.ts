import { type SelectOptionProps, type SelectType } from './Select';
type DefaultSelectAllOptionBase = <
  Type extends SelectType,
  SelectOptionValue extends string = string,
>(
  props: SelectOptionProps<Type, SelectOptionValue> & {
    ref?: React.Ref<HTMLButtonElement>;
  },
) => React.ReactElement;
export declare const DefaultSelectAllOption: DefaultSelectAllOptionBase;
export {};
//# sourceMappingURL=DefaultSelectAllOption.d.ts.map
