import { type SelectRef, type SelectType } from '../Select';
declare const _default: {
  title: string;
  component: <Type extends SelectType = 'single', SelectOptionValue extends string = string>(
    props: import('..').SelectProps<Type, SelectOptionValue> & {
      ref?: React.Ref<SelectRef>;
    },
  ) => React.ReactElement;
  parameters: {
    a11y: {
      options: {
        rules: {
          'nested-interactive': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export default _default;
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
export declare const Compact: () => import('react/jsx-runtime').JSX.Element;
export declare const LabelVariant: () => import('react/jsx-runtime').JSX.Element;
export declare const ExampleForm: () => import('react/jsx-runtime').JSX.Element;
export declare const HelperText: () => import('react/jsx-runtime').JSX.Element;
export declare const Description: () => import('react/jsx-runtime').JSX.Element;
export declare const OnlyDescription: () => import('react/jsx-runtime').JSX.Element;
export declare const AccessibilityLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const AccessibilityRoles: () => import('react/jsx-runtime').JSX.Element;
export declare const Alignments: () => import('react/jsx-runtime').JSX.Element;
export declare const NoLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const Disabled: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        /**
         * Color contrast ratio doesn't need to meet 4.5:1, as the element is disabled.
         * Use axe run options (instead of config.rules) to reliably disable this rule.
         * @link https://dequeuniversity.com/rules/axe/4.3/color-contrast
         */
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export declare const DisabledOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const WithoutNull: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsAsReactNodes: () => import('react/jsx-runtime').JSX.Element;
export declare const MixedDefaultAndCustomComponentOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const StartNode: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomEndNode: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomAccessory: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const UniqueAccessoryAndMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const UniqueEndNodeForEachOption: () => import('react/jsx-runtime').JSX.Element;
export declare const PositiveVariant: () => import('react/jsx-runtime').JSX.Element;
export declare const NegativeVariant: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomStyles: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomClassNames: () => import('react/jsx-runtime').JSX.Element;
export declare const Typed: () => import('react/jsx-runtime').JSX.Element;
export declare const DefaultOpen: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export declare const DisabledClickOutsideClose: () => import('react/jsx-runtime').JSX.Element;
export declare const ControlledOpen: () => import('react/jsx-runtime').JSX.Element;
export declare const EmptyOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const EmptyOptionsWithCustomLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const EmptyOptionsWithCustomComponent: () => import('react/jsx-runtime').JSX.Element;
export declare const VeryLongLabels: () => import('react/jsx-runtime').JSX.Element;
export declare const MixedOptionsWithAndWithoutDescriptions: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsWithOnlyAccessory: () => import('react/jsx-runtime').JSX.Element;
export declare const OptionsWithOnlyMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const CompactWithVariants: () => import('react/jsx-runtime').JSX.Element;
export declare const DisabledWithVariants: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export declare const StartNodeWithVariants: () => import('react/jsx-runtime').JSX.Element;
export declare const LongHelperText: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomLongPlaceholder: () => import('react/jsx-runtime').JSX.Element;
export declare const AllCombinedFeatures: () => import('react/jsx-runtime').JSX.Element;
export declare const ComplexStyleCombinations: () => import('react/jsx-runtime').JSX.Element;
export declare const SingleNullOnlyOption: () => import('react/jsx-runtime').JSX.Element;
export declare const NestedComplexOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const EdgeCaseEmptyLabels: () => import('react/jsx-runtime').JSX.Element;
export declare const StressTestManyOptionsWithDescriptions: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomControlComponent: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomOptionComponent: () => import('react/jsx-runtime').JSX.Element;
export declare const ValueDisplayed: () => import('react/jsx-runtime').JSX.Element;
export declare const RefImperativeHandle: () => import('react/jsx-runtime').JSX.Element;
export declare const Borderless: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Select.stories.d.ts.map
