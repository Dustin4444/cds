declare const _default: {
  title: string;
  component: <
    Type extends import('..').SelectType = 'single',
    SelectOptionValue extends string = string,
  >(
    props: import('..').SelectProps<Type, SelectOptionValue> & {
      ref?: React.Ref<import('..').SelectRef>;
    },
  ) => React.ReactElement;
  parameters: {
    a11y: {
      options: {
        rules: {
          'nested-interactive': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export default _default;
export declare const Default: () => import('react/jsx-runtime').JSX.Element;
export declare const Compact: () => import('react/jsx-runtime').JSX.Element;
export declare const InsideLabelVariant: () => import('react/jsx-runtime').JSX.Element;
export declare const CompactManySelected: () => import('react/jsx-runtime').JSX.Element;
export declare const HideSelectAll: () => import('react/jsx-runtime').JSX.Element;
export declare const Alignments: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomSelectAllLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomClearAllLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomSelectAllOption: () => import('react/jsx-runtime').JSX.Element;
export declare const LongOptionLabels: () => import('react/jsx-runtime').JSX.Element;
export declare const Disabled: {
  (): import('react/jsx-runtime').JSX.Element;
  parameters: {
    a11y: {
      options: {
        rules: {
          'color-contrast': {
            enabled: boolean;
          };
        };
      };
    };
  };
};
export declare const DisabledOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomAccessory: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const ManyOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const MaxSelectedOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const CustomHiddenSelectedOptionsLabel: () => import('react/jsx-runtime').JSX.Element;
export declare const Descriptions: () => import('react/jsx-runtime').JSX.Element;
export declare const DescriptionsOnly: () => import('react/jsx-runtime').JSX.Element;
export declare const MixedAccessoriesMedia: () => import('react/jsx-runtime').JSX.Element;
export declare const AllCombinedFeatures: () => import('react/jsx-runtime').JSX.Element;
export declare const EdgeCaseEmptyLabels: () => import('react/jsx-runtime').JSX.Element;
export declare const ControlledOpen: () => import('react/jsx-runtime').JSX.Element;
export declare const PositiveVariant: () => import('react/jsx-runtime').JSX.Element;
export declare const NegativeVariant: () => import('react/jsx-runtime').JSX.Element;
export declare const StartNode: () => import('react/jsx-runtime').JSX.Element;
export declare const EmptyOptions: () => import('react/jsx-runtime').JSX.Element;
export declare const ComplexStyles: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=MultiSelect.stories.d.ts.map
