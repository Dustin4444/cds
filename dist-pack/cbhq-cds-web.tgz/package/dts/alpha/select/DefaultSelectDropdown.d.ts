import type { SelectDropdownProps, SelectType } from './Select';
type DefaultSelectDropdownBase = <
  Type extends SelectType,
  SelectOptionValue extends string = string,
>(
  props: SelectDropdownProps<Type, SelectOptionValue> & {
    ref?: React.Ref<HTMLDivElement>;
  },
) => React.ReactElement;
export declare const DefaultSelectDropdown: DefaultSelectDropdownBase;
export {};
//# sourceMappingURL=DefaultSelectDropdown.d.ts.map
