import { type UseFloatingReturn } from '@floating-ui/react-dom';
import { type SelectDropdownProps, type SelectProps, type SelectType } from './types';
export type {
  SelectBaseProps,
  SelectControlComponent,
  SelectControlProps,
  SelectDropdownComponent,
  SelectDropdownProps,
  SelectEmptyDropdownContentComponent,
  SelectEmptyDropdownContentProps,
  SelectOption,
  SelectOptionComponent,
  SelectOptionCustomUI,
  SelectOptionGroup,
  SelectOptionGroupComponent,
  SelectOptionGroupCustomUI,
  SelectOptionGroupProps,
  SelectOptionProps,
  SelectProps,
  SelectType,
} from './types';
export { isSelectOptionGroup } from './types';
export declare const defaultAccessibilityRoles: SelectDropdownProps['accessibilityRoles'];
export type SelectRef = HTMLElement &
  Pick<SelectProps, 'open' | 'setOpen'> & {
    refs: UseFloatingReturn['refs'];
  };
type SelectComponent = <
  Type extends SelectType = 'single',
  SelectOptionValue extends string = string,
>(
  props: SelectProps<Type, SelectOptionValue> & {
    ref?: React.Ref<SelectRef>;
  },
) => React.ReactElement;
export declare const Select: SelectComponent;
//# sourceMappingURL=Select.d.ts.map
