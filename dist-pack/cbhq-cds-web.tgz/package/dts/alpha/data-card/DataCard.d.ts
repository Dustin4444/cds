import { type CardRootBaseProps } from '../../cards/CardRoot';
import type { Polymorphic } from '../../core/polymorphism';
import { type DataCardLayoutProps } from './DataCardLayout';
export type DataCardBaseProps = Polymorphic.ExtendableProps<
  Omit<CardRootBaseProps, 'children'>,
  DataCardLayoutProps & {
    classNames?: {
      /** Root element */
      root?: string;
    };
    styles?: {
      /** Root element */
      root?: React.CSSProperties;
    };
  }
>;
export type DataCardProps<AsComponent extends React.ElementType = 'article'> = Polymorphic.Props<
  AsComponent,
  DataCardBaseProps
>;
type DataCardComponent = (<AsComponent extends React.ElementType = 'article'>(
  props: DataCardProps<AsComponent>,
) => Polymorphic.ReactReturn) &
  Polymorphic.ReactNamed;
export declare const DataCard: DataCardComponent;
export {};
//# sourceMappingURL=DataCard.d.ts.map
