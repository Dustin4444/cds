import React from 'react';
export type DataCardLayoutBaseProps = {
  /** Text or React node to display as the card title. Use a Text component to override default color and font. */
  title: React.ReactNode;
  /** Text or React node to display as the card subtitle. Use a Text component to override default color and font. */
  subtitle?: React.ReactNode;
  /** React node to display as a title accessory. */
  titleAccessory?: React.ReactNode;
  /** React node to display as a thumbnail in the header area. */
  thumbnail?: React.ReactNode;
  /** Layout orientation of the card. Horizontal places header and visualization side by side, vertical stacks them.
   * @default 'vertical'
   */
  layout: 'horizontal' | 'vertical';
  /** Child node to display as the visualization (e.g., ProgressBar or ProgressCircle). */
  children?: React.ReactNode;
};
export type DataCardLayoutProps = DataCardLayoutBaseProps & {
  classNames?: {
    /** Layout container element */
    layoutContainer?: string;
    /** Header container element */
    headerContainer?: string;
    /** Text container element */
    textContainer?: string;
    /** Title container element */
    titleContainer?: string;
  };
  styles?: {
    /** Layout container element */
    layoutContainer?: React.CSSProperties;
    /** Header container element */
    headerContainer?: React.CSSProperties;
    /** Text container element */
    textContainer?: React.CSSProperties;
    /** Title container element */
    titleContainer?: React.CSSProperties;
  };
};
export declare const DataCardLayout: React.MemoExoticComponent<
  ({
    title,
    subtitle,
    titleAccessory,
    thumbnail,
    layout,
    classNames,
    styles,
    children,
  }: DataCardLayoutProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=DataCardLayout.d.ts.map
