import React, { type JSX } from 'react';
export declare const BasicExamples: () => JSX.Element;
export declare const Features: () => JSX.Element;
export declare const Interactive: () => JSX.Element;
export declare const StyleOverrides: () => JSX.Element;
export declare const MultipleCards: () => JSX.Element;
declare const _default: {
    title: string;
    component: (<AsComponent extends React.ElementType = "article">(props: import("..").DataCardProps<AsComponent>) => import("../../..").Polymorphic.ReactReturn) & import("../../..").Polymorphic.ReactNamed;
};
export default _default;
//# sourceMappingURL=DataCard.stories.d.ts.map