/**
 * This is a copy of the cx function from @linaria/core@3.0.0-beta.22.
 * We copy it here to avoid the need to depend on @linaria/core@3.0.0-beta.22 at runtime.
 * https://github.com/callstack/linaria/blob/08ddb916cd944dedb30881fedb997bba185da3a5/packages/core/src/cx.ts
 */
type LinariaClassName = string & {
  __linariaClassName: true;
};
type ClassName<T = string> = T | false | void | null | 0 | '';
interface ICX {
  (...classNames: ClassName<LinariaClassName>[]): LinariaClassName;
  (...classNames: ClassName[]): string;
}
/**
 * Takes a list of class names and filters for truthy ones, joining them into a single class name for convenience.
 * eg.
 * ```js
 *  cx('red', isBig && 'big') // returns 'red big' if `isBig` is true, otherwise returns 'red'
 * ```
 * If space separated atomic styles are provided, they are deduplicated according to the first hashed valued:
 *
 * ```js
 *  cx('atm_a_class1 atm_b_class2', 'atm_a_class3') // returns `atm_a_class3 atm_b_class2`
 * ```
 *
 * @returns the combined, space separated class names that can be applied directly to the class attribute
 */
export declare const cx: ICX;
export {};
//# sourceMappingURL=cx.d.ts.map
