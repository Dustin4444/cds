export {};
//# sourceMappingURL=LogoMark.test.d.ts.map
