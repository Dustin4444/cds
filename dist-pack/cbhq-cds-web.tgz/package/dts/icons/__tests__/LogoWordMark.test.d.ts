export {};
//# sourceMappingURL=LogoWordMark.test.d.ts.map
