export {};
//# sourceMappingURL=SubBrandLogoMark.test.d.ts.map
