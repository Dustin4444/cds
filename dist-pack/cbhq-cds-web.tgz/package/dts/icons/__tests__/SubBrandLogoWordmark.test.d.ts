export {};
//# sourceMappingURL=SubBrandLogoWordmark.test.d.ts.map
