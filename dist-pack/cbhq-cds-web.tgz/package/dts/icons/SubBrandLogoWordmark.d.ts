import React from 'react';
import type { SubBrandLogoWordmarkParams } from '@cbhq/cds-common/hooks/useSubBrandLogo';
export declare const SubBrandLogoWordmark: React.MemoExoticComponent<
  (
    props: Omit<SubBrandLogoWordmarkParams, 'colorScheme'>,
  ) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=SubBrandLogoWordmark.d.ts.map
