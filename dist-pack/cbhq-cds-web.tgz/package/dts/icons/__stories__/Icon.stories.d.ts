/**
 * DO NOT MODIFY
 * Generated from yarn nx run icons:generate-stories
 */
declare const _default: {
    title: string;
    component: import("react").NamedExoticComponent<Omit<import("..").IconProps, "ref"> & import("react").RefAttributes<HTMLElement>>;
};
export default _default;
export declare const IconSheet1: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet2: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet3: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet4: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet5: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet6: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet7: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet8: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet9: () => import("react/jsx-runtime").JSX.Element;
export declare const IconSheet10: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Icon.stories.d.ts.map