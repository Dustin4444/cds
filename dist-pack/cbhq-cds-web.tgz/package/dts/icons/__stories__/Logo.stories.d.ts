declare const _default: {
  title: string;
  component: import('react').MemoExoticComponent<
    ({
      size,
      foreground,
    }: Omit<
      import('@cbhq/cds-common/hooks/useLogo').LogoMarkParams,
      'colorScheme'
    >) => import('react/jsx-runtime').JSX.Element
  >;
};
export default _default;
export declare const LogoSheet: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Logo.stories.d.ts.map
