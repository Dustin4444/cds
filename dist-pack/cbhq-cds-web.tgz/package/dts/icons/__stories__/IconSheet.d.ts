import React from 'react';
type IconSheetProps = {
  startIndex?: number;
  endIndex?: number;
};
export declare const IconSheet: React.NamedExoticComponent<IconSheetProps>;
export {};
//# sourceMappingURL=IconSheet.d.ts.map
