import React from 'react';
import type { SubBrandLogoMarkParams } from '@cbhq/cds-common/hooks/useSubBrandLogo';
export declare const SubBrandLogoMark: React.MemoExoticComponent<
  ({
    type,
    foreground,
  }: Omit<SubBrandLogoMarkParams, 'colorScheme'>) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=SubBrandLogoMark.d.ts.map
