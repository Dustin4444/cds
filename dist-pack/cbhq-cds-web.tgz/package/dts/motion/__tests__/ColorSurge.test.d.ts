export {};
//# sourceMappingURL=ColorSurge.test.d.ts.map
