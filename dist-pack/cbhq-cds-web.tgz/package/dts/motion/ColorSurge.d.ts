import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { HintMotionBaseProps } from './types';
export type ColorSurgeRefBaseProps = {
    play: (background?: ThemeVars.Color) => Promise<void>;
};
export type ColorSurgeBaseProps = HintMotionBaseProps & {
    /**
     * The surge color
     * @default bgPrimary
     */
    background?: ThemeVars.Color;
};
export type ColorSurgeTypes = ColorSurgeBaseProps;
/**
 * Please consult with the motion team in #ask-motion before using this component.
 */
export declare const ColorSurge: React.NamedExoticComponent<HintMotionBaseProps & {
    /**
     * The surge color
     * @default bgPrimary
     */
    background?: ThemeVars.Color;
} & React.RefAttributes<ColorSurgeRefBaseProps>>;
//# sourceMappingURL=ColorSurge.d.ts.map