import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types';
import { type IconProps } from '../icons/Icon';
export type AnimatedCaretBaseProps = SharedProps & {
  rotate: number;
};
export type AnimatedCaretProps = AnimatedCaretBaseProps & Partial<Omit<IconProps, 'name'>>;
export declare const AnimatedCaret: React.NamedExoticComponent<AnimatedCaretProps>;
//# sourceMappingURL=AnimatedCaret.d.ts.map
