import React from 'react';
declare const _default: {
  component: React.NamedExoticComponent<import('../AnimatedCaret').AnimatedCaretProps>;
  title: string;
};
export default _default;
export declare const BasicAnimatedCaret: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=AnimatedCaret.stories.d.ts.map
