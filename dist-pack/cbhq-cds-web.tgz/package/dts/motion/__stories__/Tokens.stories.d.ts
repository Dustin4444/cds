export declare const AnimationTokens: () => import('react/jsx-runtime').JSX.Element;
declare const _default: {
  component: () => import('react/jsx-runtime').JSX.Element;
  title: string;
};
export default _default;
//# sourceMappingURL=Tokens.stories.d.ts.map
