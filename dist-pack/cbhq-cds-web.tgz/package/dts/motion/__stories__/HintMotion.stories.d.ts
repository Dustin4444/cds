declare const _default: {
  title: string;
};
export default _default;
export declare const ColorSurge: () => import('react/jsx-runtime').JSX.Element;
export declare const Pulse: () => import('react/jsx-runtime').JSX.Element;
export declare const Shake: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=HintMotion.stories.d.ts.map
