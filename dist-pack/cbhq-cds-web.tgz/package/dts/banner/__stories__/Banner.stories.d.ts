import React from 'react';
import type { BannerProps } from '../Banner';
export declare const All: () => import("react/jsx-runtime").JSX.Element;
export declare const BannerWithLink: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomMargin: () => import("react/jsx-runtime").JSX.Element;
export declare const BorderRadiusExamples: () => import("react/jsx-runtime").JSX.Element;
export declare const CustomAlignment: () => import("react/jsx-runtime").JSX.Element;
declare const _default: {
    component: React.NamedExoticComponent<Omit<BannerProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
    title: string;
};
export default _default;
//# sourceMappingURL=Banner.stories.d.ts.map