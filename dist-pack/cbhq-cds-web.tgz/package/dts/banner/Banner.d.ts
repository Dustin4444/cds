import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { BannerStyleVariant, BannerVariant, IconName, SharedProps } from '@cbhq/cds-common/types';
import { type HStackDefaultElement, type HStackProps } from '../layout';
import type { ResponsiveProps, StaticStyleProps } from '../styles/styleProps';
import type { StylesAndClassNames } from '../types';
export declare const contentResponsiveConfig: ResponsiveProps<StaticStyleProps>['flexDirection'];
/**
 * Static class names for Banner component parts.
 * Use these selectors to target specific elements with CSS.
 */
export declare const bannerClassNames: {
    /** Persistent outer wrapper around both dismissible and non-dismissible variants. */
    readonly root: "cds-Banner";
    /** Main content container (`HStack`) for banner body. */
    readonly content: "cds-Banner-content";
    /** Start icon wrapper. */
    readonly start: "cds-Banner-start";
    /** Right-side body wrapper containing middle content and actions. */
    readonly body: "cds-Banner-body";
    /** Middle content wrapper containing title/message/label region. */
    readonly middle: "cds-Banner-middle";
    /** Label text element. */
    readonly label: "cds-Banner-label";
    /** Actions row element. */
    readonly actions: "cds-Banner-actions";
    /** Dismiss button wrapper element. */
    readonly dismiss: "cds-Banner-dismiss";
};
export type BannerBaseProps = SharedProps & {
    /** Sets the variant of the banner - which is responsible for foreground and background color assignment */
    variant: BannerVariant;
    /** Name of icon to be shown in the banner */
    startIcon: IconName;
    /** Whether the start icon is active */
    startIconActive?: boolean;
    /** Provide a CDS Link component to be used as a primary action. It will inherit colors depending on the provided variant */
    primaryAction?: React.ReactNode;
    /** Provide a CDS Link component to be used as a secondary action. It will inherit colors depending on the provided tone */
    secondaryAction?: React.ReactNode;
    /** Title of banner. Indicates the intent of this banner */
    title?: React.ReactNode;
    /** Message of banner */
    children?: React.ReactNode;
    /**
     * Determines whether banner can be dismissed or not. Banner is not dismisable when styleVariant is set to global.
     * @default true
     * */
    showDismiss?: boolean;
    /** A callback fired when banner is dismissed */
    onClose?: () => void;
    /** Indicates the max number of lines after which body text will be truncated */
    numberOfLines?: number;
    /** Use for supplemental data */
    label?: React.ReactNode;
    /**
     * Determines the banner style and indicates the suggested positioning for the banner
     * @default 'contextual'
     * */
    styleVariant?: BannerStyleVariant;
    /** Accessibility label for start icon on the banner */
    startIconAccessibilityLabel?: string;
    /** Accessibility label for close button on the banner
     * @default 'close'
     */
    closeAccessibilityLabel?: string;
    /**
     * Determines whether banner has a border or not
     * @default true
     * */
    bordered?: boolean;
    /**
     * Determines banner's border radius
     * @default 400 for contextual, undefined for global and inline
     * */
    borderRadius?: ThemeVars.BorderRadius;
};
export type BannerProps = BannerBaseProps & StylesAndClassNames<typeof bannerClassNames> & Omit<HStackProps<HStackDefaultElement>, 'children' | 'title'>;
export declare const Banner: React.NamedExoticComponent<Omit<BannerProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=Banner.d.ts.map