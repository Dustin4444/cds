import React from 'react';
import type { ThemeVars } from '@cbhq/cds-common/core/theme';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
export type MaterialSpinnerProp = {
  /** Size of the spinner */
  size: number;
  /** Color of the spinner */
  color: ThemeVars.Color;
} & SharedProps;
/**
 * @deprecated Use Spinner component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v7
 */
export declare const MaterialSpinner: React.MemoExoticComponent<
  ({ size, color, testID }: MaterialSpinnerProp) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=MaterialSpinner.d.ts.map
