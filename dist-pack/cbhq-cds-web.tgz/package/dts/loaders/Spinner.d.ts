import React from 'react';
import { type BoxDefaultElement, type BoxProps } from '../layout/Box';
export type SpinnerBaseProps = {
    /**
     * The font size of the spinner in pixels - used to calculate the width, height, and borderWidth.
     * Width and height are 10em while borderWidth is 1.1em.
     */
    size: number;
};
export type SpinnerProps = SpinnerBaseProps & BoxProps<BoxDefaultElement>;
/**
 * @deprecated Use indeterminate ProgressCircle component instead. This will be removed in a future major release.
 * @deprecationExpectedRemoval v10
 */
export declare const Spinner: React.MemoExoticComponent<({ color, size, style, className, accessibilityLabel, testID, ...props }: SpinnerProps) => import("react/jsx-runtime").JSX.Element>;
//# sourceMappingURL=Spinner.d.ts.map