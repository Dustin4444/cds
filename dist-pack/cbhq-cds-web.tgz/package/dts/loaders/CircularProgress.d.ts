import React from 'react';
import type { SharedProps } from '@cbhq/cds-common/types/SharedProps';
export type CircularProgressProps = {
  /** Radius of circular progress */
  radius: number;
  /** Stroke width of circular progress */
  strokeWidth: number;
  /**
   * For determinate variant, you can specify the exact moment to pause the circular progress at
   */
  progress: number;
  /**
   *  A boolean flag indicating whether the circular progress is
   *  in indeterminate or determinate states.
   *  Indeterminate (true) - indicators visualize an unspecified wait time
   *  Determinate (false) - indicators display how long an operation will take.
   *  @default true
   */
  indeterminate?: boolean;
} & SharedProps;
export declare const CircularProgress: React.MemoExoticComponent<
  ({
    radius,
    strokeWidth,
    progress,
    indeterminate,
    testID,
  }: CircularProgressProps) => import('react/jsx-runtime').JSX.Element
>;
//# sourceMappingURL=CircularProgress.d.ts.map
