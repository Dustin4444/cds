export {};
//# sourceMappingURL=MaterialSpinner.test.d.ts.map
