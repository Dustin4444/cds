import React from 'react';
declare const _default: {
  component: React.MemoExoticComponent<
    ({
      color,
      size,
      style,
      className,
      accessibilityLabel,
      testID,
      ...props
    }: import('..').SpinnerProps) => import('react/jsx-runtime').JSX.Element
  >;
  title: string;
};
export default _default;
export declare const SpinnerDefault: () => import('react/jsx-runtime').JSX.Element;
export declare const SpinnerPrimary: () => import('react/jsx-runtime').JSX.Element;
export declare const SpinnerWithAccessibility: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=Spinner.stories.d.ts.map
