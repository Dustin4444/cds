import React from 'react';
declare const _default: {
  component: React.MemoExoticComponent<
    ({
      radius,
      strokeWidth,
      progress,
      indeterminate,
      testID,
    }: import('../CircularProgress').CircularProgressProps) => import('react/jsx-runtime').JSX.Element
  >;
  title: string;
};
export default _default;
export declare const Determinate: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=CircularProgress.stories.d.ts.map
