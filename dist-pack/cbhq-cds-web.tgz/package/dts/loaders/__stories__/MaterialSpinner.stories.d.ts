import React from 'react';
declare const _default: {
  component: React.MemoExoticComponent<
    ({
      size,
      color,
      testID,
    }: import('../MaterialSpinner').MaterialSpinnerProp) => import('react/jsx-runtime').JSX.Element
  >;
  title: string;
};
export default _default;
export declare const MaterialSpinnerDefault: () => import('react/jsx-runtime').JSX.Element;
//# sourceMappingURL=MaterialSpinner.stories.d.ts.map
