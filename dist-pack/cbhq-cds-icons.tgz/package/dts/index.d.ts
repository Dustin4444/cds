export * from './descriptionMap';
export * from './glyphMap';
export * from './IconName';
export * from './names';
//# sourceMappingURL=index.d.ts.map
